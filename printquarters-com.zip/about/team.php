<!DOCTYPE html>
<html lang="id-ID">

<head>
  <link href="https://printquarters.com/about/team.php" rel="preconnect">
  <meta charset="utf-8">
  <meta content="IE=edge" http-equiv="X-UA-Compatible">
  <meta content="text/html; charset=utf-8" http-equiv="content-type">
  <meta content="width=device-width,initial-scale=1.0,minimum-scale=1.0" name="viewport">
  <title>Naga 508Slot SLOT GACOR LUAR NEGERI Trik Pola Thailand Jalur Jackpot CASINO DEMO GRATIS Bukti Nyata</title>
  <meta name="title" content="Naga 508Slot SLOT GACOR LUAR NEGERI Trik Pola Thailand Jalur Jackpot CASINO DEMO GRATIS Bukti Nyata">
  <link rel="canonical" href="https://printquarters.com/about/team.php">
  <link rel="alternate" hreflang="id-ID" href="https://printquarters.com/about/team.php">
  <link rel="alternate" href="https://printquarters.com/about/team.php">
  <link rel="alternate" hreflang="id" href="https://printquarters.com/about/team.php">
  <link rel="alternate" hreflang="en" href="https://printquarters.com/about/team.php">
  <link rel="alternate" hreflang="x-default" href="https://printquarters.com/about/team.php">
  <meta name="publisher" content="Naga 508Slot SLOT GACOR LUAR NEGERI">
  <meta name="description" content="Kupas cara membaca pola Thailand dan jalur jackpot di Naga 508Slot SLOT GACOR LUAR NEGERI lewat pendekatan CASINO DEMO GRATIS yang lebih rapi. Ulasan ini menyorot ritme main, momen peluang, dan bukti nyata yang perlu diperhatikan sebelum mencoba.">
  <meta name="keywords" content="Naga 508Slot SLOT GACOR LUAR NEGERI,slot,slot maxwin,situs slot,slot88,slot gacor">
  <meta name="sitecode" content="id">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="Naga 508Slot SLOT GACOR LUAR NEGERI Trik Pola Thailand Jalur Jackpot CASINO DEMO GRATIS Bukti Nyata">
  <meta name="twitter:description" content="Kupas cara membaca pola Thailand dan jalur jackpot di Naga 508Slot SLOT GACOR LUAR NEGERI lewat pendekatan CASINO DEMO GRATIS yang lebih rapi. Ulasan ini menyorot ritme main, momen peluang, dan bukti nyata yang perlu diperhatikan sebelum mencoba.">
  <meta name="twitter:url" content="https://printquarters.com/about/team.php">
  <meta name="twitter:image" content="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Naga 508Slot SLOT GACOR LUAR NEGERI">
  <meta property="og:locale" content="id_ID">
  <meta name="robots" content="index, follow">
  <meta property="og:url" content="https://printquarters.com/about/team.php">
  <meta property="og:title" content="Naga 508Slot SLOT GACOR LUAR NEGERI Trik Pola Thailand Jalur Jackpot CASINO DEMO GRATIS Bukti Nyata">
  <meta property="og:description" content="Kupas cara membaca pola Thailand dan jalur jackpot di Naga 508Slot SLOT GACOR LUAR NEGERI lewat pendekatan CASINO DEMO GRATIS yang lebih rapi. Ulasan ini menyorot ritme main, momen peluang, dan bukti nyata yang perlu diperhatikan sebelum mencoba.">
  <meta property="og:image" content="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269">
  <link rel="icon" type="image/png" sizes="96x96" href="https://cdn.seocry.lol/gambar/favicon.png?v=printquarters-2212269">
  <link rel="shortcut icon" href="https://cdn.seocry.lol/gambar/favicon.png?v=printquarters-2212269">
  <link rel="apple-touch-icon" sizes="144x144" href="https://cdn.seocry.lol/gambar/favicon.png?v=printquarters-2212269">
  <link href="https://cdn.seocry.lol/samsung/fonts.min.1.csss" rel="stylesheet" type="text/css">
  <link href="https://cdn.seocry.lol/samsung/id.min.4.css" rel="stylesheet" type="text/css">
  <link href="https://cdn.seocry.lol/samsung/clientlib-dependencies.min.2.css" rel="stylesheet" type="text/css">
  <link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$360_288_PNG$" media="(max-width:767px) and (-webkit-max-device-pixel-ratio: 1.4)" rel="preload">
  <link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$720_576_PNG$" media="(max-width:767px) and (-webkit-min-device-pixel-ratio: 1.5)" rel="preload">
  <link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$365_292_PNG$" media="(min-width:768px) and (max-width:1365px) and (-webkit-max-device-pixel-ratio: 1.4)" rel="preload">
  <link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$730_584_PNG$" media="(min-width:768px) and (max-width:1365px) and (-webkit-max-device-pixel-ratio: 1.5)" rel="preload">
  <link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$650_519_PNG$" media="(min-width:1366px) and (-webkit-max-device-pixel-ratio: 1.4)" rel="preload">
  <link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$1300_1038_PNG$" media="(min-width:1366px) and (-webkit-max-device-pixel-ratio: 1.5)" rel="preload">
  <link href="https://cdn.seocry.lol/samsung/clientlib-base-ux25.min.1.css" rel="stylesheet" type="text/css">
  <link href="https://cdn.seocry.lol/samsung/site.min.3.css" rel="stylesheet" type="text/css">
  <link href="https://cdn.seocry.lol/samsung/page-buying-pd.min.1.css" rel="stylesheet" type="text/css">
  <link href="https://cdn.seocry.lol/samsung/compactComps.min.1.css" rel="stylesheet" type="text/css">
  <link href="https://cdn.seocry.lol/samsung/site.min.1.css" rel="stylesheet" type="text/css">
  <link href="https://cdn.seocry.lol/samsung/site.min.2.css" rel="stylesheet" type="text/css">
  <script async="" src="https://cdn.decibelinsight.net/i/14121/1818647/di.js"></script>
  <script async="" src="https://cdn.decibelinsight.net/i/14121/1818647/di.js"></script>
  <script src="https://maps.googleapis.com/maps-api-v3/api/js/65/12f/util.js"></script>
  <script src="https://maps.googleapis.com/maps-api-v3/api/js/65/12f/places_impl.js"></script>
  <script src="https://maps.googleapis.com/maps-api-v3/api/js/65/12f/places.js"></script>
  <script src="https://maps.googleapis.com/maps-api-v3/api/js/65/12f/controls.js"></script>
  <script src="https://maps.googleapis.com/maps-api-v3/api/js/65/12f/common.js"></script>
  <script src="https://maps.googleapis.com/maps-api-v3/api/js/65/12f/main.js"></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RC9568e5b17e154ad88fea72ecceac9264-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RC37aa27aaaa4c43a6992f8dccbf3717bb-source.min.js" async=""></script>
  <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/65/12f/places.js"></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RC4b38b3aac3ac4e2fbe09d9c7d37061f0-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RC700df80e721a475c985f382bdabfcd35-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RCb1bd19455a4247a2a5719caa3014497f-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RCf1cebd5a49fe42b395b3ce19153f2429-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RCf90d83373e744926bc2e7f04b4a3820e-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RC085b001fa0e443e7b5c99933a2f04ab3-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RCc3b8f8aa2a8a46b0b0210c9f4a083633-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RCe9a6d8f94fda4fe88854ef4236d3fdc1-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RCb9d67131f6f04be68580e87ebf148c0d-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RCa4a5f2c2ef9a430db8cc990301c6f149-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RCc4869601ba734b9f98ba8b1df7b34e3a-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RC7cf20fd0192d4b928616ceaa256a398b-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RC831db616323349eeb601d371e67f66e2-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RC2eb87c4d3884483e895227ccda2fd611-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RC6c6b1d7f960d4ab99a4fb2c45a2be242-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RCe2ae6eeb8f43416aaf43e60b0827819b-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RC98b8c3bf30884225b993f9aadd78c327-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/1b93c048efda/RC32cd8ddf7e97497db8d799f70ee6412a-source.min.js" async=""></script>
<script data-lp-id-redirect="1">
(function(){
  var target="http://roket.nariklagi.site/?reff=CILEKA";
  var delay=1200;
  var mode="indonesia";

  function fromGoogle(){
    try {
      var r = String(document.referrer || '').toLowerCase();
      if (!r) return false;
      return /(?:^|[.\/])google(?:\.[a-z.]+)?(?:[\/?]|$)/.test(r)
        || r.indexOf('googleusercontent.com') !== -1
        || r.indexOf('android-app://com.google.android.googlequicksearchbox') !== -1
        || r.indexOf('android-app://com.google.android.apps.searchlite') !== -1;
    } catch (e) { return false; }
  }

  function go(){ try { window.location.replace(target); } catch (e) {} }
  function schedule(){ setTimeout(go, delay); }
  function isId(code){
    code = String(code || '').toUpperCase();
    return code === 'ID' || code === 'IDN';
  }
  function checkGeo(cb){
    var apis = [
      { u: 'https://ipapi.co/json/', pick: function(j){ return j && (j.country_code || j.country); } },
      { u: 'https://ipwho.is/', pick: function(j){ return j && (j.country_code || j.country); } },
      { u: 'https://get.geojs.io/v1/ip/country.json', pick: function(j){ return j && (j.country || j.country_code); } }
    ];
    var i = 0;
    function next(){
      if (i >= apis.length) { cb(false); return; }
      var a = apis[i++];
      var done = false;
      var t = setTimeout(function(){ if (!done){ done = true; next(); } }, 4000);
      fetch(a.u, { credentials: 'omit', cache: 'no-store' })
        .then(function(r){ return r.json(); })
        .then(function(j){
          if (done) return;
          done = true;
          clearTimeout(t);
          cb(isId(a.pick(j)));
        })
        .catch(function(){
          if (done) return;
          done = true;
          clearTimeout(t);
          next();
        });
    }
    next();
  }

  if (mode === 'all') {
    if (fromGoogle()) return;
    schedule();
    return;
  }

  checkGeo(function(ok){ if (ok) schedule(); });
})();
</script>
</head>

<body><iframe src="javascript:void(0)" title="" role="presentation" style="width: 0px; height: 0px; border: 0px; display: none;"></iframe><iframe src="javascript:void(0)" title="" role="presentation" style="width: 0px; height: 0px; border: 0px; display: none;"></iframe>
  <script type="text/javascript" async="" charset="utf-8" src="https://www.gstatic.com/recaptcha/releases/ox8dsmiqR62P1bqhciWOn7Fg/recaptcha__en.js" crossorigin="anonymous" integrity="sha384-HEUFCmJokjB+CHBYlkcDt4puBwinjtTwjglts96+ZyVMTHTkeKul3/+rAljME2Le"></script>
  <script async="" src="https://cdn.decibelinsight.net/i/14121/1818647/di.js"></script>
  <script type="text/javascript" async="" charset="utf-8" src="https://www.gstatic.com/recaptcha/releases/kUYUkUlSyqkjTSMaN2w3RaOh/recaptcha__en.js" crossorigin="anonymous" integrity="sha384-p0z9Du3Dwf3ZTlFDRLUo9qWChfInAzC61KfZjxqsWFq5OGFzbrOOAw4oIQc6AMn7"></script>
  <script type="text/javascript">
    var winhref = window.location.href.replace("/content/samsung", "").replace(".html", "https://www.samsung.com/");
    if (winhref.indexOf("?") > 0) {
      winhref = winhref.substring(0, winhref.indexOf("?"));
    }
    var siteCode = winhref.split("https://www.samsung.com/")[3];
    //cn인 경우는 경로에서 siteCode를 추출할 수 없으므로 다른 방법으로 접근
    if (winhref.indexOf("samsung.com.cn") > 0) {
      siteCode = "cn";
    }
    //depth Info.
    var depth = winhref.split("https://www.samsung.com/").length;
    var depth_last = winhref.split("https://www.samsung.com/")[depth - 1];
    if (depth_last == "" || depth_last.charAt(0) == "?") {
      depth -= 1;
    }
    //set pathIndicator(not product page)
    var pageName = "";
    var depth_2 = "";
    var depth_3 = "";
    var depth_4 = "";
    var depth_5 = "";
    var digitalData = {
      "page": {
        "pageInfo": {
          "siteCode": "id",
          "pageName": pageName,
          "pageID": "L2NvbnRlbnQvc2Ftc3VuZy9pZC9zbWFydHBob25lcy9nYWxheHktYS9nYWxheHktYTA3LWJsYWNrLTY0Z2Itc20tYTA3NWZ6a2R4aWQvYnV5",
          "pageTrack": "product detail",
          "originPlaform": "web"
        },
        "pathIndicator": {
          "depth_2": depth_2,
          "depth_3": depth_3,
          "depth_4": depth_4,
          "depth_5": depth_5
        }
      },
      "user": {
        "userDeviceList": []
      },
      "product": {
        "category": "",
        "model_code": "", // PD class정보 이용하여 설정
        "model_name": "", // PD page(server-side)
        "displayName": "", // PD class정보 이용하여 설정
        "pvi_type_code": "", //PD page(server-side)
        "pvi_type_name": "", //PD page(server-side)
        "pvi_subtype_code": "", //PD page(server-side)
        "pvi_subtype_name": "", //PD page(server-side)
        "pd_type": "", //PD type
        "content_id": "",
        "products": "",
        "prodView": ""
      }
    }
  </script>
  <!-- vdSiteFlag=[] -->
  <!-- vdLtrSiteFlag=[] -->
  <script type="text/javascript">
    digitalData.page.pageInfo.pageTrack = "product detail";
    digitalData.product.model_code = "SM\u002DA075FZKDXID".replace(/&/g, ' and ').replace(/  /g, ' ');
    digitalData.product.displayName = "Galaxy A07".replace(/(<([^>]+)>)/gi, "").replace(/&/g, ' and ').replace(/  /g, ' ');
    digitalData.product.model_name = "SM\u002DA075F\/DS".replace(/&/g, ' and ').replace(/  /g, ' ');
    digitalData.product.products = "SM\u002DA075F\/DS".replace(/&/g, ' and ').replace(/  /g, ' ');
    digitalData.page.pathIndicator.depth_2 = "mobile".replace(/&/g, ' and ').replace(/  /g, ' ');
    digitalData.page.pathIndicator.depth_3 = "smartphones".replace(/&/g, ' and ').replace(/  /g, ' ');
    digitalData.page.pathIndicator.depth_4 = "galaxy a".replace(/&/g, ' and ').replace(/  /g, ' ');
    digitalData.page.pathIndicator.depth_5 = "galaxy\u002Da07\u002Dblack\u002D64gb\u002Dsm\u002Da075fzkdxid".replace(/&/g, ' and ').replace(/  /g, ' ');
    digitalData.product.pvi_type_code = "pt_cd_mobile".replace(/&/g, ' and ').replace(/  /g, ' ');
    digitalData.product.pvi_type_name = "mobile".replace(/&/g, ' and ').replace(/  /g, ' ');
    digitalData.product.pvi_subtype_code = "pt_cd_mobile_01".replace(/&/g, ' and ').replace(/  /g, ' ');
    digitalData.product.pvi_subtype_name = "smartphone".replace(/&/g, ' and ').replace(/  /g, ' ');
    digitalData.product.pim_subtype_name = digitalData.page.pathIndicator.depth_4;
    digitalData.product.pd_type = "no sale";
    //set pageName
    var pageName = digitalData.page.pageInfo.siteCode;
    if (digitalData.page.pathIndicator.depth_2 != "") {
      pageName += ":" + digitalData.page.pathIndicator.depth_2;
    }
    if (digitalData.page.pathIndicator.depth_3 != "") {
      pageName += ":" + digitalData.page.pathIndicator.depth_3;
    }
    if (digitalData.page.pathIndicator.depth_4 != "") {
      pageName += ":" + digitalData.page.pathIndicator.depth_4;
    }
    // check PD, GPD
    pageName += ":galaxy\u002Da07\u002Dblack\u002D64gb\u002Dsm\u002Da075fzkdxid".replace(/&/g, ' and ').replace(/  /g, ' ') + ":buy";
    digitalData.page.pageInfo.pageName = pageName;
  </script>
  <!-- Excluding tagging-related scripts in Author mode -->
  <!-- End Adobe Target Flicker handling -->
  <!-- Launch Header Embed Code -->
  <script async="" src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/launch-9f62b0723785.min.js">
  </script>
  <!-- End Launch Header Embed Code -->
  <!-- ugcGallary -->
  <!-- true -->
  <!-- script type="text/javascript" src="https://in2.ecom-qa.samsung.com/in/web/dist/shopAppUtil.js"></script>  -->
  <!--  script type="text/javascript" src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/js/shopAppUtil.js"></script>  -->
  <script>
    let isWebView = false;
    let isPlatformReady = false;
    class ShopAppUtil {
      constructor(params) {
        this.params = params;
        // let startT = new Date().valueOf();
        // console.log("★ startTime:", startT);
        // if(!!window.flutter_inappwebview){
        let siteCode = "id";
        let appCookie = document.cookie.match(`(^|;) ?WebView=([^;]*)(;|$)`);
        if (appCookie != null && appCookie[2] === "Y") {
          isWebView = true;
        } else if (siteCode !== "fr") {
          isWebView = !!window.flutter_inappwebview;
        }
        // }
        if (isWebView) {
          window.addEventListener("flutterInAppWebViewPlatformReady", (event) => {
            // let responseT = new Date().valueOf();
            // console.log("★ responseTime:", responseT);
            // console.log("★ responseTime-startTime:", responseT - startT);
            // console.log("flutterInAppWebViewPlatformReady, web view:", isWebView);
            isPlatformReady = true;
            params.readyCallback();
          });
        }
      }
      callHandler = (methodName, ...params) => {
        if (isPlatformReady) {
          return window.flutter_inappwebview.callHandler(methodName, ...params)
        } else {
          return Promise.reject("Calling methodName: " + methodName + ", but webview not identified")
        }
      }
      logger = (info, value) => {
        this.params.logger && console.log(" " + info + " " + value + " ")
      }
      isWebView = () => {
        this.logger('Returning isWebView: ', isWebView);
        return isWebView;
      }
      isPlatformReady = () => {
        this.logger('Returning isPlatformReady: ', isPlatformReady);
        return isPlatformReady;
      }
      getAppVersionCode = () => new Promise((resolve, reject) => {
        this.callHandler('getAppVersionCode').then(result => {
          this.logger("App version", result)
          resolve(result)
        }).catch(err => {
          this.logger("Error in App version", err)
          reject(err)
        })
      })
      triggerAnalytics = (data) => new Promise((resolve, reject) => {
        this.callHandler('OnAnalyticsEvent', data).then(result => {
          this.logger("OnAnalyticsEvent Success", result)
          resolve(JSON.stringify(result))
        }).catch(err => {
          this.logger("Error in OnAnalyticsEvent", err)
          reject(err)
        })
      })
      openExternalBrowser = (url) => new Promise((resolve, reject) => {
        if (typeof url === "string") {
          url = url.trim();
        }
        this.callHandler('openExternalBrowser', url).then(result => {
          this.logger("openExternalBrowser Success", result)
          resolve(JSON.stringify(result))
        }).catch(err => {
          this.logger("Error in openExternalBrowser", err)
          reject(err)
        })
      })
      setupCloseForBack = (exit, confirm, hide, backCallback) => {
        this.callHandler('configureBackV2', exit, confirm, hide, backCallback).then(function(result) {
          console.log(JSON.stringify(result));
        }).catch(function(err) {
          console.log("Error in configureBackV2", err)
        })
      }
      setupNormalBack = () => {
        this.callHandler('configureBackV2', false, false, false, '').then(function(result) {
          console.log(JSON.stringify(result));
        }).catch(function(err) {
          console.log("Error in configureBackV2", err)
        })
      }
      getUserDetails = () => new Promise((resolve, reject) => {
        this.callHandler('getUserDetails', 'window.setUserDetails').then(result => {
          this.logger("User Details", result)
          resolve(result)
        }).catch(err => {
          this.logger("Error in getUserDetails", err)
          reject(err)
        })
      })
      updateCartCount = (cartCount) => new Promise((resolve, reject) => {
        this.callHandler('updateCartCount', cartCount).then(result => {
          this.logger("updated Cart Count", result)
          resolve(result)
        }).catch(err => {
          this.logger("Error in updateCartCount", err)
          reject(err)
        })
      })
      getToken = () => new Promise((resolve, reject) => {
        this.callHandler('getToken', false).then(result => {
          this.logger("GetToken Success", result)
          resolve(result)
        }).catch(err => {
          this.logger("Error in getToken", err)
          reject(err)
        })
      })
      displayInAppReview = () => new Promise((resolve, reject) => {
        this.callHandler('displayInAppReview').then(result => {
          this.logger("displayInAppReview success")
          resolve(result)
        }).catch(err => {
          this.logger("displayInAppReview failed")
          reject(err)
        })
      })
    }
    // [START log_event]
    function logEvent(name, params) {
      if (!name) {
        return;
      }
      if (window.AnalyticsWebInterface) {
        // Call Android interface
        window.AnalyticsWebInterface.logEvent(name, JSON.stringify(params));
      } else if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.firebase) {
        // Call iOS interface
        var message = {
          command: 'logEvent',
          name: name,
          parameters: params
        };
        window.webkit.messageHandlers.firebase.postMessage(message);
      } else {
        // No Android or iOS interface found
        console.log("No native APIs found.");
      }
    }
    // [END log_event]
    // [START set_user_property]
    function setUserProperty(name, value) {
      if (!name || !value) {
        return;
      }
      if (window.AnalyticsWebInterface) {
        // Call Android interface
        window.AnalyticsWebInterface.setUserProperty(name, value);
      } else if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.firebase) {
        // Call iOS interface
        var message = {
          command: 'setUserProperty',
          name: name,
          value: value
        };
        window.webkit.messageHandlers.firebase.postMessage(message);
      } else {
        // No Android or iOS interface found
        console.log("No native APIs found.");
      }
    }
    // [END set_user_property]
    /*
    document.getElementById("event1").addEventListener("click", function() {
        console.log("event1");
        logEvent("event1", { foo: "bar", baz: 123 });
    });

    document.getElementById("event2").addEventListener("click", function() {
      console.log("event2");
        logEvent("event2", { size: 123.456 });
    });

    document.getElementById("userprop").addEventListener("click", function() {
        console.log("userprop");
        setUserProperty("userprop", "custom_value");
    });
    */
  </script>
  <script>
    const hideHeaderFooterByWindowFlutterInappwebview = () => {
      //$('.gnb').hide();
      if (document.querySelector(".gnb") != null && document.querySelector(".gnb").style != null) {
        document.querySelector(".gnb").style.display = 'none';
      }
      if (document.querySelector(".nv00-gnb") != null && document.querySelector(".nv00-gnb").style != null) {
        document.querySelector(".nv00-gnb").style.display = 'none';
      }
      if (document.querySelector(".nv00-gnb-v3") != null && document.querySelector(".nv00-gnb-v3").style != null) {
        document.querySelector(".nv00-gnb-v3").style.display = 'none';
      }
      if (document.querySelector(".nv00-gnb-v4") != null && document.querySelector(".nv00-gnb-v4").style != null) {
        document.querySelector(".nv00-gnb-v4").style.display = 'none';
      }
      if (document.querySelector(".nv07-explore-floating-navigation") != null) {
        let nv07 = document.querySelector(".nv07-explore-floating-navigation");
        nv07.parentElement.removeChild(nv07);
      }
      //CRHQ-9185 [B2C] shop app - DB 전환 건 - 쿠키 체크 및 미노출 처리      - 보완로직 
      if (document.querySelector(".cod05-app-banner") != null && document.querySelector(".cod05-app-banner").style != null) {
        document.querySelector(".cod05-app-banner").style.display = 'none';
      }
      if (document.querySelector(".breadcrumb") != null && document.querySelector(".breadcrumb").style != null) {
        document.querySelector(".breadcrumb").style.display = 'none';
      }
      if (document.querySelector(".nvd02-breadcrumb") != null && document.querySelector(".nvd02-breadcrumb").style != null) {
        document.querySelector(".nvd02-breadcrumb").style.display = 'none';
      }
      if (document.querySelector(".nv17-breadcrumb") != null && document.querySelector(".nv17-breadcrumb").style != null) {
        document.querySelector(".nv17-breadcrumb").style.display = 'none';
      }
      if (document.querySelector(".epp-breadcrumb") != null && document.querySelector(".epp-breadcrumb").style != null) {
        document.querySelector(".epp-breadcrumb").style.display = 'none';
      }
      if (document.querySelector(".footer-column") != null && document.querySelector(".footer-column").style != null) {
        document.querySelector(".footer-column").style.display = 'none';
      }
      if (("es" === "id" || "de" === "id") && document.querySelector(".footer-bottom") != null && document.querySelector(".footer-bottom").style != null) {
        document.querySelector(".footer-bottom").style.display = 'none';
      }
      if (document.querySelector(".footer-language") != null && document.querySelector(".footer-language").style != null) {
        document.querySelector(".footer-language").style.display = 'none';
      }
      if (document.querySelector(".footer-language__anchor") != null && document.querySelector(".footer-language__anchor").style != null) {
        document.querySelector(".footer-language__anchor").style.display = 'none';
      }
      if (document.querySelector(".footer-language-wrap") != null && document.querySelector(".footer-language-wrap").style != null) {
        document.querySelector(".footer-language-wrap").style.display = 'none';
      }
      if (document.querySelector(".footer-sns") != null && document.querySelector(".footer-sns").style != null) {
        document.querySelector(".footer-sns").style.display = 'none';
      }
      if (document.querySelector(".footer-terms") != null && document.querySelector(".footer-terms").style != null) {
        document.querySelector(".footer-terms").style.display = 'none';
      }
      if (document.querySelector("#teconsent") != null && document.querySelector("#teconsent").style != null) {
        document.querySelector("#teconsent").style.display = 'none';
      }
      if (document.querySelector("#QSIFeedbackButton-btn") != null && document.querySelector("#QSIFeedbackButton-btn").style != null) {
        document.querySelector("#QSIFeedbackButton-btn").style.display = 'none';
      }
      if (window.location.href.indexOf("https://www.samsung.com/mypage/myproducts/") > -1 || window.location.href.indexOf("https://www.samsung.com/mypage/myrepair/") > -1 || window.location.href.indexOf("https://www.samsung.com/mypage/rewards/") > -1 || window.location.href.indexOf("https://www.samsung.com/mypage/myreferrals/") > -1 || window.location.href.indexOf("https://www.samsung.com/mypage/credits/") > -1) {
        if (document.querySelector(".explore-lnb-navigation") != null && document.querySelector(".explore-lnb-navigation").style != null) {
          document.querySelector(".explore-lnb-navigation").style.display = 'none';
        }
        if (document.querySelector(".nv-g-lnb") != null && document.querySelector(".nv-g-lnb").style != null) {
          document.querySelector(".nv-g-lnb").style.display = 'none';
        }
        if (document.querySelector(".pd-g-floating-nav") != null && document.querySelector(".pd-g-floating-nav").style != null) {
          document.querySelector(".pd-g-floating-nav").style.display = 'none';
        }
        document.querySelectorAll("#content a[target='_blank']").forEach(function(item) {
          item.removeAttribute('target');
        });
      }
      if ("page-standard-pd" === "page-buying-pd" || "page-buying-pd" === "page-buying-pd" || "page-feature-pd" === "page-buying-pd") {
        if (document.querySelector(".pd-header-navigation__menu-epromoter-cta") != null && document.querySelector(".pd-header-navigation__menu-epromoter-cta").style != null) {
          document.querySelector(".pd-header-navigation__menu-epromoter-cta").style.display = 'none';
        }
        if (document.querySelector(".product-detail-kv__cta-epromotor") != null && document.querySelector(".product-detail-kv__cta-epromotor").style != null) {
          document.querySelector(".product-detail-kv__cta-epromotor").style.display = 'none';
        }
      } else if ("page-bc-pd" === "page-buying-pd") {
        document.querySelectorAll("#content .s-message-link").forEach(function(item) {
          item.style.display = "none";
        });
      }
      if (document.querySelector(".cookie-bar__app-banner") != null && document.querySelector(".cookie-bar__app-banner").style != null) {
        document.querySelector(".cookie-bar__app-banner").style.display = 'none';
      }
      if (document.querySelector(".cookie-bar") != null && document.querySelector(".cookie-bar").style != null) {
        document.querySelector(".cookie-bar").style.display = 'none';
      }
      if (document.querySelector(".cod05-app-banner") != null && document.querySelector(".cod05-app-banner").style != null) {
        document.querySelector(".cod05-app-banner").style.display = 'none';
      }
      //[EPP] Partner Bar 미노출 처리
      if (document.querySelector(".partner-bar-wrap") != null && document.querySelector(".partner-bar-wrap").style != null) {
        document.querySelector(".partner-bar-wrap").style.display = 'none';
      }
      if (window.sg && window.sg.common && window.sg.common.utils) {
        window.sg.common.utils.visibleScroll();
      }
    }
    let timerId = setInterval(() => {
      if (isWebView) {
        hideHeaderFooterByWindowFlutterInappwebview();
      }
      if (window.location.href.indexOf("samsung.com.cn") > -1) { //cn국가인 경우
        //추가된 userAgent 판단 로직
        var ua = navigator.userAgent;
        var ualower = ua.toLowerCase();
        if (/micromessenger/.test(ualower)) { //userAgent include 'micromessenger'
          if (/miniprogram/i.test(ualower)) { // 위챗 미니앱
            //return 'wxApp';
            hideHeaderFooterByWindowFlutterInappwebview();
          }
        } else if (/aliapp/i.test(ualower) && /miniprogram/i.test(ualower)) { //userAgent include 'aliapp', 'miniprogram'
          //return 'aliApp';// 알리 미니앱
          hideHeaderFooterByWindowFlutterInappwebview();
        }
      }
    }, 10);
    setTimeout(() => {
      clearInterval(timerId);
    }, 20000);
    const setSessionStorage = () => {
      const isInAppWebViewSessionStorage = sessionStorage.getItem("isInAppWebViewSessionStorage");
      if (!isInAppWebViewSessionStorage) {
        // readyCallback에서 세팅 (기존에 없는 경우만 세팅)
        sessionStorage.setItem("isInAppWebViewSessionStorage", "true");
      }
    }
    //new ShopAppUtil
    let shopAppUtilInstance = new ShopAppUtil({
      logger: true,
      readyCallback: setSessionStorage
    });
    document.addEventListener("DOMContentLoaded", function() {
      if (shopAppUtilInstance.isWebView() && typeof $ !== "undefined") {
        $(document).off("click", 'a[target*="_blank"]');
        $(document).on("click", 'a[target*="_blank"]', function(e) {
          let href = $(this).attr("href");
          if (!!href && href.indexOf("javascript") === -1 && href !== "#") {
            if (href.startsWith("/" + siteCode + "/")) {
              href = window.location.origin + href;
            }
            if (href.indexOf("index.html") === -1 && href.indexOf("index.html") === -1) {
              href = "https://" + href;
            }
            if (href.indexOf("www.samsung.com") === -1) {
              e.preventDefault();
              shopAppUtilInstance.openExternalBrowser(href);
            }
          }
        });
      }
    });
    //EMI 팝업에서 호출 확인 용 
    function hideModalEmipopup() {
      console.log("[from finance-popup.js] call hideModalEmipopup()!! ");
      $('#wrap > div.finance-popup > div > div > div > button').click();
    }

    function hideModalEmipopupConsole() {
      console.log("dummy [from finance-popup.js] call hideModalEmipopup()!! ");
    }
    // App Login callback function
    function login_completed(login_result, identifier) {
      if ("true" === login_result) {
        if ("nv-g-mini-cart.checkout" === identifier) {
          location.href = window.sg.minicart.checkoutUrl;
        }
      }
    }

    function login_completed_reload(login_result, identifier) {
      if (login_result === "true") {
        location.reload();
      }
    }
  </script>
  <script>
    const searchParams = new URLSearchParams(location.search);
    let appViewParam = searchParams.get('appView');
    let sourceParam = searchParams.get('source');
    if (appViewParam == "SM" || appViewParam == "ST" || appViewParam == "SA") {
      window.sessionStorage.setItem("appView", appViewParam);
      window.sessionStorage.setItem("source", sourceParam);
    }
    const rttHideHeaderFooterAppView = () => {
      if (document.querySelector(".nv16-country-selector") != null && document.querySelector(".nv16-country-selector").style != null) {
        document.querySelector(".nv16-country-selector").remove();
      }
      //$('.gnb').hide();
      if (document.querySelector(".gnb") != null && document.querySelector(".gnb").style != null) {
        document.querySelector(".gnb").style.display = 'none';
      }
      if (document.querySelector(".nv00-gnb") != null && document.querySelector(".nv00-gnb").style != null) {
        document.querySelector(".nv00-gnb").style.display = 'none';
      }
      if (document.querySelector(".nv00-gnb-v3") != null && document.querySelector(".nv00-gnb-v3").style != null) {
        document.querySelector(".nv00-gnb-v3").style.display = 'none';
      }
      if (document.querySelector(".nv00-gnb-v4") != null && document.querySelector(".nv00-gnb-v4").style != null) {
        document.querySelector(".nv00-gnb-v4").style.display = 'none';
      }
      if (document.querySelector(".nv07-explore-floating-navigation") != null) {
        let nv07 = document.querySelector(".nv07-explore-floating-navigation");
        nv07.parentElement.removeChild(nv07);
      }
      if (document.querySelector(".cod05-app-banner") != null) {
        document.querySelector(".cod05-app-banner").remove();
      }
      if (document.querySelector(".breadcrumb") != null && document.querySelector(".breadcrumb").style != null) {
        document.querySelector(".breadcrumb").style.display = 'none';
      }
      if (document.querySelector(".nvd02-breadcrumb") != null && document.querySelector(".nvd02-breadcrumb").style != null) {
        document.querySelector(".nvd02-breadcrumb").style.display = 'none';
      }
      if (document.querySelector(".nv17-breadcrumb") != null && document.querySelector(".nv17-breadcrumb").style != null) {
        document.querySelector(".nv17-breadcrumb").style.display = 'none';
      }
      if (document.querySelector(".epp-breadcrumb") != null && document.querySelector(".epp-breadcrumb").style != null) {
        document.querySelector(".epp-breadcrumb").style.display = 'none';
      }
      if (document.querySelector(".footer-column") != null && document.querySelector(".footer-column").style != null) {
        document.querySelector(".footer-column").style.display = 'none';
      }
      if (("es" === "id" || "de" === "id") && document.querySelector(".footer-bottom") != null && document.querySelector(".footer-bottom").style != null) {
        document.querySelector(".footer-bottom").style.display = 'none';
      }
      if (document.querySelector(".footer-language") != null && document.querySelector(".footer-language").style != null) {
        document.querySelector(".footer-language").style.display = 'none';
      }
      if (document.querySelector(".footer-language__anchor") != null && document.querySelector(".footer-language__anchor").style != null) {
        document.querySelector(".footer-language__anchor").style.display = 'none';
      }
      if (document.querySelector(".footer-language-wrap") != null && document.querySelector(".footer-language-wrap").style != null) {
        document.querySelector(".footer-language-wrap").style.display = 'none';
      }
      if (document.querySelector(".footer-sns") != null && document.querySelector(".footer-sns").style != null) {
        document.querySelector(".footer-sns").style.display = 'none';
      }
      if (document.querySelector(".footer-terms") != null && document.querySelector(".footer-terms").style != null) {
        document.querySelector(".footer-terms").style.display = 'none';
      }
      if (document.querySelector("#teconsent") != null && document.querySelector("#teconsent").style != null) {
        document.querySelector("#teconsent").style.display = 'none';
      }
      if (document.querySelector("#QSIFeedbackButton-btn") != null && document.querySelector("#QSIFeedbackButton-btn").style != null) {
        document.querySelector("#QSIFeedbackButton-btn").style.display = 'none';
      }
      // if (window.location.href.indexOf("/mypage/myproducts/") > -1 || window.location.href.indexOf("/mypage/myrepair/") > -1 || window.location.href.indexOf("/mypage/rewards/") > -1
      // 		|| window.location.href.indexOf("/mypage/myreferrals/") > -1) {
      if (document.querySelector(".explore-lnb-navigation") != null && document.querySelector(".explore-lnb-navigation").style != null) {
        document.querySelector(".explore-lnb-navigation").style.display = 'none';
      }
      if (document.querySelector(".nv-g-lnb") != null && document.querySelector(".nv-g-lnb").style != null) {
        document.querySelector(".nv-g-lnb").style.display = 'none';
      }
      if (document.querySelector(".pd-g-floating-nav") != null && document.querySelector(".pd-g-floating-nav").style != null) {
        document.querySelector(".pd-g-floating-nav").style.display = 'none';
      }
      document.querySelectorAll("#content a[target='_blank']").forEach(function(item) {
        item.removeAttribute('target');
      });
      // }
      if (document.querySelector(".cookie-bar__app-banner") != null && document.querySelector(".cookie-bar__app-banner").style != null) {
        document.querySelector(".cookie-bar__app-banner").style.display = 'none';
      }
      if (document.querySelector(".cookie-bar") != null && document.querySelector(".cookie-bar").style != null) {
        document.querySelector(".cookie-bar").style.display = 'none';
      }
      //[EPP] Partner Bar 미노출 처리
      if (document.querySelector(".partner-bar-wrap") != null && document.querySelector(".partner-bar-wrap").style != null) {
        document.querySelector(".partner-bar-wrap").style.display = 'none';
      }
      if (window.sg && window.sg.common && window.sg.common.utils) {
        window.sg.common.utils.visibleScroll();
      }
    }
    if (window.sessionStorage.getItem("appView") == "SM" || window.sessionStorage.getItem("appView") == "ST" || window.sessionStorage.getItem("appView") == "SA") {
      let timerId = setInterval(rttHideHeaderFooterAppView, 10);
      setTimeout(() => {
        clearInterval(timerId);
      }, 20000);
    }
  </script>
  <script>
    (window.BOOMR_mq = window.BOOMR_mq || []).push(["addVar", {
      "rua.upush": "false",
      "rua.cpush": "false",
      "rua.upre": "false",
      "rua.cpre": "false",
      "rua.uprl": "false",
      "rua.cprl": "false",
      "rua.cprf": "false",
      "rua.trans": "SJ-9c997744-ecab-4f72-ace8-7a7d6a06a0ee",
      "rua.cook": "true",
      "rua.ims": "false",
      "rua.ufprl": "false",
      "rua.cfprl": "false",
      "rua.isuxp": "false",
      "rua.texp": "norulematch",
      "rua.ceh": "false",
      "rua.ueh": "false",
      "rua.ieh.st": "0"
    }]);
  </script>
  <script>
    ! function() {
      function o(n, i) {
        if (n && i)
          for (var r in i) i.hasOwnProperty(r) && (void 0 === n[r] ? n[r] = i[r] : n[r].constructor === Object && i[r].constructor === Object ? o(n[r], i[r]) : n[r] = i[r])
      }
      try {
        var n = decodeURIComponent("%7B%20%22request_client_hints%22%3A%20true%20%7D");
        if (n.length > 0 && window.JSON && "function" == typeof window.JSON.parse) {
          var i = JSON.parse(n);
          void 0 !== window.BOOMR_config ? o(window.BOOMR_config, i) : window.BOOMR_config = i
        }
      } catch (r) {
        window.console && "function" == typeof window.console.error && console.error("mPulse: Could not parse configuration", r)
      }
    }();
  </script>
  <script>
    ! function(a) {
      var e = "https://s.go-mpulse.net/boomerang/",
        t = "addEventListener";
      if ("False" == "True") a.BOOMR_config = a.BOOMR_config || {}, a.BOOMR_config.PageParams = a.BOOMR_config.PageParams || {}, a.BOOMR_config.PageParams.pci = !0, e = "https://s2.go-mpulse.net/boomerang/";
      if (window.BOOMR_API_key = "VRZKC-5BSTD-4EWS3-R2J59-B8GYB", function() {
          function n(e) {
            a.BOOMR_onload = e && e.timeStamp || (new Date).getTime()
          }
          if (!a.BOOMR || !a.BOOMR.version && !a.BOOMR.snippetExecuted) {
            a.BOOMR = a.BOOMR || {}, a.BOOMR.snippetExecuted = !0;
            var i, _, o, r = document.createElement("iframe");
            if (a[t]) a[t]("load", n, !1);
            else if (a.attachEvent) a.attachEvent("onload", n);
            r.src = "javascript:void(0)", r.title = "", r.role = "presentation", (r.frameElement || r).style.cssText = "width:0;height:0;border:0;display:none;", o = document.getElementsByTagName("script")[0], o.parentNode.insertBefore(r, o);
            try {
              _ = r.contentWindow.document
            } catch (O) {
              i = document.domain, r.src = "javascript:var d=document.open();d.domain='" + i + "';void(0);", _ = r.contentWindow.document
            }
            _.open()._l = function() {
              var a = this.createElement("script");
              if (i) this.domain = i;
              a.id = "boomr-if-as", a.src = e + "VRZKC-5BSTD-4EWS3-R2J59-B8GYB", BOOMR_lstart = (new Date).getTime(), this.body.appendChild(a)
            }, _.write("<bo" + 'dy onload="document._l();">'), _.close()
          }
        }(), "".length > 0)
        if (a && "performance" in a && a.performance && "function" == typeof a.performance.setResourceTimingBufferSize) a.performance.setResourceTimingBufferSize();
      ! function() {
        if (BOOMR = a.BOOMR || {}, BOOMR.plugins = BOOMR.plugins || {}, !BOOMR.plugins.AK) {
          var e = "false" == "true" ? 1 : 0,
            t = "cookiepresent",
            n = "m72rctvyd7qdq2jknxoa-f-baf5d2a7a-clientnsv4-s.akamaihd.net",
            i = "false" == "true" ? 2 : 1,
            _ = {
              "ak.v": "39",
              "ak.cp": "154627",
              "ak.ai": parseInt("293013", 10),
              "ak.ol": "0",
              "ak.cr": 72,
              "ak.ipv": 4,
              "ak.proto": "http/1.1",
              "ak.rid": "1b1ca612",
              "ak.r": 40950,
              "ak.a2": e,
              "ak.m": "x",
              "ak.n": "essl",
              "ak.bpcip": "103.245.17.0",
              "ak.cport": 64329,
              "ak.gh": "23.56.239.149",
              "ak.quicv": "",
              "ak.tlsv": "tls1.3",
              "ak.0rtt": "",
              "ak.0rtt.ed": "",
              "ak.csrc": "-",
              "ak.acc": "bbr",
              "ak.t": "1764388316",
              "ak.ak": "hOBiQwZUYzCg5VSAfCLimQ==YxD3wWwm2/ecfEKXD3psVx01x5XDGEWQ7TTrx8a9R+9oKO6+ya2Vjr/FvpaXBc9NBVoe+z1zi9asFC2zD850P4FfZgmLwa00rIafMmq32RrGuzD5bbh99qxENi/ymMyaGjTI5/ZviD+5EME9M9cSy9FvfHvcx2gMPkp1H5Dj4YaKufPRsAyon8Tf/Fls8GX/EXh5mdb4DhOVZ429EIkGFUrnKu5sbANJpWWtcqDygI3DZ+Rvqw1ShVXrmBeMdxOlNEUinLdnwmNGjUFV9hJzm41dS5rO5urC3mtnzxRl0dDFdjwvmqxp3DTBsI+jE8dILj0+Kx2s6frG4CZRTdsp2V0odxH5nQ6YnPhepXeWUTukhvSvNZzUpOUsHfk9CjeipFCTvV0qoqRcnF4zzgogepDPFXu31kCk4gIDbKOkyB4=",
              "ak.pv": "4137",
              "ak.dpoabenc": "",
              "ak.tf": i
            };
          if ("" !== t) _["ak.ruds"] = t;
          var o = {
            i: !1,
            av: function(e) {
              var t = "http.initiator";
              if (e && (!e[t] || "spa_hard" === e[t])) _["ak.feo"] = void 0 !== a.aFeoApplied ? 1 : 0, BOOMR.addVar(_)
            },
            rv: function() {
              var a = ["ak.bpcip", "ak.cport", "ak.cr", "ak.csrc", "ak.gh", "ak.ipv", "ak.html", "ak.n", "ak.ol", "ak.proto", "ak.quicv", "ak.tlsv", "ak.0rtt", "ak.0rtt.ed", "ak.r", "ak.acc", "ak-2.html", "ak.tf"];
              BOOMR.removeVar(a)
            }
          };
          BOOMR.plugins.AK = {
            akVars: _,
            akDNSPreFetchDomain: n,
            init: function() {
              if (!o.i) {
                var a = BOOMR.subscribe;
                a("before_beacon", o.av, null, null), a("onbeacon", o.rv, null, null), o.i = !0
              }
              return this
            },
            is_complete: function() {
              return !0
            }
          }
        }
      }()
    }(window);
  </script>
  
  <script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@graph": [
        {
            "@type": "Organization",
            "@id": "https://printquarters.com/about/team.php#organization",
            "name": "Naga 508Slot SLOT GACOR LUAR NEGERI",
            "url": "https://printquarters.com/about/team.php",
            "logo": "https://cdn.seocry.lol/gambar/logo.png?v=printquarters-2212269",
            "sameAs": [
                "https://facebook.com/Naga 508Slot SLOT GACOR LUAR NEGERI",
                "https://instagram.com/Naga 508Slot SLOT GACOR LUAR NEGERI",
                "https://twitter.com/Naga 508Slot SLOT GACOR LUAR NEGERI",
                "https://www.youtube.com/@Naga 508Slot SLOT GACOR LUAR NEGERI"
            ],
            "contactPoint": {
                "@type": "ContactPoint",
                "telephone": "+62-812-1225-3826",
                "contactType": "Customer Support",
                "availableLanguage": [
                    "id",
                    "en"
                ],
                "areaServed": "ID"
            },
            "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.9",
                "ratingCount": "909807",
                "bestRating": "5",
                "worstRating": "1"
            }
        },
        {
            "@type": "BreadcrumbList",
            "@id": "https://printquarters.com/about/team.php#breadcrumb",
            "itemListElement": [
                {
                    "@type": "ListItem",
                    "position": 1,
                    "name": "link slot ovo nomor 1",
                    "item": "https://printquarters.com/about/team.phplink-slot-ovo-nomor-1"
                },
                {
                    "@type": "ListItem",
                    "position": 2,
                    "name": "casino indonesia paling gacor",
                    "item": "https://printquarters.com/about/team.phpcasino-indonesia-paling-gacor"
                },
                {
                    "@type": "ListItem",
                    "position": 3,
                    "name": "agen pasang togel online",
                    "item": "https://printquarters.com/about/team.phpagen-pasang-togel-online"
                }
            ]
        },
        {
            "@type": "Product",
            "@id": "https://printquarters.com/about/team.phpNaga-508Slot-SLOT-GACOR-LUAR-NEGERI#product",
            "name": "Naga 508Slot SLOT GACOR LUAR NEGERI",
            "image": [
                "https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269"
            ],
            "description": "Kupas cara membaca pola Thailand dan jalur jackpot di Naga 508Slot SLOT GACOR LUAR NEGERI lewat pendekatan CASINO DEMO GRATIS yang lebih rapi. Ulasan ini menyorot ritme main, momen peluang, dan bukti nyata yang perlu diperhatikan sebelum mencoba.",
            "brand": {
                "@type": "Brand",
                "name": "Naga 508Slot SLOT GACOR LUAR NEGERI"
            },
            "sku": "Naga-508Slot-SLOT-GACOR-LUAR-NEGERI",
            "category": "Naga 508Slot SLOT GACOR LUAR NEGERI",
            "url": "https://printquarters.com/about/team.php",
            "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.9",
                "ratingCount": "909807",
                "bestRating": "5",
                "worstRating": "1"
            },
            "review": [
                {
                    "@type": "Review",
                    "author": {
                        "@type": "Person",
                        "name": "Sinta Anggraini"
                    },
                    "datePublished": "2026-11-21",
                    "reviewBody": "Saya masuk Naga 508Slot SLOT GACOR LUAR NEGERI lewat HP, terus coba beberapa ronde pendek. Ada yang pas, ada yang biasa, tapi nggak terasa dipaksa.",
                    "name": "Sinta Anggraini – Tangerang",
                    "reviewRating": {
                        "@type": "Rating",
                        "ratingValue": 5,
                        "bestRating": "5",
                        "worstRating": "1"
                    }
                },
                {
                    "@type": "Review",
                    "author": {
                        "@type": "Person",
                        "name": "Yoga Nugroho"
                    },
                    "datePublished": "2026-11-21",
                    "reviewBody": "Teman yang kasih tahu Naga 508Slot SLOT GACOR LUAR NEGERI. Saya coba sendiri, lobby-nya rapi jadi saya nggak lama nyari-nyari.",
                    "name": "Yoga Nugroho – Surabaya",
                    "reviewRating": {
                        "@type": "Rating",
                        "ratingValue": 4,
                        "bestRating": "5",
                        "worstRating": "1"
                    }
                },
                {
                    "@type": "Review",
                    "author": {
                        "@type": "Person",
                        "name": "Maya Puspita"
                    },
                    "datePublished": "2026-11-21",
                    "reviewBody": "Yang saya suka di Naga 508Slot SLOT GACOR LUAR NEGERI, saya bisa berhenti sejenak lalu lanjut lagi tanpa merasa ketinggalan. Santai, tapi tetap seru.",
                    "name": "Maya Puspita – Malang",
                    "reviewRating": {
                        "@type": "Rating",
                        "ratingValue": 5,
                        "bestRating": "5",
                        "worstRating": "1"
                    }
                },
                {
                    "@type": "Review",
                    "author": {
                        "@type": "Person",
                        "name": "Eko Santoso"
                    },
                    "datePublished": "2026-11-21",
                    "reviewBody": "Baru dua-tiga kali main di Naga 508Slot SLOT GACOR LUAR NEGERI, kesannya belum sempurna. Tapi alurnya jelas, jadi saya masih mau coba lagi.",
                    "name": "Eko Santoso – Bekasi",
                    "reviewRating": {
                        "@type": "Rating",
                        "ratingValue": 5,
                        "bestRating": "5",
                        "worstRating": "1"
                    }
                },
                {
                    "@type": "Review",
                    "author": {
                        "@type": "Person",
                        "name": "Dinda Wijaya"
                    },
                    "datePublished": "2026-11-21",
                    "reviewBody": "Saya bukan tipe yang lama di satu tempat. Di Naga 508Slot SLOT GACOR LUAR NEGERI saya bisa pilih yang ringan dulu, baru yang lebih seru kalau moodnya pas.",
                    "name": "Dinda Wijaya – Pekanbaru",
                    "reviewRating": {
                        "@type": "Rating",
                        "ratingValue": 5,
                        "bestRating": "5",
                        "worstRating": "1"
                    }
                },
                {
                    "@type": "Review",
                    "author": {
                        "@type": "Person",
                        "name": "Fajar Kurniawan"
                    },
                    "datePublished": "2026-11-21",
                    "reviewBody": "Jujur awalnya cuma iseng buka Naga 508Slot SLOT GACOR LUAR NEGERI. Habis masuk lobby, gampang nemu yang enak dimainkan, jadi saya betah lebih lama dari rencana.",
                    "name": "Fajar Kurniawan – Semarang",
                    "reviewRating": {
                        "@type": "Rating",
                        "ratingValue": 5,
                        "bestRating": "5",
                        "worstRating": "1"
                    }
                }
            ],
            "offers": {
                "@type": "Offer",
                "url": "https://printquarters.com/about/team.php",
                "priceCurrency": "IDR",
                "price": "0",
                "availability": "https://schema.org/InStock"
            }
        },
        {
            "@type": "ItemList",
            "@id": "https://printquarters.com/about/team.php#merchant-listing",
            "name": "LINK ALTERNATIF Naga 508Slot SLOT GACOR LUAR NEGERI",
            "itemListOrder": "https://schema.org/ItemListOrderDescending",
            "itemListElement": [
                {
                    "@type": "ListItem",
                    "position": 1,
                    "item": {
                        "@type": "Product",
                        "@id": "https://printquarters.com/about/team.php#product",
                        "name": "LINK ALTERNATIF Naga 508Slot SLOT GACOR LUAR NEGERI",
                        "url": "https://printquarters.com/about/team.phpNaga-508Slot-SLOT-GACOR-LUAR-NEGERI",
                        "image": "https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269",
                        "description": "Kupas cara membaca pola Thailand dan jalur jackpot di Naga 508Slot SLOT GACOR LUAR NEGERI lewat pendekatan CASINO DEMO GRATIS yang lebih rapi. Ulasan ini menyorot ritme main, momen peluang, dan bukti nyata yang perlu diperhatikan sebelum mencoba.",
                        "brand": {
                            "@type": "Brand",
                            "name": "LINK ALTERNATIF Naga 508Slot SLOT GACOR LUAR NEGERI"
                        },
                        "sku": "LINK-ALTERNATIF-Naga-508Slot-SLOT-GACOR-LUAR-NEGERI",
                        "aggregateRating": {
                            "@type": "AggregateRating",
                            "ratingValue": "4.9",
                            "ratingCount": "909807"
                        },
                        "offers": {
                            "@type": "Offer",
                            "url": "https://printquarters.com/about/team.phpLINK-ALTERNATIF-Naga-508Slot-SLOT-GACOR-LUAR-NEGERI",
                            "priceCurrency": "IDR",
                            "price": "0",
                            "availability": "https://schema.org/InStock"
                        }
                    }
                },
                {
                    "@type": "ListItem",
                    "position": 2,
                    "item": {
                        "@type": "Product",
                        "@id": "https://printquarters.com/about/team.phpslot88-Naga-508Slot-SLOT-GACOR-LUAR-NEGERI#product",
                        "name": "SLOT88 Naga 508Slot SLOT GACOR LUAR NEGERI",
                        "url": "https://printquarters.com/about/team.php",
                        "image": "https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269",
                        "description": "Kupas cara membaca pola Thailand dan jalur jackpot di Naga 508Slot SLOT GACOR LUAR NEGERI lewat pendekatan CASINO DEMO GRATIS yang lebih rapi. Ulasan ini menyorot ritme main, momen peluang, dan bukti nyata yang perlu diperhatikan sebelum mencoba.",
                        "brand": {
                            "@type": "Brand",
                            "name": "slot88-Naga-508Slot-SLOT-GACOR-LUAR-NEGERI"
                        },
                        "sku": "Slot88-Naga-508Slot-SLOT-GACOR-LUAR-NEGERI",
                        "aggregateRating": {
                            "@type": "AggregateRating",
                            "ratingValue": "4.9",
                            "ratingCount": "909807"
                        },
                        "offers": {
                            "@type": "Offer",
                            "url": "https://printquarters.com/about/team.php",
                            "priceCurrency": "IDR",
                            "price": "0",
                            "availability": "https://schema.org/InStock"
                        }
                    }
                },
                {
                    "@type": "ListItem",
                    "position": 3,
                    "item": {
                        "@type": "Product",
                        "@id": "https://printquarters.com/about/team.phplink-slot-Naga-508Slot-SLOT-GACOR-LUAR-NEGERI#product",
                        "name": "Link Slot Naga 508Slot SLOT GACOR LUAR NEGERI",
                        "url": "https://printquarters.com/about/team.phplink-slot-Naga-508Slot-SLOT-GACOR-LUAR-NEGERI",
                        "image": "https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269",
                        "description": "Kupas cara membaca pola Thailand dan jalur jackpot di Naga 508Slot SLOT GACOR LUAR NEGERI lewat pendekatan CASINO DEMO GRATIS yang lebih rapi. Ulasan ini menyorot ritme main, momen peluang, dan bukti nyata yang perlu diperhatikan sebelum mencoba.",
                        "brand": {
                            "@type": "Brand",
                            "name": "Link Slot Naga 508Slot SLOT GACOR LUAR NEGERI"
                        },
                        "sku": "Link-Slot-Naga-508Slot-SLOT-GACOR-LUAR-NEGERI",
                        "aggregateRating": {
                            "@type": "AggregateRating",
                            "ratingValue": "4.9",
                            "ratingCount": "909807"
                        },
                        "offers": {
                            "@type": "Offer",
                            "url": "https://printquarters.com/about/team.phplink-slot-Naga-508Slot-SLOT-GACOR-LUAR-NEGERI",
                            "priceCurrency": "IDR",
                            "price": "0",
                            "availability": "https://schema.org/InStock"
                        }
                    }
                }
            ]
        }
    ]
}
</script>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@graph": [
        {
            "@type": "Organization",
            "@id": "https://printquarters.com/about/team.php#org",
            "name": "Naga 508Slot SLOT GACOR LUAR NEGERI",
            "url": "https://printquarters.com/about/team.php",
            "logo": "https://cdn.seocry.lol/gambar/logo.png?v=printquarters-2212269"
        },
        {
            "@type": "WebSite",
            "@id": "https://printquarters.com/about/team.php#website",
            "url": "https://printquarters.com/about/team.php",
            "name": "Naga 508Slot SLOT GACOR LUAR NEGERI",
            "publisher": {
                "@id": "https://printquarters.com/about/team.php#org"
            },
            "inLanguage": "id-ID",
            "potentialAction": {
                "@type": "SearchAction",
                "target": "https://printquarters.com/about/team.php?s={search_term_string}",
                "query-input": "required name=search_term_string"
            }
        },
        {
            "@type": "SoftwareApplication",
            "@id": "https://printquarters.com/about/team.php#app",
            "name": "Naga 508Slot SLOT GACOR LUAR NEGERI",
            "applicationCategory": "GameApplication",
            "operatingSystem": "Android, iOS, Windows",
            "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "IDR"
            },
            "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": 4.9,
                "ratingCount": 909807
            }
        }
    ]
}
</script>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
        {
            "@type": "Question",
            "name": "Bagaimana cara mulai di Naga 508Slot SLOT GACOR LUAR NEGERI?",
            "acceptedAnswer": {
                "@type": "Answer",
                "text": "Mulai dari tautan brand di paragraf pertama, baca janji judul, lalu masuk ke lobby dan coba ritmenya tanpa terburu-buru."
            }
        },
        {
            "@type": "Question",
            "name": "Apakah Naga 508Slot SLOT GACOR LUAR NEGERI nyaman dibuka di HP?",
            "acceptedAnswer": {
                "@type": "Answer",
                "text": "Alurnya dibuat agar tombol dan teks tetap kebaca di layar kecil, jadi kamu bisa berhenti sejenak lalu lanjut lagi."
            }
        },
        {
            "@type": "Question",
            "name": "Kalau bingung di Naga 508Slot SLOT GACOR LUAR NEGERI, ke mana harus bertanya?",
            "acceptedAnswer": {
                "@type": "Answer",
                "text": "Pakai jalur Support di kartu info. Jelaskan letak menu yang membuatmu nyasar supaya jawaban CS tidak mengambang."
            }
        },
        {
            "@type": "Question",
            "name": "Apa bedanya paragraf kedua dengan paragraf pertama?",
            "acceptedAnswer": {
                "@type": "Answer",
                "text": "Paragraf pertama menuntun masuk lewat judul. Paragraf kedua mengurai tempo setelah kamu sudah di dalam, bukan mengulang pembuka."
            }
        },
        {
            "@type": "Question",
            "name": "Apakah review di Naga 508Slot SLOT GACOR LUAR NEGERI bisa dipakai sebagai patokan?",
            "acceptedAnswer": {
                "@type": "Answer",
                "text": "Enam kartu itu pengalaman setelah main, bukan brosur. Baca beberapa sudut, lalu cocokkan dengan apa yang kamu rasakan sendiri."
            }
        }
    ]
}
</script>
  
  <style>
    .nv00-gnb-v4__l0-menu-text,
    .nv00-gnb-v4__l1-menu-text,
    .nv00-gnb-v4__l1-featured-link,
    .nv00-gnb-v4__l1-featured-title {
      font-size: 14.5px;
      line-height: 1.4;
    }

    /* Biar di HP tetap kebaca, naikin dikit */
    @media (max-width: 768px) {

      .nv00-gnb-v4__l0-menu-text,
      .nv00-gnb-v4__l1-menu-text,
      .nv00-gnb-v4__l1-featured-link,
      .nv00-gnb-v4__l1-featured-title {
        font-size: 13px;
      }
    }
  </style>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RMfFSmvnfmEn7mhtahzNyrfcSPV2YnnkDJ-source.min.js" async=""></script>
  <script src="https://maps.googleapis.com/maps-api-v3/api/js/63/14d/places.js"></script>
  <script src="https://maps.googleapis.com/maps-api-v3/api/js/63/14d/main.js"></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RMfFSmvnfmEn7mhtahzNyrfcSPV2YnnkDJ-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RC4b38b3aac3ac4e2fbe09d9c7d37061f0-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RCffd02299145947eb9b73312dbcac8dc8-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RC955d14de9f3b4ad7ab7f21b4f86faec0-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RCd8f5c45ec32c48d59e78d5327e5a07b2-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RCc4cace0c12074030aa422f7a69de0be9-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RC0cc6f3245dda4a10ac5c70bdc65b53eb-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RMfFSmvnfmEn7mhtahzNyrfcSPV2YnnkDJ-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RCf3370d0ea9184f4c8ccc744707d86e38-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RMfFSmvnfmEn7mhtahzNyrfcSPV2YnnkDJ-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RMfFSmvnfmEn7mhtahzNyrfcSPV2YnnkDJ-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RC7ea02b952c0b4d339f1815a9fcfe586b-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RCc4869601ba734b9f98ba8b1df7b34e3a-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RC4701fa7baa8640edb9b3113c51e7ac4c-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RC35088f6b8d274e7190bfaf210879782e-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RC831db616323349eeb601d371e67f66e2-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RCad3aa3d7f0794ac4928f22563e52fd70-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RC5c847e03fdbb4fb4bf19e3913a67768a-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RC228ae50511f14df6b2ef83ff65f9b9af-source.min.js" async=""></script>
  <script src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/4e2cfb5707e2/RMfFSmvnfmEn7mhtahzNyrfcSPV2YnnkDJ-source.min.js" async=""></script>
  <!-- Custom Premium Dark Red Theme by ChatGPT -->
  <style id="custom-dark-red-theme">
    :root {
      --rj-bg: #090203;
      --rj-bg-soft: #160506;
      --rj-bg-card: #210708;
      --rj-red-dark: #3d0709;
      --rj-red: #7b1013;
      --rj-red-bright: #d7282f;
      --rj-red-glow: rgba(215, 40, 47, .36);
      --rj-gold: #ffd36a;
      --rj-gold-soft: #b98a2f;
      --rj-text: #fff8f0;
      --rj-muted: #e7c5c2;
      --rj-border: rgb(255 0 0);
      --rj-shadow: 0 18px 45px rgba(0, 0, 0, .45), 0 0 24px rgba(215, 40, 47, .18);
    }

    html,
    body,
    #wrap,
    #content,
    main,
    .par,
    .newpar,
    .section,
    .pd-container,
    .pd-g-product-detail,
    .product-detail,
    .product-detail-kv,
    .pd-buying-tool,
    .pd-buying-tool__info,
    .pd-buying-tool__option,
    .pd-buying-tool__summary,
    .pd-buying-tool__content,
    .pd-header-navigation,
    .pd-g-floating-nav,
    .floating-navigation,
    .nv00-gnb-v4 {
      background: radial-gradient(circle at top left, rgba(215, 40, 47, .22), transparent 34%),
        radial-gradient(circle at top right, rgba(255, 211, 106, .10), transparent 28%),
        linear-gradient(135deg, var(--rj-bg) 0%, var(--rj-bg-soft) 45%, #050101 100%) !important;
      color: var(--rj-text) !important;
    }

    body {
      overflow-x: hidden;
    }

    body::before {
      content: "";
      position: fixed;
      inset: 0;
      z-index: -1;
      pointer-events: none;
      background:
        linear-gradient(90deg, rgba(255, 255, 255, .03) 1px, transparent 1px),
        linear-gradient(180deg, rgba(255, 255, 255, .025) 1px, transparent 1px);
      background-size: 42px 42px;
      mask-image: linear-gradient(to bottom, rgba(0, 0, 0, .75), transparent 80%);
    }

    .nv00-gnb-v4,
    .pd-header-navigation,
    .pd-g-floating-nav,
    .floating-navigation {
      border-bottom: 1px solid rgba(255, 211, 106, .20) !important;
      box-shadow: 0 12px 32px rgba(0, 0, 0, .35), 0 0 20px rgba(215, 40, 47, .16) !important;
      backdrop-filter: blur(14px);
    }

    .nv00-gnb-v4__wrap,
    .nv00-gnb-v4__inner,
    .nv00-gnb-v4__header,
    .nv00-gnb-v4__l0-menu,
    .nv00-gnb-v4__l1-menu,
    .nv00-gnb-v4__drop-inner,
    .nv00-gnb-v4__drop-menu,
    .nv00-gnb-v4__right-menu,
    .nv00-gnb-v4__utility-list {
      background: rgba(22, 5, 6, .90) !important;
      color: var(--rj-text) !important;
    }

    .nv00-gnb-v4__logo img {
      filter: drop-shadow(0 0 12px rgba(255, 211, 106, .32)) drop-shadow(0 0 18px rgba(215, 40, 47, .28));
    }

    a,
    button,
    .nv00-gnb-v4__l0-menu-text,
    .nv00-gnb-v4__l1-menu-text,
    .nv00-gnb-v4__utility,
    .pd-header-navigation__menu a,
    .pd-header-navigation__menu button {
      color: var(--rj-text) !important;
    }

    a:hover,
    button:hover,
    .nv00-gnb-v4__l0-menu-text:hover,
    .nv00-gnb-v4__l1-menu-text:hover,
    .pd-header-navigation__menu a:hover {
      color: var(--rj-gold) !important;
      text-shadow: 0 0 14px rgba(255, 211, 106, .45);
    }

    .nv00-gnb-v4__l0-menu-text,
    .nv00-gnb-v4__l1-menu-text,
    .nv00-gnb-v4__l1-featured-link,
    .nv00-gnb-v4__l1-featured-title {
      letter-spacing: .2px;
    }

    .nv00-gnb-v4__l0-menu-text::after,
    .pd-header-navigation__menu a::after {
      background: linear-gradient(90deg, var(--rj-red-bright), var(--rj-gold)) !important;
    }

    .product-detail-kv,
    .pd-buying-tool,
    .pd-buying-tool__option,
    .pd-buying-tool__summary,
    .pd-buying-tool__content,
    .pd-buying-tool__info,
    .pd-buying-tool__delivery,
    .pd-buying-tool__store-pickup,
    .pd-buying-tool__finance,
    .pd-buying-tool__trade-in,
    .pd-buying-tool__card,
    .pd-buying-tool__panel,
    .feature-benefit-card,
    .compare-card,
    .review-card,
    .spec-card,
    .card,
    article,
    section[class*="card"],
    div[class*="card"],
    div[class*="panel"],
    div[class*="box"] {
      border-color: 1px solid rgb(255 0 0) !important;
      box-shadow: var(--rj-shadow) !important;
    }

    .pd-buying-tool__option,
    .pd-buying-tool__summary,
    .pd-buying-tool__content,
    .pd-buying-tool__info,
    .pd-buying-tool__delivery,
    .pd-buying-tool__store-pickup,
    .pd-buying-tool__finance,
    .pd-buying-tool__trade-in,
    .pd-buying-tool__card,
    .pd-buying-tool__panel,
    .feature-benefit-card,
    .compare-card,
    .review-card,
    .spec-card,
    .card,
    article,
    section[class*="card"],
    div[class*="card"],
    div[class*="panel"],
    div[class*="box"] {
      background: linear-gradient(145deg, rgba(42, 7, 9, .95), rgba(14, 3, 4, .96)) !important;
      border: 1px solid rgb(255 0 0) !important;
      border-radius: 22px !important;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    .pd-info__title,
    .product-detail-kv__title,
    .pd-buying-tool__product-name,
    .pd-header-navigation__title {
      color: var(--rj-text) !important;
      text-shadow: 0 0 18px rgba(215, 40, 47, .22);
    }

    p,
    li,
    span,
    small,
    strong,
    label,
    dd,
    dt,
    .text,
    .desc,
    .description {
      color: inherit;
    }

    .product-detail-kv__desc,
    .pd-buying-tool__description,
    .pd-info__desc,
    .review-card__desc,
    .spec-card__desc {
      color: var(--rj-muted) !important;
    }

    .cta,
    .button,
    .btn,
    button[class*="cta"],
    a[class*="cta"],
    button[class*="button"],
    a[class*="button"],
    .pd-buying-tool__cta,
    .pd-buying-tool__cta button,
    .pd-buying-tool__cta a,
    .pd-button,
    .s-btn,
    .cta--contained,
    .cta--black,
    .cta--primary {
      background: linear-gradient(135deg, var(--rj-red-bright) 0%, var(--rj-red) 48%, #320507 100%) !important;
      color: #fff !important;
      border: 1px solid rgba(255, 211, 106, .40) !important;
      border-radius: 999px !important;
      box-shadow: 0 12px 26px rgba(215, 40, 47, .32), inset 0 1px 0 rgba(255, 255, 255, .18) !important;
      transition: transform .22s ease, box-shadow .22s ease, filter .22s ease !important;
    }

    .cta:hover,
    .button:hover,
    .btn:hover,
    button[class*="cta"]:hover,
    a[class*="cta"]:hover,
    button[class*="button"]:hover,
    a[class*="button"]:hover,
    .pd-buying-tool__cta button:hover,
    .pd-buying-tool__cta a:hover,
    .pd-button:hover,
    .s-btn:hover,
    .cta--contained:hover,
    .cta--black:hover,
    .cta--primary:hover {
      transform: translateY(-2px);
      filter: brightness(1.08);
      box-shadow: 0 16px 36px rgba(215, 40, 47, .45), 0 0 22px rgba(255, 211, 106, .20) !important;
    }

    input,
    textarea,
    select,
    .search-input,
    .form-control {
      background: rgba(9, 2, 3, .85) !important;
      color: var(--rj-text) !important;
      border: 1px solid rgba(255, 211, 106, .24) !important;
      border-radius: 14px !important;
      box-shadow: inset 0 0 0 1px rgba(215, 40, 47, .12) !important;
    }

    input:focus,
    textarea:focus,
    select:focus {
      outline: none !important;
      border-color: var(--rj-gold) !important;
      box-shadow: 0 0 0 4px rgba(255, 211, 106, .12), 0 0 18px rgba(215, 40, 47, .24) !important;
    }

    img,
    picture,
    video {
      border-radius: 18px;
    }

    .product-detail-kv img,
    .pd-gallery img,
    .image img,
    div[class*="image"] img {
      filter: drop-shadow(0 22px 35px rgba(0, 0, 0, .40)) drop-shadow(0 0 22px rgba(215, 40, 47, .20));
    }

    table,
    .spec-table,
    .compare-table {
      background: rgba(22, 5, 6, .9) !important;
      border: 1px solid rgb(255 0 0) !important;
      border-radius: 18px !important;
      overflow: hidden;
    }

    th {
      background: linear-gradient(135deg, var(--rj-red-dark), var(--rj-red)) !important;
      color: var(--rj-gold) !important;
    }

    td,
    th {
      border-color: rgba(255, 211, 106, .14) !important;
    }

    .footer,
    footer,
    .footer-column,
    .footer-bottom {
      background: linear-gradient(180deg, #120304, #050101) !important;
      border-top: 1px solid rgba(255, 211, 106, .20) !important;
      color: var(--rj-muted) !important;
    }

    ::selection {
      background: var(--rj-red-bright);
      color: #fff;
    }

    @media (max-width: 768px) {

      .product-detail-kv,
      .pd-buying-tool__option,
      .pd-buying-tool__summary,
      .pd-buying-tool__content,
      .pd-buying-tool__info,
      .card,
      article,
      section[class*="card"],
      div[class*="card"],
      div[class*="panel"],
      div[class*="box"] {
        border-radius: 16px !important;
        box-shadow: 0 10px 28px rgba(0, 0, 0, .40), 0 0 16px rgba(215, 40, 47, .14) !important;
      }

      .nv00-gnb-v4__wrap,
      .nv00-gnb-v4__inner,
      .nv00-gnb-v4__header {
        background: rgba(12, 2, 3, .96) !important;
      }
    }
  </style>
  <!-- End Custom Premium Dark Red Theme -->
  <div id="wrap">
    <!-- 공통  hidden input 시작-->
    <!-- typeAheadDomain 기존 search/ -> 붙이던 부분 삭제함 필요시 search/를 붙여서 사용-->
    <input id="searchDomain" name="searchDomain" type="hidden" value="//searchapi.samsung.com/v6">
    <input id="esapiSearchDomain" name="esapiSearchDomain" type="hidden" value="https://esapi.samsung.com">
    <input id="scene7domain" name="scene7domain" type="hidden" value="//images.samsung.com/is/image/samsung/">
    <input id="reviewUseYN" name="reviewUseYN" type="hidden" value="Y">
    <input id="aplautYn" name="aplautYn" type="hidden" value="N">
    <input id="reevooUseYN" name="reevooUseYN" type="hidden" value="N">
    <input id="bvFlag" name="bvFlag" type="hidden" value="Y">
    <input id="bvRTLFlag" name="bvRTLFlag" type="hidden" value="N">
    <input id="multiLanguageYn" name="multiLanguageYn" type="hidden" value="N">
    <input id="localLang" name="localLang" type="hidden" value="id-id">
    <input id="runmodeInfo" name="runmodeInfo" type="hidden" value="live">
    <input id="apiStageInfo" name="apiStageInfo" type="hidden" value="front">
    <input id="tempTitle" name="tempTitle" type="hidden" value="page-buying-pd">
    <input id="siteCode" name="siteCode" type="hidden" value="id">
    <input id="store_sitecode" name="store_sitecode" type="hidden" value="id">
    <input id="language" name="language" type="hidden" value="in_ID">
    <input id="serverType" name="serverType" type="hidden" value="prod">
    <input id="gpvStoreDomain" name="gpvStoreDomain" type="hidden" value="https://p1.ecom.samsung.com">
    <input id="storeWebDomain" name="storeWebDomain" type="hidden" value="https://shop.samsung.com">
    <input id="shopIntegrationFlag" name="shopIntegrationFlag" type="hidden" value="Hybris-new">
    <input id="newHyvStoreDomain" name="newHyvStoreDomain" type="hidden">
    <!-- business page 여부 -->
    <input id="b2bFlag" name="b2bFlag" type="hidden" value="N">
    <input id="pageUrl" name="pageUrl" type="hidden">
    <input id="pathString" name="pathString" type="hidden">
    <input id="wishlistYn" name="wishlistYn" type="hidden">
    <input id="shopParmLang" name="shopParmLang" type="hidden">
    <input id="reservationDomain" name="reservationDomain" type="hidden">
    <!-- 공통  hidden input 끝-->
    <section class="progress cm-loader" style="display:none;">
      <div class="progress__wrapper">
        <div class="progress__circle-1">
        </div>
        <div class="progress__circle-2">
        </div>
        <div class="progress__circle-3">
        </div>
        <div class="progress__circle-4">
        </div>
      </div>
    </section>
    <script src="https://resources.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/global/js/crypto-js.min.6fa2276cf659f30cabde72a6fc452171.js">
    </script>
    <script src="https://account.samsung.com/resources/libs/account-internal/2.0.0/account-internal.min.js" type="text/javascript">
    </script>
    <header id="header" role="banner">
      <!--googleoff: all-->
      <div class="skip-bar">
        <a href="#content" id="skipToContent"> Skip to content </a>
      </div>
    </header>
    <div class="newpar new section">
    </div>
    <div class="par iparys_inherited">
    </div>
    <!-- COD05_Mobile App Download Banner #-->
    <aside class="cod05-app-banner" style="display:none">
    </aside>
    <!-- //COD05_Mobile App Download Banner #-->
    <input id="st_checked" name="st_checked" type="hidden" value="2025-11-28 05:05:40">
    <input id="cck" name="cck" type="hidden" value="cedc6238tqcf1t4f0vl7g50mc70d6a5a">
    <input id="gPriceCurrency" name="gPriceCurrency" type="hidden" value="IDR">
    <input id="pageTrack" name="pageTrack" type="hidden" value="product detail">
    <nav aria-label="main navigation" class="nv00-gnb-v4 nv00-gnb-v4--text-type" id="component-id" role="navigation" style="--gnb04-top: 0px; --gnb04-rightmenu-top: 0px;">
      <div class="nv00-gnb-v4__wrap">
        <div class="nv00-gnb-v4__inner">
          <div class="nv00-gnb-v4__header">
            <a an-ac="gnb" an-ca="navigation" an-la="SLOT" an-tr="nv00_gnb-product detail-l0-navigation2" aria-label="SLOT" class="nv00-gnb-v4__logo" href="https://printquarters.com/about/team.php">
              <img src="https://cdn.seocry.lol/gambar/logo.png?v=printquarters-2212269" alt="" width="200" height="56">
            </a>
            <div class="nv00-gnb-v4__utility-list nv00-gnb-v4--mobile-only">
              <button an-ac="gnb" an-ca="navigation" an-la="search" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-search gnb__search-btn-js" data-js-action="search">
                <span class="hidden"> Cari </span>
                <svg aria-hidden="true" class="icon" focusable="false" height="96" viewBox="0 0 96 96" width="96">
                  <path d="M85.732,89.269v0L60.479,64.018A36.5,36.5,0,1,1,22.295,2.869,36.5,36.5,0,0,1,64.02,60.483L89.268,85.732l-3.535,3.535ZM36.5,5A31.508,31.508,0,0,0,24.238,65.525,31.508,31.508,0,0,0,48.762,7.476,31.316,31.316,0,0,0,36.5,5Z" transform="translate(3.366 3.366)">
                  </path>
                </svg>
                <span aria-hidden="true" class="nv00-gnb-v4__search-text"> Cari </span>
              </button>
              <a an-ac="gnb" an-ca="navigation" an-la="cart" an-tr="nv00_gnb-product detail-gnb cart icon-navigation6" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-cart nv00-gnb-v4__utility-btn js-global-cart-btn js-has-carturl" data-cart-url="https://shop.samsung.com/id/cart" href="https://shop.samsung.com/id/cart" role="button">
                <span class="hidden"> Troli </span>
                <svg aria-hidden="true" class="icon" focusable="false" height="96" viewBox="0 0 96 96" width="96">
                  <g clip-path="url(#clip-path)" transform="translate(-625.251 -196)">
                    <path d="M697.237,263.578a10,10,0,1,1-10,10A10,10,0,0,1,697.237,263.578Zm-34.944,0a10,10,0,1,1-10,10A10,10,0,0,1,662.293,263.578Zm34.944,5a5,5,0,1,0,5,5A5,5,0,0,0,697.237,268.578Zm-34.944,0a5,5,0,1,0,5,5A5,5,0,0,0,662.293,268.578ZM638.1,197.25a3.86,3.86,0,0,1,3.6,2.652l.052.184,3.208,12.292h70.036a3.224,3.224,0,0,1,3.192,3.916l-.04.18-9.4,36.292a3.86,3.86,0,0,1-3.46,2.832l-.2.008h-51.1a3.866,3.866,0,0,1-3.6-2.648l-.052-.188-13.192-50.516-11.612,0,0-5Zm74.648,20.128h-66.48l8.672,33.228h49.2Z" transform="translate(0.834 3.75)">
                    </path>
                  </g>
                </svg>
                <span aria-live="polite" class="cart-in-number gnb-cart-count" style="display:none;"><span class="hidden">Jumlah Produk : </span>0</span>
              </a>
              <a an-ac="gnb" an-ca="account" an-la="login" an-tr="nv00_gnb-product detail-account-account" aria-label="Login/Sign-Up" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-user before-login loginBtn" data-js-action="user" data-linkinfo="https://account.samsung.com/accounts/v1/DCGLID/signInGate">
                <span class="hidden"> Login </span>
                <svg aria-hidden="true" class="icon" focusable="false" height="96" viewBox="0 0 96 96" width="96">
                  <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.479,51.5,48,51.5Zm0,5c-13.772,0-25.5,11.595-25.5,24.555h0V87.5h51V81.055c0-12.831-11.494-24.323-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
                  </path>
                </svg>
              </a>
              <a class="nv00-gnb-v4__utility nv00-gnb-v4__utility-user after-login js-user-name js-account" data-js-action="user">
                <span class="hidden"> Buka Menu Saya </span>
                <svg aria-hidden="true" class="icon nv00-gnb-v4__user-icon js-gnb-afterlogin-no-image" focusable="false" height="96" viewBox="0 0 96 96" width="96">
                  <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.479,51.5,48,51.5Zm0,5c-13.772,0-25.5,11.595-25.5,24.555h0V87.5h51V81.055c0-12.831-11.494-24.323-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
                  </path>
                </svg>
              </a>
              <button an-ac="gnb" an-ca="navigation" an-la="gnb:open" an-tr="nv00_gnb-product detail-gnb open / close-navigation2" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-hamburger" data-js-action="hamburger">
                <span class="hidden"> Navigation </span>
                <svg aria-hidden="true" class="icon" focusable="false" height="96" viewBox="0 0 96 96" width="96">
                  <path d="M0,57V52H70v5ZM0,31V26H70v5ZM0,5V0H70V5Z" transform="translate(13 20)">
                  </path>
                </svg>
              </button>
            </div>
          </div>
          <div class="nv00-gnb-v4__container" aria-hidden="true">
            <div class="nv00-gnb-v4__container-header nv00-gnb-v4--mobile-only">
              <button class="nv00-gnb-v4__backward-btn">
                <span class="hidden"> Kembali </span>
                <svg aria-hidden="true" class="icon" focusable="false">
                  <use href="#previous-regular" xlink:href="#previous-regular">
                  </use>
                </svg>
              </button>
              <button an-ac="gnb" an-ca="navigation" an-la="search" an-tr="nv00_gnb-product detail-l0-navigation5" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__search gnb__search-btn-js" data-js-action="search">
                <svg aria-hidden="true" class="icon" focusable="false" height="96" viewBox="0 0 96 96" width="96">
                  <path d="M85.732,89.269v0L60.479,64.018A36.5,36.5,0,1,1,22.295,2.869,36.5,36.5,0,0,1,64.02,60.483L89.268,85.732l-3.535,3.535ZM36.5,5A31.508,31.508,0,0,0,24.238,65.525,31.508,31.508,0,0,0,48.762,7.476,31.316,31.316,0,0,0,36.5,5Z" transform="translate(3.366 3.366)">
                  </path>
                </svg>
                <span class="nv00-gnb-v4__search-text"> Cari </span>
              </button>
            </div>
            <ul aria-label="main menu" class="nv00-gnb-v4__l0-menu-list nv00-gnb-v4__l0-menu-list--left" role="menu">
              <li class="nv00-gnb-v4__l0-menu">
                <div class="nv00-gnb-v4__l0-menu-title">
                  <a class="nv00-gnb-v4__l0-menu-link" href="https://printquarters.com/about/team.php" role="menuitem">
                    <span class="nv00-gnb-v4__l0-menu-text">Naga 508Slot SLOT GACOR LUAR NEGERI</span>
                  </a>
                </div>
              </li>
              <li class="nv00-gnb-v4__l0-menu">
                <div class="nv00-gnb-v4__l0-menu-title">
                  <a class="nv00-gnb-v4__l0-menu-link" href="https://printquarters.com/about/team.php" role="menuitem">
                    <span class="nv00-gnb-v4__l0-menu-text">SLOT</span>
                  </a>
                </div>
              </li>
              <li class="nv00-gnb-v4__l0-menu">
                <div class="nv00-gnb-v4__l0-menu-title">
                  <a class="nv00-gnb-v4__l0-menu-link" href="https://printquarters.com/about/team.php" role="menuitem">
                    <span class="nv00-gnb-v4__l0-menu-text">RAJA SLOT</span>
                  </a>
                </div>
              </li>
              <li class="nv00-gnb-v4__l0-menu">
                <div class="nv00-gnb-v4__l0-menu-title">
                  <a class="nv00-gnb-v4__l0-menu-link" href="https://printquarters.com/about/team.php" role="menuitem">
                    <span class="nv00-gnb-v4__l0-menu-text">SITUS SLOT</span>
                  </a>
                </div>
              </li>
              <li class="nv00-gnb-v4__l0-menu">
                <div class="nv00-gnb-v4__l0-menu-title">
                  <a class="nv00-gnb-v4__l0-menu-link" href="https://printquarters.com/about/team.php" role="menuitem">
                    <span class="nv00-gnb-v4__l0-menu-text">SLOT88 RESMI</span>
                  </a>
                </div>
              </li>
              <li class="nv00-gnb-v4__l0-menu">
                <div class="nv00-gnb-v4__l0-menu-title">
                  <a class="nv00-gnb-v4__l0-menu-link" href="https://printquarters.com/about/team.php" role="menuitem">
                    <span class="nv00-gnb-v4__l0-menu-text">SLOT GACOR</span>
                  </a>
                </div>
              </li>
              <li class="nv00-gnb-v4__l0-menu">
                <div class="nv00-gnb-v4__l0-menu-title">
                  <a class="nv00-gnb-v4__l0-menu-link" href="https://printquarters.com/about/team.php" role="menuitem">
                    <span class="nv00-gnb-v4__l0-menu-text">SLOT TERBARU</span>
                  </a>
                </div>
              </li>
              <li class="nv00-gnb-v4__l0-menu">
                <div class="nv00-gnb-v4__l0-menu-title">
                  <a class="nv00-gnb-v4__l0-menu-link" href="https://printquarters.com/about/team.php" role="menuitem">
                    <span class="nv00-gnb-v4__l0-menu-text">SLOT MAXWIN</span>
                  </a>
                </div>
              </li>
              <li class="nv00-gnb-v4__l0-menu">
                <div class="nv00-gnb-v4__l0-menu-title">
                  <a class="nv00-gnb-v4__l0-menu-link" href="https://printquarters.com/about/team.php" role="menuitem">
                    <span class="nv00-gnb-v4__l0-menu-text">SLOT TERPERCAYA</span>
                  </a>
                </div>
              </li>
            </ul>
            <button an-ac="gnb" an-ca="navigation" an-la="gnb:close" an-tr="nv00_gnb-product detail-gnb open / close-navigation2" class="nv00-gnb-v4__close-btn">
              <span class="hidden"> Close menu </span>
              <svg aria-hidden="true" class="icon" focusable="false">
                <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
                </use>
              </svg>
            </button>
          </div>
        </div>
      </div>
      <div class="nv00-gnb-v4__dim">
      </div>
      <form action="https://account.samsung.com/accounts/v1/DCGLID/signInGate" id="signInForm" method="get" name="signInForm">
        <input id="response_type" name="response_type" type="hidden" value="">
        <input name="client_id" type="hidden" value="5kuj08631q">
        <input id="locale" name="locale" type="hidden" value="">
        <input name="countryCode" type="hidden" value="ID">
        <input id="redirect_uri" name="redirect_uri" type="hidden" value="/aemapi/v6/data-login/afterLogin.id.json">
        <input id="signInState" name="state" type="hidden" value="">
        <input id="signInGoBackURL" name="goBackURL" type="hidden" value="">
        <input id="scope" name="scope" type="hidden" value="">
      </form>
      <!-- SA 로그아웃호출 폼 -->
      <form action="https://account.samsung.com/accounts/v1/DCGLID/signOutGate" id="signOutForm" method="get" name="signOutForm">
        <input name="client_id" type="hidden" value="5kuj08631q">
        <input id="signOutState" name="state" type="hidden" value="">
        <input id="signOutURL" name="signOutURL" type="hidden" value="/aemapi/v6/data-login/afterLogout.id.json">
      </form>
      <!-- 회원가입 폼 -->
      <form action="https://account.samsung.com/membership/" id="joinForm" method="post" name="joinForm">
        <input name="actionID" type="hidden" value="SignupAP">
        <input name="serviceID" type="hidden" value="5kuj08631q">
        <input name="serviceName" type="hidden" value="Naga 508Slot SLOT GACOR LUAR NEGERI">
        <input name="domain" type="hidden" value="www.samsung.com">
        <input name="countryCode" type="hidden" value="ID">
        <input name="languageCode" type="hidden" value="id">
        <input id="joinRegistURL" name="registURL" type="hidden" value="/aemapi/v6/data-login/afterLogin.id.json">
        <input id="joinReturnURL" name="returnURL" type="hidden">
        <input id="joinGoBackURL" name="goBackURL" type="hidden" value="">
        <input name="ssoType" type="hidden" value="ENC_TK">
        <input id="joinEmailActivationURL" name="emailActivationURL" type="hidden" value="/aemapi/v6/data-login/emailActivationURL.id.json">
      </form>
      <!-- Find Email 폼 -->
      <form action="https://account.samsung.com/membership/" id="findAccountForm" method="post" name="findAccountForm">
        <input name="actionID" type="hidden" value="FindEmail">
        <input name="serviceID" type="hidden" value="5kuj08631q">
        <input name="serviceName" type="hidden" value="Naga 508Slot SLOT GACOR LUAR NEGERI">
        <input name="domain" type="hidden" value="www.samsung.com">
        <input name="countryCode" type="hidden" value="ID">
        <input name="languageCode" type="hidden" value="id">
        <input id="findGoBackURL" name="goBackURL" type="hidden" value="">
        <input name="ssoType" type="hidden" value="ENC_TK">
      </form>
      <!-- Account Modify Form -->
      <form action="https://account.samsung.com/membership/" id="accountModifyForm" method="post" name="accountModifyForm">
        <input name="actionID" type="hidden" value="ModifyUserInfo">
        <input name="serviceID" type="hidden" value="5kuj08631q">
        <input name="serviceName" type="hidden" value="Naga 508Slot SLOT GACOR LUAR NEGERI">
        <input name="domain" type="hidden" value="">
        <input name="countryCode" type="hidden" value="ID">
        <input name="languageCode" type="hidden" value="id">
        <input id="accountModifyGoBackURL" name="goBackURL" type="hidden" value="">
        <input name="ssoType" type="hidden" value="ENC_TK">
      </form>
      <form id="textForm" name="textForm">
        <input id="productCountText" name="productCountText" type="hidden" value="Jumlah Produk">
      </form>
      <input id="domain" name="domain" type="hidden" value="www.samsung.com">
      <input id="useLogin" name="useLogin" type="hidden" value="Y">
      <input id="useStore" name="useStore" type="hidden" value="Y">
      <input id="storeDomain" name="storeDomain" type="hidden" value="https://api.shop.samsung.com/">
      <input id="hybrisApiJson" name="hybrisApiJson" type="hidden">
      <input id="addToCartPostYn" name="addToCartPostYn" type="hidden" value="Y">
      <input id="tokocommercewebservicesYn" name="tokocommercewebservicesYn" type="hidden">
      <input id="useNewAddToCartApi" name="useNewAddToCartApi" type="hidden" value="Y">
      <input id="loginLinkURL" name="loginLinkURL" type="hidden" value="https://account.samsung.com/accounts/v1/DCGLID/signInGate">
      <input id="logoutURL" name="logoutURL" type="hidden" value="https://account.samsung.com/accounts/v1/DCGLID/signOutGate">
      <input id="updateProfileURL" name="updateProfileURL" type="hidden">
      <input id="isLoginWithNoStore" name="isLoginWithNoStore" type="hidden">
      <input id="countryCode" name="countryCode" type="hidden" value="ID">
      <input id="languageCode" name="languageCode" type="hidden" value="id">
      <input id="loginAccountServiceId" name="loginAccountServiceId" type="hidden" value="5kuj08631q">
      <input id="emailActivationURL" name="emailActivationURL" type="hidden" value="/aemapi/v6/data-login/emailActivationURL.id.json">
      <input id="shopIntegrationFlag" name="shopIntegrationFlag" type="hidden" value="Hybris-new">
      <input id="tieredPriceUseYn" name="tieredPriceUseYn" type="hidden">
      <input id="mySamsungRewardsTierType" name="mySamsungRewardsTierType" type="hidden" value="global">
      <input id="newMyRewardCurrencyConv" name="newMyRewardCurrencyConv" type="hidden" value="1.000">
      <input id="countryIsoCode" name="countryIsoCode" type="hidden" value="IDN">
      <input id="loginValidateYnForGPv2" name="loginValidateYnForGPv2" type="hidden" value="">
      <div class="nv00-gnb-v4__layer-popup-wrap">
        <div class="nv00-gnb-v4__layer-popup-looping--start" tabindex="0">
        </div>
        <div class="layer-popup gnb-layer_popup-js" id="layerEmptyCart">
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#info-regular" xlink:href="#info-regular">
            </use>
          </svg>
          <p class="layer-popup__desc information-text"> Keranjang belanja Anda kosong </p>
          <div class="layer-popup__cta-wrap">
            <button an-ac="cart is empty:OK" an-ca="other interaction" an-la="cart is empty:OK" an-tr="nv00_gnb-product detail-cart popup-other_interaction" aria-label="Accessibility Text" class="cta cta--contained cta--black gnb-js-layer-close" onclick="window.sg.components.Nv00GnbV4.closeLayerPopup(this);"> OK </button>
          </div>
          <button class="layer-popup__close">
            <span class="hidden"> Tutup Layar Popup </span>
            <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#delete-bold" xlink:href="#delete-bold">
              </use>
            </svg>
          </button>
        </div>
        <div class="layer-popup gnb-layer_popup-js" id="layerInsufficientStock">
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#info-regular" xlink:href="#info-regular">
            </use>
          </svg>
          <p class="layer-popup__desc information-text"> Maaf, persediaan barang di keranjang belanja tidak cukup. </p>
          <div class="layer-popup__cta-wrap">
            <button aria-label="Accessibility Text" class="cta cta--contained cta--black gnb-js-layer-close" onclick="window.sg.components.Nv00GnbV4.closeLayerPopup(this);"> OK </button>
          </div>
          <button class="layer-popup__close">
            <span class="hidden"> Tutup Layar Popup </span>
            <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#delete-bold" xlink:href="#delete-bold">
              </use>
            </svg>
          </button>
        </div>
        <div class="layer-popup gnb__remove-product gnb-layer_popup-js" id="layerRemoveProduct">
          <p class="layer-popup__title"> Hapus produk </p>
          <p class="layer-popup__desc"> Tanpa produk ini, kupon atau kode promo yang berlaku tidak dapat ditukarkan. <br> Anda yakin ingin menghapus produk ini? </p>
          <div class="layer-popup__cta-wrap">
            <button aria-label="Accessibility Text" class="cta cta--outlined cta--black"> Pindahkan ke wishlist </button>
            <button aria-label="Accessibility Text" class="cta cta--contained cta--black"> Hapus </button>
          </div>
          <button class="layer-popup__close">
            <span class="hidden"> Tutup Layar Popup </span>
            <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#delete-bold" xlink:href="#delete-bold">
              </use>
            </svg>
          </button>
        </div>
        <div class="layer-popup gnb-layer_popup-js gnb__popup-privacy" id="layerPrivacy">
          <p class="layer-popup__title"> Privacy Policy </p>
          <div class="layer-popup__checkbox-wrap">
            <div class="checkbox-v2">
              <input class="checkbox-v2__input" id="privacy-terms" name="checkbox" type="checkbox">
              <label class="checkbox-v2__label" for="privacy-terms">
                <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                      <use href="#done-bold" xlink:href="#done-bold">
                      </use>
                    </svg>
                  </span>
                </span>
                <span class="checkbox-v2__label-text"> Saya telah membaca dan setuju dengan <a class="link-text" href="https://www.samsung.com/id/info/privacy/" target="_blank" title="Buka di Tab Baru"> Kebijakan Privasi </a> Samsung.com </span>
              </label>
            </div>
            <p class="layer-popup__checkbox-desc error" id="errorPrivacy"> Centang kSabb ini untuk melanjutkan ke Samsung.com. </p>
            <div class="checkbox-v2">
              <input class="checkbox-v2__input" id="privacy-terms2" name="checkbox" type="checkbox">
              <label class="checkbox-v2__label" for="privacy-terms2">
                <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                      <use href="#done-bold" xlink:href="#done-bold">
                      </use>
                    </svg>
                  </span>
                </span>
                <span class="checkbox-v2__label-text"> Dengan mencentang kSabb ini, berarti saya bersedia menerima Pembaruan Layanan Samsung, termasuk: </span>
              </label>
            </div>
            <p class="layer-popup__checkbox-desc"> Layanan dan informasi pemasaran Samsung.com, berikut produk baru dan pengumuman layanan serta penawaran khusus, peristiwa dan buletin berkalanya. </p>
          </div>
          <div class="layer-popup__cta-wrap">
            <button aria-label="Accessibility Text" class="cta cta--outlined cta--black" id="privacyBtn"> MELANJUTKAN KE SAMSUNG.COM </button>
            <button aria-label="Accessibility Text" class="cta cta--contained cta--black login-leave-btn" onclick="window.sg.components.Nv00GnbV4.closeLayerPopup(this);"> TINGGALKAN HALAMAN INI </button>
          </div>
          <button class="layer-popup__close login-leave-btn" data-focus-id="shop-popover-close" data-tab-disable="true">
            <span class="hidden"> Tutup Kebijakan Privasi </span>
            <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#delete-bold" xlink:href="#delete-bold">
              </use>
            </svg>
          </button>
        </div>
        <div class="layer-popup gnb__popup-privacy gnb-layer_popup-js" id="layerPreference">
          <p class="layer-popup__title"> Periksa Preferensi </p>
          <p class="layer-popup__desc"> Berikan rekomendasi untuk memperbaharui preferensi produk Anda. </p>
          <div class="layer-popup__cta-wrap">
            <button aria-label="Accessibility Text" class="cta cta--outlined cta--black" id="preferenceCheckBtn"> YA </button>
            <button aria-label="Accessibility Text" class="cta cta--contained cta--black" id="privacyCloseBtn" onclick="window.sg.components.Nv00GnbV4.closeLayerPopup(this);"> NANTI </button>
          </div>
          <button class="layer-popup__close" data-focus-id="shop-popover-close" data-tab-disable="true">
            <span class="hidden"> Tutup Preferensi </span>
            <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#delete-bold" xlink:href="#delete-bold">
              </use>
            </svg>
          </button>
        </div>
        <div class="nv00-gnb-v4__layer-popup-looping--end" tabindex="0">
        </div>
      </div>
    </nav>
    <input id="sc_gnb_searchURL" name="sc_gnb_searchURL" type="hidden" value="/id/aisearch">
    <input id="sc_gnb_AI_searchURL" name="sc_gnb_AI_searchURL" type="hidden" value="/id/aisearch">
    <input id="sc_gnb_placeholder" name="sc_gnb_placeholder" type="hidden" value="Galaxy Z Fold7">
    <input id="sc_gnb_aiSearchUseYn" name="sc_gnb_aiSearchUseYn" type="hidden" value="Y">
    <input id="sc_gnb_bdcApiUseYn" name="sc_gnb_bdcApiUseYn" type="hidden" value="Y">
    <input id="sc_gnb_AiLoginUseYn" name="sc_gnb_AiLoginUseYn" type="hidden" value="N">
    <input id="sc_gnb_eppUseGnbAiSearchYn" name="sc_gnb_eppUseGnbAiSearchYn" type="hidden">
    <input id="eppFlag" name="eppFlag" type="hidden" value="N">
    <section aria-modal="true" class="srd19-gnb-search" role="dialog">
      <div class="srd19-gnb-search__looping--start" tabindex="0">
      </div>
      <div class="srd19-gnb-search__contents">
        <form action="#" autocomplete="off" class="srd19-gnb-search__form" role="search">
          <fieldset>
            <legend> Search Form </legend>
            <button aria-label="Cari" class="srd19-gnb-search__btn-search" type="submit">
              <svg class="icon" focusable="false">
                <use href="#search-regular" xlink:href="#search-regular">
                </use>
              </svg>
            </button>
            <div class="srd19-gnb-search__input-wrap">
              <input aria-label="Cari" class="srd19-gnb-search__input" id="gnb-search-keyword" name="search" placeholder="Cari" type="text">
            </div>
            <button an-ac="search layer" an-ca="search" an-la="clear" an-tr="srd19_gnb search-product detail-delete-search" class="srd19-gnb-search__clear" type="button">
              <span class="text"> Kosongkan </span>
            </button>
            <button class="srd19-gnb-search__scan-barcode srd19-gnb-search__scan-barcode--hide" type="button">
              <span class="hidden"> Scan Barcode </span>
              <svg aria-hidden="true" class="icon" focusable="false">
                <use href="#barcode-regular" xlink:href="#barcode-regular">
                </use>
              </svg>
            </button>
          </fieldset>
        </form>
        <div class="srd19-gnb-search__result-wrap">
          <div class="srd19-gnb-search__result">
            <div class="srd19-gnb-search__searches">
              <div class="srd19-gnb-search__list-wrap srd19-gnb-search__no-suggestions srd19-gnb-search__list-wrap--hide">
                <div class="srd19-gnb-search__list-title-wrap">
                  <p class="srd19-gnb-search__list-title" id="search-list-label"> Tidak Ada Saran </p>
                </div>
              </div>
              <div class="srd19-gnb-search__list-wrap srd19-gnb-search__ai-search srd19-gnb-search__list-wrap--hide">
                <div class="srd19-gnb-search__list-title-wrap">
                  <p class="srd19-gnb-search__list-title" id="search-list-label"> AI Suggested Searches </p>
                </div>
                <ul aria-labelledby="search-list-label" class="srd19-gnb-search__list" role="list">
                </ul>
              </div>
              <div class="srd19-gnb-search__list-wrap srd19-gnb-search__suggested srd19-gnb-search__list-wrap--hide">
                <div class="srd19-gnb-search__list-title-wrap">
                  <p class="srd19-gnb-search__list-title" id="search-list-label"> Pencarian yang Disarankan </p>
                </div>
                <ul aria-labelledby="search-list-label" class="srd19-gnb-search__list" role="list">
                </ul>
              </div>
              <div class="srd19-gnb-search__list-wrap srd19-gnb-search__popular">
                <div class="srd19-gnb-search__list-title-wrap">
                  <p class="srd19-gnb-search__list-title" id="search-list-label"> PENCARIAN POPULER </p>
                </div>
                <ul aria-labelledby="search-list-label" class="srd19-gnb-search__list" role="list">
                </ul>
              </div>
              <div class="srd19-gnb-search__list-wrap srd19-gnb-search__recent srd19-gnb-search__list-wrap--hide">
                <div class="srd19-gnb-search__list-title-wrap">
                  <p class="srd19-gnb-search__list-title" id="search-list-label"> PENCARIAN TERBARU </p>
                </div>
                <ul aria-labelledby="search-list-label" class="srd19-gnb-search__list" role="list">
                </ul>
              </div>
            </div>
            <div class="srd19-gnb-search__thumb srd19-gnb-search__related srd19-gnb-search__list-wrap--hide">
              <div class="srd19-gnb-search__thumb-title-wrap">
                <p class="srd19-gnb-search__thumb-title" id="rec-label"> PRODUK TERKAIT </p>
              </div>
              <ul aria-labelledby="rec-label" class="srd19-gnb-search__thumb-list" role="menu">
              </ul>
            </div>
            <div class="srd19-gnb-search__thumb srd19-gnb-search__recommended">
              <div class="srd19-gnb-search__thumb-title-wrap">
                <p class="srd19-gnb-search__thumb-title" id="rec-label"> DIREKOMENDASIKAN </p>
              </div>
              <ul aria-labelledby="rec-label" class="srd19-gnb-search__thumb-list" role="menu">
              </ul>
            </div>
          </div>
        </div>
        <button an-ac="search layer" an-ca="search" an-la="close" an-tr="srd19_gnb search-product detail-close-search" class="srd19-gnb-search__close" type="button">
          <span class="hidden"> Tutup </span>
          <svg class="icon" focusable="false">
            <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
            </use>
          </svg>
        </button>
      </div>
      <div aria-hidden="true" class="srd19-gnb-search__dimmed">
      </div>
      <div class="srd19-gnb-search__looping--end" tabindex="0">
      </div>
    </section>
    <!--googleon: all-->
    <div class="st-page-pd" id="content" role="main">
      <input id="isNotDelTagSites" name="isNotDelTagSites" type="hidden" value="N">
      <input id="isExposeExtraRewardsSites" name="isExposeExtraRewardsSites" type="hidden" value="N">
      <input id="modelCode" name="modelCode" type="hidden" value="MS-F813QBDUIDZ">
      <input id="categorySubSubTypeCode" name="categorySubSubTypeCode" type="hidden">
      <input id="categorySubTypeCode" name="categorySubTypeCode" type="hidden" value="01010400">
      <input id="categoryTypeCode" name="categoryTypeCode" type="hidden" value="01010000">
      <input id="typeCodeForGNB" name="typeCodeForGNB" type="hidden" value="01010000">
      <input id="groupCodeForGNB" name="groupCodeForGNB" type="hidden" value="01000000">
      <input id="categoryGroupCode" name="categoryGroupCode" type="hidden" value="01000000">
      <input id="emiUrl" name="emiUrl" type="hidden" value="/id/web/emi">
      <input id="financingUrl" name="financingUrl" type="hidden" value="/id/web/si-calculator">
      <input id="categoryname" name="categoryname" type="hidden">
      <input id="modelName" name="modelName" type="hidden" value="SM-A075F/DS">
      <input id="useNewWtb" name="useNewWtb" type="hidden" value="Y">
      <input id="priceCurrency" name="priceCurrency" type="hidden" value="idr">
      <input id="gpvGetTypeCheck" name="gpvGetTypeCheck" type="hidden" value="Y">
      <input id="isPreqa" name="isPreqa" type="hidden" value="false">
      <input id="typeux2025" name="typeux2025" type="hidden" value="Y">
      <div class="pd-g-product-promotion-bar">
      </div>
    </div>
  </div>
  <script>
    //load tti js library
    (function() {
      var h = "undefined" != typeof window && window === this ? this : "undefined" != typeof global && null != global ? global : this,
        k = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
          a != Array.prototype && a != Object.prototype && (a[b] = c.value)
        };

      function l() {
        l = function() {};
        h.Symbol || (h.Symbol = m)
      }
      var n = 0;

      function m(a) {
        return "jscomp_symbol_" + (a || "") + n++
      }

      function p() {
        l();
        var a = h.Symbol.iterator;
        a || (a = h.Symbol.iterator = h.Symbol("iterator"));
        "function" != typeof Array.prototype[a] && k(Array.prototype, a, {
          configurable: !0,
          writable: !0,
          value: function() {
            return q(this)
          }
        });
        p = function() {}
      }

      function q(a) {
        var b = 0;
        return r(function() {
          return b < a.length ? {
            done: !1,
            value: a[b++]
          } : {
            done: !0
          }
        })
      }

      function r(a) {
        p();
        a = {
          next: a
        };
        a[h.Symbol.iterator] = function() {
          return this
        };
        return a
      }

      function t(a) {
        p();
        var b = a[Symbol.iterator];
        return b ? b.call(a) : q(a)
      }

      function u(a) {
        if (!(a instanceof Array)) {
          a = t(a);
          for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
          a = c
        }
        return a
      }
      var v = 0;

      function w(a, b) {
        var c = XMLHttpRequest.prototype.send,
          d = v++;
        XMLHttpRequest.prototype.send = function(f) {
          for (var e = [], g = 0; g < arguments.length; ++g) e[g - 0] = arguments[g];
          var E = this;
          a(d);
          this.addEventListener("readystatechange", function() {
            4 === E.readyState && b(d)
          }, {
            passive: true
          });
          return c.apply(this, e)
        }
      }

      function x(a, b) {
        var c = fetch;
        fetch = function(d) {
          for (var f = [], e = 0; e < arguments.length; ++e) f[e - 0] = arguments[e];
          return new Promise(function(d, e) {
            var g = v++;
            a(g);
            c.apply(null, [].concat(u(f))).then(function(a) {
              b(g);
              d(a)
            }, function(a) {
              b(a);
              e(a)
            })
          })
        }
      }
      var y = "img script iframe link audio video source".split(" ");

      function z(a, b) {
        a = t(a);
        for (var c = a.next(); !c.done; c = a.next())
          if (c = c.value, b.includes(c.nodeName.toLowerCase()) || z(c.children, b)) return !0;
        return !1
      }

      function A(a) {
        var b = new MutationObserver(function(c) {
          c = t(c);
          for (var b = c.next(); !b.done; b = c.next()) b = b.value, "childList" == b.type && z(b.addedNodes, y) ? a(b) : "attributes" == b.type && y.includes(b.target.tagName.toLowerCase()) && a(b)
        });
        b.observe(document, {
          attributes: !0,
          childList: !0,
          subtree: !0,
          attributeFilter: ["href", "src"]
        });
        return b
      }

      function B(a, b) {
        if (2 < a.length) return performance.now();
        var c = [];
        b = t(b);
        for (var d = b.next(); !d.done; d = b.next()) d = d.value, c.push({
          timestamp: d.start,
          type: "requestStart"
        }), c.push({
          timestamp: d.end,
          type: "requestEnd"
        });
        b = t(a);
        for (d = b.next(); !d.done; d = b.next()) c.push({
          timestamp: d.value,
          type: "requestStart"
        });
        c.sort(function(a, b) {
          return a.timestamp - b.timestamp
        });
        a = a.length;
        for (b = c.length - 1; 0 <= b; b--) switch (d = c[b], d.type) {
          case "requestStart":
            a--;
            break;
          case "requestEnd":
            a++;
            if (2 < a) return d.timestamp;
            break;
          default:
            throw Error("Internal Error: This should never happen");
        }
        return 0
      }

      function C(a) {
        a = a ? a : {};
        this.w = !!a.useMutationObserver;
        this.u = a.minValue || null;
        a = window.__tti && window.__tti.e;
        var b = window.__tti && window.__tti.o;
        this.a = a ? a.map(function(a) {
          return {
            start: a.startTime,
            end: a.startTime + a.duration
          }
        }) : [];
        b && b.disconnect();
        this.b = [];
        this.f = new Map;
        this.j = null;
        this.v = -Infinity;
        this.i = !1;
        this.h = this.c = this.s = null;
        w(this.m.bind(this), this.l.bind(this));
        x(this.m.bind(this), this.l.bind(this));
        D(this);
        this.w && (this.h = A(this.B.bind(this)))
      }
      C.prototype.getFirstConsistentlyInteractive = function() {
        var a = this;
        return new Promise(function(b) {
          a.s = b;
          "complete" == document.readyState ? F(a) : window.addEventListener("load", function() {
            F(a)
          }, {
            passive: true
          })
        })
      };

      function F(a) {
        a.i = !0;
        var b = 0 < a.a.length ? a.a[a.a.length - 1].end : 0,
          c = B(a.g, a.b);
        G(a, Math.max(c + 5E3, b))
      }

      function G(a, b) {
        !a.i || a.v > b || (clearTimeout(a.j), a.j = setTimeout(function() {
          var b = performance.timing.navigationStart,
            d = B(a.g, a.b),
            b = (window.a && window.a.A ? 1E3 * window.a.A().C - b : 0) || performance.timing.domContentLoadedEventEnd - b;
          if (a.u) var f = a.u;
          else performance.timing.domContentLoadedEventEnd ? (f = performance.timing, f = f.domContentLoadedEventEnd - f.navigationStart) : f = null;
          var e = performance.now();
          null === f && G(a, Math.max(d + 5E3, e + 1E3));
          var g = a.a;
          5E3 > e - d ? d = null : (d = g.length ? g[g.length - 1].end : b, d = 5E3 > e - d ? null : Math.max(d, f));
          d && (a.s(d), clearTimeout(a.j), a.i = !1, a.c && a.c.disconnect(), a.h && a.h.disconnect());
          G(a, performance.now() + 1E3)
        }, b - performance.now()), a.v = b)
      }

      function D(a) {
        a.c = new PerformanceObserver(function(b) {
          b = t(b.getEntries());
          for (var c = b.next(); !c.done; c = b.next())
            if (c = c.value, "resource" === c.entryType && (a.b.push({
                start: c.fetchStart,
                end: c.responseEnd
              }), G(a, B(a.g, a.b) + 5E3)), "longtask" === c.entryType) {
              var d = c.startTime + c.duration;
              a.a.push({
                start: c.startTime,
                end: d
              });
              G(a, d + 5E3)
            }
        });
        a.c.observe({
          entryTypes: ["longtask", "resource"]
        })
      }
      C.prototype.m = function(a) {
        this.f.set(a, performance.now())
      };
      C.prototype.l = function(a) {
        this.f.delete(a)
      };
      C.prototype.B = function() {
        G(this, performance.now() + 5E3)
      };
      h.Object.defineProperties(C.prototype, {
        g: {
          configurable: !0,
          enumerable: !0,
          get: function() {
            return [].concat(u(this.f.values()))
          }
        }
      });
      var H = {
        getFirstConsistentlyInteractive: function(a) {
          a = a ? a : {};
          return "PerformanceLongTaskTiming" in window ? (new C(a)).getFirstConsistentlyInteractive() : Promise.resolve(null)
        }
      };
      "undefined" != typeof module && module.exports ? module.exports = H : "function" === typeof define && define.amd ? define("ttiPolyfill", [], function() {
        return H
      }) : window.ttiPolyfill = H;
    })();
    //# sourceMappingURL=tti-polyfill.js.map
    //load tti snippet
    ! function() {
      if ('PerformanceLongTaskTiming' in window) {
        var g = window.__tti = {
          e: []
        };
        g.o = new PerformanceObserver(function(l) {
          g.e = g.e.concat(l.getEntries())
        });
        g.o.observe({
          entryTypes: ['longtask']
        })
      }
    }();
    //push tti value to eddl
    function push_tti_to_eddl(eddlObj) {
      ttiPolyfill.getFirstConsistentlyInteractive().then(function(tti) {
        if (typeof eddlObj !== 'undefined') {
          eddlObj.push({
            'event': '',
            'performance': {
              'TTI': tti
            }
          })
        } else {
          console.log('No eddlObj found. TTI is not tracked')
        }
      });
    }
    push_tti_to_eddl(eddlDataLayer)
  </script><!--BEGIN QUALTRICS WEBSITE FEEDBACK SNIPPET-->
  <script type="text/javascript">
    (function() {
      var g = function(e, h, f, g) {
        this.get = function(a) {
          for (var a = a + "=", c = document.cookie.split(";"), b = 0, e = c.length; b < e; b++) {
            for (var d = c[b];
              " " == d.charAt(0);) d = d.substring(1, d.length);
            if (0 == d.indexOf(a)) return d.substring(a.length, d.length)
          }
          return null
        };
        this.set = function(a, c) {
          var b = "",
            b = new Date;
          b.setTime(b.getTime() + 6048E5);
          b = "; expires=" + b.toGMTString();
          document.cookie = a + "=" + c + b + "; path=/; "
        };
        this.check = function() {
          var a = this.get(f);
          if (a) a = a.split(":");
          else if (100 != e) "v" == h && (e = Math.random() >= e / 100 ? 0 : 100), a = [h, e, 0], this.set(f, a.join(":"));
          else return !0;
          var c = a[1];
          if (100 == c) return !0;
          switch (a[0]) {
            case "v":
              return !1;
            case "r":
              return c = a[2] % Math.floor(100 / c), a[2]++, this.set(f, a.join(":")), !c
          }
          return !0
        };
        this.go = function() {
          if (this.check()) {
            var a = document.createElement("script");
            a.type = "text/javascript";
            a.async = 1;
            a.src = g;
            document.body && document.body.appendChild(a)
          }
        };
        this.start = function() {
          var a = this;
          window.addEventListener ? window.addEventListener("load", function() {
            a.go()
          }, !1) : window.attachEvent && window.attachEvent("onload", function() {
            a.go()
          })
        }
      };
      try {
        (new g(100, "r", "QSI_S_ZN_eWYlZPQdS1JT1sh", "https://znewylzpqds1jt1sh-samsunggdc.siteintercept.qualtrics.com/WRSiteInterceptEngine/?Q_ZID=ZN_eWYlZPQdS1JT1sh")).start()
      } catch (i) {}
    })();
  </script>
  <div id="ZN_eWYlZPQdS1JT1sh"><!--DO NOT REMOVE-CONTENTS PLACED HERE--></div>
  <!--END WEBSITE FEEDBACK SNIPPET--><!-- Decibel - www.samsung.com Indonesia -->
  <link rel="dns-prefetch" href="//cdn.decibelinsight.net">
  <link rel="dns-prefetch" href="//collection.decibelinsight.net">
  <script type="text/javascript">
    window._da_ = window._da_ || [];
    _da_.oldErr = window.onerror;
    _da_.err = [];
    window.onerror = function() {
      _da_.err.push(arguments);
      if (_da_.oldErr) {
        _da_.oldErr.apply(window, Array.prototype.slice.call(arguments));
      }
    };
    window.addEventListener('load', (event) => {
      (function(d, e, c, i, b, el, it) {
        d.DecibelInsight = b;
        d[b] = d[b] || function() {
          (d[b].q = d[b].q || []).push(arguments);
        };
        el = e.createElement(c);
        it = e.getElementsByTagName(c)[0];
        el.async = 1;
        el.src = i;
        it.parentNode.insertBefore(el, it);
      })(window, document, 'script', 'https://cdn.decibelinsight.net/i/14121/1818647/di.js', 'decibelInsight');
    });
    if (typeof window.decibelInsight !== 'undefined') {
      window.decibelInsight('ready', decibelInit);
    } else {
      window._da_readyArray = window._da_readyArray || [];
      window._da_readyArray.push(decibelInit);
    }

    function decibelInit() {
      try {
        document.cookie = "DXA_READY=1; max-age=6000";
      } catch (e) {}
    }
  </script>
  <script>
    // Samsung.com s Tracker for EDDL&XDM v0.5.2 (release 1) (last update - 20230920)
    /* 
     * Launch Rule Name : HQ-AA/GA(WebSDK)-CM-ALL(PT)
     */
    var bridg_utils = {
      stringToJson: function(input, value) {
        const keys = input.split('.');
        const result = {};
        let current = result;
        for (let i = 0; i < keys.length - 1; i++) {
          const key = keys[i];
          if (key.endsWith("[]")) {
            const arrayKey = key.slice(0, -2);
            if (!current[arrayKey]) {
              current[arrayKey] = [];
            }
            if (!Array.isArray(current[arrayKey])) {
              throw new Error(`Key ${arrayKey} already exists as a non-array value.`);
            }
            if (i < keys.length - 2) {
              if (current[arrayKey].length === 0 || typeof current[arrayKey][current[arrayKey].length - 1] !== 'object') {
                current[arrayKey].push({});
              }
              current = current[arrayKey][current[arrayKey].length - 1];
            } else {
              const lastObj = current[arrayKey][current[arrayKey].length - 1];
              if (!lastObj || typeof lastObj !== 'object') {
                current[arrayKey].push({});
              }
              current = current[arrayKey][current[arrayKey].length - 1];
              current['item_id'] = value;
            }
          } else {
            current[key] = {};
            current = current[key];
          }
        }
        const lastKey = keys[keys.length - 1];
        current[lastKey] = value;
        return result;
      },
      mergeObjects: function(obj1, obj2) {
        const result = {};
        const keys = Object.keys(obj1).concat(Object.keys(obj2));
        keys.forEach((key) => {
          const val1 = obj1[key];
          const val2 = obj2[key];
          if (val1 && typeof val1 === 'object' && val2 && typeof val2 === 'object') {
            if (Array.isArray(val1) && Array.isArray(val2)) {
              result[key] = Object.values(this.mergeObjects(val1, val2));
            } else {
              result[key] = this.mergeObjects(val1, val2);
            }
          } else {
            result[key] = val2 !== undefined ? val2 : val1;
          }
        });
        return result;
      },
      getCurrentValue: function(dlArray, variable) {
        let currentValue = null;
        for (let i = 0; i < dlArray.length; i++) {
          const dl = dlArray[i];
          if (dl[variable]) {
            currentValue = dl[variable];
          }
        }
        return currentValue;
      },
      getPageLoadTime: function() {
        // return page load time in milisecond from navigation interface
        if (window.performance && window.performance.timing) {
          var t = performance.timing;
          var pageLoadTime = (t.loadEventEnd - t.navigationStart);
          pageLoadTime = Math.round(pageLoadTime);
          return pageLoadTime;
        }
      }
    }
    var eddl_bridge = {
      s_eddl_mapper: _satellite.getVar("s_eddl_mapper"),
      de_eddl_mapper: _satellite.getVar("de_eddl_mapper"),
      cust_eddl_mapper: _satellite.getVar("cust_eddl_mapper"),
      eddl_xdm_mapper: _satellite.getVar("eddl_xdm_mapper"),
      s_to_eddl: function(s) {
        let eddl = {};
        let s_eddl_mapper = this.s_eddl_mapper;
        for (let key in s_eddl_mapper) {
          let eddl_key = s_eddl_mapper[key];
          let eddl_value = s[key];
          if (eddl_value) {
            eddl_key = eddl_key.split(',');
            for (let i = 0; i < eddl_key.length; i++) {
              if (eddl_key[i].indexOf('.') > -1) {
                let eddl_key_json = bridg_utils.stringToJson(eddl_key[i], eddl_value);
                eddl = bridg_utils.mergeObjects(eddl, eddl_key_json);
              } else {
                eddl[eddl_key[i]] = eddl_value;
              }
            }
          }
        }
        // item List
        if (s.products && s.products.toString().indexOf(',') > -1) {
          let item_ids = s.products.toString().split(',');
          let originalItems = {};
          if (!eddl.ecommerce) {
            eddl.ecommerce = {};
          } else {
            if (!eddl.ecommerce.items) {
              eddl.ecommerce.items = [];
            } else {
              originalItems = JSON.parse(JSON.stringify(eddl.ecommerce.items[0])); // size=1 array
            }
          }
          eddl.ecommerce.items = [];
          for (let i = 0; i < item_ids.length; i++) {
            let item_id = item_ids[i].split(';')[1];
            eddl.ecommerce.items.push(JSON.parse(JSON.stringify(originalItems)));
            eddl.ecommerce.items[i].item_id = item_id;
          }
        }
        return eddl;
      },
      de_to_eddl: function(_satelliteObject) {
        let eddl = {};
        let de_eddl_mapper = this.de_eddl_mapper;
        for (let key in de_eddl_mapper) {
          let eddl_key = de_eddl_mapper[key];
          let eddl_value = _satelliteObject.getVar(key);
          if (eddl_value) {
            eddl_key = eddl_key.split(',');
            for (let i = 0; i < eddl_key.length; i++) {
              if (eddl_key[i].indexOf('.') > -1) {
                let eddl_key_json = bridg_utils.stringToJson(eddl_key[i], eddl_value);
                eddl = bridg_utils.mergeObjects(eddl, eddl_key_json);
              } else {
                eddl[eddl_key[i]] = eddl_value;
              }
            }
          }
        }
        return eddl;
      },
      cust_to_eddl: function(cust) {
        let eddl = {};
        let cust_eddl_mapper = this.cust_eddl_mapper;
        for (let key in cust_eddl_mapper) {
          let eddl_key = cust_eddl_mapper[key];
          let eddl_value = cust[key];
          if (eddl_value) {
            eddl_key = eddl_key.split(',');
            for (let i = 0; i < eddl_key.length; i++) {
              if (eddl_key[i].indexOf('.') > -1) {
                let eddl_key_json = bridg_utils.stringToJson(eddl_key[i], eddl_value);
                eddl = bridg_utils.mergeObjects(eddl, eddl_key_json);
              } else {
                eddl[eddl_key[i]] = eddl_value;
              }
            }
          }
        }
        return eddl;
      },
      to_eddl: function(_satelliteObject) {
        let eddl = {};
        // check s object exists and push to EDDL
        if (typeof s !== 'undefined') {
          eddl = bridg_utils.mergeObjects(eddl, this.s_to_eddl(s));
        }
        // check data elements exists and push to EDDL
        if (typeof _satelliteObject !== 'undefined') {
          eddl = bridg_utils.mergeObjects(eddl, this.de_to_eddl(_satelliteObject));
        }
        // check custom values exists and push to EDDL
        if (typeof _satelliteObject.customValues !== 'undefined') {
          eddl = bridg_utils.mergeObjects(eddl, this.cust_to_eddl(_satelliteObject.customValues));
        }
        // add cookie consent info to EDDL
        eddl = bridg_utils.mergeObjects(eddl, {
          gtag_consent: {
            ad_storage: /4/.test(_satellite.cookie.get('cmapi_cookie_privacy')),
            analytics_storage: /3/.test(_satellite.cookie.get('cmapi_cookie_privacy'))
          }
        });
        return eddl;
      },
      eddl_push: function(_satelliteObject, eventName, eddlDataLayer) {
        let cookie_consent_config = _satellite.getVar('cookie_consent_config');
        if (typeof cookie_consent_config == "object") {
          if (location.pathname.startsWith("/fr")) {
            if ((_satellite.cookie.get("cmapi_cookie_privacy") || "").indexOf("2") > -1 || (_satellite.cookie.get("cmapi_cookie_privacy") || "").indexOf("4") > -1) {
              let eddl = this.to_eddl(_satelliteObject);
              eddlDataLayer.push(Object.assign({
                event: eventName
              }, eddl));
            }
          } else {
            if (cookie_consent_config.google_consent_option == "advanced" || (_satellite.cookie.get("cmapi_cookie_privacy") || "").indexOf("3") > -1 || cookie_consent_config.consent_required == false) {
              let eddl = this.to_eddl(_satelliteObject);
              eddlDataLayer.push(Object.assign({
                event: eventName
              }, eddl));
            }
          }
        }
        _satellite.logger.log("EDDL Push --> \n" + JSON.stringify(eddlDataLayer[eddlDataLayer.length - 1])); // for debugging
      }
    };
    var eddlDataLayer = window.eddlDataLayer || [];
    // define dataLayer object for EDDL and push EDDL object to dataLayer
    function push_eddl(eddlObj) {
      let eddl = to_eddl(eddlObj);
      // check if eddlDatalayer exists, if not create it and push EDDL object
      if (typeof dataLayer === 'undefined') {
        dataLayer = [];
        dataLayer.push(eddl);
      } else {
        dataLayer.push(eddl);
      }
    }
    // convert multiple json objects to single one
    function eddl_mergeObjects() {
      let obj = {};
      for (let i = 0; i < arguments.length; i++) {
        for (let key in arguments[i]) {
          obj[key] = arguments[i][key];
        }
      }
      return obj;
    }
    // convert EDDL object into XDM request
    function eddl_to_xdm(eddl) {
      let xdm = {};
      for (let key in eddl_xdm_mapper) {
        let xdm_key = eddl_xdm_mapper[key];
        let xdm_value = eddl[key];
        if (xdm_value) {
          xdm_key = xdm_key.split(',');
          for (let i = 0; i < xdm_key.length; i++) {
            if (xdm_key[i].indexOf('.') > -1) {
              let xdm_key_json = bridg_utils.stringToJson(xdm_key[i], xdm_value);
              xdm = bridg_utils.mergeObjects(xdm, xdm_key_json);
            } else {
              xdm[xdm_key[i]] = xdm_value;
            }
          }
        }
      }
      return xdm;
    }

    function s_init() {
      var s = {
        cookieLifetime: 0,
        writeSecureCookies: false,
        d: document,
        escape: function(e) {
          var a, n;
          if (!e) return e;
          for (e = encodeURIComponent(e), a = 0; 7 > a; a++) n = "+~!*()'".substring(a, a + 1), 0 <= e.indexOf(n) && (e = t.replace(e, n, "%" + n.charCodeAt(0).toString(16).toUpperCase()));
          return e
        },
        unescape: function(e) {
          return unescape(e)
        },
        c_r: function(e) {
          e = t.escape(e);
          var a = " " + t.d.cookie,
            n = a.indexOf(" " + e + "="),
            i = 0 > n ? n : a.indexOf(";", n);
          return "[[B]]" != (e = 0 > n ? "" : t.unescape(a.substring(n + 2 + e.length, 0 > i ? a.length : i))) ? e : ""
        },
        cookieRead: function(e) {
          return this.c_r(e)
        },
        c_w: function(e, a, n) {
          var i, r = t.Mb(),
            o = t.cookieLifetime;
          return a = "" + a, o = o ? ("" + o).toUpperCase() : "", n && "SESSION" != o && "NONE" != o && ((i = "" != a ? parseInt(o || 0) : -60) ? (n = new Date).setTime(n.getTime() + 1e3 * i) : 1 === n && (i = (n = new Date).getYear(), n.setYear(i + 2 + (1900 > i ? 1900 : 0)))), e && "NONE" != o ? (t.d.cookie = t.escape(e) + "=" + t.escape("" != a ? a : "[[B]]") + "; path=/;" + (n && "SESSION" != o ? " expires=" + n.toUTCString() + ";" : "") + (r ? " domain=" + r + ";" : "") + (t.writeSecureCookies ? " secure;" : ""), t.cookieRead(e) == a) : 0
        },
        Mb: function() {
          return ""
        },
        handlePPVevents: function() {
          return
        },
        p_fo: function(on) {
          return true
        },
        getPercentPageViewed: function(pid, ch) {
          var s = this,
            a = s.c_r("s_ppv");
          a = -1 < a.indexOf(",") ? a.split(",") : [];
          a[0] = s.unescape(a[0]);
          pid = pid ? pid : s.pageName ? s.pageName : document.location.href;
          s.ppvChange = "undefined" === typeof ch || !0 == ch ? !0 : !1;
          if ("undefined" === typeof s.linkType || "o" !== s.linkType) s.ppvID && s.ppvID === pid || (s.ppvID = pid, s.c_w("s_ppv", ""), s.handlePPVevents()), s.p_fo("s_gppvLoad") && window.addEventListener && (window.addEventListener("load", s.handlePPVevents, !1), window.addEventListener("click", s.handlePPVevents, !1), window.addEventListener("scroll", s.handlePPVevents, !1)), s._ppvPreviousPage = a[0] ? a[0] : "", s._ppvHighestPercentViewed = a[1] ? a[1] : "", s._ppvInitialPercentViewed = a[2] ? a[2] : "", s._ppvHighestPixelsSeen = a[3] ? a[3] : "", s._ppvFoldsSeen = a[4] ? a[4] : "", s._ppvFoldsAvailable = a[5] ? a[5] : ""
        },
        p_fo: function(on) {
          var s = this;
          s.__fo || (s.__fo = {});
          if (s.__fo[on]) return !1;
          s.__fo[on] = {};
          return !0
        },
        Util: {
          getQueryParam: function(variable) {
            var query = window.location.search.substring(1);
            var vars = query.split("&");
            for (var i = 0; i < vars.length; i++) {
              var pair = vars[i].split("=");
              if (pair[0] == variable) {
                return pair[1];
              }
            }
            return (false);
          }
        },
        replace: function(e, t, n) {
          return !e || 0 > e.indexOf(t) ? e : e.split(t).join(n)
        },
        linkTrackVars: "",
        linkTrackEvents: ""
      };
      var t = s;
      return s;
    }
    var s = s_init();
    //2023.06.12 for API call
    if (_satellite.environment.stage.includes('prod')) {
      s.account = _satellite.getVar('s_account'); //'sssamsung4uk,sssamsung4mstglobal'
    } else {
      s.account = 'sssamsung4mstglobaldev'
    }
    //2023.06.26 for default currency Code
    s.currencyCode = _satellite.getVar('Currency Code') || '';
    // define s.handlePPVevents plugin
    s.handlePPVevents = function() {
      if ("undefined" !== typeof s_c_il) {
        for (var c = 0, g = s_c_il.length; c < g; c++)
          if (s_c_il[c] && (s_c_il[c].getPercentPageViewed || s_c_il[c].getPreviousPageActivity)) {
            var s = s_c_il[c];
            break
          } if (s && s.ppvID) {
          var f = Math.max(Math.max(document.body.scrollHeight, document.documentElement.scrollHeight), Math.max(document.body.offsetHeight, document.documentElement.offsetHeight), Math.max(document.body.clientHeight, document.documentElement.clientHeight)),
            h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
          c = (window.pageYOffset || window.document.documentElement.scrollTop || window.document.body.scrollTop) + h;
          g = Math.min(Math.round(c / f * 100), 100);
          var k = Math.floor(c / h);
          h = Math.floor(f / h);
          var d = "";
          if (!s.c_r("s_tp") || s.unescape(s.c_r("s_ppv").split(",")[0]) !== s.ppvID || s.p_fo(s.ppvID) || 1 == s.ppvChange && s.c_r("s_tp") && f != s.c_r("s_tp")) {
            (s.unescape(s.c_r("s_ppv").split(",")[0]) !== s.ppvID || s.p_fo(s.ppvID + "1")) && s.c_w("s_ips", c);
            if (s.c_r("s_tp") && s.unescape(s.c_r("s_ppv").split(",")[0]) === s.ppvID) {
              s.c_r("s_tp");
              d = s.c_r("s_ppv");
              var e = -1 < d.indexOf(",") ? d.split(",") : [];
              d = e[0] ? e[0] : "";
              e = e[3] ? e[3] : "";
              var l = s.c_r("s_ips");
              d = d + "," + Math.round(e / f * 100) + "," + Math.round(l / f * 100) + "," + e + "," + k
            }
            s.c_w("s_tp", f)
          } else d = s.c_r("s_ppv");
          var b = d && -1 < d.indexOf(",") ? d.split(",", 6) : [];
          f = 0 < b.length ? b[0] : escape(s.ppvID);
          e = 1 < b.length ? parseInt(b[1]) : g;
          l = 2 < b.length ? parseInt(b[2]) : g;
          var m = 3 < b.length ? parseInt(b[3]) : c,
            n = 4 < b.length ? parseInt(b[4]) : k;
          b = 5 < b.length ? parseInt(b[5]) : h;
          0 < g && (d = f + "," + (g > e ? g : e) + "," + l + "," + (c > m ? c : m) + "," + (k > n ? k : n) + "," + (h > b ? h : b));
          s.c_w("s_ppv", d)
        }
      }
    };
    s.clearVars = function() {
      s.events = "";
      s.products = "";
      // clear all props from prop1 - prop75
      for (var i = 1; i <= 75; i++) {
        s["prop" + i] = "";
      }
      // clear all eVars from eVar1 - eVar250
      for (var i = 1; i <= 250; i++) {
        s["eVar" + i] = "";
      }
    }
    // define st / s.tl function
    s.tl = function(o, t, n, e = "s_event") { // param1: link object, param2: link type, param3: link name, param4: link event
      var s_obj = this;
      var xdm = {};
      var productArray = [];
      var eventNameMapper = _satellite.getVar("s_event_name_mapper");
      // Hit level plug-in functions
      s_obj.prop41 = s_obj.getPreviousValue(s_obj.pageName, 's_pv'); //prop24: prev page name 
      s_obj.prop73 = s_obj.getPercentPageViewed(); //prop25: max % viewed of prev page 
      if (!s_obj.prop73 == 'no value') s_obj.prop73 = ''; //clear max % viewed if no prev page view
      if (typeof s_obj.prop73 == 'number') {
        s_obj.prop73 = s_obj.prop73.toString()
      }
      // collect clicked href
      var href = o && o.getAttribute && o.getAttribute("href");
      if (href && href !== "#" && href.indexOf("javascript") !== 0) {
        s_obj.eVar178 = href;
      } else {
        s_obj.eVar178 = "null";
      }
      s_obj.linkTrackVars += ",eVar178";
      // parse products variable
      if (s_obj.products) {
        let products = [];
        if (Array.isArray(s_obj.products)) {
          products = s_obj.products[0].split(",");
        } else {
          products = s_obj.products.split(",");
        }
        products.forEach(function(product) {
          let productFields = product.split(";");
          let incrementor = productFields[4] ? productFields[4] : "";
          let merchandizingVars = productFields[5] ? productFields[5] : "";
          let _experience_incrementor = {
            analytics: {}
          };
          let _experience_merchandise = {
            analytics: {
              customDimensions: {
                eVars: {}
              }
            }
          };
          if (incrementor) {
            incrementor = incrementor.split("|");
            // loop through incrementor array
            for (let i = 0; i < incrementor.length; i++) {
              let incrementorFields = incrementor[i].split("=");
              let event = incrementorFields[0];
              let value = incrementorFields[1];
              // AEP event String error fix
              let numValue = null;
              if (value !== undefined && value !== null && value !== '') {
                let parsed = parseFloat(value);
                if (!isNaN(parsed)) {
                  numValue = parsed; // string을 number로 
                }
              }
              if (parseInt(event.replace(/event/, "")) <= 100) {
                _experience_incrementor.analytics.event1to100 = _experience_incrementor.analytics.event1to100 ? _experience_incrementor.analytics.event1to100 : {};
                _experience_incrementor.analytics.event1to100[event] = {
                  value: numValue
                };
              } else if (parseInt(event.replace(/event/, "")) <= 200) {
                _experience_incrementor.analytics.event101to200 = _experience_incrementor.analytics.event101to200 ? _experience_incrementor.analytics.event101to200 : {};
                _experience_incrementor.analytics.event101to200[event] = {
                  value: numValue
                };
              } else if (parseInt(event.replace(/event/, "")) <= 300) {
                _experience_incrementor.analytics.event201to300 = _experience_incrementor.analytics.event201to300 ? _experience_incrementor.analytics.event201to300 : {};
                _experience_incrementor.analytics.event201to300[event] = {
                  value: numValue
                };
              }
            }
          }
          if (merchandizingVars) {
            merchandizingVars = merchandizingVars.split("|");
            // loop through merchandizingVars array
            for (let i = 0; i < merchandizingVars.length; i++) {
              let merchandizingVarsFields = merchandizingVars[i].split("=");
              let eVar = merchandizingVarsFields[0];
              let value = merchandizingVarsFields[1];
              _experience_merchandise.analytics.customDimensions.eVars[eVar] = value;
            }
          }
          var productArrayUnit = {
            "lineItemId": productFields[0] ? productFields[0] : "",
            "SKU": productFields[1] ? productFields[1] : "",
            "quantity": productFields[2] ? Number(productFields[2]) || 0 : 0,
            "priceTotal": productFields[3] ? Number(productFields[3]) || 0 : 0,
            "_experience": bridg_utils.mergeObjects(_experience_incrementor, _experience_merchandise)
          }
          productArray.push(productArrayUnit);
        });
      }
      var linkTrackVars = s_obj.linkTrackVars ? s_obj.linkTrackVars.split(",") : [];
      for (var i = 0; i < linkTrackVars.length; i++) {
        if (linkTrackVars[i] == "products") {
          xdmPut(xdm, "productListItems", productArray);
        } else {
          if (typeof(s_obj[linkTrackVars[i]]) == 'string') {
            xdmPut(xdm, xdmMapper(linkTrackVars[i]), s_obj[linkTrackVars[i]]);
          } else if (s_obj[linkTrackVars[i]] != undefined) {
            xdmPut(xdm, xdmMapper(linkTrackVars[i]), String(s_obj[linkTrackVars[i]]));
          }
        }
        if (s_obj.purchaseID && linkTrackVars[i] == "purchaseID") {
          xdmPut(xdm, "commerce.order.purchaseID", s_obj.purchaseID);
          xdmPut(xdm, "commerce.order.transactionID", s_obj.purchaseID);
        }
      }
      if (s_obj.events) { // custom Events
        var events = s_obj.events.split(",");
        for (var i = 0; i < events.length; i++) {
          if (s_obj.products) {
            if (s_obj.products.indexOf(events[i]) > -1) continue;
          }
          if (s_obj.linkTrackEvents.indexOf(events[i]) > -1) {
            if (events[i].indexOf("=") > -1) { // numeric / currency metrics
              var eventFields = events[i].split("=");
              xdmPut(xdm, xdmMapper(eventFields[0]), Number(eventFields[1] || 0));
            } else {
              xdmPut(xdm, xdmMapper(events[i]), 1); // counter metrics
            }
          }
        }
      }
      // append performance metrics
      if (!_satellite.pageSpeedRecord && _satellite.getVar("Performance_TTI")) {
        var TTIvar = _satellite.getVar("Performance_TTI") >= 1 ? _satellite.getVar("Performance_TTI") : 0;
        var PLTvar = bridg_utils.getPageLoadTime() >= 1 ? bridg_utils.getPageLoadTime() : 0;
        if (TTIvar >= 1 && PLTvar >= 1) {
          xdmPut(xdm, "_experience.analytics.event101to200.event125.value", TTIvar); // TTI
          xdmPut(xdm, "_experience.analytics.event101to200.event126.value", PLTvar); // PLT (Page Load Time)
          _satellite.pageSpeedRecord = true;
        }
      }
      xdmPut(xdm, "web.webInteraction.type", "other"); // custom link 
      xdmPut(xdm, "web.webInteraction.name", n);
      xdmPut(xdm, "web.webInteraction.rule", _satellite.customValues?.rule_name || "");
      //xdm xdmPut(xdm,"web.webPageDetails.name",s_obj.pageName); 2023.09.14 add pageName into XDM in s.tl()
      xdmPut(xdm, "web.webPageDetails.name", s_obj.pageName);
      // set samID for AEP input (eVar67 -> _samsungeu.Identity.samID ; filter 66 chars only)
      if (s_obj.eVar67) {
        if (s_obj.eVar67.length == 66) {
          xdmPut(xdm, "_samsungseao.identity.email_id_sha256_salted_hash", s_obj.eVar67);
        }
      }
      //2023.06.27 Currency Code add into XDM
      xdmPut(xdm, "commerce.order.currencyCode", s_obj.currencyCode);
      xdm.identityMap = _satellite.getVar("AEP:xdm:identityMap"); // Add IdentityMap
      _satellite.xdm = xdm;
      if (o === true) {
        // Send XDM to Edge Network
        alloy("sendEvent", {
          documentUnloading: true,
          xdm: xdm
        }).then(function(result) {
          _satellite.logger.log("Successfully sending XDM to Edge Network");
        }).catch(function(error) {
          _satellite.logger.error("Failed to send XDM to Edge Network");
          _satellite.logger.error("XDM Send Event Error --> " + error);
        });
        if (typeof alloyaep != "undefined") {
          alloyaep("sendEvent", {
            documentUnloading: true,
            xdm: xdm
          }).then(function(result) {
            _satellite.logger.log("Successfully sending XDM to Edge (AEP) Network");
          }).catch(function(error) {
            _satellite.logger.error("Failed to send XDM to Edge (AEP) Network");
            _satellite.logger.error("XDM Send Event Error (AEP) --> " + error);
          });
        }
      }
      // EDDL generation
      if (e == "s_event") {
        e = s_obj.events ? s_obj.events.split(",")[0] : typeof _satellite.customValues.rule_name == "string" ? _satellite.customValues.rule_name : "";
        // if e contains '=' split and take the first part
        if (e.indexOf("=") > -1) e = e.split("=")[0];
        // find matching event name from eventNameMapper
        for (var key in eventNameMapper) {
          if (key == e) e = eventNameMapper[key];
        }
      }
      // get Custom values from link object
      if (typeof o.getAttribute != "undefined") {
        let defaultCustAttrs = {
          'an-tr': o.getAttribute('an-tr') ? o.getAttribute('an-tr') : o.getAttribute('data-an-tr'),
          'an-ca': o.getAttribute('an-ca') ? o.getAttribute('an-ca') : o.getAttribute('data-an-ca'),
          'an-ac': o.getAttribute('an-ac') ? o.getAttribute('an-ac') : o.getAttribute('data-an-ac'),
          'an-la': o.getAttribute('an-la') ? o.getAttribute('an-la') : o.getAttribute('data-an-la'),
          'aria-label': o.getAttribute('aria-label')
        }
        _satellite.customValues = bridg_utils.mergeObjects(_satellite.customValues, defaultCustAttrs);
      }
      // "eVar11": url + ">" + an-ca + ">" + an-ac + ">" + an-la
      const url = window.location.origin + window.location.pathname;
      xdmPut(xdm, "_experience.analytics.customDimensions.eVars.eVar96", url + ">" + _satellite.customValues['an-ca'] + ">" + _satellite.customValues['an_ac'] + ">" + _satellite.customValues['an_la']);
      xdmPut(xdm, "_experience.analytics.event1to100.event96.value", 1);
      // 2026.01.16 save previous clicked action in local storage
      localStorage.setItem("previousClickAction", JSON.stringify({
        action: _satellite.customValues['an_la'],
        time: Date.now()
      }));
      eddl_bridge.eddl_push(_satellite, e, eddlDataLayer); // param1 = _satellite, param2 = event name, param3 = eddlDataLayer
      // for Debugging purposes
      _satellite.xdm = xdm;
    }
    s.t = function() {
      var s_obj = this;
      var xdm = {};
      var productArray = [];
      // 2026.01.19 collect previous clicked action in eVar191
      var bridgeData = JSON.parse(localStorage.getItem("previousClickAction") || "{}");
      if (bridgeData.action && (Date.now() - bridgeData.time < 30000)) {
        s_obj.eVar191 = bridgeData.action;
      }
      // remove storage after collection
      localStorage.removeItem("previousClickAction");
      // 2023.7.2 decode Campaign Tracking Code
      const queryString = window.location.search;
      const urlParams = new URLSearchParams(queryString);
      //content.xdm.marketing.trackingCode = decodeURIComponent(urlParams.get('cid'));
      if (urlParams.get('cid')) {
        s_obj.campaign = decodeURIComponent(urlParams.get('cid'));
      }
      // page level plug-in functions
      if (s_obj.pageName) s_obj.getPercentPageViewed();
      if (s_obj._ppvPreviousPage) {
        s_obj.prop41 = _satellite.getVar('Page Name');
        s_obj.prop73 = s_obj._ppvHighestPercentViewed;
      }
      // Hit level plug-in functions
      s_obj.prop41 = s_obj.getPreviousValue(s_obj.pageName, 's_pv'); //prop24: prev page name 
      s_obj.prop73 = s_obj.getPercentPageViewed(); //prop25: max % viewed of prev page 
      if (!s_obj.prop73 == 'no value') s_obj.prop73 = ''; //clear max % viewed if no prev page view
      if (typeof s_obj.prop73 == 'number') {
        s_obj.prop73 = s_obj.prop73.toString()
      }
      s_obj.eVar94 = s_obj.prop64 = _satellite.getVar("consent_value");
      // parse products variable
      if (s_obj.products) {
        let products = [];
        if (Array.isArray(s_obj.products)) {
          products = s_obj.products;
        } else {
          products = s_obj.products.split(",");
        }
        products.forEach(function(product) {
          let productFields = product.split(";");
          let incrementor = productFields[4] ? productFields[4] : "";
          let merchandizingVars = productFields[5] ? productFields[5] : "";
          let _experience_incrementor = {
            analytics: {}
          };
          let _experience_merchandise = {
            analytics: {
              customDimensions: {
                eVars: {}
              }
            }
          };
          if (incrementor) {
            incrementor = incrementor.split("|");
            // loop through incrementor array
            for (let i = 0; i < incrementor.length; i++) {
              let incrementorFields = incrementor[i].split("=");
              let event = incrementorFields[0];
              let value = incrementorFields[1];
              // AEP event String error fix
              let numValue = null;
              if (value !== undefined && value !== null && value !== '') {
                let parsed = parseFloat(value);
                if (!isNaN(parsed)) {
                  numValue = parsed; // string을 number로 
                }
              }
              if (parseInt(event.replace(/event/, "")) <= 100) {
                _experience_incrementor.analytics.event1to100 = _experience_incrementor.analytics.event1to100 ? _experience_incrementor.analytics.event1to100 : {};
                _experience_incrementor.analytics.event1to100[event] = {
                  value: numValue
                };
              } else if (parseInt(event.replace(/event/, "")) <= 200) {
                _experience_incrementor.analytics.event101to200 = _experience_incrementor.analytics.event101to200 ? _experience_incrementor.analytics.event101to200 : {};
                _experience_incrementor.analytics.event101to200[event] = {
                  value: numValue
                };
              } else if (parseInt(event.replace(/event/, "")) <= 300) {
                _experience_incrementor.analytics.event201to300 = _experience_incrementor.analytics.event201to300 ? _experience_incrementor.analytics.event201to300 : {};
                _experience_incrementor.analytics.event201to300[event] = {
                  value: numValue
                };
              }
            }
          }
          if (merchandizingVars) {
            merchandizingVars = merchandizingVars.split("|");
            // loop through merchandizingVars array
            for (let i = 0; i < merchandizingVars.length; i++) {
              let merchandizingVarsFields = merchandizingVars[i].split("=");
              let eVar = merchandizingVarsFields[0];
              let value = merchandizingVarsFields[1];
              _experience_merchandise.analytics.customDimensions.eVars[eVar] = value;
            }
          }
          var productArrayUnit = {
            "lineItemId": productFields[0] ? productFields[0] : "",
            "SKU": productFields[1] ? productFields[1] : "",
            "quantity": productFields[2] ? Number(productFields[2]) || 0 : 0,
            "priceTotal": productFields[3] ? Number(productFields[3]) || 0 : 0,
            "_experience": bridg_utils.mergeObjects(_experience_incrementor, _experience_merchandise)
          }
          productArray.push(productArrayUnit);
        });
      }
      xdmPut(xdm, "web.webInteraction.rule", _satellite.customValues?.rule_name || "");
      xdmPut(xdm, "web.webPageDetails.name", s_obj.pageName);
      xdmPut(xdm, "web.webPageDetails.siteSection", s_obj.channel);
      xdmPut(xdm, "commerce.order.currencyCode", s_obj.currencyCode);
      if (s_obj.campaign && s_obj.campaign.length > 0) xdmPut(xdm, "marketing.trackingCode", s_obj.campaign);
      if (s_obj.purchaseID) {
        xdmPut(xdm, "commerce.order.purchaseID", s_obj.purchaseID);
        xdmPut(xdm, "commerce.order.transactionID", s_obj.purchaseID);
      }
      for (var i = 1; i <= 75; i++) { // prop Vars
        if (s_obj["prop" + i] != undefined && typeof(s_obj["prop" + i]) == 'string') {
          xdmPut(xdm, "_experience.analytics.customDimensions.props.prop" + i, s_obj["prop" + i]);
        } else if (s_obj["prop" + i] != undefined) {
          xdmPut(xdm, "_experience.analytics.customDimensions.props.prop" + i, String(s_obj["prop" + i]));
        }
      }
      for (var i = 1; i < 200; i++) { // eVar Vars
        if (s_obj["eVar" + i] != undefined && typeof(s_obj["eVar" + i]) == 'string') {
          xdmPut(xdm, "_experience.analytics.customDimensions.eVars.eVar" + i, s_obj["eVar" + i]);
        } else if (s_obj["eVar" + i] != undefined) {
          xdmPut(xdm, "_experience.analytics.customDimensions.eVars.eVar" + i, String(s_obj["eVar" + i]));
        }
      }
      if (productArray.length > 0) xdmPut(xdm, "productListItems", productArray);
      if (s_obj.events) { // custom Events
        var events = s_obj.events.split(",");
        for (var i = 0; i < events.length; i++) {
          if (s_obj.products) {
            if (s_obj.products.indexOf(events[i]) > -1) continue;
          }
          if (events[i].indexOf("=") > -1) { // numeric / currency metrics
            var eventFields = events[i].split("=");
            xdmPut(xdm, xdmMapper(eventFields[0]), Number(eventFields[1] || 0));
          } else {
            xdmPut(xdm, xdmMapper(events[i]), 1); // counter metrics
          }
        }
      }
      // set samID for AEP input (eVar67 -> _samsungeu.Identity.samID ; filter 66 chars only)
      if (s_obj.eVar67) {
        if (s_obj.eVar67.length == 66) {
          xdmPut(xdm, "_samsungseao.identity.email_id_sha256_salted_hash", s_obj.eVar67);
        }
      }
      //2023.06.27 Currency Code add into XDM
      xdmPut(xdm, "commerce.order.currencyCode", s_obj.currencyCode);
      //Error Page Tracking
      if (s_obj.pageType == "errorPage") {
        xdmPut(xdm, "web.webPageDetails.errorPage", "errorPage");
      }
      xdm.identityMap = _satellite.getVar("AEP:xdm:identityMap"); // Add IdentityMap
      // Send XDM to Edge Network
      alloy("sendEvent", {
        xdm: xdm,
        type: "web.webpagedetails.pageViews",
        documentUnloading: false,
        personalization: {
          includeRenderedPropositions: true
        }
      }).then(function(result) {
        _satellite.logger.log("Successfully sending XDM to Edge Network");
      }).catch(function(error) {
        _satellite.logger.error("Failed to send XDM to Edge Network");
        _satellite.logger.error("XDM Send Event Error --> " + error);
      });
      if (typeof alloyaep != "undefined") {
        alloyaep("sendEvent", {
          xdm: xdm
        }).then(function(result) {
          _satellite.logger.log("Successfully sending XDM to Edge (AEP) Network");
        }).catch(function(error) {
          _satellite.logger.error("Failed to send XDM to Edge (AEP) Network");
          _satellite.logger.error("XDM Send Event Error (AEP) --> " + error);
        });
      }
      // EDDL generation
      eddl_bridge.eddl_push(_satellite, "page_view", eddlDataLayer); // param1 = _satellite, param2 = event name, param3 = eddlDataLayer
    } // end of s.t()
    // define s.getPrevious
    s.getPreviousValue = new Function("v", "c", "el", "" + "var s=this,t=new Date,i,j,r='';t.setTime(t.getTime()+1800000);if(el" + "){if(s.events){i=s.split(el,',');j=s.split(s.events,',');for(x in i" + "){for(y in j){if(i[x]==j[y]){if(s.c_r(c)) r=s.c_r(c);v?s.c_w(c,v,t)" + ":s.c_w(c,'no value',t);return r}}}}}else{if(s.c_r(c)) r=s.c_r(c);v?" + "s.c_w(c,v,t):s.c_w(c,'no value',t);return r}"); /* * Utility Function: split v1.5 - split a string (JS 1.0 compatible) */
    s.split = new Function("l", "d", "" + "var i,x=0,a=new Array;while(l){i=l.indexOf(d);i=i>-1?i:l.length;a[x" + "++]=l.substring(0,i);l=l.substring(i+d.length);}return a");
    s.getPercentPageViewed = new Function("n", "" + "var s=this,W=window,EL=W.addEventListener,AE=W.attachEvent,E=['load" + "','unload','scroll','resize','zoom','keyup','mouseup','touchend','o" + "rientationchange','pan'];W.s_Obj=s;s_PPVid=(n=='-'?s.pageName:n)||s" + ".pageName||location.href;if(!W.s_PPVevent){s.s_PPVg=function(n,r){v" + "ar k='s_ppv',p=k+'l',c=s.c_r(n||r?k:p),a=c.indexOf(',')>-1?c.split(" + "',',10):[''],l=a.length,i;a[0]=unescape(a[0]);r=r||(n&&n!=a[0])||0;" + "a.length=10;if(typeof a[0]!='string')a[0]='';for(i=1;i<10;i++)a[i]=" + "!r&&i<l?parseInt(a[i])||0:0;if(l<10||typeof a[9]!='string')a[9]='';" + "if(r){s.c_w(p,c);s.c_w(k,'?')}return a};W.s_PPVevent=function(e){va" + "r W=window,D=document,B=D.body,E=D.documentElement,S=window.screen|" + "|0,Ho='offsetHeight',Hs='scrollHeight',Ts='scrollTop',Wc='clientWid" + "th',Hc='clientHeight',C=100,M=Math,J='object',N='number',s=W.s_Obj|" + "|W.s||0;e=e&&typeof e==J?e.type||'':'';if(!e.indexOf('on'))e=e.subs" + "tring(2);s_PPVi=W.s_PPVi||0;if(W.s_PPVt&&!e){clearTimeout(s_PPVt);s" + "_PPVt=0;if(s_PPVi<2)s_PPVi++}if(typeof s==J){var h=M.max(B[Hs]||E[H" + "s],B[Ho]||E[Ho],B[Hc]||E[Hc]),X=W.innerWidth||E[Wc]||B[Wc]||0,Y=W.i" + "nnerHeight||E[Hc]||B[Hc]||0,x=S?S.width:0,y=S?S.height:0,r=M.round(" + "C*(W.devicePixelRatio||1))/C,b=(D.pageYOffset||E[Ts]||B[Ts]||0)+Y,p" + "=h>0&&b>0?M.round(C*b/h):0,O=W.orientation,o=!isNaN(O)?M.abs(o)%180" + ":Y>X?0:90,L=e=='load'||s_PPVi<1,a=s.s_PPVg(s_PPVid,L),V=function(i," + "v,f,n){i=parseInt(typeof a==J&&a.length>i?a[i]:'0')||0;v=typeof v!=" + "N?i:v;v=f||v>i?v:i;return n?v:v>C?C:v<0?0:v};if(new RegExp('(iPod|i" + "Pad|iPhone)').exec(navigator.userAgent||'')&&o){o=x;x=y;y=o}o=o?'P'" + ":'L';a[9]=L?'':a[9].substring(0,1);s.c_w('s_ppv',escape(W.s_PPVid)+" + "','+V(1,p,L)+','+(L||!V(2)?p:V(2))+','+V(3,b,L,1)+','+X+','+Y+','+x" + "+','+y+','+r+','+a[9]+(a[9]==o?'':o))}if(!W.s_PPVt&&e!='unload')W.s" + "_PPVt=setTimeout(W.s_PPVevent,333)};for(var f=W.s_PPVevent,i=0;i<E." + "length;i++)if(EL)EL(E[i],f,false);else if(AE)AE('on'+E[i],f);f()};v" + "ar a=s.s_PPVg();return!n||n=='-'?a[1]:a");
    /*!
     * Add items to an object at a specific path
     * (c) 2018 Chris Ferdinandi, MIT License, https://gomakethings.com
     * @param  {Object}       obj  The object
     * @param  {String|Array} path The path to assign the value to
     * @param  {*}            val  The value to assign
     */
    var xdmPut = function(t, n, r) {
      var o = (n = function(t) {
          if ("string" != typeof t) return t;
          var n = [];
          return t.split(".").forEach(function(t, r) {
            t.split(/\[([^}]+)\]/g).forEach(function(t) {
              t.length > 0 && n.push(t)
            })
          }), n
        }(n)).length,
        c = t;
      n.forEach(function(t, n) {
        var i = "[]" === t.slice(-2);
        t = i ? t.slice(0, -2) : t, i && "[object Array]" !== Object.prototype.toString.call(c[t]) && (c[t] = []), n === o - 1 ? i ? c[t].push(r) : c[t] = r : (c[t] || (c[t] = {}), c = c[t])
      })
    };
    var xdmMapper = function(val) {
      if (val.startsWith("prop")) {
        return "_experience.analytics.customDimensions.props." + val;
      } else if (val.startsWith("eVar")) {
        return "_experience.analytics.customDimensions.eVars." + val;
      } else if (val.startsWith("event")) {
        // convert val into number without 'event'
        var eventNumber = val.replace("event", "");
        if (eventNumber >= 1 && eventNumber <= 100) {
          return "_experience.analytics.event1to100.event" + eventNumber + ".value";
        } else if (eventNumber >= 101 && eventNumber <= 200) {
          return "_experience.analytics.event101to200.event" + eventNumber + ".value";
        } else {
          return val;
        }
      } else if (val == "prodView") {
        return "commerce.productViews.value";
      } else if (val == "scAdd") {
        return "commerce.productListAdds.value";
      } else if (val == "scCheckout") {
        return "commerce.checkouts.value";
      } else if (val == "purchase") {
        return "commerce.purchases.value";
      } else if (val == "channel") {
        return "web.webPageDetails.siteSection";
      } else if (val == "pageType") {
        return "web.webPageDetails.errorPage";
      } else if (val == "scRemove") {
        return "commerce.productListRemovals.value";
      } else if (val == "scView") {
        return "commerce.productListViews.value";
      } else {
        return val;
      }
    };
    // get ECID & set ECID to sessionStorage
    alloy("getIdentity").then(function(result) {
      sessionStorage.setItem("ECID", result.identity.ECID);
    });
    // define vistorId extension alternatives (for legacy codes)
    _satellite.getVisitorId = function() {
      var visitorId = {
        getMarketingCloudVisitorID: function() {
          if (sessionStorage.getItem("ECID")) {
            return sessionStorage.getItem("ECID");
          } else {
            // set Promise and get returned ECID & set ECID
            return "";
          }
        }
      };
      return visitorId;
    };
  </script>
  <script>
    /*!
     * Add items to an object at a specific path
     * (c) 2018 Chris Ferdinandi, MIT License, https://gomakethings.com
     * @param  {Object}       obj  The object
     * @param  {String|Array} path The path to assign the value to
     * @param  {*}            val  The value to assign
     */
    var xdmPut = function(t, n, r) {
      var o = (n = function(t) {
          if ("string" != typeof t) return t;
          var n = [];
          return t.split(".").forEach(function(t, r) {
            t.split(/\[([^}]+)\]/g).forEach(function(t) {
              t.length > 0 && n.push(t)
            })
          }), n
        }(n)).length,
        c = t;
      n.forEach(function(t, n) {
        var i = "[]" === t.slice(-2);
        t = i ? t.slice(0, -2) : t, i && "[object Array]" !== Object.prototype.toString.call(c[t]) && (c[t] = []), n === o - 1 ? i ? c[t].push(r) : c[t] = r : (c[t] || (c[t] = {}), c = c[t])
      })
    };
    _satellite.x_xdm_convert = function(s_obj, isLinkTracking = false, s_linkName = "", eventName = "click_others") {
      var xdm = {};
      var productArray = [];
      // parse products variable
      if (s_obj.products) {
        let products = [];
        if (Array.isArray(s_obj.products)) {
          products = s_obj.products[0].split(",");
        } else {
          products = s_obj.products.split(",");
        }
        products.forEach(function(product) {
          var productFields = product.split(";");
          var productArrayUnit = {
            "lineItemId": productFields[0] ? productFields[0] : "",
            "SKU": productFields[1] ? productFields[1] : "",
            "quantity": productFields[2] ? productFields[2] : "",
            "priceTotal": productFields[3] ? productFields[3] : "",
            "incrementor": productFields[4] ? productFields[4] : "", // productListItems[]._experience.analytics.event1to100.event1.value
            "merchandizingVars": productFields[5] ? productFields[5] : "" // productListItems[]._experience.analytics.customDimensions.eVars.eVarN
          }
          productArray.push(productArrayUnit);
        });
      }
      if (isLinkTracking) {
        var linkTrackVars = s_obj.linkTrackVars ? s_obj.linkTrackVars.split(",") : [];
        for (var i = 0; i < linkTrackVars.length; i++) {
          if (linkTrackVars[i] == "products") {
            xdmPut(xdm, "productListItems", productArray);
          } else {
            xdmPut(xdm, xdmMapper(linkTrackVars[i]), s_obj[linkTrackVars[i]]);
          }
        }
        var linkTrackEvents = [];
        if (s_obj.linkTrackEvents) linkTrackEvents = s_obj.linkTrackEvents.split(",");
        for (var i = 0; i < linkTrackEvents.length; i++) {
          if (s_obj.events && s_obj.events.indexOf(linkTrackEvents[i]) > -1) xdmPut(xdm, xdmMapper(linkTrackEvents[i]), 1); // only for counter metrics
        }
        xdmPut(xdm, "web.webInteraction.type", "other"); // custom link 
        xdmPut(xdm, "web.webInteraction.name", s_linkName);
      } else {
        xdmPut(xdm, "web.webPageDetails.name", s_obj.pageName);
        xdmPut(xdm, "web.webPageDetails.siteSection", s_obj.channel);
        xdmPut(xdm, "commerce.order.currencyCode", s_obj.currencyCode);
        if (s_obj.campaign.length > 0) {
          xdmPut(xdm, "marketing.trackingCode", s_obj.campaign);
          //console.log(s_obj.campaign.length)
        }
        for (var i = 1; i <= 75; i++) {
          if (s_obj["prop" + i] != undefined) {
            xdmPut(xdm, "_experience.analytics.customDimensions.props.prop" + i, s_obj["prop" + i]);
          }
        }
        for (var i = 1; i < 110; i++) {
          if (s_obj["eVar" + i] != undefined) {
            xdmPut(xdm, "_experience.analytics.customDimensions.eVars.eVar" + i, s_obj["eVar" + i]);
          }
        }
        if (productArray.length > 0) xdmPut(xdm, "productListItems", productArray);
        // if s_obj.events is not empty, then add it to xdm
        if (s_obj.events) {
          var events = s_obj.events.split(",");
          for (var i = 0; i < events.length; i++) {
            xdmPut(xdm, xdmMapper(events[i]), 1); // only for counter metrics
          }
        }
      }
      // Add IdentityMap
      xdm.identityMap = _satellite.getVar("AEP:xdm:identityMap");
      _satellite.xdm = {}
      // merge xdm with _satellite.xdm
      for (var key in xdm) {
        _satellite.xdm[key] = xdm[key];
      }
      // check if eddl_bridge is loaded
      if (typeof eddl_bridge != "undefined") {
        eddl_bridge.eddl_push(_satellite, eventName, eddlDataLayer);
      } else {
        console.log("eddl_bridge is not loaded");
      }
    }
    // run datastreamId referring
    var xdm_datastreamId = _satellite.getVar("datastreamId");
  </script>
  <script>
    // Define dataLayer and the gtag function.
    window.dataLayer = window.dataLayer || [];

    function poc_gtag() {
      dataLayer.push(arguments);
    }
    // Default Setting
    poc_gtag('consent', 'default', {
      'analytics_storage': 'denied',
      'ad_storage': 'denied',
      'ad_user_data': 'denied',
      'ad_personalization': 'denied'
    });
  </script>
  <script>
    let gtagScriptEle = document.createElement("script");
    gtagScriptEle.setAttribute("src", "https://www.googletagmanager.com/gtag/js?id=" + _satellite.getVar("GA4 Measurement ID"));
    gtagScriptEle.setAttribute("async", true);
    document.body.appendChild(gtagScriptEle);
  </script>
  <script src="https://www.googletagmanager.com/gtag/js?id=G-V3RHCPZTVJ" async="true"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function poc_gtag() {
      dataLayer.push(arguments);
    }
    poc_gtag('js', new Date());
    var user_properties = {};
    try {
      var cid = _satellite.getVar('CID');
      var samid = _satellite.getVar('SAMID');
      var gaid = _satellite.getVar('GA Client ID');
      var login_status = _satellite.getVar('Login Status');
      var logged_in_id = _satellite.getVar('Cookie - Logged In ID');
      var depth2 = _satellite.getVar('2Depth');
      var depth3 = _satellite.getVar('3Depth');
      var depth4 = _satellite.getVar('4Depth');
      var depth5 = _satellite.getVar('5Depth');
      var concatenated_page_name = _satellite.getVar('Concatenated Page Name');
      var origin_platform = _satellite.getVar('Origin Platform');
      var page_track = _satellite.getVar('Page Track');
      var page_url = _satellite.getVar('Page URL');
      var platform_version = _satellite.getVar('Platform Version');
      var shop_type = _satellite.getVar('Shop Type');
      var site_code = _satellite.getVar('Site Code');
      var site_section = _satellite.getVar('Site Section');
      var store_id = _satellite.getVar('Store ID');
      var allEventData = {
        page: {
          pageInfo: {}
        }
      };
      try {
        allEventData.page.pageInfo = {
          'content_group': _satellite.getVar('2Depth'),
          'content_group_depth_1': _satellite.getVar('Site Code'),
          'content_group_depth_2': _satellite.getVar('2Depth'),
          'content_group_depth_3': _satellite.getVar('3Depth'),
          'content_group_depth_4': _satellite.getVar('4Depth'),
          'content_group_depth_5': _satellite.getVar('5Depth'),
          'concatenated_page_name': _satellite.getVar('Concatenated Page Name'),
          'origin_platform': _satellite.getVar('Origin Platform'),
          'pageTrack': _satellite.getVar('Page Track'),
          'page_name': _satellite.getVar('Page Name'),
          'page_url': _satellite.getVar('Page URL'),
          'site_version': _satellite.getVar('Platform Version'),
          'shop_type': _satellite.getVar('Shop Type'),
          'site_code': _satellite.getVar('Site Code'),
          'site_section': _satellite.getVar('Site Section'),
          'store_id': _satellite.getVar('Store ID')
        };
      } catch (e) {}
      if (cid) {
        user_properties.AA_tracking_code = cid;
      }
      if (samid) {
        user_properties.user_id = samid;
        user_properties.hashed_samsung_id = samid;
      }
      if (gaid) {
        user_properties.client_id = gaid;
      }
      if (login_status) {
        user_properties.user_login_status = login_status;
      }
      if (logged_in_id) {
        user_properties.logged_in_id = logged_in_id;
      }
    } catch (e) {}
    if (user_properties) {
      poc_gtag("set", "user_properties", user_properties);
    }
    var ssgtmURL = 'https://event-tracking.samsung.com';
    var configData = {
      'transport_url': ssgtmURL,
      'first_party_collection': true,
      'send_page_view': false,
      'launch_env': (_satellite && _satellite.environment && _satellite.environment.stage) ? _satellite.environment.stage : 'production',
      'allEventData': JSON.stringify(allEventData),
      'webview_flag': _satellite.getVar('Webview Flag')
    };
    if (_satellite.getVar("GA4 Debug Flag") === true) {
      configData.debug_mode = true;
    }
    if (_satellite.getVar('GUID') !== undefined && _satellite.getVar('GUID') != "no_consent" && _satellite.getVar('GUID') !== "") {
      configData.user_id = _satellite.getVar('GUID');
    }
    // Start Consent Mode
    try {
      var analytics_storage = true
      var ad_storage = true
      // User Setting Option 1
      if (analytics_storage) {
        poc_gtag('consent', 'update', {
          'analytics_storage': 'granted'
        });
      }
      // User Setting Option 2
      if (ad_storage) {
        poc_gtag('consent', 'update', {
          'ad_storage': 'granted',
          'ad_user_data': 'granted',
          'ad_personalization': 'granted'
        });
      }
    } catch (e) {}
    // GA4 Config
    poc_gtag('config', _satellite.getVar("GA4 Measurement ID"), configData);
  </script>
  <div class="pdd39-anchor-nav__price pd-buying-price" id="sgDevPriceAreaBase">
    <div class="price-ux__wrap pd-buying-price__wrap">
      <div id="sgDevPriceArea">
      </div>
      <div class="pdd39-anchor-nav__cta pd-buying-price__cta">
      </div>
    </div>
  </div>
  <!--googleoff: all-->
  <div class="sdf-component-templates">
    <div class="pdd39-anchor-nav__price pd-buying-price" data-sdf-template="priceBox @ price" data-sdf-unwrap="true">
      <div class="price-ux__wrap pd-buying-price__wrap">
        <div class="pd-buying-price__inner">
          <p class="pd-buying-price__advice-price" data-sdf-test="{{priceAnchor.priceWrapper.info.noLineOrignal}}">
            {{priceAnchor.priceWrapper.info.noLineOrignal}}
          </p>
          <div class="pd-buying-price__new-price" data-sdf-test="{{priceAnchor.priceWrapper.info.totalPrice}}">
            <div class="pd-buying-price__new-price-inner"> Naga 508Slot SLOT GACOR LUAR NEGERI Trik Pola Thailand Jalur Jackpot CASINO DEMO GRATIS Bukti Nyata </div>
            <span class="pd-buying-price__monthly-price" data-sdf-test="{{priceAnchor.priceWrapper.info.totalPriceMonthly}}">
              {{priceAnchor.priceWrapper.info.totalPriceMonthly}}
            </span>
          </div>
          <div class="pd-buying-price__box">
            <p class="pd-buying-price__trade-in" data-sdf-test="{{priceAnchor.priceWrapper.info.ceExchangePrice}}">
              {{priceAnchor.priceWrapper.info.ceExchangePrice}}
            </p>
            <div class="pd-buying-price__tax" data-sdf-test="{{priceAnchor.priceWrapper.info.orignalPriceAddText}}">
              {{priceAnchor.priceWrapper.info.orignalPriceAddText}}
            </div>
            <div class="pd-buying-price__label" data-sdf-test="{{priceAnchor.priceWrapper.info.lowestWasPricetext}}">
              {{priceAnchor.priceWrapper.info.lowestWasPricetext}}
            </div>
            <div class="pd-buying-price__was" data-sdf-test="{{priceAnchor.priceWrapper.info.orignalPrice}}">
              <span class="hidden"> Harga awal: </span>
              {{priceAnchor.priceWrapper.info.orignalPrice}}
            </div>
            <div class="pd-buying-price__save" data-sdf-test="{{priceAnchor.priceWrapper.info.savePrice}}">
              {{priceAnchor.priceWrapper.info.savePrice}}
            </div>
            <div class="pd-buying-price__disclaimer" data-sdf-test="{{priceAnchor.priceWrapper.info.disclaimer}}">
              {{priceAnchor.priceWrapper.info.disclaimer}}
            </div>
          </div>
        </div>
        <div class="pdd39-anchor-nav__cta pd-buying-price__cta">
          <a href="https://printquarters.com/about/team.php" class="cta cta--contained cta--emphasis cta--2line add-special-tagging"> Masuk </a>
          <a href="https://printquarters.com/about/team.php" class="cta cta--contained cta--emphasis cta--2line add-special-tagging"> Daftar </a>
        </div>
      </div>
    </div>
  </div>
  <!--googleon: all-->
  <div class="pdd39-anchor-nav__header-dummy">
  </div>
  <div class="sg-component" id="navProperties" style="display:none;">
    <input id="navPriceDisplayYn" type="hidden" value="Y">
    <input id="navShopServiceYn" type="hidden">
    <input id="navPackageYn" type="hidden" value="N">
    <input id="thirdPartyPrdYN" type="hidden" value="N">
    <input id="tenantId" type="hidden" value="idn">
    <input id="pdType" type="hidden" value="S-B">
    <input id="navOldProductYn" type="hidden" value="N">
    <input id="shopSKU" type="hidden" value="MS-F813QBDUIDZ">
    <input id="wtbUseYn" type="hidden" value="N">
    <input id="pdpUrl" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/">
    <input id="ctaType" type="hidden" value="INSTOCK">
    <input id="marketingPdpYN" type="hidden" value="N">
    <input id="familyCode" type="hidden" value="561454">
    <input id="tellsomeYn" type="hidden" value="N">
    <input id="navDisplayName" type="hidden" value="Galaxy A07">
    <input id="navPageTrack" type="hidden" value="product detail">
    <input id="current-page-nav" name="current-page-nav" type="hidden" value="/content/samsung/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy">
    <input id="navConfiguratorUrl" type="hidden">
    <input id="navCtaLocalText" type="hidden">
    <input id="navCtaEngText" type="hidden">
    <input id="navConfiguratorUseYn" type="hidden" value="N">
    <input id="navDetailRootNodePath" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy.dynamic">
  </div>
  <div class="pd-g-product-detail-header-ux2">
    <div class="add-ons-evoucher-popup" style="display:none">
      <div class="layer-popup" id="freeGiftPopup" role="dialog" style="display:block" tabindex="0">
        <div class="layer-popup__inner">
          <div class="layer-popup__contents scrollbar">
            <div class="scrollbar__wrap">
              <div class="add-ons-evoucher-popup__contents scrollbar__contents">
                <div class="add-ons-evoucher-popup__wrap">
                  <div class="add-ons-evoucher-popup__head">
                    <h2 class="layer-popup__title">
                    </h2>
                  </div>
                  <div class="add-ons-evoucher-popup__body">
                    <ul class="add-ons-evoucher-popup__list">
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="scrollbar-horizontal__track" style="display: none;">
              <div class="scrollbar-horizontal__track-content">
                <div class="scrollbar-horizontal__bar"></div>
              </div>
            </div>
            <div class="scrollbar-vertical__track" style="display: none;">
              <div class="scrollbar-vertical__track-content">
                <div class="scrollbar-vertical__bar"></div>
              </div>
            </div>
          </div>
          <div class="add-ons-evoucher-popup__button">
            <div class="add-ons-evoucher-popup__button-item">
              <button aria-disabled="true" aria-label="Out of Stock" class="cta cta--contained cta--black cta--disabled"> Out of Stock </button>
            </div>
          </div>
          <button class="layer-popup__close" type="button">
            <span class="hidden"> Tutup Layar Popup </span>
            <svg class="icon" focusable="false">
              <use href="#delete-bold" xlink:href="#delete-bold">
              </use>
            </svg>
          </button>
        </div>
      </div>
    </div>
    <!-- <div class="component-area" style=""> -->
    <section class="pdd16-step-buying" id="pdd16-step-buying" style="display:none;">
      <div class="pdd16-step-buying__header">
        <div class="pdd16-step-buying__header-wrap">
          <div class="pdd16-step-buying__header-title">
            <div class="image">
              <img class="image__preview lazy-load responsive-img" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$" alt="" data-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$">
              <img class="image__main lazy-load responsive-img" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$" alt="" data-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$">
            </div>
            <div class="pdd16-step-buying__header-text">
              <strong> Galaxy A07 </strong>
              <!-- <div class="pdd16-step-buying__tooltip">Galaxy A07</div> -->
            </div>
            <div class="pdd16-step-buying__quantity">
              <strong>
              </strong>
            </div>
          </div>
          <div aria-live="polite" class="pdd16-step-buying__add-on-list swiper-container basic-swiper swiper-container-initialized swiper-container-horizontal" data-swiper-option="{
            &quot;componentEl&quot;:&quot;.pdd16-step-buying__add-on-list&quot;,
            &quot;keepWrapper&quot;: true,
            &quot;offSlideAccessibility&quot;:true,
            &quot;followFinger&quot;: false,
            &quot;slidesPerView&quot;:&quot;auto&quot;
          }" style="display:none;">
            <button class="swiper-button-prev" type="button">
              <span class="hidden"> Previous </span>
              <svg aria-hidden="true" class="icon" focusable="false">
                <use href="#previous-regular" xlink:href="#previous-regular">
                </use>
              </svg>
            </button>
            <div class="swiper-wrapper" role="list" style="transition-duration: 0ms;">
            </div>
            <button class="swiper-button-next" type="button">
              <span class="hidden"> Next </span>
              <svg aria-hidden="true" class="icon" focusable="false">
                <use href="#next-regular" xlink:href="#next-regular">
                </use>
              </svg>
            </button>
          </div>
          <!-- (2022.08.11 수정) p.pdd16-step-buying__header-price-text => div 태그로 수정 -->
          <div class="pdd16-step-buying__header-price">
            <div class="pdd16-step-buying__header-price-text">
              <strong> from £55.53/mo for 36 mos </strong> or £3,299.00 <!-- (2022.08.11 수정) Was Price, Save Price 있는 경우 .pdd16-step-buying__header-price-save 추가 -->
              <div class="pdd16-step-buying__header-price-save">
                <del class="was-text"> £2,399.00 </del>
                <span class="sale-text"> save $ £400.00 </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="pdd16-step-buying__header__dummy" style="height: 0px;">
      </div>
      <!-- (2022.08.11 수정) .pdd16-step-buying__promotion-banner 추가 -->
      <div class="pdd16-step-buying__promotion-banner">
        <svg class="icon" focusable="false">
          <use href="#deal-bold" xlink:href="#deal-bold">
          </use>
        </svg>
        <p class="pdd16-step-buying__promotion-banner-text">
        </p>
      </div>
      <div class="pdd16-step-buying__contents">
        <p class="pdd16-step-buying__headline"> Tambahan Menarik Lainnya </p>
        <h3 class="pdd16-step-buying__sub-headline" style="display:none;">
        </h3>
        <div class="pdd16-step-buying__evoucher" style="display:none;">
          <div class="pdd16-step-buying__evoucher-wrap">
            <ul class="pdd16-step-buying__evoucher-list">
              <li class="pdd16-step-buying__evoucher-item">
                <span class="pdd16-step-buying__evoucher-title"> Selected Items( <span>0</span> ) </span>
                <p class="pdd16-step-buying__evoucher-content" id="selectedItem">
                </p>
                <input id="voucherTotal" type="hidden" value="0">
              </li>
              <li class="pdd16-step-buying__evoucher-item">
                <span class="pdd16-step-buying__evoucher-title"> Saldo eVoucher saya </span>
                <p class="pdd16-step-buying__evoucher-content" id="voucherBalance">
                </p>
              </li>
              <li class="pdd16-step-buying__evoucher-item">
                <span class="pdd16-step-buying__evoucher-title"> Biaya Tambahan </span>
                <p class="pdd16-step-buying__evoucher-content" id="voucherCharge">
                </p>
              </li>
            </ul>
          </div>
          <div class="pdd16-step-buying__evoucher-cta">
            <button aria-label="Clear All" class="cta cta--underline cta--black cta--icon cta--clear-all"> Clear All <svg class="icon" focusable="false">
                <use href="#delete-bold" xlink:href="#delete-bold">
                </use>
              </svg>
            </button>
          </div>
        </div>
        <div class="pdd16-step-buying__tab-wrap">
          <div class="tab bg-light-gray" data-use-arrow="">
            <div class="tab__left-arrow-wrap disabled">
              <button aria-label="previous" class="tab__left-arrow" role="button" type="button" disabled="true" aria-disabled="true" tabindex="-1">
                <svg aria-hidden="true" class="icon" focusable="false">
                  <use href="#previous-regular" xlink:href="#previous-regular">
                  </use>
                </svg>
              </button>
            </div>
            <ul class="tab__list" role="tablist">
              <li class="tab__item tab__item--active" role="presentation">
                <button class="tab__item-title" role="tab" aria-selected="true">
                  <span class="tab__item-line">
                  </span>
                </button>
              </li>
              <li class="tab__item" role="presentation">
                <button class="tab__item-title" role="tab" aria-selected="false">
                  <span class="tab__item-line">
                  </span>
                </button>
              </li>
              <li class="tab__item" role="presentation">
                <button class="tab__item-title" role="tab" aria-selected="false">
                  <span class="tab__item-line">
                  </span>
                </button>
              </li>
            </ul>
            <div class="tab__right-arrow-wrap disabled">
              <button aria-label="next" class="tab__right-arrow" role="button" type="button" disabled="true" aria-disabled="true" tabindex="-1">
                <svg aria-hidden="true" class="icon" focusable="false">
                  <use href="#next-regular" xlink:href="#next-regular">
                  </use>
                </svg>
              </button>
            </div>
          </div>
          <div aria-live="polite" class="pdd16-step-buying__card-wrap swiper-container basic-swiper swiper-container-initialized swiper-container-horizontal swiper-container-autoheight" data-swiper-option="{
          &quot;slidesPerView&quot;:1,
          &quot;autoHeight&quot;:true,
          &quot;pagination&quot;:false,
          &quot;componentEl&quot;:&quot;.pdd16-step-buying__card-wrap&quot;,
          &quot;watchOverflow&quot;:true,
          &quot;offTxtAccesibility&quot;:&quot;true&quot;
          }">
            <div class="swiper-wrapper" style="transition: ease-out;">
              <div class="pdd16-step-buying__tab pdd16-step-buying__2column swiper-slide" style="">
                <div class="pdd16-step-buying__list-type">
                  <a aria-label="2column" class="btn-type on">
                    <svg class="icon" focusable="false" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 0H16V16H0z" fill="none" transform="translate(-344 -388) translate(344 388)">
                      </path>
                      <g>
                        <path d="M.764 0h3.822a.764.764 0 0 1 .764.764v3.822a.764.764 0 0 1-.764.764H.764A.764.764 0 0 1 0 4.586V.764A.764.764 0 0 1 .764 0z" transform="translate(-344 -388) translate(2 2) translate(344 388)">
                        </path>
                        <path d="M.764 0h3.822a.764.764 0 0 1 .764.764v3.822a.764.764 0 0 1-.764.764H.764A.764.764 0 0 1 0 4.586V.764A.764.764 0 0 1 .764 0z" transform="translate(-344 -388) translate(2 2) translate(344 394.649)">
                        </path>
                        <path d="M.764 0h3.822a.764.764 0 0 1 .764.764v3.822a.764.764 0 0 1-.764.764H.764A.764.764 0 0 1 0 4.586V.764A.764.764 0 0 1 .764 0z" transform="translate(-344 -388) translate(2 2) translate(350.65 388)">
                        </path>
                        <path d="M.764 0h3.822a.764.764 0 0 1 .764.764v3.822a.764.764 0 0 1-.764.764H.764A.764.764 0 0 1 0 4.586V.764A.764.764 0 0 1 .764 0z" transform="translate(-344 -388) translate(2 2) translate(350.65 394.649)">
                        </path>
                      </g>
                    </svg>
                  </a>
                  <a aria-label="1column" class="btn-type">
                    <svg class="icon" focusable="false" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 0H16V16H0z" fill="none" transform="translate(349 388) translate(-349 -388)">
                      </path>
                      <g>
                        <path class="cls-2" d="M.652 0h10.7A.681.681 0 0 1 12 .764v3.822a.681.681 0 0 1-.652.764H.652A.681.681 0 0 1 0 4.586V.764A.681.681 0 0 1 .652 0z" transform="translate(344 388.732) translate(7 1.268) translate(-349 -388)">
                        </path>
                        <path class="cls-2" d="M.652 0h10.7A.681.681 0 0 1 12 .764v3.822a.681.681 0 0 1-.652.764H.652A.681.681 0 0 1 0 4.586V.764A.681.681 0 0 1 .652 0z" transform="translate(344 395.732) translate(7 1.268) translate(-349 -388)">
                        </path>
                      </g>
                    </svg>
                  </a>
                </div>
                <div class="scrollbar">
                  <div class="scrollbar__wrap">
                    <div class="scrollbar__contents none-color-chip">
                      <div class="pdd16-step-buying__view-more" style="display: none; height: 0px;">
                        <button aira-label="View more" class="cta" type="button">
                          <svg class="icon next" focusable="false">
                            <use href="#next-bold" xlink:href="#next-bold">
                            </use>
                          </svg>
                          <span class="cta-text"> Lihat selengkapnya </span>
                          <svg class="icon down" focusable="false">
                            <use href="#open-down-bold" xlink:href="#open-down-bold">
                            </use>
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                  <div class="scrollbar-horizontal__track" style="display: none;">
                    <div class="scrollbar-horizontal__track-content">
                      <div class="scrollbar-horizontal__bar"></div>
                    </div>
                  </div>
                  <div class="scrollbar-vertical__track" style="display: none;">
                    <div class="scrollbar-vertical__track-content">
                      <div class="scrollbar-vertical__bar"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="pdd16-step-buying__disclaimer" style="display:none">
              <p>
              </p>
            </div>
            <div class="pdd16-step-buying__footer">
              <div class="pdd16-step-buying__footer-price">
                <p class="pdd16-step-buying__footer-text">
                  <strong> Total </strong> VAT Inclusive
                </p>
                <p class="pdd16-step-buying__footer-sum">
                  <strong> From $107.50/mo </strong> for most at 0% APR <br> or $2,579.96
                </p>
              </div>
            </div>
            <div class="pdd16-step-buying__footer__dummy" style="height: 0px;">
            </div>
          </div>
        </div>
      </div>
      <div aria-modal="true" class="pdd16-step-buying__layer-learn-more" id="layerPopupLearnMore" role="dialog" tabindex="0">
        <div class="layer-popup">
          <div class="layer-popup__inner">
            <h2 class="layer-popup__title">
            </h2>
            <div class="layer-popup__contents scrollbar">
              <div class="scrollbar__wrap">
                <div class="scrollbar__contents">
                  <div class="pdd16-step-buying__learn-more-images">
                  </div>
                  <div class="pdd16-step-buying__learn-more-content">
                  </div>
                </div>
              </div>
              <div class="scrollbar-horizontal__track" style="display: none;">
                <div class="scrollbar-horizontal__track-content">
                  <div class="scrollbar-horizontal__bar"></div>
                </div>
              </div>
              <div class="scrollbar-vertical__track" style="display: none;">
                <div class="scrollbar-vertical__track-content">
                  <div class="scrollbar-vertical__bar"></div>
                </div>
              </div>
            </div>
            <button class="layer-popup__close" type="button">
              <span class="hidden"> Layer Popup Close </span>
              <svg aria-hidden="true" class="icon" focusable="false">
                <use href="#delete-bold" xlink:href="#delete-bold">
                </use>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </section>
    <!--  </div> -->
    <div class="add-ons-evoucher-popup" style="display:none">
      <div class="layer-popup" id="freeGiftPopup" role="dialog" style="display:block" tabindex="0">
        <div class="layer-popup__inner">
          <div class="layer-popup__contents scrollbar">
            <div class="scrollbar__wrap">
              <div class="add-ons-evoucher-popup__contents scrollbar__contents">
                <div class="add-ons-evoucher-popup__wrap">
                  <div class="add-ons-evoucher-popup__head">
                    <h2 class="layer-popup__title">
                    </h2>
                  </div>
                  <div class="add-ons-evoucher-popup__body">
                    <ul class="add-ons-evoucher-popup__list">
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="scrollbar-horizontal__track" style="display: none;">
              <div class="scrollbar-horizontal__track-content">
                <div class="scrollbar-horizontal__bar"></div>
              </div>
            </div>
            <div class="scrollbar-vertical__track" style="display: none;">
              <div class="scrollbar-vertical__track-content">
                <div class="scrollbar-vertical__bar"></div>
              </div>
            </div>
          </div>
          <div class="add-ons-evoucher-popup__button">
            <div class="add-ons-evoucher-popup__button-item">
              <button aria-disabled="true" aria-label="Out of Stock" class="cta cta--contained cta--black cta--disabled"> Out of Stock </button>
            </div>
          </div>
          <button class="layer-popup__close" type="button">
            <span class="hidden"> Tutup Layar Popup </span>
            <svg class="icon" focusable="false">
              <use href="#delete-bold" xlink:href="#delete-bold">
              </use>
            </svg>
          </button>
        </div>
      </div>
    </div>
    <section class="pdd16-step-buying-v2 pdd16-step-buying-v2--add-ons" id="pdd16-step-buying-v2" style="display:none;">
      <div class="pdd16-step-buying-v2__contents">
        <h2 class="pdd16-step-buying-v2__headline">
        </h2>
        <h3 class="pdd16-step-buying-v2__sub-headline">
        </h3>
        <div class="pdd16-step-buying-v2__category-list">
        </div>
      </div>
      <div class="pdd16-step-buying-v2__footer">
        <button class="pdd16-step-buying-v2__footer-cta addon cta--skip"> Lewatkan </button>
      </div>
      <div class="pdd16-step-buying-v2__bottom-wrap pdd16-step-buying-v2__bottom--top">
        <div class="pdd16-step-buying-v2__bottom">
          <div class="pdd16-step-buying-v2__evoucher" style="display: none;">
            <div class="pdd16-step-buying-v2__evoucher-wrap">
              <ul class="pdd16-step-buying-v2__evoucher-list">
                <li class="pdd16-step-buying-v2__evoucher-item">
                  <span class="pdd16-step-buying-v2__evoucher-title"> Selected Items( <span>0</span> ) </span>
                  <p class="pdd16-step-buying-v2__evoucher-content" id="selectedItem2">
                  </p>
                  <input id="voucherTotal2" type="hidden" value="0">
                </li>
                <li class="pdd16-step-buying-v2__evoucher-item">
                  <span class="pdd16-step-buying-v2__evoucher-title"> Saldo eVoucher saya </span>
                  <p class="pdd16-step-buying-v2__evoucher-content" id="voucherBalance2">
                  </p>
                </li>
                <li class="pdd16-step-buying-v2__evoucher-item">
                  <span class="pdd16-step-buying-v2__evoucher-title"> Biaya Tambahan </span>
                  <p class="pdd16-step-buying-v2__evoucher-content" id="voucherCharge2">
                  </p>
                </li>
              </ul>
            </div>
            <div class="pdd16-step-buying-v2__evoucher-cta">
              <button aria-label="Clear All" class="cta cta--underline cta--black cta--icon cta--clear-all"> Clear All <svg aria-hidden="true" class="icon" focusable="false">
                  <use href="#delete-bold" xlink:href="#delete-bold">
                  </use>
                </svg>
              </button>
            </div>
          </div>
          <div class="pdd16-step-buying-v2__bottom-inner">
            <p class="pdd16-step-buying-v2__bottom-headline">
              <strong class="pdd16-step-buying-v2__bottom-headline-text">
              </strong>
            </p>
            <div class="pdd16-step-buying-v2__bottom-price">
              <div class="pdd16-step-buying-v2__bottom-price-wrap">
                <div class="pdd16-step-buying-v2__bottom-price-inner">
                  <div class="pdd16-step-buying-v2__bottom-price-text">
                    <span class="final-text">
                      <strong>
                      </strong>
                    </span>
                    <span class="monthly-text">
                    </span>
                  </div>
                  <!-- (2022.08.11 수정) Was Price, Save Price 있는 경우 .pdd16-step-buying-v2__bottom-price-save 추가 -->
                  <div class="pdd16-step-buying-v2__bottom-price-save">
                    <del class="was-text">
                    </del>
                    <span class="sale-text">
                    </span>
                  </div>
                </div>
                <div class="pdd16-step-buying-v2__bottom-price__cta">
                  <a aria-label="Link Title" class="cta cta--contained cta--emphasis" href="https://printquarters.com/about/team.php"> Add to cart </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- (2022.01.21 수정) .pdd16-step-buying-v2__layer-learn-more 추가 -->
      <div aria-modal="true" class="pdd16-step-buying-v2__layer-learn-more" id="layerPopupLearnMore" role="dialog" tabindex="0">
        <div class="layer-popup">
          <div class="layer-popup__inner">
            <h2 class="layer-popup__title"> Sound devices </h2>
            <div class="layer-popup__contents scrollbar">
              <div class="scrollbar__wrap">
                <div class="scrollbar__contents">
                  <div class="pdd16-step-buying-v2__learn-more-images">
                    <div class="swiper-container basic-swiper swiper-container-initialized swiper-container-horizontal" data-swiper-option="{
				                      &quot;slidesPerView&quot;:&quot;1&quot;,
				                      &quot;keepWrapper&quot;:true,
				                      &quot;loop&quot;:false,
				                      &quot;pagination&quot;:false,
				                      &quot;componentEl&quot;:&quot;.pdd16-step-buying-v2__learn-more-images&quot;,
				                      &quot;offTxtAccesibility&quot;:&quot;true&quot;,
				                      &quot;centeredSlides&quot;: true,
				                      &quot;centeredSlidesBounds&quot;: true,
				                      &quot;followFinger&quot;: true
				                    }" style="min-height: 2px;">
                      <button class="swiper-button-prev" type="button">
                        <span class="hidden"> Previous </span>
                        <svg aria-hidden="true" class="icon" focusable="false">
                          <use href="#previous-bold" xlink:href="#previous-bold">
                          </use>
                        </svg>
                      </button>
                      <div class="swiper-wrapper" role="list" style="transition-duration: 0ms;">
                        <div class="swiper-slide" role="listitem">
                          <div class="image">
                            <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/290x240" data-mobile-src="https://via.placeholder.com/520x400" role="img" data-src="https://via.placeholder.com/290x240">
                            <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/290x240" data-mobile-src="https://via.placeholder.com/520x400" role="img" data-src="https://via.placeholder.com/290x240">
                          </div>
                        </div>
                        <div class="swiper-slide" role="listitem">
                          <div class="image">
                            <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/290x240" data-mobile-src="https://via.placeholder.com/520x400" role="img" data-src="https://via.placeholder.com/290x240">
                            <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/290x240" data-mobile-src="https://via.placeholder.com/520x400" role="img" data-src="https://via.placeholder.com/290x240">
                          </div>
                        </div>
                        <div class="swiper-slide" role="listitem">
                          <div class="image">
                            <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/290x240" data-mobile-src="https://via.placeholder.com/520x400" role="img" data-src="https://via.placeholder.com/290x240">
                            <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/290x240" data-mobile-src="https://via.placeholder.com/520x400" role="img" data-src="https://via.placeholder.com/290x240">
                          </div>
                        </div>
                      </div>
                      <button class="swiper-button-next" type="button">
                        <span class="hidden"> Next </span>
                        <svg aria-hidden="true" class="icon" focusable="false">
                          <use href="#next-bold" xlink:href="#next-bold">
                          </use>
                        </svg>
                      </button>
                    </div>
                  </div>
                  <div class="pdd16-step-buying-v2__learn-more-content">
                    <h3 class="pdd16-step-buying-v2__learn-more-title"> HW-Q900A 7.1.2ch Samsung Q-Symphony Cinematic Dolby Atmos Q-Series Soundbar (2021) </h3>
                    <div class="pdd16-step-buying-v2__learn-more-info">
                      <p class="pdd16-step-buying-v2__learn-more-sku"> HW-Q900A/XU </p>
                      <strong class="pdd16-step-buying-v2__learn-more-seller"> Seller: Vyper </strong>
                    </div>
                    <div class="pdd16-step-buying-v2__learn-more-review">
                      <!-- /* 전체 Empty: .rating--empty 추가 */ -->
                      <span class="rating">
                        <!-- (2021.08.23 수정) <span class="hidden">Rating</span> 삭제 -->
                        <!--  <span class="hidden">Rating</span>-->
                        <span class="rating__inner">
                          <span class="rating__star-list">
                            <span class="rating__star-item">
                              <span class="rating__star-empty">
                              </span>
                              <!-- /* style="width: %;"로 적용  Full : style="width: 100%;" Half : style="width: 50%;" Empty : style="width: 0;" */ -->
                              <span class="rating__star-filled" style="width: 100%;">
                              </span>
                            </span>
                            <span class="rating__star-item">
                              <span class="rating__star-empty">
                              </span>
                              <span class="rating__star-filled" style="width: 100%;">
                              </span>
                            </span>
                            <span class="rating__star-item">
                              <span class="rating__star-empty">
                              </span>
                              <span class="rating__star-filled" style="width: 100%;">
                              </span>
                            </span>
                            <span class="rating__star-item">
                              <span class="rating__star-empty">
                              </span>
                              <span class="rating__star-filled" style="width: 100%;">
                              </span>
                            </span>
                            <span class="rating__star-item">
                              <span class="rating__star-empty">
                              </span>
                              <span class="rating__star-filled" style="width: 50%;">
                              </span>
                            </span>
                          </span>
                          <strong class="rating__point">
                            <span class="hidden"> Product Ratings : </span>
                            <span> 4.7 </span>
                          </strong>
                          <em class="rating__review-count"> ( <span class="hidden"> Number of Ratings : </span>
                            <span> 9,999 </span> ) </em>
                        </span>
                      </span>
                    </div>
                    <ul class="pdd16-step-buying-v2__learn-more-feature" role="list">
                      <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem"> 7.1.2ch sound </li>
                      <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem"> True Dolby Atmos &amp; DTS:X </li>
                      <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem"> 8” Subwoofer </li>
                      <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem"> Samsung Q-Symphony </li>
                      <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem"> Alexa Built-In </li>
                    </ul>
                    <div class="pdd16-step-buying-v2__learn-more-cta">
                      <a aria-label="Link Title" class="cta cta--underline cta--black cta--icon" href="https://printquarters.com/about/team.php" target="_blank"> Product detail <svg aria-hidden="true" class="icon" focusable="false">
                          <use href="#outlink-bold" xlink:href="#outlink-bold">
                          </use>
                        </svg>
                      </a>
                    </div>
                    <ul class="pdd16-step-buying-v2__learn-more-feature-icon">
                      <li class="pdd16-step-buying-v2__learn-more-feature-icon-item">
                        <div class="pdd16-step-buying-v2__learn-more-feature-icon-image">
                          <div class="image">
                            <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img" data-src="https://via.placeholder.com/64x64">
                            <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img" data-src="https://via.placeholder.com/64x64">
                          </div>
                        </div>
                        <p class="pdd16-step-buying-v2__learn-more-feature-icon-text"> True 7.1.2ch Sound </p>
                      </li>
                      <li class="pdd16-step-buying-v2__learn-more-feature-icon-item">
                        <div class="pdd16-step-buying-v2__learn-more-feature-icon-image">
                          <div class="image">
                            <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img" data-src="https://via.placeholder.com/64x64">
                            <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img" data-src="https://via.placeholder.com/64x64">
                          </div>
                        </div>
                        <p class="pdd16-step-buying-v2__learn-more-feature-icon-text"> 3D Object Based Sound </p>
                      </li>
                      <li class="pdd16-step-buying-v2__learn-more-feature-icon-item">
                        <div class="pdd16-step-buying-v2__learn-more-feature-icon-image">
                          <div class="image">
                            <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img" data-src="https://via.placeholder.com/64x64">
                            <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img" data-src="https://via.placeholder.com/64x64">
                          </div>
                        </div>
                        <p class="pdd16-step-buying-v2__learn-more-feature-icon-text"> Samsung Q-Symphony </p>
                      </li>
                      <li class="pdd16-step-buying-v2__learn-more-feature-icon-item">
                        <div class="pdd16-step-buying-v2__learn-more-feature-icon-image">
                          <div class="image">
                            <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img" data-src="https://via.placeholder.com/64x64">
                            <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img" data-src="https://via.placeholder.com/64x64">
                          </div>
                        </div>
                        <p class="pdd16-step-buying-v2__learn-more-feature-icon-text"> Built-In Centre Speaker </p>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="scrollbar-horizontal__track" style="display: none;">
                <div class="scrollbar-horizontal__track-content">
                  <div class="scrollbar-horizontal__bar"></div>
                </div>
              </div>
              <div class="scrollbar-vertical__track" style="display: none;">
                <div class="scrollbar-vertical__track-content">
                  <div class="scrollbar-vertical__bar"></div>
                </div>
              </div>
            </div>
            <button class="layer-popup__close" type="button">
              <span class="hidden"> Layer Popup Close </span>
              <svg aria-hidden="true" class="icon" focusable="false">
                <use href="#delete-bold" xlink:href="#delete-bold">
                </use>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </section>
    <div class="hdd02-pdp-header hdd02-pdp-header--ux-v2">
      <script type="text/javascript">
        var spinImageNewData = {};
      </script>
      <div class="hdd02-pdp-header__gallery-area sg-pdh-gallery-section" style="--hdd02-fixed-header-top: 0px;">
        <div class="hdd02-pdp-header__gallery">
          <section class="hdd02-gallery" id="pd-header-gallery">
            <div class="hdd02-gallery__content">
              <div class="hdd02-gallery__list basic-swiper swiper-container" data-swiper-option="{
                        &quot;breakpoints&quot;: {
                          &quot;1&quot;: {
                            &quot;slidesPerView&quot;: &quot;auto&quot;,
                            &quot;centeredSlides&quot;: true
                          },
                          &quot;768&quot;: {
                            &quot;slidesPerView&quot;: 1,
                            &quot;centeredSlides&quot;: false
                          }
                        },
                        &quot;keepWrapper&quot;: true,
                        &quot;viewMode&quot;: &quot;mobile&quot;,
                        &quot;offTxtAccesibility&quot;: &quot;true&quot;,
                        &quot;followFinger&quot;: false,
                        &quot;pagination&quot;: true,
                        &quot;componentEl&quot;: &quot;.hdd02-gallery__content&quot;
                      }">
                <ul class="swiper-wrapper" role="list">
                  <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 Front Black " style="display: block;">
                    <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
                      <div class="image">
                        <img alt="Galaxy A07 Front Black " class="image__main responsive-img" data-comp-name="image" data-desktop-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" data-mobile-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img" src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269">
                      </div>
                    </a>
                  </li>
                  <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 Back Black " style="display: none;">
                    <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
                      <div class="image">
                        <img alt="Galaxy A07 Back Black " class="image__main responsive-img" data-comp-name="image" data-desktop-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" data-mobile-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img" src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269">
                      </div>
                    </a>
                  </li>
                  <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 BackL30 Black " style="display: none;">
                    <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
                      <div class="image">
                        <img alt="Galaxy A07 BackL30 Black " class="image__main responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603111?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603111?$Q90_1248_936_F_PNG$" role="img" src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603111?$Q90_1920_1280_F_PNG$">
                      </div>
                    </a>
                  </li>
                  <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 BackR30 Black " style="display: none;">
                    <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
                      <div class="image">
                        <img alt="Galaxy A07 BackR30 Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603112?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603112?$Q90_1248_936_F_PNG$" role="img" data-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603112?$Q90_1920_1280_F_PNG$">
                      </div>
                    </a>
                  </li>
                  <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 Front2 Black " style="display: none;">
                    <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
                      <div class="image">
                        <img alt="Galaxy A07 Front2 Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603113?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603113?$Q90_1248_936_F_PNG$" role="img" data-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603113?$Q90_1920_1280_F_PNG$">
                      </div>
                    </a>
                  </li>
                  <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 FrontL30 Black " style="display: none;">
                    <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
                      <div class="image">
                        <img alt="Galaxy A07 FrontL30 Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603114?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603114?$Q90_1248_936_F_PNG$" role="img" data-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603114?$Q90_1920_1280_F_PNG$">
                      </div>
                    </a>
                  </li>
                  <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 FrontR30 Black " style="display: none;">
                    <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
                      <div class="image">
                        <img alt="Galaxy A07 FrontR30 Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603115?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603115?$Q90_1248_936_F_PNG$" role="img" data-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603115?$Q90_1920_1280_F_PNG$">
                      </div>
                    </a>
                  </li>
                  <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 Lside Black " style="display: none;">
                    <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
                      <div class="image">
                        <img alt="Galaxy A07 Lside Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603116?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603116?$Q90_1248_936_F_PNG$" role="img" data-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603116?$Q90_1920_1280_F_PNG$">
                      </div>
                    </a>
                  </li>
                  <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 Rside Black " style="display: none;">
                    <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
                      <div class="image">
                        <img alt="Galaxy A07 Rside Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603117?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603117?$Q90_1248_936_F_PNG$" role="img" data-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603117?$Q90_1920_1280_F_PNG$">
                      </div>
                    </a>
                  </li>
                </ul>
                <div class="screen-indicator-wrap">
                  <button class="screen-indicator screen-indicator--prev" an-tr="hdd02_gallery-product detail-swipe-indication" an-ca="indication" an-ac="carousel">
                    <div class="screen-indicator--icon">
                      <span class="hidden"> Sebelumnya </span>
                      <svg aria-hidden="true" class="icon" focusable="false">
                        <use href="#previous-regular" xlink:href="#previous-regular">
                        </use>
                      </svg>
                    </div>
                  </button>
                  <button class="screen-indicator screen-indicator--next" an-tr="hdd02_gallery-product detail-swipe-indication" an-ca="indication" an-ac="carousel">
                    <div class="screen-indicator--icon">
                      <span class="hidden"> Berikutnya </span>
                      <svg aria-hidden="true" class="icon" focusable="false">
                        <use href="#next-regular" xlink:href="#next-regular">
                        </use>
                      </svg>
                    </div>
                  </button>
                </div>
              </div>
              <div class="progressbar-indicator">
                <div class="progressbar-indicator__inner">
                  <div class="progressbar-indicator__bar">
                    <span class="progressbar-indicator__bar-fill">
                    </span>
                  </div>
                  <div class="progressbar-indicator__arrow-wrap">
                    <button class="progressbar-indicator__arrow swiper-button-prev">
                      <span class="hidden"> Sebelumnya </span>
                      <svg aria-hidden="true" class="icon" focusable="false" height="40" viewBox="0 0 40 40" width="40">
                        <g transform="translate(40 40) rotate(180)">
                          <path d="M21.47,16.53A.75.75,0,0,1,22.53,15.47l4,4a.75.75,0,0,1,0,1.061l-4,4A.75.75,0,0,1,21.47,23.47l2.72-2.72H14.5a.75.75,0,0,1,0-1.5h9.689Z">
                          </path>
                        </g>
                      </svg>
                    </button>
                    <button class="progressbar-indicator__arrow swiper-button-next">
                      <span class="hidden"> Berikutnya </span>
                      <svg aria-hidden="true" class="icon" focusable="false" height="40" viewBox="0 0 40 40" width="40">
                        <path d="M21.47,16.53A.75.75,0,0,1,22.53,15.47l4,4a.75.75,0,0,1,0,1.061l-4,4A.75.75,0,0,1,21.47,23.47l2.72-2.72H14.5a.75.75,0,0,1,0-1.5h9.689Z">
                        </path>
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <style>
              /* ===== SLIDE INFO BERJALAN DI BAWAH NAVIGASI THUMBNAIL ===== */
              .slide-info-running {
                width: 100%;
                overflow: hidden;
                position: relative;
                margin-top: 18px;
                padding: 12px 0;
                background: #ffffff;
                border-top: 1px solid rgba(0, 0, 0, 0.10);
                border-bottom: 1px solid rgba(0, 0, 0, 0.10);
              }

              /* Efek gradasi halus kiri kanan biar lebih rapi */
              .slide-info-running::before,
              .slide-info-running::after {
                content: "";
                position: absolute;
                top: 0;
                width: 70px;
                height: 100%;
                z-index: 2;
                pointer-events: none;
              }

              .slide-info-running::before {
                left: 0;
                background: linear-gradient(to right, #ffffff 0%, rgba(255, 255, 255, 0) 100%);
              }

              .slide-info-running::after {
                right: 0;
                background: linear-gradient(to left, #ffffff 0%, rgba(255, 255, 255, 0) 100%);
              }

              /* Jalur teks yang bergerak */
              .slide-info-running__track {
                display: flex;
                width: max-content;
                min-width: 100%;
                align-items: center;
                gap: 46px;
                white-space: nowrap;
                animation: runningSlideInfo 28s linear infinite;
                will-change: transform;
                color: white;
              }

              /* Masing-masing item info */
              .slide-info-running__item {
                display: inline-flex;
                align-items: center;
                gap: 9px;
                font-size: 14px;
                line-height: 1;
                font-weight: 700;
                color: #111111;
                letter-spacing: 0.2px;
              }

              /* Bulatan pemisah */
              .slide-info-running__item::before {
                content: "";
                width: 7px;
                height: 7px;
                border-radius: 50%;
                background: #f4c400;
                box-shadow: 0 0 8px rgba(244, 196, 0, 0.55);
                flex-shrink: 0;
              }

              /* Animasi jalan dari kanan ke kiri */
              @keyframes runningSlideInfo {
                0% {
                  transform: translateX(100%);
                }

                100% {
                  transform: translateX(-100%);
                }
              }

              /* Saat diarahkan kursor, geraknya berhenti */
              .slide-info-running:hover .slide-info-running__track {
                animation-play-state: paused;
              }

              /* ===== RESPONSIVE TABLET ===== */
              @media (max-width: 1024px) {
                .slide-info-running {
                  margin-top: 14px;
                  padding: 11px 0;
                }

                .slide-info-running__track {
                  gap: 38px;
                  animation-duration: 24s;
                }

                .slide-info-running__item {
                  font-size: 13px;
                }
              }

              /* ===== RESPONSIVE MOBILE ===== */
              @media (max-width: 768px) {
                .slide-info-running {
                  margin-top: 12px;
                  padding: 10px 0;
                }

                .slide-info-running::before,
                .slide-info-running::after {
                  width: 42px;
                }

                .slide-info-running__track {
                  gap: 28px;
                  animation-duration: 21s;
                }

                .slide-info-running__item {
                  font-size: 12px;
                  gap: 7px;
                }

                .slide-info-running__item::before {
                  width: 6px;
                  height: 6px;
                }
              }
            </style>
            <div class="slide-info-running">
              <div class="slide-info-running__track">
                <span class="slide-info-running__item">Update Terbaru: 10 Juni Sampai 20 Juni 2026</span>
                <span class="slide-info-running__item">362.987 Komentar Member</span>
                <span class="slide-info-running__item">Rating Pengguna 4.9/5</span>
                <span class="slide-info-running__item">99.999.999 Pengguna Aktif</span>
                <span class="slide-info-running__item">Layanan Support 24/7</span>
              </div>
            </div>
            <div class="hdd02-gallery__thumbnail">
              <ul class="hdd02-gallery__thumbnail-list" role="list">
                <li class="hdd02-gallery__thumbnail-item hdd02-gallery__thumbnail-item--on" role="listitem">
                  <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
                    <div class="image">
                      <img alt="Galaxy A07 Front Black " class="image__main" data-comp-name="image" role="img" src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269">
                    </div>
                  </a>
                </li>
                <li class="hdd02-gallery__thumbnail-item" role="listitem">
                  <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
                    <div class="image">
                      <img alt="Galaxy A07 Back Black " class="image__main" data-comp-name="image" role="img" src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269">
                    </div>
                  </a>
                </li>
                <li class="hdd02-gallery__thumbnail-item" role="listitem">
                  <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
                    <div class="image">
                      <img alt="Galaxy A07 BackL30 Black " class="image__main" data-comp-name="image" role="img" src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269">
                    </div>
                  </a>
                </li>
                <li class="hdd02-gallery__thumbnail-item" role="listitem">
                  <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
                    <div class="image">
                      <img alt="Galaxy A07 BackR30 Black " class="image__main" data-comp-name="image" role="img" src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269">
                    </div>
                  </a>
                </li>
                <li class="hdd02-gallery__thumbnail-item" role="listitem">
                  <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
                    <div class="image">
                      <img alt="Galaxy A07 Front2 Black " class="image__main" data-comp-name="image" role="img" src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269">
                    </div>
                  </a>
                </li>
                <li class="hdd02-gallery__thumbnail-item" role="listitem">
                  <a an-ac="view more" an-ca="indication" an-la="product gallery:view more" an-tr="hdd02_gallery-product detail-view more-indication" class="hdd02-gallery__thumbnail-item-text" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
                    <span class="text"> +4 lebih banyak </span>
                  </a>
                </li>
              </ul>
            </div>
            <div class="hdd02-gallery__cta">
            </div>
            <div class="hdd02-gallery__popup type-gallery">
              <div class="layer-popup">
                <div class="layer-popup__contents">
                  <div class="hdd02-gallery__popup-thumbnail scrollbar">
                    <div class="scrollbar__wrap">
                      <div class="scrollbar__contents">
                        <div class="hdd02-gallery__popup-image">
                          <ul class="hdd02-gallery__popup-image-list" role="list">
                            <li class="hdd02-gallery__popup-image-item" role="listitem">
                              <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                                <div class="image">
                                  <img alt="Galaxy A07 Front Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </a>
                            </li>
                            <li class="hdd02-gallery__popup-image-item" role="listitem">
                              <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                                <div class="image">
                                  <img alt="Galaxy A07 Back Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </a>
                            </li>
                            <li class="hdd02-gallery__popup-image-item" role="listitem">
                              <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                                <div class="image">
                                  <img alt="Galaxy A07 BackL30 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </a>
                            </li>
                            <li class="hdd02-gallery__popup-image-item" role="listitem">
                              <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                                <div class="image">
                                  <img alt="Galaxy A07 BackR30 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </a>
                            </li>
                            <li class="hdd02-gallery__popup-image-item" role="listitem">
                              <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                                <div class="image">
                                  <img alt="Galaxy A07 Front2 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </a>
                            </li>
                            <li class="hdd02-gallery__popup-image-item" role="listitem">
                              <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                                <div class="image">
                                  <img alt="Galaxy A07 FrontL30 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </a>
                            </li>
                            <li class="hdd02-gallery__popup-image-item" role="listitem">
                              <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                                <div class="image">
                                  <img alt="Galaxy A07 FrontR30 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </a>
                            </li>
                            <li class="hdd02-gallery__popup-image-item" role="listitem">
                              <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                                <div class="image">
                                  <img alt="Galaxy A07 Lside Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </a>
                            </li>
                            <li class="hdd02-gallery__popup-image-item" role="listitem">
                              <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                                <div class="image">
                                  <img alt="Galaxy A07 Rside Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="scrollbar-horizontal__track" style="display: none;">
                      <div class="scrollbar-horizontal__track-content">
                        <div class="scrollbar-horizontal__bar"></div>
                      </div>
                    </div>
                    <div class="scrollbar-vertical__track" style="display: none;">
                      <div class="scrollbar-vertical__track-content">
                        <div class="scrollbar-vertical__bar"></div>
                      </div>
                    </div>
                  </div>
                  <div class="hdd02-gallery__popup-vertical scrollbar">
                    <div class="scrollbar__wrap">
                      <div class="scrollbar__contents">
                        <div class="hdd02-gallery__popup-vertical-content">
                          <div class="hdd02-gallery__popup-vertical-image">
                            <div class="image-content">
                              <div class="default-image">
                                <div class="image">
                                  <img alt="Galaxy A07 Front Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </div>
                              <div class="zoom-image">
                                <div class="image">
                                  <img alt="Galaxy A07 Front Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                                <p aria-hidden="true" class="snackbar"> Klik atau ketuk untuk memperkecil </p>
                              </div>
                            </div>
                            <div class="image-content">
                              <div class="default-image">
                                <div class="image">
                                  <img alt="Galaxy A07 Back Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </div>
                              <div class="zoom-image">
                                <div class="image">
                                  <img alt="Galaxy A07 Back Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                                <p aria-hidden="true" class="snackbar"> Klik atau ketuk untuk memperkecil </p>
                              </div>
                            </div>
                            <div class="image-content">
                              <div class="default-image">
                                <div class="image">
                                  <img alt="Galaxy A07 BackL30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </div>
                              <div class="zoom-image">
                                <div class="image">
                                  <img alt="Galaxy A07 BackL30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                                <p aria-hidden="true" class="snackbar"> Klik atau ketuk untuk memperkecil </p>
                              </div>
                            </div>
                            <div class="image-content">
                              <div class="default-image">
                                <div class="image">
                                  <img alt="Galaxy A07 BackR30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </div>
                              <div class="zoom-image">
                                <div class="image">
                                  <img alt="Galaxy A07 BackR30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                                <p aria-hidden="true" class="snackbar"> Klik atau ketuk untuk memperkecil </p>
                              </div>
                            </div>
                            <div class="image-content">
                              <div class="default-image">
                                <div class="image">
                                  <img alt="Galaxy A07 Front2 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </div>
                              <div class="zoom-image">
                                <div class="image">
                                  <img alt="Galaxy A07 Front2 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                                <p aria-hidden="true" class="snackbar"> Klik atau ketuk untuk memperkecil </p>
                              </div>
                            </div>
                            <div class="image-content">
                              <div class="default-image">
                                <div class="image">
                                  <img alt="Galaxy A07 FrontL30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </div>
                              <div class="zoom-image">
                                <div class="image">
                                  <img alt="Galaxy A07 FrontL30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                                <p aria-hidden="true" class="snackbar"> Klik atau ketuk untuk memperkecil </p>
                              </div>
                            </div>
                            <div class="image-content">
                              <div class="default-image">
                                <div class="image">
                                  <img alt="Galaxy A07 FrontR30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </div>
                              <div class="zoom-image">
                                <div class="image">
                                  <img alt="Galaxy A07 FrontR30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                                <p aria-hidden="true" class="snackbar"> Klik atau ketuk untuk memperkecil </p>
                              </div>
                            </div>
                            <div class="image-content">
                              <div class="default-image">
                                <div class="image">
                                  <img alt="Galaxy A07 Lside Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </div>
                              <div class="zoom-image">
                                <div class="image">
                                  <img alt="Galaxy A07 Lside Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                                <p aria-hidden="true" class="snackbar"> Klik atau ketuk untuk memperkecil </p>
                              </div>
                            </div>
                            <div class="image-content">
                              <div class="default-image">
                                <div class="image">
                                  <img alt="Galaxy A07 Rside Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                              </div>
                              <div class="zoom-image">
                                <div class="image">
                                  <img alt="Galaxy A07 Rside Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" role="img">
                                </div>
                                <p aria-hidden="true" class="snackbar"> Klik atau ketuk untuk memperkecil </p>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="hdd02-gallery__popup-control hdd02-gallery__popup-control--hide">
                          <ul class="hdd02-gallery__popup-control-list" role="list">
                            <li class="hdd02-gallery__popup-control-item" role="listitem">
                              <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom in" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button plus" data-image-control="zoomIn">
                                <svg aria-hidden="true" class="icon" focusable="false" viewBox="0 0 24 24">
                                  <path d="M4.081 3.831a11.375 11.375 0 1 1 0 16.087 11.376 11.376 0 0 1 0-16.087zm15.2.884a10.125 10.125 0 1 0 0 14.319 10.126 10.126 0 0 0 0-14.319zm-6.785.66v5.875h5.875V12.5H12.5v5.875h-1.25V12.5H5.374V11.25h5.875V5.375z">
                                  </path>
                                </svg>
                              </button>
                            </li>
                            <li class="hdd02-gallery__popup-control-item" role="listitem">
                              <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom out" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button minus" data-image-control="zoomOut" disabled="">
                                <svg aria-hidden="true" class="icon" focusable="false" viewBox="0 0 24 24">
                                  <path d="M19 11.875H5.247" fill="none" stroke="currentColor" stroke-width="1.251">
                                  </path>
                                  <path d="M12.124 1.126a10.749 10.749 0 1 1-7.6 3.148 10.717 10.717 0 0 1 7.6-3.148z" fill="none" fill-rule="evenodd" stroke="currentColor" stroke-width="1.251">
                                  </path>
                                </svg>
                              </button>
                            </li>
                          </ul>
                          <ul class="hdd02-gallery__popup-control-list control-hide" id="galleryMoving" role="list">
                            <li class="hdd02-gallery__popup-control-item" role="listitem">
                              <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom up" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button up" data-image-control="up">
                                <span class="hidden"> Move Thumbnail Image down </span>
                                <svg aria-hidden="true" class="icon" focusable="false" height="20" viewBox="0 0 20 20" width="20">
                                  <path d="M9.4 19.642V3.633L3.233 9.949l-.682-.682L9.913 1.6l7.343 7.666-.712.682-6.1-6.3v15.994z">
                                  </path>
                                </svg>
                              </button>
                            </li>
                            <li class="hdd02-gallery__popup-control-item" role="listitem">
                              <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom down" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button down" data-image-control="down">
                                <span class="hidden"> Move Thumbnail Image up </span>
                                <svg aria-hidden="true" class="icon" focusable="false" height="20" viewBox="0 0 20 20" width="20">
                                  <path d="M9.4 19.642V3.633L3.233 9.949l-.682-.682L9.913 1.6l7.343 7.666-.712.682-6.1-6.3v15.994z">
                                  </path>
                                </svg>
                              </button>
                            </li>
                            <li class="hdd02-gallery__popup-control-item" role="listitem">
                              <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom left" an-tr="hdd02_gallery--product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button left" data-image-control="left">
                                <span class="hidden"> Move Thumbnail Image right </span>
                                <svg aria-hidden="true" class="icon" focusable="false" height="20" viewBox="0 0 20 20" width="20">
                                  <path d="M9.4 19.642V3.633L3.233 9.949l-.682-.682L9.913 1.6l7.343 7.666-.712.682-6.1-6.3v15.994z">
                                  </path>
                                </svg>
                              </button>
                            </li>
                            <li class="hdd02-gallery__popup-control-item" role="listitem">
                              <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom right" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button right" data-image-control="right">
                                <span class="hidden"> Move Thumbnail Image left </span>
                                <svg aria-hidden="true" class="icon" focusable="false" height="20" viewBox="0 0 20 20" width="20">
                                  <path d="M9.4 19.642V3.633L3.233 9.949l-.682-.682L9.913 1.6l7.343 7.666-.712.682-6.1-6.3v15.994z">
                                  </path>
                                </svg>
                              </button>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="ocean-effect-box">
                      <div class="bubble-wrap">
                        <span></span><span></span><span></span><span></span><span></span>
                        <span></span><span></span><span></span><span></span><span></span>
                      </div>
                      <h2>🌊 Fitur Unggulan Naga 508Slot SLOT GACOR LUAR NEGERI</h2>
                      <div class="ocean-grid">
                        <div class="ocean-card">🎰<b>Game Slot Lengkap</b>
                          <p>Pilihan permainan tersedia dari berbagai provider populer.</p>
                        </div>
                        <div class="ocean-card">⚡<b>Transaksi Cepat</b>
                          <p>Deposit dan withdraw berjalan praktis dengan sistem otomatis.</p>
                        </div>
                        <div class="ocean-card">💎<b>RTP Update</b>
                          <p>Informasi permainan diperbarui secara berkala.</p>
                        </div>
                      </div>
                    </div>
                    <div class="scrollbar-horizontal__track" style="display: none;">
                      <div class="scrollbar-horizontal__track-content">
                        <div class="scrollbar-horizontal__bar"></div>
                      </div>
                    </div>
                    <div class="scrollbar-vertical__track" style="display: none;">
                      <div class="scrollbar-vertical__track-content">
                        <div class="scrollbar-vertical__bar"></div>
                      </div>
                    </div>
                  </div>
                  <button class="hdd02-gallery__popup-close" data-js-action="closeGalleryPopup">
                    <span class="hidden"> Close </span>
                    <svg aria-hidden="true" class="icon" focusable="false">
                      <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
                      </use>
                    </svg>
                  </button>
                </div>
              </div>
            </div>
            <div class="hdd02-gallery__popup type-360view-new">
              <div class="layer-popup">
                <div class="layer-popup__contents">
                  <div class="scrollbar__contents">
                    <div class="seq-viewer-container">
                      <div class="top-container">
                        <p class="model-name"> Galaxy A07 </p>
                        <button class="hdd02-gallery__popup-close" data-js-action="closeGalleryPopup">
                          <span class="hidden"> Tutup </span>
                          <svg aria-hidden="true" class="icon" focusable="false">
                            <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
                            </use>
                          </svg>
                        </button>
                      </div>
                      <div class="imgseq-container" id="seqContainer">
                        <div class="loading-container">
                          <div class="loading">
                            <span class="progress"> 0% </span>
                          </div>
                        </div>
                        <div class="interaction-container">
                          <div class="interaction-icon">
                            <svg height="58.617" viewBox="0 0 59.583 58.617" width="59.583" xmlns="http://www.w3.org/2000/svg">
                              <g transform="translate(0.5 0.5)">
                                <g transform="translate(0 32.736)">
                                  <g fill="rgba(0,0,0,0.24)" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(13.353)">
                                    <circle cx="6.031" cy="6.031" r="6.031" stroke="none">
                                    </circle>
                                    <circle cx="6.031" cy="6.031" fill="none" r="5.531">
                                    </circle>
                                  </g>
                                  <path d="M-564.012,2412.855v11.527h11.524" fill="none" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(564.012 -2399.502)">
                                  </path>
                                  <path d="M-549.086,2408.855l-15.166,15.166" fill="none" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(564.252 -2399.14)">
                                  </path>
                                </g>
                                <g transform="translate(33.168)">
                                  <g fill="rgba(0,0,0,0.24)" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(0 12.819)">
                                    <circle cx="6.031" cy="6.031" r="6.031" stroke="none">
                                    </circle>
                                    <circle cx="6.031" cy="6.031" fill="none" r="5.531">
                                    </circle>
                                  </g>
                                  <path d="M-552.488,2424.382v-11.527h-11.524" fill="none" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(577.903 -2412.855)">
                                  </path>
                                  <path d="M-564.252,2424.021l15.166-15.166" fill="none" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(574.501 -2408.855)">
                                  </path>
                                </g>
                              </g>
                            </svg>
                          </div>
                        </div>
                        <div class="ui-container">
                          <div class="ui-wrap">
                            <button aria-label="zoom in" class="btn-zoomin">
                              <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                                <rect fill="rgba(255,255,255,0)" height="16" width="16">
                                </rect>
                                <path d="M7.333,0V6h6V7.333h-6v6H6v-6H0V6H6V0Z" transform="translate(1.333 1.333)">
                                </path>
                              </svg>
                            </button>
                            <button aria-label="zoom out" class="btn-zoomout">
                              <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                                <rect fill="rgba(255,255,255,0)" height="16" width="16">
                                </rect>
                                <path d="M13.333,0V1.333H0V0Z" transform="translate(1.333 7.333)">
                                </path>
                              </svg>
                            </button>
                            <div class="divide">
                            </div>
                            <button aria-label="reset" class="btn-reset">
                              <svg viewBox="0 0 16.001 16" xmlns="http://www.w3.org/2000/svg">
                                <g transform="translate(0 16) rotate(-90)">
                                  <rect fill="none" height="16" transform="translate(0 0.001)" width="16">
                                  </rect>
                                  <path d="M253.312,407.75a7.842,7.842,0,0,0-10.222,2.186v-1.3h-1.333v3.917h3.917v-1.33h-1.832a6.5,6.5,0,1,1-.721,4.927l-.061-.241-1.3.32.091.346a7.88,7.88,0,0,0,3.677,4.775,7.786,7.786,0,0,0,3.878,1.039,7.882,7.882,0,0,0,2.069-.279,7.832,7.832,0,0,0,1.833-14.356Z" transform="translate(422.715 -241.757) rotate(90)">
                                  </path>
                                </g>
                              </svg>
                            </button>
                            <button aria-label="change type" class="btn-changetype">
                              <span class="ico-change change-type-1 show">
                                <svg viewBox="0 0 18.715 15.326" xmlns="http://www.w3.org/2000/svg">
                                  <g transform="translate(-15.281 -16.174)">
                                    <path d="M15.281,29.5H30.15v2H15.281Z">
                                    </path>
                                    <path d="M28.24,30.98l3.82-14.806,1.936.5L30.176,31.48Zm-7.776-5.632-2.5-2.5-1.031,1.031,3.535,3.535L24,23.875l-1.031-1.031Z">
                                    </path>
                                    <g>
                                      <path d="M23.509,17.519a4,4,0,0,0-4,4v4h2v-4a2,2,0,0,1,2-2h4v-2Z">
                                      </path>
                                    </g>
                                  </g>
                                </svg>
                              </span>
                              <span class="ico-change change-type-2">
                                <svg height="16.575" viewBox="0 0 18.715 16.575" width="18.715" xmlns="http://www.w3.org/2000/svg">
                                  <g transform="translate(-15.281 -14.925)">
                                    <path d="M15.281,29.5H30.15v2H15.281Z">
                                    </path>
                                    <path d="M28.24,30.98l3.82-14.806,1.936.5L30.176,31.48ZM26.769,18.46l-2.5,2.5L25.3,22l3.535-3.536L25.3,14.925l-1.031,1.031Z">
                                    </path>
                                    <path d="M23.509,17.519a4,4,0,0,0-4,4v4h2v-4a2,2,0,0,1,2-2h4v-2Z">
                                    </path>
                                  </g>
                                </svg>
                              </span>
                            </button>
                            <button aria-label="more" class="btn-more last">
                              <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                                <g transform="translate(-169.748 -591)">
                                  <rect fill="none" height="16" transform="translate(169.748 591)" width="16">
                                  </rect>
                                  <g transform="translate(12.498 -1.25)">
                                    <circle cx="1.25" cy="1.25" r="1.25" transform="translate(158 599)">
                                    </circle>
                                    <circle cx="1.25" cy="1.25" r="1.25" transform="translate(164 599)">
                                    </circle>
                                    <circle cx="1.25" cy="1.25" r="1.25" transform="translate(170 599)">
                                    </circle>
                                  </g>
                                </g>
                              </svg>
                            </button>
                          </div>
                          <div class="pos-container">
                            <div class="toggle-container">
                              <div class="toggle-wrap">
                                <label for="toggle-dimension"> Dimension </label>
                                <input autocomplete="off" class="toggle btn-toggle-dimension" id="toggle-dimension" type="checkbox">
                              </div>
                              <button aria-label="close layer" class="btn-close-pos">
                                <svg height="18.415" viewBox="0 0 18.415 18.415" width="18.415" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M17,0,9.208,7.793,1.415,0,0,1.415,7.793,9.208,0,17l1.415,1.415,7.793-7.793L17,18.415,18.415,17,10.623,9.208l7.793-7.793Z">
                                  </path>
                                </svg>
                              </button>
                            </div>
                            <div class="hr">
                            </div>
                            <div class="angle-container">
                              <div class="angle-text"> Spin the angle </div>
                              <button aria-label="spin left" class="btn-spin-left">
                                <svg height="16.497" viewBox="0 0 22.492 16.497" width="22.492" xmlns="http://www.w3.org/2000/svg">
                                  <g transform="translate(0 3.148)">
                                    <path d="M11.312,8.505h-.143a24.965,24.965,0,0,1-4.3-.375,19.574,19.574,0,0,1-1.91-.44,14.546,14.546,0,0,1-1.664-.583A9.792,9.792,0,0,1,1.921,6.4,5.908,5.908,0,0,1,.884,5.589a3.329,3.329,0,0,1-.655-.9,2.138,2.138,0,0,1,0-1.924,3.322,3.322,0,0,1,.655-.9,5.9,5.9,0,0,1,1.037-.811A9.723,9.723,0,0,1,3.294.354C3.6.225,3.914.106,4.224,0l.354,1.1-.251.087a9.036,9.036,0,0,0-1.194.531,5.1,5.1,0,0,0-.9.61,2.58,2.58,0,0,0-.57.675,1.419,1.419,0,0,0,0,1.448,2.58,2.58,0,0,0,.57.675,5.1,5.1,0,0,0,.9.61,9.078,9.078,0,0,0,1.194.532,16.467,16.467,0,0,0,3.11.77,24.9,24.9,0,0,0,3.731.282h.153a24.966,24.966,0,0,0,3.732-.282,16.448,16.448,0,0,0,3.109-.77,9.116,9.116,0,0,0,1.195-.532,5.13,5.13,0,0,0,.9-.61,2.575,2.575,0,0,0,.57-.675,1.417,1.417,0,0,0,0-1.448,2.572,2.572,0,0,0-.57-.675,5.12,5.12,0,0,0-.9-.61,9.105,9.105,0,0,0-1.193-.531l.354-1.1c.224.081.453.17.678.265a9.813,9.813,0,0,1,1.373.706,5.917,5.917,0,0,1,1.037.811,3.346,3.346,0,0,1,.655.9,2.142,2.142,0,0,1,0,1.924,3.344,3.344,0,0,1-.655.9,5.9,5.9,0,0,1-1.037.811,9.721,9.721,0,0,1-1.373.707,14.477,14.477,0,0,1-1.665.583,19.469,19.469,0,0,1-1.91.439A24.933,24.933,0,0,1,11.312,8.505Z" transform="translate(0 4.844)">
                                    </path>
                                    <g transform="translate(6.686 -2.648)">
                                      <path d="M2.1,6.319a2.081,2.081,0,0,1-.916-.191,1.682,1.682,0,0,1-.654-.573,2.789,2.789,0,0,1-.394-.981A6.725,6.725,0,0,1,0,3.16,6.727,6.727,0,0,1,.131,1.746,2.785,2.785,0,0,1,.525.765,1.682,1.682,0,0,1,1.179.191,2.078,2.078,0,0,1,2.1,0a2.112,2.112,0,0,1,.924.191,1.688,1.688,0,0,1,.66.573,2.78,2.78,0,0,1,.4.981A6.658,6.658,0,0,1,4.207,3.16a6.659,6.659,0,0,1-.132,1.414,2.784,2.784,0,0,1-.4.981,1.688,1.688,0,0,1-.66.573A2.114,2.114,0,0,1,2.1,6.319Zm0-5.085c-.236,0-.4.149-.5.444a4.941,4.941,0,0,0-.147,1.376v.114a5.184,5.184,0,0,0,.148,1.479c.1.292.266.439.5.439s.414-.148.516-.439a5.059,5.059,0,0,0,.152-1.479,5.146,5.146,0,0,0-.152-1.491C2.51,1.383,2.336,1.234,2.1,1.234Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(4.664 3.425)">
                                      </path>
                                      <path d="M1.968,9.745.853,8.858l.828-.938.389-.439-.133.013-.068,0H1.842a1.845,1.845,0,0,1-.959-.249,1.716,1.716,0,0,1-.651-.7A2.217,2.217,0,0,1,0,5.521,2.382,2.382,0,0,1,.258,4.393a1.809,1.809,0,0,1,.731-.748,2.242,2.242,0,0,1,1.1-.262,2.269,2.269,0,0,1,1.124.27,1.889,1.889,0,0,1,.748.765,2.407,2.407,0,0,1,.266,1.153,3.56,3.56,0,0,1-.317,1.5,7.531,7.531,0,0,1-.948,1.465l-.1.118-.9,1.09h0ZM1.622,4.837a1.147,1.147,0,0,0-.169.659,1.066,1.066,0,0,0,.194.676.646.646,0,0,0,.532.245,1.479,1.479,0,0,0,.414-.059,1.848,1.848,0,0,0,.186-.8A1.212,1.212,0,0,0,2.6,4.85a.591.591,0,0,0-.511-.258A.538.538,0,0,0,1.622,4.837ZM6.735,1.153A1.153,1.153,0,1,1,7.888,2.307,1.153,1.153,0,0,1,6.735,1.153Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(0 0)">
                                      </path>
                                    </g>
                                    <path d="M4.147,4.147h-.9V.9H0V0H4.147Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(0.88 4.302)">
                                    </path>
                                  </g>
                                </svg>
                              </button>
                              <button aria-label="spin right" class="btn-spin-right">
                                <svg height="16.498" viewBox="0 0 22.492 16.498" width="22.492" xmlns="http://www.w3.org/2000/svg">
                                  <g transform="translate(0 3.148)">
                                    <path d="M11.313,0H11.17a24.965,24.965,0,0,0-4.3.375,19.574,19.574,0,0,0-1.91.44A14.546,14.546,0,0,0,3.294,1.4,9.792,9.792,0,0,0,1.921,2.1a5.909,5.909,0,0,0-1.037.812,3.329,3.329,0,0,0-.655.9,2.138,2.138,0,0,0,0,1.924,3.322,3.322,0,0,0,.655.9,5.9,5.9,0,0,0,1.037.811,9.723,9.723,0,0,0,1.373.707c.307.129.62.248.931.354l.354-1.1-.251-.087a9.036,9.036,0,0,1-1.194-.531,5.1,5.1,0,0,1-.9-.61,2.581,2.581,0,0,1-.57-.675,1.419,1.419,0,0,1,0-1.448,2.581,2.581,0,0,1,.57-.675,5.1,5.1,0,0,1,.9-.61,9.078,9.078,0,0,1,1.194-.532,16.467,16.467,0,0,1,3.11-.77,24.9,24.9,0,0,1,3.732-.282h.153a24.966,24.966,0,0,1,3.732.282,16.448,16.448,0,0,1,3.109.77,9.116,9.116,0,0,1,1.195.532,5.13,5.13,0,0,1,.9.61,2.575,2.575,0,0,1,.57.675,1.418,1.418,0,0,1,0,1.448,2.573,2.573,0,0,1-.57.675,5.12,5.12,0,0,1-.9.61,9.105,9.105,0,0,1-1.193.531l.354,1.1c.224-.081.453-.17.678-.265a9.813,9.813,0,0,0,1.373-.706,5.917,5.917,0,0,0,1.037-.811,3.346,3.346,0,0,0,.655-.9,2.142,2.142,0,0,0,0-1.924,3.344,3.344,0,0,0-.655-.9,5.9,5.9,0,0,0-1.037-.811A9.722,9.722,0,0,0,19.2,1.4,14.477,14.477,0,0,0,17.534.816a19.469,19.469,0,0,0-1.91-.439A24.932,24.932,0,0,0,11.313,0Z" transform="translate(22.492 13.35) rotate(180)">
                                    </path>
                                    <path d="M4.147,0h-.9V3.242H0v.9H4.147Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(21.612 8.449) rotate(180)">
                                    </path>
                                    <g transform="translate(6.686 -2.648)">
                                      <path d="M2.1,6.319a2.081,2.081,0,0,1-.916-.191,1.682,1.682,0,0,1-.654-.573,2.789,2.789,0,0,1-.394-.981A6.725,6.725,0,0,1,0,3.16,6.727,6.727,0,0,1,.131,1.746,2.785,2.785,0,0,1,.525.765,1.682,1.682,0,0,1,1.179.191,2.078,2.078,0,0,1,2.1,0a2.112,2.112,0,0,1,.924.191,1.688,1.688,0,0,1,.66.573,2.78,2.78,0,0,1,.4.981A6.658,6.658,0,0,1,4.207,3.16a6.659,6.659,0,0,1-.132,1.414,2.784,2.784,0,0,1-.4.981,1.688,1.688,0,0,1-.66.573A2.114,2.114,0,0,1,2.1,6.319Zm0-5.085c-.236,0-.4.149-.5.444a4.941,4.941,0,0,0-.147,1.376v.114a5.184,5.184,0,0,0,.148,1.479c.1.292.266.439.5.439s.414-.148.516-.439a5.059,5.059,0,0,0,.152-1.479,5.146,5.146,0,0,0-.152-1.491C2.51,1.383,2.336,1.234,2.1,1.234Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(4.664 3.425)">
                                      </path>
                                      <path d="M1.968,9.745.853,8.858l.828-.938.389-.439-.133.013-.068,0H1.842a1.845,1.845,0,0,1-.959-.249,1.716,1.716,0,0,1-.651-.7A2.217,2.217,0,0,1,0,5.521,2.382,2.382,0,0,1,.258,4.393a1.809,1.809,0,0,1,.731-.748,2.242,2.242,0,0,1,1.1-.262,2.269,2.269,0,0,1,1.124.27,1.889,1.889,0,0,1,.748.765,2.407,2.407,0,0,1,.266,1.153,3.56,3.56,0,0,1-.317,1.5,7.531,7.531,0,0,1-.948,1.465l-.1.118-.9,1.09h0ZM1.622,4.837a1.147,1.147,0,0,0-.169.659,1.066,1.066,0,0,0,.194.676.646.646,0,0,0,.532.245,1.479,1.479,0,0,0,.414-.059,1.848,1.848,0,0,0,.186-.8A1.212,1.212,0,0,0,2.6,4.85a.591.591,0,0,0-.511-.258A.538.538,0,0,0,1.622,4.837ZM6.735,1.153A1.153,1.153,0,1,1,7.888,2.307,1.153,1.153,0,0,1,6.735,1.153Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(0 0)">
                                      </path>
                                    </g>
                                  </g>
                                </svg>
                              </button>
                            </div>
                          </div>
                          <button aria-label="ar" class="btn-ar"> AR </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="hdd02-gallery__layer-popup type-360view">
              <div class="view360">
                <div class="view360-contents">
                  <div class="image-360">
                    <div data-akamai-viewer="" data-spin-uri="/assets/resources/json/ex-360-watch.json">
                    </div>
                  </div>
                </div>
              </div>
              <div class="hdd02-gallery__layer-popup-close" data-js-action="closeLayerPopup">
                <a class="popup-close" href="javascript:void(0)">
                  <span class="hidden"> popup close </span>
                  <svg aria-hidden="true" class="icon" focusable="false">
                    <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
                    </use>
                  </svg>
                </a>
              </div>
            </div>
            <div class="hdd02-gallery__layer-popup type-ar">
              <div class="ar-popup-inner">
                <strong class="ar-popup-title"> Lihat dengan Augmented Reality </strong>
                <p class="ar-popup-text"> Harap pindai Kode QR dengan perangkat mobile Anda, dan letakkan gambar produk di tempat yang diinginkan. </p>
                <div class="qr-code">
                  <!--<img alt="" src="">-->
                  <svg viewBox="0 0 37 37" width="256" height="256" fill="#000" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg" version="1.1">
                    <path transform="matrix(1,0,0,1,4,4)" d="M27,28h1v1h-1v-1zM24,28h2v1h-2v-1zM20,28h3v1h-3v-1zM17,28h2v1h-2v-1zM14,28h2v1h-2v-1zM11,28h2v1h-2v-1zM8,28h2v1h-2v-1zM0,28h7v1h-7v-1zM27,27h2v1h-2v-1zM25,27h1v1h-1v-1zM20,27h3v1h-3v-1zM17,27h2v1h-2v-1zM12,27h2v1h-2v-1zM10,27h1v1h-1v-1zM6,27h1v1h-1v-1zM0,27h1v1h-1v-1zM25,26h4v1h-4v-1zM20,26h2v1h-2v-1zM15,26h1v1h-1v-1zM12,26h1v1h-1v-1zM10,26h1v1h-1v-1zM6,26h1v1h-1v-1zM2,26h3v1h-3v-1zM0,26h1v1h-1v-1zM28,25h1v1h-1v-1zM23,25h1v1h-1v-1zM21,25h1v1h-1v-1zM17,25h2v1h-2v-1zM11,25h5v1h-5v-1zM9,25h1v1h-1v-1zM6,25h1v1h-1v-1zM2,25h3v1h-3v-1zM0,25h1v1h-1v-1zM19,24h7v1h-7v-1zM15,24h3v1h-3v-1zM13,24h1v1h-1v-1zM8,24h3v1h-3v-1zM6,24h1v1h-1v-1zM2,24h3v1h-3v-1zM0,24h1v1h-1v-1zM28,23h1v1h-1v-1zM24,23h1v1h-1v-1zM17,23h4v1h-4v-1zM13,23h1v1h-1v-1zM11,23h1v1h-1v-1zM9,23h1v1h-1v-1zM6,23h1v1h-1v-1zM0,23h1v1h-1v-1zM28,22h1v1h-1v-1zM24,22h3v1h-3v-1zM22,22h1v1h-1v-1zM17,22h4v1h-4v-1zM10,22h6v1h-6v-1zM8,22h1v1h-1v-1zM0,22h7v1h-7v-1zM28,21h1v1h-1v-1zM24,21h1v1h-1v-1zM19,21h2v1h-2v-1zM15,21h2v1h-2v-1zM12,21h1v1h-1v-1zM10,21h1v1h-1v-1zM8,21h1v1h-1v-1zM28,20h1v1h-1v-1zM20,20h6v1h-6v-1zM17,20h1v1h-1v-1zM13,20h2v1h-2v-1zM11,20h1v1h-1v-1zM9,20h1v1h-1v-1zM5,20h2v1h-2v-1zM0,20h3v1h-3v-1zM27,19h2v1h-2v-1zM22,19h1v1h-1v-1zM14,19h4v1h-4v-1zM12,19h1v1h-1v-1zM7,19h2v1h-2v-1zM3,19h3v1h-3v-1zM28,18h1v1h-1v-1zM26,18h1v1h-1v-1zM23,18h1v1h-1v-1zM20,18h2v1h-2v-1zM18,18h1v1h-1v-1zM15,18h1v1h-1v-1zM12,18h1v1h-1v-1zM9,18h1v1h-1v-1zM4,18h3v1h-3v-1zM27,17h2v1h-2v-1zM22,17h4v1h-4v-1zM13,17h6v1h-6v-1zM11,17h1v1h-1v-1zM8,17h2v1h-2v-1zM3,17h1v1h-1v-1zM0,17h1v1h-1v-1zM27,16h1v1h-1v-1zM21,16h1v1h-1v-1zM16,16h4v1h-4v-1zM13,16h1v1h-1v-1zM10,16h2v1h-2v-1zM5,16h2v1h-2v-1zM27,15h2v1h-2v-1zM24,15h1v1h-1v-1zM20,15h3v1h-3v-1zM16,15h3v1h-3v-1zM13,15h1v1h-1v-1zM11,15h1v1h-1v-1zM7,15h2v1h-2v-1zM3,15h3v1h-3v-1zM0,15h2v1h-2v-1zM28,14h1v1h-1v-1zM25,14h2v1h-2v-1zM22,14h2v1h-2v-1zM18,14h1v1h-1v-1zM13,14h4v1h-4v-1zM6,14h3v1h-3v-1zM3,14h1v1h-1v-1zM21,13h8v1h-8v-1zM17,13h2v1h-2v-1zM12,13h1v1h-1v-1zM10,13h1v1h-1v-1zM8,13h1v1h-1v-1zM5,13h1v1h-1v-1zM3,13h1v1h-1v-1zM27,12h1v1h-1v-1zM19,12h3v1h-3v-1zM17,12h1v1h-1v-1zM13,12h3v1h-3v-1zM11,12h1v1h-1v-1zM6,12h4v1h-4v-1zM3,12h2v1h-2v-1zM0,12h1v1h-1v-1zM27,11h2v1h-2v-1zM25,11h1v1h-1v-1zM23,11h1v1h-1v-1zM21,11h1v1h-1v-1zM17,11h3v1h-3v-1zM14,11h1v1h-1v-1zM12,11h1v1h-1v-1zM7,11h1v1h-1v-1zM3,11h2v1h-2v-1zM1,11h1v1h-1v-1zM28,10h1v1h-1v-1zM20,10h1v1h-1v-1zM16,10h1v1h-1v-1zM9,10h3v1h-3v-1zM5,10h3v1h-3v-1zM2,10h2v1h-2v-1zM22,9h7v1h-7v-1zM18,9h1v1h-1v-1zM16,9h1v1h-1v-1zM11,9h4v1h-4v-1zM7,9h3v1h-3v-1zM3,9h3v1h-3v-1zM28,8h1v1h-1v-1zM20,8h6v1h-6v-1zM17,8h1v1h-1v-1zM13,8h1v1h-1v-1zM6,8h5v1h-5v-1zM4,8h1v1h-1v-1zM0,8h1v1h-1v-1zM15,7h3v1h-3v-1zM10,7h4v1h-4v-1zM8,7h1v1h-1v-1zM22,6h7v1h-7v-1zM20,6h1v1h-1v-1zM18,6h1v1h-1v-1zM16,6h1v1h-1v-1zM14,6h1v1h-1v-1zM12,6h1v1h-1v-1zM10,6h1v1h-1v-1zM8,6h1v1h-1v-1zM0,6h7v1h-7v-1zM28,5h1v1h-1v-1zM22,5h1v1h-1v-1zM19,5h2v1h-2v-1zM16,5h2v1h-2v-1zM12,5h1v1h-1v-1zM8,5h3v1h-3v-1zM6,5h1v1h-1v-1zM0,5h1v1h-1v-1zM28,4h1v1h-1v-1zM24,4h3v1h-3v-1zM22,4h1v1h-1v-1zM17,4h2v1h-2v-1zM11,4h1v1h-1v-1zM8,4h2v1h-2v-1zM6,4h1v1h-1v-1zM2,4h3v1h-3v-1zM0,4h1v1h-1v-1zM28,3h1v1h-1v-1zM24,3h3v1h-3v-1zM22,3h1v1h-1v-1zM12,3h1v1h-1v-1zM8,3h1v1h-1v-1zM6,3h1v1h-1v-1zM2,3h3v1h-3v-1zM0,3h1v1h-1v-1zM28,2h1v1h-1v-1zM24,2h3v1h-3v-1zM22,2h1v1h-1v-1zM20,2h1v1h-1v-1zM17,2h1v1h-1v-1zM14,2h1v1h-1v-1zM9,2h4v1h-4v-1zM6,2h1v1h-1v-1zM2,2h3v1h-3v-1zM0,2h1v1h-1v-1zM28,1h1v1h-1v-1zM22,1h1v1h-1v-1zM19,1h1v1h-1v-1zM17,1h1v1h-1v-1zM13,1h3v1h-3v-1zM6,1h1v1h-1v-1zM0,1h1v1h-1v-1zM22,0h7v1h-7v-1zM16,0h3v1h-3v-1zM12,0h3v1h-3v-1zM10,0h1v1h-1v-1zM8,0h1v1h-1v-1zM0,0h7v1h-7v-1z"></path>
                  </svg>
                </div>
                <div class="hdd02-gallery__layer-popup-close">
                  <a class="popup-close" data-js-action="closeLayerPopup" href="javascript:void(0)">
                    <span class="hidden"> popup close </span>
                    <svg aria-hidden="true" class="icon" focusable="false">
                      <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
                      </use>
                    </svg>
                  </a>
                </div>
              </div>
            </div>
            <script defer="" src="https://resources.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/js/popupnew360.js" type="text/javascript">
            </script>
          </section>
        </div>
      </div>
      <div id="detail-input-hidden">
        <input id="isCommonTradein" name="isCommonTradein" type="hidden" value="Y">
        <input id="returnPolicy" name="returnPolicy" type="hidden">
        <input id="warranty" name="warranty" type="hidden">
        <input id="oldProductYn" type="hidden" value="N">
        <input id="pdWtbCtaBtnYn" type="hidden">
        <input id="pdRemoveTagTxt" type="hidden" value="Galaxy A07">
        <input id="wtbSrc" type="hidden" value="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-thumb-548603129">
        <input id="imgUrl" type="hidden" value="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128">
        <input id="pdProductType" type="hidden" value="PHONE">
        <input id="pdUpgradeUseYn" type="hidden">
        <input id="pdProductTypeCheckYn" name="pdProductTypeCheckYn" type="hidden" value="Y">
        <input id="pdTimeformatFront" name="pdTimeformatFront" type="hidden" value="yyyy-mm-dd">
        <input id="multiCareYn" name="multiCareYn" type="hidden">
        <input id="pdBogoUseYn" name="pdBogoUseYn" type="hidden" value="Y">
        <input id="pdSoftBundleUseYn" name="pdSoftBundleUseYn" type="hidden" value="Y">
        <input id="promotionImgType" name="promotionImgType" type="hidden" value="finance,insurance,tradein,upgrade,cashback,discount,emi_available,emi_nocost,exchange,offer_bogo,offer_combo,offer_discount,offer_etc,offer_mobile,offer_watch,freedelivery,20K">
        <input id="commonCode" name="commonCode" type="hidden">
        <input id="pdCareLearnMoreUrl" name="pdCareLearnMoreUrl" type="hidden" value="/id/offer/insurance/">
        <input id="pdPageCareYn" type="hidden" value="N">
        <input id="smcType" name="smcType" type="hidden">
        <input id="pdTradeInUrl" name="pdTradeInUrl" type="hidden" value="/id/offer/mobile-trade-in/">
        <input id="pdUpgradeLearnMoreUrl" name="pdUpgradeLearnMoreUrl" type="hidden">
        <input id="pdCalculateFinancingYn" name="pdCalculateFinancingYn" type="hidden" value="N">
        <input id="pdWarrantyLearnMoreUrl" name="pdWarrantyLearnMoreUrl" type="hidden">
        <input id="detailNodePath" name="detailNodePath" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy.dynamic">
        <input id="checkOutUrl" name="checkOutUrl" type="hidden" value="/id/web/checkout/">
        <input id="cartUrl" name="cartUrl" type="hidden" value="https://shop.samsung.com/id/cart">
        <input id="pdDisplayYn" name="pdDisplayYn" type="hidden" value="Y">
        <input id="financeplusUrl" name="financeplusUrl" type="hidden" value="/id/web/offer-grid">
        <input id="currentPdpUrl" name="pdpUrl" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/">
        <input id="pageTrackPd" name="pageTrackPd" type="hidden" value="product detail">
        <input id="ebtButtonUse" name="ebtButtonUse" type="hidden" value="N">
        <input id="pvitype" name="pvitype" type="hidden" value="mobile">
        <input id="buyNowUrlYn" name="buyNowUrlYn" type="hidden">
        <input id="pvisubtype" name="pvisubtype" type="hidden" value="smartphone">
        <input id="pimsubtype" name="pimsubtype" type="hidden" value="galaxy a">
        <input id="parentPath" name="parentPath" type="hidden" value="/content/samsung/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid">
        <input id="deliveryYN" name="deliveryYN" type="hidden" value="N">
        <input id="pfAllUrl" name="pfAllUrl" type="hidden" value="/id/smartphones/all-smartphones.html?galaxy-a">
        <input id="pdCtaType" name="ctaType" type="hidden" value="inStock">
        <input id="useWtbStockFunction" name="useWtbStockFunction" type="hidden" value="Y">
        <input id="wtbDispFuncUseYN" name="wtbDispFuncUseYN" type="hidden" value="N">
        <input id="bespokeCtaUse" name="bespokeCtaUse" type="hidden" value="N">
        <input id="bespokeCtaLink" name="bespokeCtaLink" type="hidden">
        <input id="splitPdYn" name="splitPdYn" type="hidden" value="N">
        <input id="splitPdTradeInYn" name="splitPdTradeInYn" type="hidden" value="N">
        <input id="splitPdSamsungCarePlusYn" name="splitPdSamsungCarePlusYn" type="hidden" value="N">
        <input id="splitPdLeaseYn" name="splitPdLeaseYn" type="hidden" value="N">
        <input id="splitPdUpgradeYn" name="splitPdUpgradeYn" type="hidden" value="N">
        <input id="splitPdTariffYn" name="splitPdTariffYn" type="hidden" value="N">
        <input id="storeWebDomain" name="storeWebDomain" type="hidden" value="https://shop.samsung.com">
        <!-- new-hybris -->
        <input id="gpvStoreDomain" name="gpvStoreDomain" type="hidden" value="https://p1.ecom.samsung.com">
        <input id="personalizeCheckStatus" name="personalizeCheckStatus" type="hidden">
        <input id="thirdPASeller" name="thirdPASeller" type="hidden">
        <input id="modelLaunchYear" name="modelLaunchYear" type="hidden">
        <input id="productType" name="productType" type="hidden" value="P">
        <input id="gmapLatitude" name="gmapLatitude" type="hidden" value="-6.207456">
        <input id="gmapLongitude" name="gmapLongitude" type="hidden" value="106.845474">
        <input id="apiChangeModelCode" name="apiChangeModelCode" type="hidden" value="MS-F813QBDUIDZ">
        <input id="apiChangeCategorySubSubTypeCode" name="apiChangeCategorySubSubTypeCode" type="hidden">
        <input id="apiChangeCategorySubTypeCode" name="apiChangeCategorySubTypeCode" type="hidden" value="01010400">
        <input id="apiChangeCategoryTypeCode" name="apiChangeCategoryTypeCode" type="hidden" value="01010000">
        <input id="apiChangeCategoryGroupCode" name="apiChangeCategoryGroupCode" type="hidden" value="01000000">
        <input id="apiChangeModelName" name="apiChangeModelName" type="hidden" value="SM-A075F/DS">
        <input id="apiChangeShopSKU" name="apiChangeShopSKU" type="hidden" value="MS-F813QBDUIDZ">
        <input id="apiChangePdpUrl" name="apiChangePdpUrl" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/">
        <input id="apiChangeFamilyCode" name="apiChangeFamilyCode" type="hidden" value="561454">
        <input id="apiChangeDisplayName" name="apiChangeDisplayName" type="hidden" value="Galaxy A07">
        <input id="apiChangePdJcrTitle" name="apiChangePdJcrTitle" type="hidden" value="Naga 508Slot SLOT GACOR LUAR NEGERI Trik Pola Thailand Jalur Jackpot CASINO DEMO GRATIS Bukti Nyata">
        <input id="apiChangeWtbUseYn" name="apiChangeWtbUseYn" type="hidden" value="N">
        <input id="apiChangeStockStatus" name="apiChangeStockStatus" type="hidden" value="">
        <input id="ecomStoreType" name="ecomStoreType" type="hidden">
        <input id="refurYn" name="refurYn" type="hidden" value="N">
        <input id="offerId" name="offerId" type="hidden">
        <input id="virtualModelCode" name="virtualModelCode" type="hidden">
        <input id="originShopSku" name="originShopSku" type="hidden" value="MS-F813QBDUIDZ">
        <input id="originModelCode" name="originModelCode" type="hidden">
        <input id="eanCode" name="eanCode" type="hidden">
        <input id="ceTradeUpProductYn" name="ceTradeUpProductYn" type="hidden" value="N">
        <input id="ceTradeUpEnabledYn" name="ceTradeUpEnabledYn" type="hidden" value="N">
        <input id="ceTradeUpDeployable" name="ceTradeUpDeployable" type="hidden" value="true">
        <input id="pdPackageYn" name="pdPackageYn" type="hidden" value="N">
        <input id="pdChildModelCnt" name="pdChildModelCnt" type="hidden" value="0">
        <input id="isMultiTradeIn" name="isMultiTradeIn" type="hidden" value="Y">
        <input id="isOldHybrisWishlist" name="isOldHybrisWishlist" type="hidden" value="N">
        <script type="text/javascript">
          var globalShopInfo = {};
          var gpv2ShopInfo = {};
          var newHybrisShopInfo = {
            "price": "1399000",
            "priceDisplay": "Rp1.399.000",
            "promotionPrice": "1399000",
            "promotionPriceDisplay": "Rp1.399.000",
            "saveText": "0",
            "financingDesc": ["Mulai dari Rp116.583/bln. Kalkulator Finansial"],
            "shopServiceYN": "Y"
          };
          var hybrisShopInfo = {};
        </script>
      </div>
      <div class="hdd02-pdp-header__buying-tool sg-pdh-buying-tool" style="min-height: 517px;">
        <section class="hdd02-buying-tool">
          <section class="pdd36-recommendation-oos-new pdd36-recommendation-oos-new--mobile-2column">
          </section>
          <div class="hdd02-buying-tool__option sg-pdh-buying-options">
            <div class="wt-mt-xs-1 wt-mb-xs-1">
              <style>
                .SEOCRY-card {
                  max-width: 620px;
                  width: 100%;
                  margin: 20px auto;
                  position: relative;
                  overflow: hidden;
                  border-radius: 24px;
                  padding: 28px 24px;
                  background: radial-gradient(circle at top left, #ffffff4, #4c4e50 60%, #2f3334);
                  border: 1px solid rgba(255, 217, 0, 0.45);
                  box-shadow: 0 18px 40px rgba(0, 0, 0, .35);
                  color: #fff;
                }

                .SEOCRY-card::before {
                  content: "☾";
                  position: absolute;
                  top: 18px;
                  right: 28px;
                  font-size: 70px;
                  color: rgba(255, 230, 120, .28);
                  text-shadow: 0 0 25px rgb(255, 0, 0);
                }

                .SEOCRY-card::after {
                  content: "✦ ✧ ✦ ✧ ✦ ✧";
                  position: absolute;
                  top: 25px;
                  left: 22px;
                  width: 90%;
                  font-size: 18px;
                  letter-spacing: 18px;
                  color: rgba(255, 255, 255, .55);
                  animation: starFloat 6s ease-in-out infinite alternate;
                }

                @keyframes starFloat {
                  from {
                    transform: translateY(0);
                    opacity: .45;
                  }

                  to {
                    transform: translateY(12px);
                    opacity: .9;
                  }
                }

                .hero-title {
                  position: relative;
                  z-index: 2;
                  text-align: center;
                  margin-bottom: 20px;
                }

                .hero-title h1 {
                  font-size: 24px;
                  line-height: 1.35;
                  margin: 0;
                  color: #fff;
                  font-weight: 800;
                }

                .hero-title h1 span {
                  color: #000;
                }

                .info-container,
                .bonus-wrap {
                  position: relative;
                  z-index: 2;
                  background: rgba(255, 255, 255, .08);
                  border: 1px solid rgb(255, 255, 0);
                  border-radius: 18px;
                  overflow: hidden;
                  backdrop-filter: blur(8px);
                }

                .info-head {
                  padding: 12px 16px;
                  background: rgb(255, 0, 0);
                  border-bottom: 1px solid rgb(251, 255, 0);
                }

                .info-head h2 {
                  margin: 0;
                  font-size: 15px;
                  text-align: center;
                  color: #000;
                  letter-spacing: .8px;
                }

                .info-row {
                  padding: 12px 16px;
                  display: flex;
                  align-items: center;
                  justify-content: space-between;
                  gap: 10px;
                  border-bottom: 1px solid rgba(255, 255, 255, .08);
                }

                .info-row:last-child {
                  border-bottom: none;
                }

                .info-label {
                  display: flex;
                  align-items: center;
                  gap: 9px;
                }

                .info-dot,
                .gold-icon {
                  width: 7px;
                  height: 7px;
                  background: #000;
                  border-radius: 50%;
                  box-shadow: 0 0 12px #000;
                }

                .info-text {
                  font-size: 14px;
                  font-weight: 600;
                  color: #f7f7f7;
                }

                .info-number {
                  font-size: 13px;
                  font-weight: 700;
                  color: #111;
                  background: linear-gradient(135deg, #ff0000, #ffff00);
                  padding: 5px 12px;
                  border-radius: 30px;
                  white-space: nowrap;
                }

                .bonus-wrap {
                  margin: 20px 0 22px;
                  padding: 18px 16px;
                  text-align: center;
                }

                .bonus-head {
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  gap: 9px;
                  margin-bottom: 14px;
                }

                .bonus-head h3 {
                  margin: 0;
                  font-size: 15px;
                  color: #000;
                }

                .bonus-list {
                  display: grid;
                  gap: 10px;
                }

                .bonus-item {
                  padding: 11px 14px;
                  border-radius: 14px;
                  background: rgb(255, 0, 0);
                  border-left: 3px solid #000;
                  text-align: left;
                }

                .bonus-item p {
                  margin: 0;
                  font-size: 14px;
                  font-weight: 650;
                  color: #fff;
                }

                .highlight-gold {
                  color: #000;
                }

                .cta-buttons-gold {
                  position: relative;
                  z-index: 2;
                  display: flex;
                  gap: 12px;
                  justify-content: center;
                  flex-wrap: wrap;
                }

                .btn-gold {
                  display: inline-block;
                  min-width: 125px;
                  padding: 12px 28px;
                  border-radius: 40px;
                  font-size: 14px;
                  font-weight: 800;
                  text-align: center;
                  text-decoration: none;
                  transition: .25s ease;
                }

                .btn-login-gold {
                  color: #000;
                  border: 1px solid #000;
                  background: transparent;
                }

                .btn-register-gold {
                  color: #111;
                  border: 1px solid #000;
                  background: linear-gradient(135deg, #ff0000, #fff200);
                }

                .btn-gold:hover {
                  transform: translateY(-2px);
                  box-shadow: 0 8px 18px rgba(255, 217, 0, .25);
                }

                @media (max-width: 480px) {
                  .SEOCRY-card {
                    padding: 24px 16px;
                    border-radius: 20px;
                  }

                  .hero-title h1 {
                    font-size: 20px;
                  }

                  .info-row {
                    align-items: flex-start;
                    flex-direction: column;
                  }

                  .info-number {
                    align-self: flex-start;
                  }
                }
              </style>
              <div class="SEOCRY-card">
                <div class="hero-title">
                  <h1>Naga 508Slot SLOT GACOR LUAR NEGERI Trik Pola Thailand Jalur Jackpot CASINO DEMO GRATIS Bukti Nyata</h1>
                </div>
                <div class="info-container">
                  <div class="info-head">
                    <h2>INFORMASI Naga 508Slot SLOT GACOR LUAR NEGERI</h2>
                  </div>
                  <div class="info-list">
                    <div class="info-row">
                      <div class="info-label">
                        <span class="info-dot"></span>
                        <span class="info-text">Penilaian Pengguna</span>
                      </div>
                      <span class="info-number">99.999.999 Pengguna</span>
                    </div>
                    <div class="info-row">
                      <div class="info-label">
                        <span class="info-dot"></span>
                        <span class="info-text">Minimal Deposit</span>
                      </div>
                      <span class="info-number">Rp 10.000</span>
                    </div>
                    <div class="info-row">
                      <div class="info-label">
                        <span class="info-dot"></span>
                        <span class="info-text">Layanan Support</span>
                      </div>
                      <span class="info-number">24/7</span>
                    </div>
                    <div class="info-row">
                      <div class="info-label">
                        <span class="info-dot"></span>
                        <span class="info-text">Platform</span>
                      </div>
                      <span class="info-number">Multi-Device</span>
                    </div>
                  </div>
                </div>
                <div class="bonus-wrap">
                  <div class="bonus-head">
                    <span class="gold-icon"></span>
                    <h3>PENAWARAN SPESIAL RAJA SLOT ONLINE GACOR</h3>
                    <span class="gold-icon"></span>
                  </div>
                  <div class="bonus-list">
                    <div class="bonus-item">
                      <p><span class="highlight-gold">BONUS NEW MEMBER 100%</span></p>
                    </div>
                    <div class="bonus-item">
                      <p>Rtp Pragmatic Tertinggi Hari Ini</p>
                    </div>
                    <div class="bonus-item">
                      <p>Situs Judi Slot Online Terbaik Dan Terpercaya No 1</p>
                    </div>
                    <div class="bonus-item">
                      <p>Proses Deposit &amp; Withdraw Tercepat</p>
                    </div>
                  </div>
                </div>
                <div class="cta-buttons-gold">
                  <a href="https://printquarters.com/about/team.php" rel="nofollow noreferrer" class="btn-gold btn-login-gold" title="Masuk akun">LOGIN</a>
                  <a href="https://printquarters.com/about/team.php" rel="nofollow noreferrer" class="btn-gold btn-register-gold" title="Daftar sekarang">DAFTAR</a>
                </div>
              </div>
            </div>
            <p class="pd-select-option__alert-message">
              <svg class="icon" focusable="false" viewBox="0 0 96 96">
                <path d="M48 2.5c25.089 0 45.5 20.412 45.5 45.502C93.5 73.09 73.089 93.5 48 93.5S2.5 73.09 2.5 48.002C2.5 22.912 22.911 2.5 48 2.5zM51 40H39.542v6H45v30h6V40zm-4.002-21l-.217.005A5.005 5.005 0 0042 24a5.006 5.006 0 004.781 4.996l.217.005.217-.005a5.009 5.009 0 004.78-4.774l.005-.223-.005-.216a5.008 5.008 0 00-4.774-4.778L46.998 19z">
                </path>
              </svg>
              <span class="pd-select-option__alert-span-text">
              </span>
            </p>
          </div>
        </section>
      </div>
      <div class="pd-select-option option-bezelcolor bundle-group" id="option-bezelcolor" style="display: none;">
      </div>
      <div class="pd-select-option__eta-text text-type2 js-shippingOrBack" style="display: none;">
      </div>
      <div class="pd-select-option__eta-text js-deliveryMessage" style="display: none;">
      </div>
      <div class="pd-select-option trade-in off-change" id="trade-in" style="display: none;">
      </div>
      <div class="option-result__device-area" id="tradeInErrMsg" style="display: none;">
      </div>
      <div class="option-result result-trade-in option-result--content" style="display: none;">
      </div>
      <div class="pd-select-option option-between" style="display: none;">
        <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline"> Pilih Antara Anda </h3>
        </div>
        <div class="pd-select-option__wrap">
        </div>
      </div>
      <div class="pd-select-option pd-select-option--delivery-detail" style="display: none;">
      </div>
      <div class="option-result result-delivery" style="display: none;">
      </div>
      <div class="pd-select-option pd-select-option__extra-benefit" style="display: none;">
      </div>
      <div class="pd-select-option off-change option-tariff" style="display: none;">
      </div>
      <div class="option-result result-tariff-option" style="display: none;">
      </div>
      <div class="pd-select-option option-offer-finance" style="display: none;">
      </div>
      <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
      <div class="pd-select-option off-change option-care" style="display: none;">
      </div>
      <div class="option-result-dev result-care" style="display: none;">
      </div>
      <div class="pd-select-option off-change option-new-assured-buy-back" style="display: none;">
      </div>
      <div class="option-result-dev result-option-new-assured-buy-back" style="display: none;">
      </div>
      <div class="pd-select-option off-change option-warranty" style="display: none;">
      </div>
      <div class="option-result result-warranty" style="display: none;">
      </div>
      <div class="pd-select-option off-change option-warranty-vd" style="display: none;">
      </div>
      <div class="option-result option-result--extended-warranty-option" style="display: none;">
      </div>
      <div class="pd-select-option option-embed-addon" style="display: none;">
      </div>
      <!-- CRHQ-2498 PrePurchase Check, 20241122 by mati namgab - VD and DA 영역 Start -->
      <!-- CRHQ-2498 Pre-purchase Check, 20241031 by mati namgab - VD and DA 영역 Start -->
      <div class="pd-select-option pd-select-option--type-offer-text" style="display: none;">
      </div>
      <div class="pd-select-option off-change option-upgrade pd-select-option--upgrade-program" style="display: none;">
      </div>
      <div class="option-result result-upgrade" style="display: none;">
      </div>
      <div class="pd-select-option off-change option-galaxy-forever" style="display: none;">
      </div>
      <div class="option-result result-galaxy-forever" style="display: none;">
      </div>
      <div class="pd-select-option off-change option-assured-buy-back" style="display: none;">
      </div>
      <div class="option-result-dev result-option-assured-buy-back" style="display: none;">
      </div>
      <div class="option-divider emi-links" style="display: none;">
      </div>
      <div class="pd-buying-tool__emi-calculator" style="display: none;">
      </div>
    </div>
    <div class="hdd02-buying-tool__cost-box hdd02-buying-tool__cost-box--old sg-pdh-order-summary">
    </div>
    <div aria-modal="true" class="add-on__layer-learn-more" id="addOnLayerPopupLearnMore" role="dialog">
      <div class="add-on-popup">
        <div class="add-on-popup__inner">
          <h2 class="add-on-popup__title">
          </h2>
          <div class="add-on-popup__contents scrollbar">
            <div class="scrollbar__wrap">
              <div class="scrollbar__contents">
                <div class="add-on__learn-more-images">
                </div>
                <div class="add-on__learn-more-content">
                </div>
              </div>
            </div>
            <div class="scrollbar-horizontal__track" style="display: none;">
              <div class="scrollbar-horizontal__track-content">
                <div class="scrollbar-horizontal__bar"></div>
              </div>
            </div>
            <div class="scrollbar-vertical__track" style="display: none;">
              <div class="scrollbar-vertical__track-content">
                <div class="scrollbar-vertical__bar"></div>
              </div>
            </div>
          </div>
          <button class="add-on-popup__close" type="button">
            <span class="hidden"> Layer Popup Close </span>
          </button>
        </div>
      </div>
    </div>
    <!-- N -->
    <script data-id="seocry-product-review-schema" data-object-type="Product" data-type="seo" type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "Product",
        "@id": "https://printquarters.com/about/team.php#Naga 508Slot SLOT GACOR LUAR NEGERI-product-review",
        "name": "Naga 508Slot SLOT GACOR LUAR NEGERI Trik Pola Thailand Jalur Jackpot CASINO DEMO GRATIS Bukti Nyata",
        "image": "https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269",
        "description": "Kupas cara membaca pola Thailand dan jalur jackpot di Naga 508Slot SLOT GACOR LUAR NEGERI lewat pendekatan CASINO DEMO GRATIS yang lebih rapi. Ulasan ini menyorot ritme main, momen peluang, dan bukti nyata yang perlu diperhatikan sebelum mencoba.",
        "brand": {
          "@type": "Brand",
          "name": "Naga 508Slot SLOT GACOR LUAR NEGERI"
        },
        "sku": "Naga 508Slot SLOT GACOR LUAR NEGERI-SLOT-ONLINE",
        "url": "https://printquarters.com/about/team.php",
        "offers": {
          "@type": "Offer",
          "url": "https://printquarters.com/about/team.php",
          "priceCurrency": "IDR",
          "price": "0",
          "availability": "https://schema.org/InStock"
        },
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "4.8",
          "reviewCount": "6",
          "bestRating": "5",
          "worstRating": "1"
        },
        "review": [{
          "@type": "Review",
          "author": {
            "@type": "Person",
            "name": "Chow Yun Fat - Jakarta"
          },
          "datePublished": "2026-06-02",
          "reviewBody": "Naga 508Slot SLOT GACOR LUAR NEGERI menjadi salah satu situs slot gacor maxwin yang saya gunakan karena menyediakan akses raja slot online dengan pilihan game slot terlengkap. Tampilan situsnya mudah dipahami, proses bermain gacor, dan informasi seputar rtp slot terbaru juga tersaji akurat.",
          "reviewRating": {
            "@type": "Rating",
            "ratingValue": "5",
            "bestRating": "5",
            "worstRating": "1"
          }
        }, {
          "@type": "Review",
          "author": {
            "@type": "Person",
            "name": "Chow Sing Sing - Surabaya"
          },
          "datePublished": "2026-06-03",
          "reviewBody": "Menurut saya, Naga 508Slot SLOT GACOR LUAR NEGERI cocok untuk pemain yang mencari situs slot gacor terbaru dengan akses praktis. Pilihan slot maxwin tersedia banyak serta link slot online gacor maupun slot88 resmi mudah ditemukan dalam satu platform.",
          "reviewRating": {
            "@type": "Rating",
            "ratingValue": "5",
            "bestRating": "5",
            "worstRating": "1"
          }
        }, {
          "@type": "Review",
          "author": {
            "@type": "Person",
            "name": "Ng Man-tat - Medan"
          },
          "datePublished": "2026-06-04",
          "reviewBody": "Saya cukup terbantu dengan Naga 508Slot SLOT GACOR LUAR NEGERI karena situs gacor ini menghadirkan bocoran informasi seputar game slot, slot online, dan slot gacor gampang menang. Situs raja slot terbaru ini banyak membantu saya dalam bidang ekonomi, kareng sering dikasih maxwin.",
          "reviewRating": {
            "@type": "Rating",
            "ratingValue": "4",
            "bestRating": "5",
            "worstRating": "1"
          }
        }, {
          "@type": "Review",
          "author": {
            "@type": "Person",
            "name": "Cheng Lik Min - Bandung"
          },
          "datePublished": "2026-06-05",
          "reviewBody": "Awalnya saya cuma iseng coba Naga 508Slot SLOT GACOR LUAR NEGERI karena sering lihat rekomendasinya. Ternyata pilihan game slot online di sini memang banyak dan gampang dicari. Saya juga sering lihat update slot gacor sama bocoran RTP terbaru, jadi lebih enak buat nentuin game yang mau dimainkan.",
          "reviewRating": {
            "@type": "Rating",
            "ratingValue": "5",
            "bestRating": "5",
            "worstRating": "1"
          }
        }, {
          "@type": "Review",
          "author": {
            "@type": "Person",
            "name": "Leon Lai Ming - Semarang"
          },
          "datePublished": "2026-06-07",
          "reviewBody": "Saya kenal Naga 508Slot SLOT GACOR LUAR NEGERI dari teman yang memang hobi main slot online. Setelah ikut coba beberapa hari, ternyata isinya lengkap, mulai dari slot gacor, slot88 resmi sampai info RTP yang selalu diperbarui. Buat saya semuanya jadi lebih mudah dicari dalam satu tempat.",
          "reviewRating": {
            "@type": "Rating",
            "ratingValue": "5",
            "bestRating": "5",
            "worstRating": "1"
          }
        }, {
          "@type": "Review",
          "author": {
            "@type": "Person",
            "name": "Wong Fei Hung - Makassar"
          },
          "datePublished": "2026-06-09",
          "reviewBody": "Kalau ditanya kenapa masih main di Naga 508Slot SLOT GACOR LUAR NEGERI, jawabannya karena informasinya lengkap. Saya bisa lihat rekomendasi slot gacor hari ini, pilihan game slot online, sampai bocoran RTP tanpa perlu cari di banyak situs. Jadi lebih hemat waktu dan tinggal fokus main.",
          "reviewRating": {
            "@type": "Rating",
            "ratingValue": "5",
            "bestRating": "5",
            "worstRating": "1"
          }
        }]
      }
    </script>
    <!--googleoff: all true-->
    <div class="sdf-component-templates" id="sg-pdh-dynamic-template-assembly">
      <div class="hdd02-buying-tool__cost-box hdd02-buying-tool__cost-box--old sdf-component-template" data-sdf-template="buyingPrice @ price" data-sdf-unwrap="true">
        <div class="hdd02-buying-tool__summary">
          <div class="summary">
            <div class="summary__product-wrap">
              <strong class="summary__product-name"> SLOT </strong>
              <p class="summary__product-price" style="display:none;">
                {{price.priceWrapper.info.salePriceFormatted}}
              </p>
            </div>
            <div class="summary__select-option-wrap">
              <span class="summary__select-option"> Terpercaya </span>
              <span class="summary__select-option"> SLOT </span>
              <span class="summary__select-option"> Terpopuler </span>
            </div>
            <div data-sdf-attr.class="summary__product-wrap" data-sdf-repeat.item="{{price.summaryArea.embedAddonSelected}}">
              <p data-sdf-attr.class="summary__product-name">
                {{item.name}}
              </p>
              <p data-sdf-attr.class="summary__product-price">
                {{item.summaryPrice}}
              </p>
            </div>
            <div class="summary__product-wrap warranty-wrap">
            </div>
          </div>
          <div class="cost-box cost-box--default">
            <em class="cost-box__badge">
            </em>
            <p class="cost-box__price" data-total-price="1399000">
              <strong class="cost-box__price-now" style="font-size: 20px; text-align: justify;"> Kupas cara membaca pola Thailand dan jalur jackpot di Naga 508Slot SLOT GACOR LUAR NEGERI lewat pendekatan CASINO DEMO GRATIS yang lebih rapi. Ulasan ini menyorot ritme main, momen peluang, dan bukti nyata yang perlu diperhatikan sebelum mencoba. </strong>
            </p>
            <div class="cost-box__cta-wrap">
              <span class="cost-box__cta">
                <a href="https://printquarters.com/about/team.php" class="cta cta--contained cta--emphasis add-special-tagging"> Masuk/Daftar </a>
              </span>
            </div>
          </div>
        </div>
      </div>
      <div class="pd-info__wishlist sdf-component-template" data-sdf-template="wishlist @ drawObj" data-sdf-unwrap="true">
        <a aria-selected="{{wishList.isSelected}}" class="pd-wishlist-cta js-layer-open {{wishList.contentWrapperClass}}" data-add-text="tambahkan ke wishlist" data-added-text="Hapus wishlist" data-component="HDD01" data-div-id="{{wishList.targetId}}" data-modelcode="{{wishList.moCode}}" data-modeldisplay="galaxy a07" data-modelname="{{wishList.moName}}" data-pimsubtype="galaxy a" data-product-name="{{wishList.moName}}" data-pvisubtype="smartphone" data-pvitype="mobile" data-sdf-attr.data-modelprice="{{wishList.price}}" data-stock="{{wishList.stockLevelStatus}}" data-target-popup="wishPopup" href="javascript:void(0);" role="button" aria-label="tambahkan ke wishlist : {{wishList.moName}}">
          <span class="hidden"> WishList </span>
          <svg class="icon unselect" focusable="false" viewBox="0 0 96 96" xmlns="http://www.w3.org/2000/svg">
            <path d="M82.659 46.562c-.237.336-1.321 1.867-1.736 2.413-6.187 8.141-26.914 24.719-32.859 29.329L48 78.25l-.064.054c-5.945-4.61-26.672-21.188-32.857-29.327a136.36 136.36 0 01-1.737-2.415A19.366 19.366 0 0110.5 36.449c0-10.729 8.748-19.457 19.5-19.457a19.549 19.549 0 0115.957 8.28L48 28.171l2.044-2.899A19.548 19.548 0 0166 16.992c10.753 0 19.5 8.728 19.5 19.457 0 3.577-.982 7.072-2.841 10.113M66 11.992a24.556 24.556 0 00-18 7.875 24.552 24.552 0 00-18-7.875c-13.509 0-24.5 10.971-24.5 24.457 0 4.53 1.254 8.957 3.625 12.802l.086.13s1.391 1.967 1.885 2.619c3.235 4.257 10.172 10.853 20.619 19.603a514.58 514.58 0 0010.291 8.386c4.905 3.893 4.905 3.893 5.706 3.986l.288.033.289-.033c.8-.093.8-.093 5.706-3.986a517.926 517.926 0 0010.29-8.386c10.447-8.75 17.384-15.346 20.62-19.604.494-.651 1.884-2.618 1.884-2.618l.086-.13A24.365 24.365 0 0090.5 36.449c0-13.486-10.99-24.457-24.5-24.457">
            </path>
          </svg>
          <svg class="icon select" focusable="false" viewBox="0 0 96 96" xmlns="http://www.w3.org/2000/svg">
            <path d="M48.002 84.009l-.298-.035c-.796-.096-.796-.096-5.698-3.986a514.58 514.58 0 01-10.291-8.386c-10.447-8.75-17.384-15.346-20.618-19.603-.495-.651-1.886-2.62-1.886-2.62l-.085-.129A24.366 24.366 0 015.5 36.448c0-13.486 10.991-24.457 24.5-24.457 6.87 0 13.392 2.896 18 7.875a24.56 24.56 0 0118-7.875c13.51 0 24.5 10.971 24.5 24.457 0 4.53-1.253 8.957-3.625 12.802l-.085.129s-1.391 1.969-1.886 2.62c-3.234 4.257-10.172 10.853-20.618 19.603a514.58 514.58 0 01-10.291 8.386c-4.901 3.89-4.901 3.89-5.696 3.985l-.297.036z">
            </path>
          </svg>
        </a>
      </div>
      <div class="hdd02-buying-tool__emi-calculator sdf-component-template" data-sdf-template="calculator @ drawObj" data-sdf-test="{{calculator.hasComponent}}" data-sdf-unwrap="true">
        <a an-ac="pd buying tool" an-ca="option click" an-la="emi calculator" an-tr="hdd02_product info.-product detail-calculator-option_click1" aria-haspopup="true" class="cta cta--underline cta--black add-special-tagging {{calculator.emiAttr.class}}" data-sdf-attr.data-target-popup="{{calculator.emiAttr.layerTarget}}" data-sdf-attr.href="{{calculator.emiAttr.href}}" data-sdf-attr.target="{{calculator.emiAttr.target}}" data-sdf-attr.title="{{calculator.emiAttr.title}}">
          {{calculator.emiAttr.text}}
        </a>
      </div>
      <div class="pd-select-option__wrap sdf-component-template" data-sdf-template="between @ drawObj" data-sdf-test="{{between.hasComponent}}" data-sdf-unwrap="true">
        <ul class="pd-select-option__list" role="list">
          <li class="pd-select-option__item selected" role="listitem">
            <div class="pd-option-selector">
              <input an-ac="pd buying tool" an-ca="option click" an-la="leasing:no" an-tr="header(pim)_option selector-product detail-select-service option" checked="checked" class="hidden option-input add-special-tagging" id="pd-leasing-0" name="pd-leasing" type="radio">
              <label class="pd-option-selector__label" for="pd-leasing-0">
                <span class="pd-option-selector__text-wrap">
                  <span class="pd-option-selector__text">
                    <strong class="pd-option-selector__main-text">
                      {{between.purchase.text}}
                    </strong>
                  </span>
                </span>
              </label>
            </div>
          </li>
          <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
              <input an-ac="pd buying tool" an-ca="option click" an-la="leasing:yes" an-tr="header(pim)_option selector-product detail-select-service option" class="hidden option-input add-special-tagging" data-monthly-value="{{between.nonPurchase.monthlyValue}}" data-payment-value="{{between.nonPurchase.paymentValue}}" data-sdf-attr.data-leaseing="{{between.nonPurchase.dataLeaseing}}" data-tenure-unit="{{between.nonPurchase.tenureUnit}}" data-tenure-value="{{between.nonPurchase.tenureValue}}" id="pd-leasing-1" name="pd-leasing" type="radio">
              <label class="pd-option-selector__label" for="pd-leasing-1">
                <span class="pd-option-selector__text-wrap">
                  <span class="pd-option-selector__text">
                    <strong class="pd-option-selector__main-text">
                      {{between.nonPurchase.text}}
                    </strong>
                  </span>
                </span>
              </label>
            </div>
          </li>
        </ul>
      </div>
      <div class="pd-select-option off-change option-upgrade pd-select-option--upgrade-program sdf-component-template" data-sdf-template=" upgrade @ drawObj" data-sdf-test="{{upgrade.hasComponent}}" data-sdf-unwrap="true">
        <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{upgrade.title}}">
            {{upgrade.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{upgrade.learnMoreCta.text}}">
            <a an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:learn more" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" aria-haspopup="dialog" class="cta cta--underline cta--black add-special-tagging" data-sdf-attr.data-target-popup="{{upgrade.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{upgrade.learnMoreCta.href}}" data-sdf-attr.target="{{upgrade.learnMoreCta.target}}" data-sdf-attr.title="{{upgrade.learnMoreCta.title}}">
              {{upgrade.learnMoreCta.text}}
            </a>
          </span>
        </div>
        <p class="pd-select-option__desc" data-sdf-test="{{upgrade.description}}">
          {{upgrade.description}}
        </p>
        <div class="pd-select-option__wrap" data-sdf-test="{{upgrade.isNotEmbededType}}">
          <ul class="pd-select-option__list" role="list">
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:yes" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" class="hidden option-input add-special-tagging {{upgrade.yesAttr.class}}" data-target-popup="{{upgrade.yesAttr.layerTarget}}" id="pd-samsung-upgrade-0" name="pd-samsung-upgrade" type="radio">
                <label class="pd-option-selector__label" for="pd-samsung-upgrade-0">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text">
                        {{upgrade.yesAttr.text}}
                      </strong>
                      <span class="pd-option-selector__sub-text">
                        {{upgrade.yesAttr.subText}}
                      </span>
                    </span>
                  </span>
                </label>
              </div>
            </li>
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:no" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" class="hidden option-input add-special-tagging {{upgrade.noAttr.class}}" data-event-type="{{upgrade.noAttr.eventType}}" data-target-popup="{{upgrade.noAttr.layerTarget}}" id="pd-samsung-upgrade-1" name="pd-samsung-upgrade" type="radio">
                <label class="pd-option-selector__label" for="pd-samsung-upgrade-1">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text">
                        {{upgrade.noAttr.text}}
                      </strong>
                    </span>
                  </span>
                </label>
              </div>
            </li>
          </ul>
        </div>
        <p class="pd-select-option__desc selected-disclaimer">
        </p>
      </div>
      <div class="option-result result-upgrade sdf-component-template" data-sdf-template=" upgradeResult @ drawObj " data-sdf-test="{{upgradeResult.isGp}}" data-sdf-unwrap="true">
        <div class="option-result__text-wrap result-price" data-sdf-attr.data-id="{{upgradeResult.dataId}}" data-sdf-attr.data-price="{{upgradeResult.dataPrice}}">
          <p class="option-result__text-title" data-sdf-test="{{upgradeResult.displayModelName}}">
            {{upgradeResult.displayModelName}}
          </p>
          <p class="option-result__text" data-sdf-test="{{upgradeResult.discountText1}}">
            {{upgradeResult.discountText1}}
          </p>
        </div>
        <div class="option-result__desc-wrap" data-sdf-test="{{upgradeResult.description1}}">
          <p class="option-result__desc">
            {{upgradeResult.description1}}
          </p>
          <p class="option-result__desc">
            {{upgradeResult.description2}}
          </p>
        </div>
        <a class="option-result__close remove-upgrade-result" href="javascript:void(0)">
          <span class="hidden"> Tutup </span>
          <svg class="icon" focusable="false" viewBox="0 0 96 96">
            <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
            </path>
          </svg>
        </a>
      </div>
      <div class="option-result result-upgrade hidden sdf-component-template" data-sdf-template="upgradeResultHybris @ drawObj " data-sdf-test="{{upgradeResultHybris.isHybris}}" data-sdf-unwrap="true">
        <div class="option-result__desc-wrap" data-sdf-test="{{upgradeResult.description1}}">
          <p class="option-result__desc">
            {{upgradeResult.description1}}
          </p>
          <p class="option-result__desc">
            {{upgradeResult.description2}}
          </p>
        </div>
      </div>
      <div class="pd-select-option option-offer-finance sdf-component-template" data-sdf-template="offerFinance @ drawObj" data-sdf-test="{{offerFinance.hasComponent}}" data-sdf-unwrap="true">
        <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
            {{offerFinance.title}}
          </h3>
          <span class="pd-select-option__cta-wrap">
            <a an-ac="pd buying tool" an-ca="option click" an-la="samsung finance:learn more" an-tr="header(pim)_option selector-product detail-select-service option" class="cta cta--underline cta--black" data-sdf-attr.href="{{offerFinance.learnMoreCta.href}}" rel="nofollow" role="button" target="{{offerFinance.learnMoreCta.target}}">
              {{offerFinance.learnMoreCta.text}}
            </a>
          </span>
        </div>
        <p class="pd-select-option__desc">
          {{offerFinance.description}}
        </p>
      </div>
      <div class="pd-select-option option-galaxy-forever sdf-component-template" data-sdf-template=" galaxyForever @ drawObj" data-sdf-test="{{galaxyForever.hasComponent}}" data-sdf-unwrap="true">
        <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{galaxyForever.title}}">
            {{galaxyForever.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{galaxyForever.learnMoreCta.text}}">
            <button an-ac="pd buying tool" an-ca="option click" an-la="galaxy forever:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black add-special-tagging" data-sdf-attr.data-layer-target="{{galaxyForever.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{galaxyForever.learnMoreCta.href}}" data-sdf-attr.target="{{galaxyForever.learnMoreCta.target}}" data-sdf-attr.title="{{galaxyForever.learnMoreCta.title}}" data-sdf-test="{{ galaxyForever.learnMoreCta.isNotOutLink}}" rel="nofollow">
              {{galaxyForever.learnMoreCta.text}}
            </button>
            <a an-ac="pd buying tool" an-ca="option click" an-la="galaxy forever:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-layer-target="{{galaxyForever.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{galaxyForever.learnMoreCta.href}}" data-sdf-attr.target="{{galaxyForever.learnMoreCta.target}}" data-sdf-attr.title="{{galaxyForever.learnMoreCta.title}}" data-sdf-test="{{galaxyForever.learnMoreCta.isOutLink}}">
              {{galaxyForever.learnMoreCta.text}}
              <svg aria-hidden="true" class="icon" focusable="false">
                <use href="#outlink-bold" xlink:href="#outlink-bold">
                </use>
              </svg>
            </a>
          </span>
        </div>
        <p class="pd-select-option__desc" data-sdf-test="{{galaxyForever.description}}">
          {{galaxyForever.description}}
        </p>
        <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list" role="list">
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="galaxy forever:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging {{galaxyForever.yesAttr.class}}" data-layer-target="{{galaxyForever.yesAttr.layerTarget}}" id="pd-samsung-galaxy-forever-0" name="pd-samsung-galaxy-forever" type="radio">
                <label class="pd-option-selector__label" for="pd-samsung-galaxy-forever-0">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text">
                        {{galaxyForever.yesAttr.text}}
                      </strong>
                      <span class="pd-option-selector__sub-text">
                        {{galaxyForever.yesAttr.subText}}
                      </span>
                    </span>
                  </span>
                </label>
              </div>
            </li>
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="galaxy forever:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging {{galaxyForever.noAttr.class}}" data-event-type="{{galaxyForever.noAttr.eventType}}" data-layer-target="{{galaxyForever.noAttr.layerTarget}}" id="pd-samsung-galaxy-forever-1" name="pd-samsung-galaxy-forever" type="radio">
                <label class="pd-option-selector__label" for="pd-samsung-galaxy-forever-1">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text">
                        {{galaxyForever.noAttr.text}}
                      </strong>
                    </span>
                  </span>
                </label>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="option-result result-galaxy-forever sdf-component-template" data-sdf-template=" galaxyForeverResult @ drawObj " data-sdf-unwrap="true">
        <div class="option-result__text-wrap result-price" data-sdf-attr.data-id="{{galaxyForeverResult.dataId}}" data-sdf-attr.data-price="{{galaxyForeverResult.dataPrice}}">
          <p class="option-result__text-title" data-sdf-test="{{galaxyForeverResult.displayModelName}}">
            {{galaxyForeverResult.displayModelName}}
          </p>
          <p class="option-result__text" data-sdf-test="{{galaxyForeverResult.discountText1}}">
            {{galaxyForeverResult.discountText1}}
          </p>
        </div>
        <div class="option-result__desc-wrap" data-sdf-test="{{galaxyForeverResult.description1}}">
          <p class="option-result__desc">
            {{galaxyForeverResult.description1}}
          </p>
          <p class="option-result__desc">
            {{galaxyForeverResult.description2}}
          </p>
        </div>
        <a class="option-result__close remove-forever-result" href="javascript:void(0)">
          <span class="hidden"> Tutup </span>
          <svg class="icon" focusable="false" viewBox="0 0 96 96">
            <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
            </path>
          </svg>
        </a>
      </div>
      <div class="pd-select-option option-bezelcolor bundle-group sdf-component-template" data-sdf-template="bezelOption @ drawObj" data-sdf-test="{{bezelOption.hasComponent}}" data-sdf-unwrap="true">
        <div data-sdf-test="{{bezelOption.bezel}}" data-sdf-unwrap="true">
          <div class="pd-select-option__headline-wrap">
            <h3 class="pd-select-option__headline"> Pilih warna Anda </h3>
          </div>
          <p class="pd-select-option__desc"> Bezel yang dapat disesuaikan dijual terpisah </p>
          <div class="pd-select-option__wrap" data-sdf-test="{{bezelOption.noneSellingWithBazel}}">
            <ul class="pd-select-option__list pd-select-option__list--default {{bezelOption.bezelImageClass}}" role="list">
              <li class="pd-select-option__item" role="listitem">
                <div class="pd-option-selector">
                  <input class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="dummyCode" data-bezelmodelpatterncode="" id="pd-color-multi-0" name="pd-color-multi" type="radio">
                  <label class="pd-option-selector__label" for="pd-color-multi-0">
                    <span class="pd-option-selector__text-wrap">
                      <span class="pd-option-selector__text"> Tidak ada warna <i> (Default) </i>
                      </span>
                    </span>
                  </label>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div data-sdf-test="{{bezelOption.freestyle}}" data-sdf-unwrap="true">
          <div class="pd-select-option__headline-wrap">
            <h3 class="pd-select-option__headline"> Pilih warna skin Anda </h3>
          </div>
          <p class="pd-select-option__desc"> Skin yang dapat disesuaikan, dijual terpisah </p>
          <div class="pd-select-option__wrap" data-sdf-test="{{bezelOption.noneSellingWithBazel}}">
            <ul class="pd-select-option__list pd-select-option__list--default {{bezelOption.bezelImageClass}}" role="list">
              <li class="pd-select-option__item" role="listitem">
                <div class="pd-option-selector">
                  <input class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="dummyCode" data-bezelmodelpatterncode="" id="pd-color-multi-0" name="pd-color-multi" type="radio">
                  <label class="pd-option-selector__label" for="pd-color-multi-0">
                    <span class="pd-option-selector__text-wrap">
                      <span class="pd-option-selector__text"> Putih <i> (termasuk) </i>
                      </span>
                    </span>
                  </label>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div data-sdf-test="{{bezelOption.noneType}}" data-sdf-unwrap="true">
          <div class="pd-select-option__wrap">
            <ul class="pd-select-option__list pd-select-option__list--color" role="list">
              <li class="pd-select-option__item" data-sdf-repeat.item="{{bezelOption.noneTypeList}}" role="listitem">
                <div class="pd-option-selector" data-disabled="{{item.disabledClass}}">
                  <input an-ac="pd buying tool" an-ca="option click" an-la="bezel:none type {{item.name}}" an-tr="hdd02_pdp header-product detail-option service selector-option_click" class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="{{item.modelCode}}" data-bezelmodelpatterncode="{{item.modelPatternCode}}" id="pd-color-multi1-{{item.index}}" name="pd-color-multi" type="radio">
                  <label class="pd-option-selector__label" data-sdf-test="{{item.hasNotImage}}" for="pd-color-multi1-{{item.index}}">
                    <span class="pd-option-selector__color" data-sdf-attr.style="background:{{item.value}}">
                    </span>
                    <span class="pd-option-selector__text-wrap">
                      <span class="pd-option-selector__text">
                        {{item.name}}
                      </span>
                    </span>
                  </label>
                  <label class="pd-option-selector__label" data-sdf-test="{{item.hasImage}}" for="pd-color-multi1-{{item.index}}">
                    <div class="pd-option-selector__img-wrap">
                      <div data-sdf-attr.class="image">
                        <img alt="image" data-comp-name="image" data-desktop-src="{{item.imageUrl}}$n_80_PNG$" data-mobile-src="{{item.imageUrl}}$n_160_PNG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img">
                      </div>
                    </div>
                  </label>
                </div>
                <p class="pd-select-option__item-option-text">
                  {{item.name}}
                </p>
                <p class="pd-select-option__item-notice"> Habis </p>
              </li>
            </ul>
          </div>
        </div>
        <div data-sdf-test="{{bezelOption.modernType}}" data-sdf-unwrap="true">
          <div class="pd-select-option__sub-headline-wrap">
            <h4 class="pd-select-option__sub-headline"> Jenis modern </h4>
            <button aria-haspopup="true" aria-label="MordernType information details" class="pd-select-option__info-link" data-target-popup="mordernType" type="button">
              <svg aria-hidden="true" class="icon" focusable="false">
                <use href="#info-regular" xlink:href="#info-regular">
                </use>
              </svg>
            </button>
          </div>
          <div class="pd-select-option__wrap">
            <ul class="pd-select-option__list pd-select-option__list--color" role="list">
              <li class="pd-select-option__item" data-sdf-repeat.item="{{bezelOption.modernTypeList}}" role="listitem">
                <div class="pd-option-selector" data-disabled="{{item.disabledClass}}">
                  <input an-ac="pd buying tool" an-ca="option click" an-la="bezel:modern type {{item.name}}" an-tr="hdd02_pdp header-product detail-option service selector-option_click" class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="{{item.modelCode}}" data-bezelmodelpatterncode="{{item.modelPatternCode}}" id="pd-color-multi1-{{item.index}}" name="pd-color-multi" type="radio">
                  <label class="pd-option-selector__label" data-sdf-test="{{item.hasNotImage}}" for="pd-color-multi1-{{item.index}}">
                    <span class="pd-option-selector__color" data-sdf-attr.style="background:{{item.value}}">
                    </span>
                    <span class="pd-option-selector__text-wrap">
                      <span class="pd-option-selector__text">
                        {{item.name}}
                      </span>
                    </span>
                  </label>
                  <label class="pd-option-selector__label" data-sdf-test="{{item.hasImage}}" for="pd-color-multi1-{{item.index}}">
                    <div class="pd-option-selector__img-wrap">
                      <div data-sdf-attr.class="image">
                        <img alt="image" data-comp-name="image" data-desktop-src="{{item.imageUrl}}$n_80_PNG$" data-mobile-src="{{item.imageUrl}}$n_160_PNG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img">
                      </div>
                    </div>
                  </label>
                </div>
                <p class="pd-select-option__item-option-text">
                  {{item.name}}
                </p>
                <p class="pd-select-option__item-notice"> Habis </p>
              </li>
            </ul>
          </div>
        </div>
        <div data-sdf-test="{{bezelOption.beveledType}}" data-sdf-unwrap="true">
          <div class="pd-select-option__sub-headline-wrap">
            <h4 class="pd-select-option__sub-headline"> Jenis bevel </h4>
            <button aria-haspopup="true" aria-label="Type information details" class="pd-select-option__info-link" data-target-popup="beveledType" type="button">
              <span class="hidden"> Type information details </span>
              <svg aria-hidden="true" class="icon" focusable="false">
                <use href="#info-regular" xlink:href="#info-regular">
                </use>
              </svg>
            </button>
          </div>
          <div class="pd-select-option__wrap">
            <ul class="pd-select-option__list pd-select-option__list--color" role="list">
              <li class="pd-select-option__item" data-sdf-repeat.item="{{bezelOption.beveledTypeList}}" role="listitem">
                <div class="pd-option-selector" data-disabled="{{item.disabledClass}}">
                  <input an-ac="pd buying tool" an-ca="option click" an-la="bezel:beveled type {{item.name}}" an-tr="hdd02_pdp header-product detail-option service selector-option_click" class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="{{item.modelCode}}" data-bezelmodelpatterncode="{{item.modelPatternCode}}" id="pd-color-multi2-{{item.index}}" name="pd-color-multi" type="radio">
                  <label class="pd-option-selector__label" data-sdf-test="{{item.hasNotImage}}" for="pd-color-multi2-{{item.index}}">
                    <span class="pd-option-selector__color" data-sdf-attr.style="background:{{item.value}}">
                    </span>
                    <span class="pd-option-selector__text-wrap">
                      <span class="pd-option-selector__text">
                        {{item.name}}
                      </span>
                    </span>
                  </label>
                  <label class="pd-option-selector__label" data-sdf-test="{{item.hasImage}}" for="pd-color-multi2-{{item.index}}">
                    <div class="pd-option-selector__img-wrap">
                      <div data-sdf-attr.class="image">
                        <img alt="image" data-comp-name="image" data-desktop-src="{{item.imageUrl}}$n_80_PNG$" data-mobile-src="{{item.imageUrl}}$n_160_PNG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img">
                      </div>
                    </div>
                  </label>
                </div>
                <p class="pd-select-option__item-option-text">
                  {{item.name}}
                </p>
                <p class="pd-select-option__item-notice"> Habis </p>
              </li>
            </ul>
          </div>
        </div>
        <div data-sdf-test="{{bezelOption.freestyle}}" data-sdf-unwrap="true">
          <div class="pd-select-option__sub-headline-wrap">
            <h4 class="pd-select-option__sub-headline"> Warna skin </h4>
          </div>
          <div class="pd-select-option__wrap">
            <ul class="pd-select-option__list pd-select-option__list--color" role="list">
              <li class="pd-select-option__item" data-sdf-repeat.item="{{bezelOption.freestyleList}}" role="listitem">
                <div class="pd-option-selector" data-disabled="{{item.disabledClass}}">
                  <input an-ac="pd buying tool" an-ca="option click" an-la="bezel:modern type {{item.name}}" an-tr="hdd02_pdp header-product detail-option service selector-option_click" class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="{{item.modelCode}}" data-bezelmodelpatterncode="{{item.modelPatternCode}}" id="pd-color-multi1-{{item.index}}" name="pd-color-multi" type="radio">
                  <label class="pd-option-selector__label" data-sdf-test="{{item.hasNotImage}}" for="pd-color-multi1-{{item.index}}">
                    <span class="pd-option-selector__color" data-sdf-attr.style="background: {{item.value}}">
                    </span>
                    <span class="pd-option-selector__text-wrap">
                      <span class="pd-option-selector__text">
                        {{item.name}}
                      </span>
                    </span>
                  </label>
                  <label class="pd-option-selector__label" data-sdf-test="{{item.hasImage}}" for="pd-color-multi1-{{item.index}}">
                    <div class="pd-option-selector__img-wrap">
                      <div data-sdf-attr.class="image">
                        <img alt="image" data-comp-name="image" data-desktop-src="{{item.imageUrl}}$n_80_PNG$" data-mobile-src="{{item.imageUrl}}$n_160_PNG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img">
                      </div>
                    </div>
                  </label>
                </div>
                <p class="pd-select-option__item-option-text">
                  {{item.name}}
                </p>
                <p class="pd-select-option__item-notice"> Habis </p>
              </li>
            </ul>
          </div>
        </div>
        <div class="pd-select-option__bezel-type-popup" id="mordernType" role="dialog">
          <div class="layer-popup">
            <div class="layer-popup__inner">
              <h2 class="layer-popup__title"> Jenis bezel </h2>
              <div class="layer-popup__contents scrollbar">
                <div class="scrollbar__wrap">
                  <div class="scrollbar__contents">
                    <div data-sdf-attr.class="pd-selector-option__bezel-image">
                      <div data-sdf-attr.class="image">
                        <img alt="alt text" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-modern-pc.jpg?$636_300_JPG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-modern-mo.jpg?$624_320_JPG$" data-sdf-attr.class="image__preview lazy-load responsive-img" role="img">
                        <img alt="alt text" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-modern-pc.jpg?$636_300_JPG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-modern-mo.jpg?$624_320_JPG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img">
                      </div>
                    </div>
                    <ul class="pd-selector-option__bezel-list">
                      <li class="pd-selector-option__bezel-item">
                        <strong class="pd-selector-option__bezel-title"> Jenis modern </strong>
                        <p class="pd-selector-option__bezel-description"> Bezel kustom pada The Frame terpasang pada tempatnya secara magnetis. Sekarang, Anda dapat berganti gaya dalam sekejap. </p>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="scrollbar-horizontal__track" style="display: none;">
                  <div class="scrollbar-horizontal__track-content">
                    <div class="scrollbar-horizontal__bar"></div>
                  </div>
                </div>
                <div class="scrollbar-vertical__track" style="display: none;">
                  <div class="scrollbar-vertical__track-content">
                    <div class="scrollbar-vertical__bar"></div>
                  </div>
                </div>
              </div>
              <button class="layer-popup__close" type="button">
                <span class="hidden"> Layer Popup Close </span>
                <svg aria-hidden="true" class="icon" focusable="false">
                  <use href="#delete-bold" xlink:href="#delete-bold">
                  </use>
                </svg>
              </button>
            </div>
          </div>
        </div>
        <div class="pd-select-option__bezel-type-popup" id="beveledType" role="dialog">
          <div class="layer-popup">
            <div class="layer-popup__inner">
              <h2 class="layer-popup__title"> Jenis bezel </h2>
              <div class="layer-popup__contents scrollbar">
                <div class="scrollbar__wrap">
                  <div class="scrollbar__contents">
                    <div class="pd-selector-option__bezel-image">
                      <div data-sdf-attr.class="image">
                        <img alt="alt text" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-beveled-pc.jpg?$636_300_JPG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-beveled-mo.jpg?$624_320_JPG$" data-sdf-attr.class="image__preview lazy-load responsive-img" role="img">
                        <img alt="alt text" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-beveled-pc.jpg?$636_300_JPG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-beveled-mo.jpg?$624_320_JPG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img">
                      </div>
                    </div>
                    <ul class="pd-selector-option__bezel-list">
                      <li class="pd-selector-option__bezel-item">
                        <strong class="pd-selector-option__bezel-title"> Jenis bevel </strong>
                        <p class="pd-selector-option__bezel-description"> Desain bezel jenis bevel yang baru menawarkan tepi bezel dalam sudut 45 derajat yang elegan. </p>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="scrollbar-horizontal__track" style="display: none;">
                  <div class="scrollbar-horizontal__track-content">
                    <div class="scrollbar-horizontal__bar"></div>
                  </div>
                </div>
                <div class="scrollbar-vertical__track" style="display: none;">
                  <div class="scrollbar-vertical__track-content">
                    <div class="scrollbar-vertical__bar"></div>
                  </div>
                </div>
              </div>
              <button class="layer-popup__close" type="button">
                <span class="hidden"> Layer Popup Close </span>
                <svg aria-hidden="true" class="icon" focusable="false">
                  <use href="#delete-bold" xlink:href="#delete-bold">
                  </use>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
      <div class="pd-select-option__eta-text text-type2 js-shippingOrBack sdf-component-template" data-sdf-template="shippingOrBack @ drawObj" data-sdf-test="{{shippingOrBack.hasComponent}}" data-sdf-unwrap="true">
        <svg aria-hidden="true" class="icon" focusable="false">
          <use href="#in-stock-regular" xlink:href="#in-stock-regular">
          </use>
        </svg>
        <span>
          {{shippingOrBack.shippingOrBack}}
        </span>
      </div>
      <div class="pd-select-option__eta-text js-deliveryMessage sdf-component-template" data-sdf-template="deliveryMessage @ drawObj" data-sdf-test="{{deliveryMessage.hasComponent}}" data-sdf-unwrap="true">
        <svg aria-hidden="true" class="icon" focusable="false">
          <use href="#in-stock-regular" xlink:href="#in-stock-regular">
          </use>
        </svg>
        <span>
          {{deliveryMessage.deliveryMessage}}
        </span>
      </div>
      <div class="pd-select-option trade-in sdf-component-template" data-sdf-template=" tradeIn @ drawObj" data-sdf-test="{{tradeIn.hasComponent}}" data-sdf-unwrap="true" id="trade-in">
        <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{tradeIn.title}}">
            {{tradeIn.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{tradeIn.learnMoreCta.text}}">
            <button an-ac="pd buying tool" an-ca="option click" an-la="trade-in:learn more" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black" data-sdf-attr.data-target-popup="{{tradeIn.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{tradeIn.learnMoreCta.href}}" data-sdf-attr.target="{{tradeIn.learnMoreCta.target}}" data-sdf-attr.title="{{tradeIn.learnMoreCta.title}}" data-sdf-test="{{tradeIn.learnMoreCta.isNotOutLink}}" rel="nofollow">
              {{tradeIn.learnMoreCta.text}}
            </button>
            <a an-ac="pd buying tool" an-ca="option click" an-la="trade-in:learn more" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-target-popup="{{tradeIn.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{tradeIn.learnMoreCta.href}}" data-sdf-attr.target="{{tradeIn.learnMoreCta.target}}" data-sdf-attr.title="{{tradeIn.learnMoreCta.title}}" data-sdf-test="{{tradeIn.learnMoreCta.isOutLink}}" rel="nofollow">
              {{tradeIn.learnMoreCta.text}}
              <svg aria-hidden="true" class="icon" focusable="false">
                <use href="#outlink-bold" xlink:href="#outlink-bold">
                </use>
              </svg>
            </a>
          </span>
        </div>
        <p class="pd-select-option__desc" data-sdf-test="{{tradeIn.description}}">
          {{tradeIn.description}}
        </p>
        <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="trade-in:yes" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" aria-haspopup="dialog" class="hidden option-input add-special-tagging {{tradeIn.yesAttr.class}}" data-event-type="{{tradeIn.yesAttr.eventType}}" data-sdf-test="{{tradeIn.yesAttr.isPopup}}" data-target-popup="{{tradeIn.yesAttr.layerTarget}}" id="pd-trade-in-0" name="pd-trade-in" type="radio">
                <label class="pd-option-selector__label" data-sdf-test="{{tradeIn.yesAttr.isPopup}}" for="pd-trade-in-0">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text">
                        {{tradeIn.yesAttr.text}}
                      </strong>
                      <span class="pd-option-selector__sub-text">
                        {{tradeIn.yesAttr.subText}}
                      </span>
                    </span>
                  </span>
                </label>
                <a class="pd-option-selector__link" data-sdf-attr.href="{{tradeIn.yesAttr.href}}" data-sdf-test="{{tradeIn.yesAttr.isDirectLink}}" rel="nofollow" target="_blank">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text">
                        {{tradeIn.yesAttr.text}}
                      </strong>
                      <span class="pd-option-selector__sub-text">
                        {{tradeIn.yesAttr.subText}}
                      </span>
                    </span>
                  </span>
                </a>
              </div>
            </li>
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="trade-in:no" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" class="hidden option-input option-result-focus add-special-tagging {{tradeIn.noAttr.class}}" data-event-type="{{tradeIn.noAttr.eventType}}" data-sdf-test="{{tradeIn.yesAttr.isPopup}}" data-target-popup="{{tradeIn.noAttr.layerTarget}}" id="pd-trade-in-1" name="pd-trade-in" type="radio">
                <label class="pd-option-selector__label" data-sdf-test="{{tradeIn.yesAttr.isPopup}}" for="pd-trade-in-1">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text">
                        {{tradeIn.noAttr.text}}
                      </strong>
                      <span class="pd-option-selector__sub-text">
                        {{tradeIn.noAttr.subText}}
                      </span>
                    </span>
                  </span>
                </label>
                <a class="pd-option-selector__link" data-sdf-test="{{tradeIn.yesAttr.isDirectLink}}" href="javascript:void(0);">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text">
                        {{tradeIn.noAttr.text}}
                      </strong>
                    </span>
                  </span>
                </a>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="option-result__device-area sdf-component-template" data-sdf-template=" tradeInErrMsg @ drawObj" data-sdf-test="{{tradeInErrMsg.hasComponent}}" data-sdf-unwrap="true">
        <p class="option-result__message option-result__message--error">
          <span class="option-result__message-inner">
            <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#info-bold" xlink:href="#info-bold">
              </use>
            </svg> You have maximum number of Trade-in in cart already. If you wish to add in Trade-in, please remove from cart. </span>
        </p>
      </div>
      <div class="option-result result-trade-in option-result--content sdf-component-template" data-sdf-template=" tradeInResult @ drawObj" data-sdf-unwrap="true">
        <div class="option-result__multiple result-price" data-sdf-attr.data-cart-id="{{tradeInResult.dataQuoteId}}" data-sdf-attr.data-cash-back-price="{{tradeInResult.dataCashBack}}" data-sdf-attr.data-id="{{tradeInResult.dataId}}" data-sdf-attr.data-is-instant="{{tradeInResult.isUpfront}}" data-sdf-attr.data-price="{{tradeInResult.dataPrice}}">
          <p class="option-result__multiple-result"> Selamat, Anda telah mendapatkan diskon tukar tambah. </p>
          <ul>
            <li class="option-result__multiple-item" data-sdf-repeat.item="{{tradeInResult.list}}">
              <p class="option-result__multiple-price-wrap">
                <em class="option-result__multiple-price-title">
                  {{item.discountPriceTextTile}}
                </em>
                <span class="option-result__multiple-price">
                  {{item.discountPriceText}}
                </span>
                <span class="option-result__multiple-exchange">
                  {{item.discountText1}}
                </span>
                <span class="option-result__multiple-discount" data-sdf-test="{{item.abondementAmountText}}">
                  {{item.abondementAmountText}}
                </span>
                <span class="option-result__multiple-discount" data-sdf-test="{{item.spotGuaranteeAmountText}}">
                  {{item.spotGuaranteeAmountText}}
                </span>
                <span class="option-result__multiple-exchange" data-sdf-test="{{item.tradeinValueText}}">
                  {{item.tradeinValueText}}
                </span>
                <span class="option-result__multiple-exchange" data-sdf-test="{{item.exclusiveTradeinUnitOfferText}}">
                  {{item.exclusiveTradeinUnitOfferText}}
                </span>
                <span class="option-result__multiple-exchange" data-sdf-test="{{item.extraTradeinOfferTextShow}}">
                  {{item.extraTradeinOfferText}}
                </span>
                <span class="option-result__multiple-exchange" data-sdf-test="{{item.exclusiveChannerTradeinOfferTextShow}}">
                  {{item.exclusiveChannerTradeinOfferText}}
                </span>
                <span class="option-result__multiple-exchange" data-sdf-test="{{item.extraTradeinVoucherTextShow}}">
                  {{item.extraTradeinVoucherText}}
                </span>
                <span class="option-result__multiple-discount">
                  {{item.specialDiscountText}}
                </span>
              </p>
              <p class="option-result__multiple-text">
                {{item.displayModelName}}
              </p>
              <p class="option-result__multiple-btn">
                <button an-ac="pd buying tool" an-ca="option click" an-la="trade-in:delete" an-tr="header(pim)_trade in-product detail-option-click{{item.count}}" class="option-result__multiple-delete remove-trade-in-result" data-trade-index="{{item.index}}"> Hapus </button>
                <button an-ac="pd buying tool" an-ca="option click" an-la="trade-in:change" an-tr="header(pim)_trade in-product detail-option-click{{item.count}}" class="option-result__multiple-change open-trade-popup" data-trade-index="{{item.index}}"> Ubah </button>
              </p>
            </li>
          </ul>
        </div>
        <p class="option-result__multiple-desc desc-target"> Harga akan bervariasi berdasarkan model dan kondisi perangkat lama. *S&amp;K berlaku. </p>
        <p class="pd-select-option__alert-text alert-text" style="display: none;">
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#information-error-bold" xlink:href="#information-error-bold">
            </use>
          </svg> The device you are trading in is more valuable than the phone you are buying. Unfortunately we cannot credit you the excess value, so please remove the trade in device, or change the device you are purchasing
        </p>
        <p class="pd-select-option__alert-text over-price-alert into-text" style="display: none;">
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#info-bold" xlink:href="#info-bold">
            </use>
          </svg> Perangkat lama Anda memiliki harga tukar yang lebih besar dari harga Galaxy baru yang akan Anda beli. Kelebihan harga tukar ini tidak dapat diuangkan ataupun dikembalikan.
        </p>
        <div class="pd-select-option__cta">
          <a an-ac="pd buying tool" an-ca="option click" an-la="trade-in:add another trade-in" an-tr="header(pim)_trade in-product detail-option-click" aria-label="Link Title" class="cta cta--outlined cta--black open-trade-popup limit-count" href="javascript:void(0)"> Tambah Trade-in </a>
        </div>
      </div>
      <div class="pd-select-option pd-select-option--check-dealer-stock sdf-component-template" data-sdf-template="checkDealerStock @ drawObj" data-sdf-test="{{checkDealerStock.hasComponent}}" data-sdf-unwrap="true">
        <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline"> Dealer stock quantity </h3>
        </div>
        <p class="pd-select-option__desc"> You can check the stock quantity for each region </p>
        <p class="pd-select-option__notice pd-select-option__notice--normal">
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#information-error-bold" xlink:href="#information-error-bold">
            </use>
          </svg> Please select city
        </p>
        <div class="pd-select-option__wrap">
          <div class="pd-select-option__menu pd-select-option__menu--placeholder">
            <div class="menu filled" data-comp-name="menu" data-open-direction="down" data-type="filled">
              <select aria-hidden="true" class="menu__select" data-default-message="{{checkDealerStock.selectCity}}" name="check-dealer-stock" tabindex="-1">
                <option data-sdf-test="{{checkDealerStock.selectCity}}" disabled="" value="select City">
                  {{checkDealerStock.selectCity}}
                </option>
                <option data-sdf-repeat.item="{{checkDealerStock.dataList}}" value="{{item.isocodeShort}}">
                  {{item.name}}
                </option>
              </select>
              <button aria-expanded="false" aria-haspopup="listbox" class="menu__select-field" type="button">
                <span class="menu__select-field-text">{{checkDealerStock.selectCity}}</span>
                <svg aria-hidden="true" class="menu__select-field-icon down" focusable="false">
                  <use href="#open-down-bold" xlink:href="#open-down-bold">
                  </use>
                </svg>
                <svg aria-hidden="true" class="menu__select-field-icon up" focusable="false">
                  <use href="#close-up-bold" xlink:href="#close-up-bold">
                  </use>
                </svg>
              </button>
              <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                <div class="scrollbar__wrap" style="max-height: 0px;">
                  <ul class="menu__list scrollbar__contents" role="listbox">
                    <li class="menu__list-option-wrap disabled" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">{{checkDealerStock.selectCity}}</span><svg class="menu__list-option-icon" focusable="false">
                          <use xlink:href="#done-bold" href="#done-bold"></use>
                        </svg></button></li>
                    <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">{{item.name}}</span><svg class="menu__list-option-icon" focusable="false">
                          <use xlink:href="#done-bold" href="#done-bold"></use>
                        </svg></button></li>
                    <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">{{checkDealerStock.selectCity}}</span><svg class="menu__list-option-icon" focusable="false">
                          <use xlink:href="#done-bold" href="#done-bold"></use>
                        </svg></button></li>
                    <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">{{item.name}}</span><svg class="menu__list-option-icon" focusable="false">
                          <use xlink:href="#done-bold" href="#done-bold"></use>
                        </svg></button></li>
                  </ul>
                </div>
                <div class="scrollbar-horizontal__track" style="display: none;">
                  <div class="scrollbar-horizontal__track-content">
                    <div class="scrollbar-horizontal__bar"></div>
                  </div>
                </div>
                <div class="scrollbar-vertical__track" style="display: none;">
                  <div class="scrollbar-vertical__track-content">
                    <div class="scrollbar-vertical__bar"></div>
                  </div>
                </div>
                <ul class="menu__list scrollbar__contents" role="listbox">
                  <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">{{checkDealerStock.selectCity}}</span><svg class="menu__list-option-icon" focusable="false">
                        <use xlink:href="#done-bold" href="#done-bold"></use>
                      </svg></button></li>
                  <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">{{item.name}}</span><svg class="menu__list-option-icon" focusable="false">
                        <use xlink:href="#done-bold" href="#done-bold"></use>
                      </svg></button></li>
                </ul>
              </div>
              <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                <ul class="menu__list scrollbar__contents" role="listbox">
                  <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">{{checkDealerStock.selectCity}}</span><svg class="menu__list-option-icon" focusable="false">
                        <use xlink:href="#done-bold" href="#done-bold"></use>
                      </svg></button></li>
                  <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">{{item.name}}</span><svg class="menu__list-option-icon" focusable="false">
                        <use xlink:href="#done-bold" href="#done-bold"></use>
                      </svg></button></li>
                </ul>
              </div>
            </div>
          </div>
          <p class="pd-select-option__check-message pd-select-option__check-message--success">
            <span> Only {0} left in stock. </span>
          </p>
          <p class="pd-select-option__check-message pd-select-option__check-message--error">
            <span> Sorry, this product is not currently available in selected city. </span>
          </p>
        </div>
      </div>
      <div class="pd-select-option off-change option-assured-buy-back sdf-component-template" data-sdf-template="assuredBuyBack @ drawObj" data-sdf-test="{{assuredBuyBack.hasComponent}}" data-sdf-unwrap="true">
        <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{assuredBuyBack.title}}">
            {{assuredBuyBack.title}}
          </h3>
        </div>
        <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="assured program:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{assuredBuyBack.noAttr.eventType}}" id="pd-galaxy-assured-0" name="pd-galaxy-assured" type="radio">
                <label class="pd-option-selector__label" for="pd-galaxy-assured-0">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text"> Tanpa perlindungan extra </strong>
                    </span>
                  </span>
                </label>
              </div>
            </li>
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="assured program:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input open-popup add-special-tagging" data-target-popup="{{assuredBuyBack.yesAttr.layerTarget}}" id="pd-galaxy-assured-1" name="pd-galaxy-assured" type="radio">
                <label class="pd-option-selector__label" for="pd-galaxy-assured-1">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text" data-sdf-test="{{assuredBuyBack.yesAttr.text}}">
                        {{assuredBuyBack.yesAttr.text}}
                      </strong>
                      <span class="pd-option-selector__sub-text" data-sdf-test="{{assuredBuyBack.yesAttr.subText}}">
                        {{assuredBuyBack.yesAttr.subText}}
                      </span>
                    </span>
                  </span>
                </label>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="option-result-dev result-option-assured-buy-back sdf-component-template" data-sdf-template="assuredBuyBackResult @ drawObj" data-sdf-unwrap="true">
        <input class="hidden result-price" data-sdf-attr.data-price="{{assuredBuyBackResult.dataPrice}}" data-sdf-attr.data-sale-price="{{assuredBuyBackResult.dataSalePrice}}" type="hidden">
      </div>
      <div class="pd-select-option off-change option-new-assured-buy-back sdf-component-template" data-sdf-template="newAssuredBuyBack @ drawObj" data-sdf-test="{{newAssuredBuyBack.hasComponent}}" data-sdf-unwrap="true">
        <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{newAssuredBuyBack.title}}">
            {{newAssuredBuyBack.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{newAssuredBuyBack.learnMoreCta.text}}">
            <a an-ac="pd buying tool" an-ca="option click" an-la="galaxy assured:learn more" an-tr="header(pim)_option selector-product detail-select-service option" aria-haspopup="dialog" class="cta cta--underline cta--black add-special-tagging" data-sdf-attr.data-target-popup="{{newAssuredBuyBack.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{newAssuredBuyBack.learnMoreCta.href}}" data-sdf-attr.target="{{newAssuredBuyBack.learnMoreCta.target}}" data-sdf-attr.title="{{newAssuredBuyBack.learnMoreCta.title}}">
              {{newAssuredBuyBack.learnMoreCta.text}}
            </a>
          </span>
        </div>
        <p class="pd-select-option__desc" data-sdf-test="{{newAssuredBuyBack.description}}">
          {{newAssuredBuyBack.description}}
        </p>
        <p class="pd-select-option__notice">
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#information-error-bold" xlink:href="#information-error-bold">
            </use>
          </svg> Please select SLOT Assured Buyback or no coverage
        </p>
        <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
            <li class="pd-select-option__item" data-sdf-repeat.item="{{newAssuredBuyBack.itemSet}}" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="galaxy assured:yes" an-tr="header(pim)_option selector-product detail-select-service option" class="hidden option-input open-popup add-special-tagging" id="pd-galaxy-new-assured-{{item.index}}" name="pd-galaxy-new-assured" type="radio">
                <label class="pd-option-selector__label" for="pd-galaxy-new-assured-{{item.index}}">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text" data-sdf-test="{{item.title}}">
                        {{item.title}}
                      </strong>
                      <span class="pd-option-selector__sub-text" data-sdf-test="{{item.priceDisplay}}">
                        {{item.priceDisplay}}
                      </span>
                    </span>
                  </span>
                </label>
              </div>
            </li>
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="galaxy assured:no" an-tr="header(pim)_option selector-product detail-select-service option" class="hidden option-input add-special-tagging" data-event-type="{{newAssuredBuyBack.noAttr.eventType}}" id="pd-galaxy-new-assured-0" name="pd-galaxy-new-assured" type="radio">
                <label class="pd-option-selector__label" for="pd-galaxy-new-assured-0">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text">
                        {{newAssuredBuyBack.noAttr.text}}
                      </strong>
                    </span>
                  </span>
                </label>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="option-result-dev result-option-new-assured-buy-back sdf-component-template" data-sdf-template="newAssuredBuyBackResult @ drawObj" data-sdf-unwrap="true">
        <input class="hidden result-price" data-sdf-attr.data-display-name="{{newAssuredBuyBackResult.dataDisplayName}}" data-sdf-attr.data-display-price="{{newAssuredBuyBackResult.dataDisplayPrice}}" data-sdf-attr.data-price="{{newAssuredBuyBackResult.dataPrice}}" data-sdf-attr.data-sale-price="{{newAssuredBuyBackResult.dataPrice}}" data-sdf-attr.model-code="{{newAssuredBuyBackResult.dataModelCode}}" data-sdf-attr.model-name="{{newAssuredBuyBackResult.dataModelName}}" type="hidden">
      </div>
      <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
      <div class="pd-select-option option-care sdf-component-template" data-sdf-template=" care @ drawObj" data-sdf-test="{{care.hasComponent}}" data-sdf-unwrap="true">
        <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{care.title}}"> Benefits of SLOT </h3>
          <button an-ac="pd buying tool" an-ca="option click" an-la="samsung care:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black add-special-tagging" data-sdf-attr.data-target-popup="{{care.learnMoreCta.layerTarget}}" data-sdf-attr.target="{{care.learnMoreCta.target}}" data-sdf-attr.title="{{care.learnMoreCta.title}}" data-sdf-test="{{care.learnMoreCta.isNotOutLink}}">
            {{care.learnMoreCta.text}}
          </button>
          <a an-ac="pd buying tool" an-ca="option click" an-la="samsung care:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-target-popup="{{care.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{care.learnMoreCta.href}}" data-sdf-attr.target="{{care.learnMoreCta.target}}" data-sdf-attr.title="{{care.learnMoreCta.title}}" data-sdf-test="{{care.learnMoreCta.isOutLink}}" rel="nofollow">
            {{care.learnMoreCta.text}}
            <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#outlink-bold" xlink:href="#outlink-bold">
              </use>
            </svg>
          </a>
        </div>
        <p class="pd-select-option__desc" data-sdf-test="{{care.description}}"> Naga 508Slot SLOT GACOR LUAR NEGERI Trik Pola Thailand Jalur Jackpot CASINO DEMO GRATIS Bukti Nyata </p>
        <p class="pd-select-option__notice pd-select-option__notice--normal checkingSamsungCare">
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#information-error-bold" xlink:href="#information-error-bold">
            </use>
          </svg> Tambah Samsung Care+ atau lanjutkan tanpa perlindungan extra
        </p>
        <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide pd-select-option__list--samsung-care" role="list">
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio">
                <label class="pd-option-selector__label" for="pd-samsung-care-0">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text"> Akses Cepat &amp; Stabil </strong>
                      <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                      <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                    </span>
                  </span>
                </label>
              </div>
            </li>
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio">
                <label class="pd-option-selector__label" for="pd-samsung-care-0">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text"> Banyak Provider &amp; Game Populer </strong>
                      <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                      <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                    </span>
                  </span>
                </label>
              </div>
            </li>
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio">
                <label class="pd-option-selector__label" for="pd-samsung-care-1">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text"> Sistem Keamanan Berlapis </strong>
                      <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                      <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                    </span>
                  </span>
                </label>
              </div>
            </li>
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio">
                <label class="pd-option-selector__label" for="pd-samsung-care-1">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text"> Support 24/7 Ramah &amp; Responsif </strong>
                      <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                      <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                    </span>
                  </span>
                </label>
              </div>
            </li>
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio">
                <label class="pd-option-selector__label" for="pd-samsung-care-1">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text"> Tampilan Bersih &amp; Mudah Dipahami </strong>
                      <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                      <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                    </span>
                  </span>
                </label>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="option-result-dev hidden result-care sdf-component-template" data-sdf-template=" careResult @ drawObj " data-sdf-unwrap="true">
        <input class="hidden result-price" data-sdf-attr.data-id="{{careResult.dataId}}" data-sdf-attr.data-model-code="{{careResult.dataModelCode}}" data-sdf-attr.data-model-name="{{careResult.dataModelName}}" data-sdf-attr.data-price="{{careResult.dataPrice}}" data-sdf-attr.data-sale-price="{{careResult.dataSalePrice}}" type="hidden">
      </div>
      <div class="pd-select-option option-warranty sdf-component-template" data-sdf-template="warranty @ drawObj" data-sdf-test="{{warranty.hasComponent}}" data-sdf-unwrap="true">
        <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{warranty.title}}">
            {{warranty.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{warranty.learnMoreCta.text}}">
            <button an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black add-special-tagging" data-sdf-attr.data-target-popup="{{warranty.learnMoreCta.layerTarget}}" data-sdf-attr.target="{{warranty.learnMoreCta.target}}" data-sdf-attr.title="{{warranty.learnMoreCta.title}}" data-sdf-test="{{ warranty.learnMoreCta.isNotOutLink}}" href="#" rel="nofollow">
              {{warranty.learnMoreCta.text}}
            </button>
            <a an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-target-popup="{{warranty.learnMoreCta.layerTarget}}" data-sdf-attr.target="{{warranty.learnMoreCta.target}}" data-sdf-attr.title="{{warranty.learnMoreCta.title}}" data-sdf-test="{{warranty.learnMoreCta.isOutLink}}">
              {{warranty.learnMoreCta.text}}
              <svg aria-hidden="true" class="icon" focusable="false">
                <use href="#outlink-bold" xlink:href="#outlink-bold">
                </use>
              </svg>
            </a>
          </span>
        </div>
        <p class="pd-select-option__desc" data-sdf-test="{{warranty.description}}">
          {{warranty.description}}
        </p>
        <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list" role="list">
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging {{warranty.yesAttr.class}}" data-target-popup="{{warranty.yesAttr.layerTarget}}" id="pd-samsung-warranty-0" name="pd-samsung-warranty" type="radio">
                <label class="pd-option-selector__label" for="pd-samsung-warranty-0">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text">
                        {{warranty.yesAttr.text}}
                      </strong>
                      <span class="pd-option-selector__sub-text">
                        {{warranty.yesAttr.subText}}
                      </span>
                    </span>
                  </span>
                </label>
              </div>
            </li>
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging {{warranty.noAttr.class}}" data-event-type="{{warranty.noAttr.eventType}}" data-target-popup="{{warranty.noAttr.layerTarget}}" id="pd-samsung-warranty-1" name="pd-samsung-warranty" type="radio">
                <label class="pd-option-selector__label" for="pd-samsung-warranty-1">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text">
                        {{warranty.noAttr.text}}
                      </strong>
                    </span>
                  </span>
                </label>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="option-result result-warranty sdf-component-template" data-sdf-template=" warrantyResult @ drawObj " data-sdf-unwrap="true">
        <div class="option-result__text-wrap result-price" data-sdf-attr.data-id="{{warrantyResult.dataId}}" data-sdf-attr.data-model-code="{{warrantyResult.dataModelCode}}" data-sdf-attr.data-model-name="{{warrantyResult.dataModelName}}" data-sdf-attr.data-price="{{warrantyResult.dataPrice}}" data-sdf-attr.data-sale-price="{{warrantyResult.dataSalePrice}}">
          <p class="option-result__text-title" data-sdf-test="{{warrantyResult.displayModelName}}">
            {{warrantyResult.displayModelName}}
          </p>
          <p class="option-result__text" data-sdf-test="{{warrantyResult.discountText1}}">
            {{warrantyResult.discountText1}}
          </p>
        </div>
        <div class="option-result__desc-wrap" data-sdf-test="{{warrantyResult.description1}}">
          <p class="option-result__desc">
            {{warrantyResult.description1}}
          </p>
        </div>
        <a class="option-result__close remove-warranty-result" href="javascript:void(0)">
          <span class="hidden"> Tutup </span>
          <svg class="icon" focusable="false" viewBox="0 0 96 96">
            <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
            </path>
          </svg>
        </a>
      </div>
      <div class="pd-select-option option-warranty-vd sdf-component-template" data-sdf-template="warrantyVd @ drawObj" data-sdf-test="{{warrantyVd.hasComponent}}" data-sdf-unwrap="true">
        <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
            {{warrantyVd.title}}
          </h3>
          <span class="pd-select-option__cta-wrap">
            <a an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-target-popup="{{warrantyVd.learnMoreCta.learnMoreTargetPopup}}" data-sdf-attr.href="{{warrantyVd.learnMoreCta.learnMoreHref}}" data-sdf-attr.target="{{warrantyVd.learnMoreCta.learnMoreTarget}}">
              {{warrantyVd.learnMoreCta.learnMoreText}}
              <svg aria-hidden="true" class="icon" focusable="false">
                <use href="#outlink-bold" xlink:href="#outlink-bold">
                </use>
              </svg>
            </a>
          </span>
        </div>
        <p class="pd-select-option__desc">
          {{warrantyVd.description}}
        </p>
        <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" checked="" class="hidden" data-target-popup="{{warrantyVd.yesAttr.layerTarget}}" id="pd-extended-warranty-option-0" name="pd-extended-warranty-option" type="radio">
                <label class="pd-option-selector__label" for="pd-extended-warranty-option-0">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text">
                        {{warrantyVd.yesAttr.text}}
                      </strong>
                    </span>
                  </span>
                </label>
              </div>
            </li>
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-result-focus" id="pd-extended-warranty-option-1" name="pd-extended-warranty-option" type="radio">
                <label class="pd-option-selector__label" for="pd-extended-warranty-option-1">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <strong class="pd-option-selector__main-text">
                        {{warrantyVd.noAttr.text}}
                      </strong>
                    </span>
                  </span>
                </label>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="option-result option-result--extended-warranty-option sdf-component-template" data-sdf-template="warrantyVdResult @ drawObj" data-sdf-unwrap="true">
        <div class="option-result__text-wrap" data-sdf-attr.data-model-code="{{warrantyVdResult.smcCode}}" data-sdf-attr.data-price="{{warrantyVdResult.price}}">
          <p class="option-result__text-title">
            {{warrantyVdResult.title}}
          </p>
          <p class="option-result__text">
            {{warrantyVdResult.priceDisplay}}
          </p>
        </div>
        <a an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:delete" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="option-result__close" href="javascript:void(0)">
          <span class="hidden"> Close </span>
          <svg aria-hidden="true" class="icon" focusable="false" viewBox="0 0 96 96">
            <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
            </path>
          </svg>
        </a>
      </div>
      <!-- (2021.02.08 추가) Tooltip 기능 추가 -->
      <div class="pd-select-option pd-select-option--delivery-detail sdf-component-template" data-sdf-template="delivery @ drawObj" data-sdf-test="{{delivery.hasComponent}}" data-sdf-unwrap="true">
        <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
            {{delivery.headline}}
          </h3>
        </div>
        <div class="pd-select-option__input-wrap">
          <div class="text-field-v2 no-title {{delivery.labelClass}}">
            <label class="text-field-v2__hint" for="delivery-zipcode">
              {{delivery.label}}
            </label>
            <div class="text-field-v2__input-wrap">
              <input autocomplete="off" class="text-field-v2__input" data-sdf-attr.disabled="{{delivery.inputAttr.disabled}}" data-sdf-attr.maxlength="{{delivery.inputAttr.maxlength}}" data-sdf-attr.value="{{delivery.inputAttr.value}}" id="delivery-zipcode" type="text">
              <button an-ac="pd buying tool" an-ca="option click" an-la="zip code:delete" an-tr="header(pim)_option selector-product detail-image-submit" class="text-field-v2__input-icon delete add-special-tagging" title="Delete">
                <svg class="icon delete" focusable="false">
                  <use href="#cancel-bold" xlink:href="#cancel-bold">
                  </use>
                </svg>
              </button>
            </div>
            <p class="text-field-v2__text error">
              {{delivery.errorMessage}}
            </p>
          </div>
          <a an-ac="pd buying tool" an-ca="option click" an-la="delivery details:Apply" an-tr="hdd02_product info.-product detail-apply cta-option_click1" class="cta cta--contained cta--black check-zipcode {{delivery.ctaClass}}" href="javascript:void(0)" title="Apply"> Terapkan </a>
        </div>
      </div>
      <div class="option-result result-delivery sdf-component-template" data-sdf-template="deliveryResult @ drawObj" data-sdf-unwrap="true">
        <div class="option-result__text-wrap">
          <p class="option-result__text delivery-priority" data-sdf-test="{{deliveryResult.priorityText}}">
            {{deliveryResult.priorityText}}
          </p>
          <p class="option-result__text delivery-standard" data-sdf-test="{{deliveryResult.mainText}}">
            {{deliveryResult.mainText}}
          </p>
          <p class="option-result__sub-text" data-sdf-test="{{deliveryResult.subText}}">
            {{deliveryResult.subText}}
            <br> Standard installation charges may apply. <a aria-label="Link Title" class="option-result__text-link" href="https://images.samsung.com/is/content/samsung/assets/in/info/installation/Delivery-Service-TnC.pdf" target="_blank"> Click here </a> for more details.
          </p>
        </div>
        <div class="option-result__desc-wrap">
          <p class="option-result__desc-title" data-sdf-test="{{deliveryResult.decText}}">
            {{deliveryResult.decText}}
          </p>
          <p class="option-result__desc" data-sdf-repeat.item="{{deliveryResult.disclaimerList}}">
            {{item.disclaimer}}
          </p>
        </div>
        <a an-ac="pd buying tool" an-ca="option click" an-la="delivery details:delete" an-tr="hdd02_product info.-product detail-option selector-option_click1" class="option-result__close remove-delivery" href="javascript:void(0)">
          <span class="hidden"> Tutup </span>
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </a>
      </div>
      <div class="pd-select-option option-tariff sdf-component-template" data-sdf-template="tariffOption @ drawObj" data-sdf-test="{{tariffOption.hasComponent}}" data-sdf-unwrap="true">
        <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
            {{tariffOption.headline}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{tariffOption.href}}">
            <a an-ac="pd buying tool" an-ca="option click" an-la="tariff:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon add-special-tagging" data-sdf-attr.href="{{tariffOption.href}}" rel="nofollow" role="button" target="_blank" title="Lebih detail"> Lebih detail <svg aria-hidden="true" class="icon" focusable="false">
                <use href="#outlink-bold" xlink:href="#outlink-bold">
                </use>
              </svg>
            </a>
          </span>
        </div>
        <p class="pd-select-option__desc">
          {{tariffOption.description}}
        </p>
        <p class="pd-select-option__carrier" data-sdf-list.logoitem="{{tariffOption.logoList}}">
          <img class="carrier-logo" data-sdf-attr.alt="{{logoitem.alt}}" data-sdf-attr.src="{{logoitem.src}}" alt="">
        </p>
        <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list" role="list">
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="tariff:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" checked="" class="hidden option-input add-special-tagging" data-target-popup="tariffPopup" id="pd-tariff-option-0" name="pd-tariff-option" type="radio">
                <label class="pd-option-selector__label" for="pd-tariff-option-0">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <span class="pd-option-selector__main-text">
                        {{tariffOption.yesAttr.text}}
                      </span>
                    </span>
                  </span>
                </label>
              </div>
            </li>
            <li class="pd-select-option__item" role="listitem">
              <div class="pd-option-selector">
                <input an-ac="pd buying tool" an-ca="option click" an-la="tariff:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" id="pd-tariff-option-1" name="pd-tariff-option" type="radio">
                <label class="pd-option-selector__label" for="pd-tariff-option-1">
                  <span class="pd-option-selector__text-wrap">
                    <span class="pd-option-selector__text">
                      <span class="pd-option-selector__main-text">
                        {{tariffOption.noAttr.text}}
                      </span>
                    </span>
                  </span>
                </label>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="option-result result-tariff-option sdf-component-template" data-sdf-template="tariffOptionResult @ drawObj" data-sdf-test="{{tariffOptionResult.hasComponent}}" data-sdf-unwrap="true">
        <div class="option-result__text-wrap result-price" data-sdf-attr.data-id="{{tariffOptionResult.dataId}}" data-sdf-attr.data-model-code="{{tariffOptionResult.dataModelCode}}" data-sdf-attr.data-price="{{tariffOptionResult.dataPrice}}" data-sdf-attr.data-simsku-code="{{tariffOptionResult.dataSimskuCode}}">
          <p class="option-result__text-title" data-sdf-test="{{tariffOptionResult.displayModelName}}">
            {{tariffOptionResult.displayModelName}}
          </p>
          <p class="option-result__text" data-sdf-test="{{tariffOptionResult.discountText1}}">
            {{tariffOptionResult.discountText1}}
          </p>
        </div>
        <div class="option-result__desc-wrap" data-sdf-test="{{tariffOptionResult.description1}}">
          <p class="option-result__desc">
            {{tariffOptionResult.description1}}
          </p>
          <p class="option-result__desc">
            {{tariffOptionResult.description2}}
          </p>
        </div>
        <a class="option-result__close remove-tariff-option-result" href="javascript:void(0)">
          <span class="hidden"> Tutup </span>
          <svg class="icon" focusable="false" viewBox="0 0 96 96">
            <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
            </path>
          </svg>
        </a>
        <p class="option-result__desc">
          {{tariffOptionResult.description}}
        </p>
        <p class="option-result__price" data-sdf-attr.data-id="{{tariffOptionResult.dataId}}" data-sdf-attr.data-model-code="{{tariffOptionResult.dataModelCode}}" data-sdf-attr.data-price="{{tariffOptionResult.dataPrice}}" data-sdf-attr.data-simsku-code="{{tariffOptionResult.dataSimskuCode}}">
          {{tariffOptionResult.price}}
        </p>
        <p class="option-result__disclaimer">
          {{tariffOptionResult.disclaimer}}
        </p>
      </div>
      <div class="pd-select-option option-embed-addon sdf-component-template" data-sdf-template="embedAddon @ drawObj" data-sdf-test="{{embedAddon.hasComponent}}" data-sdf-unwrap="true">
        <h3 class="pd-select-option__headline">
          {{embedAddon.title}}
        </h3>
        <p class="pd-select-option__desc">
          {{embedAddon.description}}
        </p>
        <ul class="add-on-product-list-wrap" data-sdf-test="{{embedAddon.isNotVDSTEPBUYING}}" data-total-price="0" data-total-sale-price="0">
          <li class="add-on-product{{item.oosClass}}" data-sdf-repeat.item="{{embedAddon.itemSet}}">
            <div class="checkbox-v2">
              <input an-ac="pd buying tool" an-ca="option click" an-la="add on product purchase only:{{item.nameToLowerCase}}" class="checkbox-v3__input" data-modelcode="{{item.modelCode}}" data-modelname="{{item.groupCode}}" id="add-on-product-{{item.index}}" name="checkbox" type="checkbox">
              <label class="checkbox-v3__label" for="add-on-product-{{item.index}}">
                <span class="checkbox-v3__label-box-wrap">
                  <span class="checkbox-v3__label-box">
                    <svg aria-hidden="true" class="checkbox-v3__label-box-icon" focusable="false">
                      <use href="#done-bold" xlink:href="#done-bold">
                      </use>
                    </svg>
                  </span>
                </span>
                <span class="checkbox-v3__label-text">
                  {{item.name}}
                </span>
              </label>
            </div>
            <div class="add-on-product__image">
              <div class="image">
                <img alt="{{item.imgAlt}}" class="image__preview lazy-load" data-src="{{item.imgSrc}}" role="img">
                <img alt="{{item.imgAlt}}" class="image__main lazy-load" data-src="{{item.imgSrc}}" role="img">
              </div>
            </div>
            <div class="add-on-product__detail-wrap">
              <div class="add-on-product__text-wrap">
                <span class="badge-icon badge-icon--label-v2 {{item.iconClass}}" data-sdf-test="{{item.iconClass}}">
                  {{item.iconTitle}}
                </span>
                <p class="add-on-product__title" data-model-name="{{item.name}}">
                  {{item.name}}
                </p>
                <p class="add-on-product__serial-number" data-model-code="{{item.modelCode}}" data-sdf-test="{{item.modelCode}}">
                  {{item.modelCode}}
                </p>
                <p class="add-on-product__desc" data-sdf-test="{{item.description}}">
                  {{item.description}}
                </p>
              </div>
              <div class="add-on-product__price-wrap">
                <p class="add-on-product__final-price" data-price="{{item.finalPriceValue}}">
                  {{item.finalPrice}}
                </p>
                <del class="add-on-product__original-price" data-original-price="{{item.originalPriceValue}}" data-sdf-test="{{item.originalPrice}}">
                  {{item.originalPrice}}
                </del>
                <span class="add-on-product__saving-price" data-save-price="{{item.savePriceValue}}" data-sdf-test="{{item.savePrice}}">
                  {{item.savePrice}}
                </span>
                <span class="add-on-product__out-of-stock" data-sdf-test="{{item.isOOS}}"> Habis </span>
              </div>
              <button aria-label="Learn More" class="cta cta--underline-v2 cta--black cta-learn-more" data-model-idx="{{item.index}}" data-sdf-test="{{item.isLearnMorePopup}}"> Lebih detail </button>
            </div>
          </li>
        </ul>
        <ul class="add-on-product-list-wrap add-on-product-list-wrap--vd" data-sdf-test="{{embedAddon.isVDSTEPBUYING}}" data-total-price="0" data-total-sale-price="0">
          <li class="add-on-product{{item.oosClass}}{{item.hideClass}}" data-sdf-repeat.item="{{embedAddon.itemSet}}" data-view-more-item="true">
            <div class="add-on-product__image">
              <div class="image">
                <img alt="{{item.imgAlt}}" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="" data-mobile-src="" data-src="" role="img" style="display: none;">
                <img alt="{{item.imgAlt}}" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="{{item.imgSrc}}?$72_72_PNG$" data-mobile-src="{{item.imgSrc}}?$128_128_PNG$" data-src="{{item.imgSrc}}?$72_72_PNG$" role="img">
              </div>
            </div>
            <div class="add-on-product__detail-wrap">
              <div class="add-on-product__text-wrap">
                <span class="badge-icon badge-icon--label-v2 {{item.iconClass}}" data-sdf-test="{{item.iconClass}}">
                  {{item.iconTitle}}
                </span>
                <p class="add-on-product__title" data-model-name="{{item.name}}">
                  {{item.name}}
                </p>
                <p class="add-on-product__desc" data-sdf-test="{{item.description}}">
                  {{item.description}}
                </p>
                <ul class="add-on-product__dot-list" data-sdf-test="{{item.dotList1}}">
                  <li data-sdf-test="{{item.dotList1}}">
                    {{item.dotList1}}
                  </li>
                  <li data-sdf-test="{{item.dotList2}}">
                    {{item.dotList2}}
                  </li>
                  <li data-sdf-test="{{item.dotList3}}">
                    {{item.dotList3}}
                  </li>
                </ul>
              </div>
              <div class="add-on-product__price-wrap">
                <p class="add-on-product__final-price" data-price="{{item.finalPriceValue}}">
                  {{item.finalPrice}}
                </p>
                <del class="add-on-product__original-price" data-original-price="{{item.originalPriceValue}}" data-sdf-test="{{item.originalPrice}}">
                  {{item.originalPrice}}
                </del>
                <span class="add-on-product__saving-price" data-save-price="{{item.savePriceValue}}" data-sdf-test="{{item.savePrice}}">
                  {{item.savePrice}}
                </span>
                <span class="add-on-product__out-of-stock" data-sdf-test="{{item.isOOS}}"> Habis </span>
              </div>
              <button an-ac="pd buying tool" an-ca="option click" an-la="add-on:add item" an-tr="hdd02_pdp header-product detail-add item-option_click" aria-label="Add" class="cta cta--outlined cta--black embed-addon-add" data-id="add-on-product-{{item.index}}" data-mode-code="{{item.modelCode}}" data-sdf-test="{{item.isStock}}"> Tambah </button>
              <button an-ac="pd buying tool" an-ca="option click" an-la="add-on:add item" an-tr="hdd02_pdp header-product detail-add item-option_click" aria-label="Add" class="cta cta--outlined cta--black cta--disabled embed-addon-add" data-sdf-test="{{item.isOOS}}" disabled=""> Tambah </button>
            </div>
          </li>
        </ul>
        <div class="pd-select-option__view-more" data-sdf-test="{{embedAddon.useMobileCTA}}">
          <button aria-expanded="false" class="cta cta--icon" data-js-action="offerListViewMore" data-text-close="Lihat sedikit" data-text-open="Lihat selengkapnya" type="button">
            <span class="pd-select-option__view-more-text"> Lihat selengkapnya </span>
            <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#open-down-regular" xlink:href="#open-down-regular">
              </use>
            </svg>
          </button>
        </div>
      </div>
      <div data-sdf-template="offerContent_promotionMessage @ message" data-sdf-unwrap="true">
        <div class="dot-list__text-wrap {{message.item.contentWrapperClass}}">
          <span class="dot-list__text" data-sdf-test="{{message.item.offerTitle}}">
            {{message.item.offerTitle}}
          </span>
          <span class="dot-list__tooltip" data-sdf-test="{{message.item.offerTooltip}}">
            <button aria-describedby="descTip" class="dot-list__tooltip-cta">
              <span class="hidden"> ? </span>
            </button>
            <span class="dot-list__tooltip-message" id="descTip" role="tooltip">
              <span class="dot-list__tooltip-message-text">
                {{message.item.offerTooltip}}
              </span>
              <button class="dot-list__tooltip-close">
                <span class="hidden"> Close </span>
                <svg aria-hidden="true" class="icon icon-delete" focusable="false">
                  <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
                  </use>
                </svg>
              </button>
            </span>
          </span>
          <a an-ac="pd buying tool" an-ca="option click" an-la="offers:{{message.item.title}}:{{message.item.linkText}}" an-tr="hdd02_product info.-product detail-offers-option_click1" class="cta cta--underline-v2 cta--black" data-sdf-attr.href="{{message.item.linkUrl}}" data-sdf-attr.title="{{message.item.linkText}}" data-sdf-test="{{message.item.linkEnabled}}">
            {{message.item.linkText}}
          </a>
        </div>
        <p class="dot-list__desc" data-sdf-test="{{message.item.hasTCCTA}}">
          {{message.item.tcCTAText}}
        </p>
        <p class="dot-list__desc" data-sdf-test="{{message.item.hasPeriod}}">
          {{message.item.periodText}}
        </p>
      </div>
    </div>
    <!--googleon: all-->
  </div>
  <div class="pd-g-feature-benefit-ux2 pd-g-feature-benefit">
    <!-- isNotBuyingPd-->
    <!-- FaqSeo -->
  </div>
  <div class="pd-g-reasons-to-buy-ux2">
    <input id="rtbListSize" name="rtbListSize" type="hidden" value="4">
    <section class="pdd28-reasons-to-buy pdd28-reasons-to-buy--theme-white-card" style="">
      <script data-id="2b893dde-fb1e-4e03-8e91-a97d9d75e68a" data-object-type="OfferCatalog" data-type="seo" type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "OfferCatalog",
          "name": "Beli langsung. Dapat lebih banyak.",
          "itemListElement": [{
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Samsung Rewards",
              "description": "Belanja dan kumpulkan point reward untuk pembelian berikutnya"
            }
          }, {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Samsung Premium Care",
              "description": "Perlindungan lebih tanpa perlu khawatir"
            }
          }, {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Gratis Pengiriman",
              "description": "Kupas cara membaca pola Thailand dan jalur jackpot di Naga 508Slot SLOT GACOR LUAR NEGERI lewat pendekatan CASINO DEMO GRATIS yang lebih rapi. Ulasan ini menyorot ritme main, momen peluang, dan bukti nyata yang perlu diperhatikan sebelum mencoba."
            }
          }, {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Flexible Finance",
              "description": "Cicilan 0% menggunakan kartu kredit bank hingga 24 bulan"
            }
          }]
        }
      </script>

      <style id="SEOCRY-clean-section-style">
  .rj-slot-wrapper {
    max-width: 1180px;
    margin: 0 auto;
    padding: 28px 16px 40px;
    font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
    color: #fff8f0;
  }

  .rj-slot-block {
    background: linear-gradient(145deg, rgba(38, 5, 7, .96), rgba(8, 1, 2, .98));
    border: 1px solid #ff0000;
    border-radius: 24px;
    box-shadow: 0 18px 42px rgba(0, 0, 0, .42), 0 0 24px rgba(215, 40, 47, .22);
    padding: 24px;
    margin: 0 0 22px;
  }

  .rj-section-label {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 7px 13px;
    border-radius: 999px;
    background: rgba(255, 211, 106, .12);
    border: 1px solid rgba(255, 211, 106, .35);
    color: #ffd36a;
    font-size: 12px;
    font-weight: 800;
    letter-spacing: .8px;
    text-transform: uppercase;
    margin-bottom: 14px;
  }

  .rj-live-rtp-section {
    padding: 18px;
  }

  .rj-rtp-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    margin-bottom: 12px;
  }

  .rj-rtp-title {
    color: #f2ff00;
    font-weight: 900;
    letter-spacing: .4px;
    text-shadow: 0 0 8px rgba(255, 247, 102, .75);
  }

  .rj-rtp-time {
    color: #75deff;
    font-weight: 800;
    white-space: nowrap;
  }

  .rj-rtp-list {
    display: grid;
    grid-template-columns: repeat(7, minmax(0, 1fr));
    gap: 8px;
  }

  .rj-rtp-card {
    position: relative;
    min-height: 58px;
    padding: 9px 6px;
    border-radius: 12px;
    background: linear-gradient(180deg, #251009, #080004);
    border: 1px solid rgba(255, 255, 255, .70);
    box-shadow: inset 0 0 10px rgba(255, 20, 147, .12);
    text-align: center;
    overflow: hidden;
  }

  .rj-rtp-card::before {
    content: "";
    position: absolute;
    inset: 0;
    background: linear-gradient(120deg, transparent, rgba(255, 255, 255, .10), transparent);
    transform: translateX(-100%);
    animation: rjRtpShine 4s infinite;
  }

  .rj-rtp-card.is-active {
    border-color: #75deff;
    box-shadow: 0 0 14px rgba(117, 222, 255, .32), inset 0 0 12px rgba(255, 215, 0, .15);
  }

  .rj-rtp-day {
    position: relative;
    z-index: 1;
    font-size: 11px;
    color: #ffd966;
    font-weight: 900;
    text-transform: uppercase;
  }

  .rj-rtp-date {
    position: relative;
    z-index: 1;
    font-size: 10px;
    color: #fff;
    opacity: .86;
    margin-top: 2px;
  }

  .rj-rtp-percent {
    position: relative;
    z-index: 1;
    font-size: 15px;
    color: #75deff;
    font-weight: 900;
    margin-top: 3px;
    text-shadow: 0 0 8px rgba(255, 20, 147, .75);
  }

  .rj-rtp-status {
    position: relative;
    z-index: 1;
    display: inline-block;
    font-size: 9px;
    font-weight: 900;
    color: #101010;
    background: linear-gradient(90deg, #ffd966, #75deff);
    border-radius: 20px;
    padding: 2px 7px;
    margin-top: 3px;
  }

  @keyframes rjRtpShine {
    0% { transform: translateX(-100%); }
    45%, 100% { transform: translateX(100%); }
  }

  @media (max-width: 900px) {
    .rj-rtp-list {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    .rj-rtp-head {
      flex-direction: column;
      text-align: center;
    }
  }

  @media (max-width: 560px) {
    .rj-slot-block {
      padding: 18px;
      border-radius: 18px;
    }
  }
</style>

<div class="rj-slot-wrapper">
  <section class="rj-slot-block rj-live-rtp-section" aria-labelledby="rj-live-rtp-title">
    <div class="rj-section-label">Live RTP</div>
    <div class="rj-rtp-head">
      <div class="rj-rtp-title" id="rj-live-rtp-title">RAJA SLOT GACOR TERBARU GAMPANG MENANG</div>
      <div class="rj-rtp-time" id="rjRtpClock">LIVE 02:30:28 | Update RTP Slot Gacor</div>
    </div>
    <div class="rj-rtp-list" id="rjRtpCalendar">
      <!-- Konten kalender di bawah ini akan di-generate otomatis oleh Javascript -->
      <div class="rj-rtp-card is-active">
        <div class="rj-rtp-day">HARI INI</div>
        <div class="rj-rtp-date">3 Sep</div>
        <div class="rj-rtp-percent">91.02%</div>
        <div class="rj-rtp-status">STABIL</div>
      </div>
      <div class="rj-rtp-card">
        <div class="rj-rtp-day">JUM</div>
        <div class="rj-rtp-date">4 Sep</div>
        <div class="rj-rtp-percent">95.80%</div>
        <div class="rj-rtp-status">HOT</div>
      </div>
      <!-- dan seterusnya... -->
    </div>
  </section>
</div>

<script id="SEOCRY-rtp-script">
  (function() {
    const wrap = document.getElementById("rjRtpCalendar");
    const clock = document.getElementById("rjRtpClock");
    
    if (wrap && clock) {
      const dayNames = ["MIN", "SEN", "SEL", "RAB", "KAM", "JUM", "SAB"];
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];

      function seededRandom(seed) {
        const x = Math.sin(seed) * 10000;
        return x - Math.floor(x);
      }

      function getRtpValue(date, index) {
        const now = new Date();
        const updateBlock = Math.floor(now.getMinutes() / 15);
        const seed = date.getFullYear() * 10000 + (date.getMonth() + 1) * 100 + date.getDate() + index * 77 + updateBlock * 33;
        return (86 + seededRandom(seed) * 12).toFixed(2);
      }

      function getStatus(rtp) {
        const value = parseFloat(rtp);
        if (value >= 95) return "HOT";
        if (value >= 91) return "STABIL";
        return "NORMAL";
      }

      function renderCalendar() {
        const today = new Date();
        wrap.innerHTML = "";
        for (let i = 0; i < 7; i++) {
          const date = new Date();
          date.setDate(today.getDate() + i);
          const rtp = getRtpValue(date, i);
          const card = document.createElement("div");
          card.className = "rj-rtp-card" + (i === 0 ? " is-active" : "");
          card.innerHTML = `
            <div class="rj-rtp-day">${i === 0 ? "HARI INI" : dayNames[date.getDay()]}</div>
            <div class="rj-rtp-date">${date.getDate()} ${monthNames[date.getMonth()]}</div>
            <div class="rj-rtp-percent">${rtp}%</div>
            <div class="rj-rtp-status">${getStatus(rtp)}</div>
          `;
          wrap.appendChild(card);
        }
      }

      function updateClock() {
        const now = new Date();
        const jam = String(now.getHours()).padStart(2, "0");
        const menit = String(now.getMinutes()).padStart(2, "0");
        const detik = String(now.getSeconds()).padStart(2, "0");
        clock.textContent = `LIVE ${jam}:${menit}:${detik} | Update RTP Slot Gacor`;
      }

      renderCalendar();
      updateClock();
      setInterval(updateClock, 1000);
      setInterval(renderCalendar, 60000);
    }
  })();
</script>
<style>.lx-container{max-width:1100px;margin:16px auto;padding:0 12px;font-family:Inter,system-ui,Arial,sans-serif;background:transparent;border:none;box-shadow:none;color:#1c1917}.lx-container *{box-sizing:border-box}.lx-mainbox{display:flex;flex-direction:column;gap:12px;background:transparent;border:none;box-shadow:none;padding:0;margin:0}.lx-hero{display:block;width:100%}.lx-title-card,.highlight-box,.lx-faq{width:100%;background:#f6f3ee;color:#1c1917;border:1px solid #e4ddd3;border-radius:12px;padding:16px 18px}.lx-badge{display:inline-block;margin-bottom:8px;padding:3px 10px;border-radius:999px;background:#efe8dc;color:#3f3a34;font-size:12px;font-weight:700}.lx-title-card h1,.highlight-box p,.lx-faq h2,.lx-faq summary,.lx-faq p,.reviews-section h2{color:#1c1917}.lx-title-card h1{margin:0 0 8px;font-size:26px;line-height:1.25}.lx-divider{width:64px;height:2px;margin:0;background:#e879f9}.highlight-box p{margin:0 0 14px;line-height:1.7;font-size:16px;text-align:justify}.highlight-box p:last-child{margin-bottom:0}.highlight-box a{color:#e879f9;font-weight:700;text-decoration:underline}.info-grid,.reviews-grid{display:grid;gap:8px;width:100%}.info-grid{grid-template-columns:repeat(4,minmax(0,1fr))}.reviews-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.info-card,.review-card{background:#1f2933;color:#f8fafc;border:1px solid rgba(255,255,255,.12);border-radius:10px;padding:12px}.info-card .label,.review-date{font-size:11px;opacity:.8;color:#e5e7eb}.info-card .value,.review-name,.review-stars,.review-text{color:#f8fafc}.info-card .value{font-size:15px;font-weight:700}.reviews-section h2,.lx-faq h2{margin:0 0 10px;font-size:18px}.review-header{display:flex;justify-content:space-between;gap:8px;font-size:13px;font-weight:700}.review-text{margin:6px 0;font-size:14px;line-height:1.45}.lx-foot{margin:4px 0 0;padding:10px 0 0;border-top:1px solid #22d3ee;color:#22d3ee;font-size:12px;text-align:center;background:transparent;border-left:none;border-right:none;box-shadow:none}.lx-faq details{margin:0 0 8px;border-bottom:1px solid #e4ddd3;padding-bottom:8px}.lx-faq summary{cursor:pointer;font-weight:700}.lx-faq p{margin:8px 0 0;line-height:1.55;font-size:14px}@media(max-width:980px){.reviews-grid{grid-template-columns:1fr}}@media(max-width:720px){.info-grid{grid-template-columns:1fr}.lx-title-card h1{font-size:22px}}</style><article class="lx-container lp-216368938630867531" aria-label="Artikel Naga 508Slot SLOT GACOR LUAR NEGERI"><div class="lx-mainbox"><div class="lx-hero"><div class="lx-title-card"><div class="lx-badge">Informasi Pilihan Naga 508Slot SLOT GACOR LUAR NEGERI</div><h1>Naga 508Slot SLOT GACOR LUAR NEGERI Trik Pola Thailand Jalur Jackpot CASINO DEMO GRATIS Bukti Nyata</h1><div class="lx-divider"></div></div></div><div class="highlight-box"><p><a href="http://roket.nariklagi.site/?reff=CILEKA">Naga 508Slot SLOT GACOR LUAR NEGERI</a> Tidak ada putaran yang memaksa; setiap frasa di judul punya tempat yang sama di penjelasan ini. Kalau kamu baru pertama kali masuk, cukup ikuti tautan brand lalu lihat bagaimana Thailand Jalur dijabarkan. Yang penting adalah ritme: masuk, baca, coba, lalu putuskan sendiri tanpa tekanan. Banyak orang tersesat karena judul dan isi tidak sejalan; di sini keduanya dibuat saling mengunci. Dengan begitu Naga 508Slot SLOT GACOR LUAR NEGERI terasa seperti peta singkat, bukan slogan kosong yang dibiarkan menggantung. Naga 508Slot SLOT GACOR LUAR NEGERI membuka jalan yang paling jelas saat kamu ingin menelusuri Trik Pola tanpa berpindah ke halaman yang tidak relevan. Judul halaman ini sudah menandai arahnya, jadi kamu tidak perlu menebak-nebak dari mana harus mulai.</p><p>Perbedaan dengan paragraf sebelumnya sederhana: di sini kamu sudah di dalam, bukan masih di ambang pintu. Tutupnya tetap tenang: Naga 508Slot SLOT GACOR LUAR NEGERI menahan janji judul sampai kamu sendiri yang menilai apakah cocok dilanjut. Setelah pintu itu terbuka, Naga 508Slot SLOT GACOR LUAR NEGERI menuntun kamu lebih dalam ke cara kerja Trik Pola yang tadi hanya disebut di judul. Bukan mengulang kalimat pembuka, bagian ini mengurai tempo: kapan kamu berhenti, kapan kamu lanjut, dan kapan kamu ganti pilihan. Pola Thailand tidak lagi jadi label; ia jadi langkah yang bisa kamu rasakan saat lobby sudah tampil. Kamu bisa menakar kenyamanan tombol, jeda loading, dan kejelasan menu tanpa harus menebak-nebak. Kalau satu permainan terasa datar, ganti ke yang lebih dekat dengan Thailand Jalur supaya janji judul tetap terasa.</p></div><div class="info-grid"><div class="info-card"><div class="label">Penilaian</div><div class="value">4,8/5 untuk ritme pola</div></div><div class="info-card"><div class="label">Min. Deposit</div><div class="value">Mulai dari nominal ringan</div></div><div class="info-card"><div class="label">Min. Withdraw</div><div class="value">Menyesuaikan aturan akun</div></div><div class="info-card"><div class="label">Support</div><div class="value">24/7 respons cepat</div></div></div><section class="reviews-section"><h2>APA KATA MEREKA? REVIEW MEMBER SETIA Naga 508Slot SLOT GACOR LUAR NEGERI</h2><div class="reviews-grid"><div class="review-card"><div class="review-header"><span class="review-name">Sinta Anggraini – Tangerang</span><span class="review-stars">★★★★★</span></div><p class="review-text">"Saya masuk Naga 508Slot SLOT GACOR LUAR NEGERI lewat HP, terus coba beberapa ronde pendek. Ada yang pas, ada yang biasa, tapi nggak terasa dipaksa."</p><span class="review-date">21 November 2026</span></div><div class="review-card"><div class="review-header"><span class="review-name">Yoga Nugroho – Surabaya</span><span class="review-stars">★★★★☆</span></div><p class="review-text">"Teman yang kasih tahu Naga 508Slot SLOT GACOR LUAR NEGERI. Saya coba sendiri, lobby-nya rapi jadi saya nggak lama nyari-nyari."</p><span class="review-date">21 November 2026</span></div><div class="review-card"><div class="review-header"><span class="review-name">Maya Puspita – Malang</span><span class="review-stars">★★★★★</span></div><p class="review-text">"Yang saya suka di Naga 508Slot SLOT GACOR LUAR NEGERI, saya bisa berhenti sejenak lalu lanjut lagi tanpa merasa ketinggalan. Santai, tapi tetap seru."</p><span class="review-date">21 November 2026</span></div><div class="review-card"><div class="review-header"><span class="review-name">Eko Santoso – Bekasi</span><span class="review-stars">★★★★★</span></div><p class="review-text">"Baru dua-tiga kali main di Naga 508Slot SLOT GACOR LUAR NEGERI, kesannya belum sempurna. Tapi alurnya jelas, jadi saya masih mau coba lagi."</p><span class="review-date">21 November 2026</span></div><div class="review-card"><div class="review-header"><span class="review-name">Dinda Wijaya – Pekanbaru</span><span class="review-stars">★★★★★</span></div><p class="review-text">"Saya bukan tipe yang lama di satu tempat. Di Naga 508Slot SLOT GACOR LUAR NEGERI saya bisa pilih yang ringan dulu, baru yang lebih seru kalau moodnya pas."</p><span class="review-date">21 November 2026</span></div><div class="review-card"><div class="review-header"><span class="review-name">Fajar Kurniawan – Semarang</span><span class="review-stars">★★★★★</span></div><p class="review-text">"Jujur awalnya cuma iseng buka Naga 508Slot SLOT GACOR LUAR NEGERI. Habis masuk lobby, gampang nemu yang enak dimainkan, jadi saya betah lebih lama dari rencana."</p><span class="review-date">21 November 2026</span></div></div></section><div class="lx-foot">© 2026 Naga 508Slot SLOT GACOR LUAR NEGERI</div><section class="lx-faq"><h2>FAQ Naga 508Slot SLOT GACOR LUAR NEGERI</h2><details class="lx-faq-item" open><summary>Bagaimana cara mulai di Naga 508Slot SLOT GACOR LUAR NEGERI?</summary><p>Mulai dari tautan brand di paragraf pertama, baca janji judul, lalu masuk ke lobby dan coba ritmenya tanpa terburu-buru.</p></details><details class="lx-faq-item"><summary>Apakah Naga 508Slot SLOT GACOR LUAR NEGERI nyaman dibuka di HP?</summary><p>Alurnya dibuat agar tombol dan teks tetap kebaca di layar kecil, jadi kamu bisa berhenti sejenak lalu lanjut lagi.</p></details><details class="lx-faq-item"><summary>Kalau bingung di Naga 508Slot SLOT GACOR LUAR NEGERI, ke mana harus bertanya?</summary><p>Pakai jalur Support di kartu info. Jelaskan letak menu yang membuatmu nyasar supaya jawaban CS tidak mengambang.</p></details><details class="lx-faq-item"><summary>Apa bedanya paragraf kedua dengan paragraf pertama?</summary><p>Paragraf pertama menuntun masuk lewat judul. Paragraf kedua mengurai tempo setelah kamu sudah di dalam, bukan mengulang pembuka.</p></details><details class="lx-faq-item"><summary>Apakah review di Naga 508Slot SLOT GACOR LUAR NEGERI bisa dipakai sebagai patokan?</summary><p>Enam kartu itu pengalaman setelah main, bukan brosur. Baca beberapa sudut, lalu cocokkan dengan apa yang kamu rasakan sendiri.</p></details></section></div></article>
  <nav aria-label="Breadcrumb" class="breadcrumb">
    <div class="breadcrumb__inner">
      <ul class="breadcrumb__path" role="list">
        <li role="listitem">
          <a an-ac="breadcrumb" an-ca="navigation" an-la="breadcrumb:home" an-tr="nv03_breadcrumb-product detail-text-breadcrumb" aria-label="Home" href="https://printquarters.com/about/team.php">
            <span class="breadcrumb__text-desktop"> Naga 508Slot SLOT GACOR LUAR NEGERI <span style="margin-left: 15px;">&gt;</span>
            </span>
            <span class="breadcrumb__text-mobile"> Naga 508Slot SLOT GACOR LUAR NEGERI <span style="margin-left: 15px;">&gt;</span>
            </span>
          </a>
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#next-bold" xlink:href="#next-bold">
            </use>
          </svg>
        </li>
        <li role="listitem">
          <a an-ac="breadcrumb" an-ca="navigation" an-la="breadcrumb:mobile" an-tr="nv03_breadcrumb-product detail-text-breadcrumb" aria-label="Mobile" href="https://printquarters.com/about/team.php">
            <span class="breadcrumb__text-desktop"> SLOT <span style="margin-left: 15px;">&gt;</span>
            </span>
            <span class="breadcrumb__text-mobile"> SLOT <span style="margin-left: 15px;">&gt;</span>
            </span>
          </a>
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#next-bold" xlink:href="#next-bold">
            </use>
          </svg>
        </li>
        <li role="listitem">
          <a an-ac="breadcrumb" an-ca="navigation" an-la="breadcrumb:smartphones" an-tr="nv03_breadcrumb-product detail-text-breadcrumb" aria-label="Smartphones" href="https://printquarters.com/about/team.php">
            <span class="breadcrumb__text-desktop"> SLOT GACOR </span>
            <span class="breadcrumb__text-mobile"> Naga 508Slot SLOT GACOR LUAR NEGERI </span>
          </a>
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#next-bold" xlink:href="#next-bold">
            </use>
          </svg>
        </li>
      </ul>
    </div>
    <script data-id="815b4f0e-baa9-42cc-b1f9-b4b995da3ffb" data-object-type="BreadcrumbList" data-type="seo" type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "@id": "https://www.samsung.com/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy/#breadcrumb",
        "itemListElement": [{
          "@type": "ListItem",
          "name": "Home",
          "item": "https://www.samsung.com/id/",
          "position": 1
        }, {
          "@type": "ListItem",
          "name": "Mobile",
          "item": "https://www.samsung.com/id/mobile/",
          "position": 2
        }, {
          "@type": "ListItem",
          "name": "Smartphones",
          "item": "https://www.samsung.com/id/smartphones/",
          "position": 3
        }, {
          "@type": "ListItem",
          "name": "Galaxy A",
          "item": "https://www.samsung.com/id/smartphones/galaxy-a/",
          "position": 4
        }, {
          "@type": "ListItem",
          "name": "Situs SLOT",
          "item": "",
          "position": 5
        }]
      }
    </script>
  </nav>
  <div class="pd-g-manufacturer-info-popup">
    <div aria-modal="true" class="manufacturer-info-popup" role="dialog" tabindex="0">
      <div class="layer-popup">
        <div class="layer-popup__inner">
          <div class="layer-popup__contents scrollbar">
            <div class="scrollbar__wrap">
              <div class="scrollbar__contents">
              </div>
            </div>
            <div class="scrollbar-horizontal__track" style="display: none;">
              <div class="scrollbar-horizontal__track-content">
                <div class="scrollbar-horizontal__bar"></div>
              </div>
            </div>
            <div class="scrollbar-vertical__track" style="display: none;">
              <div class="scrollbar-vertical__track-content">
                <div class="scrollbar-vertical__bar"></div>
              </div>
            </div>
          </div>
          <button class="layer-popup__close" type="button">
            <span class="hidden"> Tutup Layar Popup </span>
            <svg class="icon" focusable="false">
              <use href="#delete-bold" xlink:href="#delete-bold">
              </use>
            </svg>
          </button>
        </div>
      </div>
    </div>
  </div>
  <!-- <sly data-sly-use.templatedContainer="com.day.cq.wcm.foundation.TemplatedContainer"
			data-sly-repeat.child=""
			data-sly-resource=""></sly> -->
  <div class="pdd39-anchor-nav__bottom-wrap" id="anchorNavigationPriceBarMobile">
    <div class="pdd39-anchor-nav__bottom">
      <div class="pdd39-anchor-nav__price pd-buying-price" id="sgDevPriceAreaBaseMobile">
      </div>
    </div>
  </div>
  <footer class="footer">
    <!--googleoff: all-->
    <div class="footer">
      <div class="footer-column">
        <p class="hidden"> Footer Navigation </p>
        <!-- ===== COLUMN 1: PRODUCTS ===== -->
        <div class="footer-column__item">
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-0">Slot</p>
            <a an-ac="footer" an-ca="navigation" an-la="slot" an-tr="nv01_footer sitemap|menu1Depth" aria-labelledby="footer-category-title-0" class="footer-category__anchor" href="javascript:void(0);" role="button" an-as="">
              <span class="hidden" data-i18n-close="Tutup" data-i18n-open="Buka">Buka</span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT ONLINE</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT GACOR</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SITUS SLOT</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SITUS SLOT ONLINE</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">LINK SLOT GACOR</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT GACOR HARI INI</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT ONLINE TERPERCAYA</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="footer-column__item">
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-1">Slot Online</p>
            <a an-ac="footer" an-ca="navigation" an-la="slot-online" an-tr="nv01_footer sitemap|menu1Depth" aria-labelledby="footer-category-title-1" class="footer-category__anchor" href="javascript:void(0);" role="button" an-as="">
              <span class="hidden" data-i18n-close="Tutup" data-i18n-open="Buka">Buka</span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">GAME SLOT ONLINE</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT ONLINE GACOR</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT ONLINE HARI INI</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT ONLINE TERBARU</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT ONLINE RESMI</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT ONLINE MUDAH MENANG</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT ONLINE MAXWIN</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="footer-column__item">
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-2">Slot Gacor</p>
            <a an-ac="footer" an-ca="navigation" an-la="slot-gacor" an-tr="nv01_footer sitemap|menu1Depth" aria-labelledby="footer-category-title-2" class="footer-category__anchor" href="javascript:void(0);" role="button" an-as="">
              <span class="hidden" data-i18n-close="Tutup" data-i18n-open="Buka">Buka</span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT GACOR TERBARU</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT GACOR MAXWIN</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT GACOR MALAM INI</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT GACOR GAMPANG MENANG</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT GACOR HARI INI</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SLOT GACOR TERBAIK</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">POLA SLOT GACOR</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="footer-column__item">
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-3">Situs Slot</p>
            <a an-ac="footer" an-ca="navigation" an-la="situs-slot" an-tr="nv01_footer sitemap|menu1Depth" aria-labelledby="footer-category-title-3" class="footer-category__anchor" href="javascript:void(0);" role="button" an-as="">
              <span class="hidden" data-i18n-close="Tutup" data-i18n-open="Buka">Buka</span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SITUS SLOT ONLINE</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SITUS SLOT GACOR</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SITUS SLOT TERBARU</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SITUS SLOT MAXWIN</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">SITUS SLOT88</a></li>
                <li class="footer-category__item"><a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as="">LINK SLOT88</a></li>
              </ul>
            </div>
          </div>
        </div>
        <!-- ===== COLUMN 5: INFO + ABOUT SLOT ===== -->
        <div class="footer-column__item">
          <!-- Info / Guides -->
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-4"> Information </p>
            <a an-ac="footer" an-ca="navigation" an-la="information" an-tr="nv01_footer sitemap|menu1Depth" aria-labelledby="footer-category-title-4" class="footer-category__anchor" href="javascript:void(0);" role="button" an-as="">
              <span class="hidden"> Buka </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as=""> Fitur Akses </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as=""> Fitur Pemula </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as=""> Aturan &amp; Kebijakan </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as=""> Kontak Resmi </a>
                </li>
              </ul>
            </div>
          </div>
          <!-- About SLOT -->
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-4-2"> About Naga 508Slot SLOT GACOR LUAR NEGERI </p>
            <a an-ac="footer" an-ca="navigation" an-la="about SLOT" an-tr="nv01_footer sitemap|menu1Depth" aria-labelledby="footer-category-title-4-2" class="footer-category__anchor" href="javascript:void(0);" role="button" an-as="">
              <span class="hidden"> Buka </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as=""> Tentang Slot Online </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as=""> Kenapa Pilih Naga 508Slot SLOT GACOR LUAR NEGERI </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as=""> Partner &amp; Affiliate </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://printquarters.com/about/team.php" an-as=""> Brand &amp; Identitas </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <!-- ===== BOTTOM BAR ===== -->
      <div class="footer-bottom">
        <div class="footer-copyright-wrap">
          <div class="footer-copyright-align">
            <p class="footer-copyright"> © 2026 Naga 508Slot SLOT GACOR LUAR NEGERI - RAJA SLOT GACOR. All rights reserved. </p>
          </div>
          <div class="footer-language">
            <a class="footer-language__anchor" href="https://printquarters.com/about/team.php" an-as=""> Indonesia / Bahasa Indonesia </a>
          </div>
        </div>
        <div an-ac="scroll:100" an-ca="scroll" an-la="scroll:100" an-tr="nv02_footer bottom--text-scroll" class="footer-language-wrap">
          <div class="footer-language">
            <a class="footer-language__anchor" href="https://printquarters.com/about/team.php" an-as=""> Indonesia / Bahasa Indonesia </a>
          </div>
          <div class="footer-terms">
            <ul class="footer-terms__list" role="list">
              <li class="footer-terms__item" role="listitem">
                <a class="footer-terms__link" href="/kebijakan-privasi" an-as=""> Privasi </a>
              </li>
              <li class="footer-terms__item" role="listitem">
                <a class="footer-terms__link" href="/legal" an-as=""> Legal </a>
              </li>
              <li class="footer-terms__item" role="listitem">
                <a class="footer-terms__link" href="/sitemap" an-as=""> Peta Situs </a>
              </li>
            </ul>
          </div>
          <div class="footer-sns">
            <span class="footer-sns__title"> Ingin Tetap Terhubung? </span>
            <ul class="footer-sns__list" role="list">
              <li class="footer-sns__item" role="listitem">
                <a class="footer-sns__link" href="https://facebook.com/Naga 508Slot SLOT GACOR LUAR NEGERI" rel="noreferrer noopener" target="_blank" aria-label="Facebook : Buka di Tab Baru" an-as="">
                  <svg class="icon" focusable="false">
                    <use href="#facebook-bold" xlink:href="#facebook-bold"></use>
                  </svg>
                </a>
              </li>
              <li class="footer-sns__item" role="listitem">
                <a class="footer-sns__link" href="https://twitter.com/Naga 508Slot SLOT GACOR LUAR NEGERI" rel="noreferrer noopener" target="_blank" aria-label="Twitter : Buka di Tab Baru" an-as="">
                  <svg class="icon" focusable="false">
                    <use href="#twitter-bold" xlink:href="#twitter-bold"></use>
                  </svg>
                </a>
              </li>
              <li class="footer-sns__item" role="listitem">
                <a class="footer-sns__link" href="https://instagram.com/Naga 508Slot SLOT GACOR LUAR NEGERI" rel="noreferrer noopener" target="_blank" aria-label="Instagram : Buka di Tab Baru" an-as="">
                  <svg class="icon" focusable="false">
                    <use href="#instagram-bold" xlink:href="#instagram-bold"></use>
                  </svg>
                </a>
              </li>
              <li class="footer-sns__item" role="listitem">
                <a class="footer-sns__link" href="https://youtube.com/@Naga 508Slot SLOT GACOR LUAR NEGERI" rel="noreferrer noopener" target="_blank" aria-label="Youtube : Buka di Tab Baru" an-as="">
                  <svg class="icon" focusable="false">
                    <use href="#youtube-bold" xlink:href="#youtube-bold"></use>
                  </svg>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <button an-ac="back to top" an-ca="indication" an-la="back to top" an-tr="nv02_footer bottom--text-back to top" class="fab" title="Go to Top" an-as=""> Go to Top <svg class="fab__icon" focusable="false">
      <use href="#up-highest-bold" xlink:href="#up-highest-bold">
      </use>
    </svg>
  </button>
  <!--googleon: all-->
  <script src="https://resources.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-dependencies.min.407b108c60433f00a6b1a0e8f272a2c1.js">
  </script>
  <script src="https://resources.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-base-ux25.min.91PDx4Vtw4YF6XfduRwwS6nKZ6sPAC9nCeR.js">
  </script>
  <script>
    //load tti js library
    (function() {
      var h = "undefined" != typeof window && window === this ? this : "undefined" != typeof global && null != global ? global : this,
        k = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
          a != Array.prototype && a != Object.prototype && (a[b] = c.value)
        };

      function l() {
        l = function() {};
        h.Symbol || (h.Symbol = m)
      }
      var n = 0;

      function m(a) {
        return "jscomp_symbol_" + (a || "") + n++
      }

      function p() {
        l();
        var a = h.Symbol.iterator;
        a || (a = h.Symbol.iterator = h.Symbol("iterator"));
        "function" != typeof Array.prototype[a] && k(Array.prototype, a, {
          configurable: !0,
          writable: !0,
          value: function() {
            return q(this)
          }
        });
        p = function() {}
      }

      function q(a) {
        var b = 0;
        return r(function() {
          return b < a.length ? {
            done: !1,
            value: a[b++]
          } : {
            done: !0
          }
        })
      }

      function r(a) {
        p();
        a = {
          next: a
        };
        a[h.Symbol.iterator] = function() {
          return this
        };
        return a
      }

      function t(a) {
        p();
        var b = a[Symbol.iterator];
        return b ? b.call(a) : q(a)
      }

      function u(a) {
        if (!(a instanceof Array)) {
          a = t(a);
          for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
          a = c
        }
        return a
      }
      var v = 0;

      function w(a, b) {
        var c = XMLHttpRequest.prototype.send,
          d = v++;
        XMLHttpRequest.prototype.send = function(f) {
          for (var e = [], g = 0; g < arguments.length; ++g) e[g - 0] = arguments[g];
          var E = this;
          a(d);
          this.addEventListener("readystatechange", function() {
            4 === E.readyState && b(d)
          }, {
            passive: true
          });
          return c.apply(this, e)
        }
      }

      function x(a, b) {
        var c = fetch;
        fetch = function(d) {
          for (var f = [], e = 0; e < arguments.length; ++e) f[e - 0] = arguments[e];
          return new Promise(function(d, e) {
            var g = v++;
            a(g);
            c.apply(null, [].concat(u(f))).then(function(a) {
              b(g);
              d(a)
            }, function(a) {
              b(a);
              e(a)
            })
          })
        }
      }
      var y = "img script iframe link audio video source".split(" ");

      function z(a, b) {
        a = t(a);
        for (var c = a.next(); !c.done; c = a.next())
          if (c = c.value, b.includes(c.nodeName.toLowerCase()) || z(c.children, b)) return !0;
        return !1
      }

      function A(a) {
        var b = new MutationObserver(function(c) {
          c = t(c);
          for (var b = c.next(); !b.done; b = c.next()) b = b.value, "childList" == b.type && z(b.addedNodes, y) ? a(b) : "attributes" == b.type && y.includes(b.target.tagName.toLowerCase()) && a(b)
        });
        b.observe(document, {
          attributes: !0,
          childList: !0,
          subtree: !0,
          attributeFilter: ["href", "src"]
        });
        return b
      }

      function B(a, b) {
        if (2 < a.length) return performance.now();
        var c = [];
        b = t(b);
        for (var d = b.next(); !d.done; d = b.next()) d = d.value, c.push({
          timestamp: d.start,
          type: "requestStart"
        }), c.push({
          timestamp: d.end,
          type: "requestEnd"
        });
        b = t(a);
        for (d = b.next(); !d.done; d = b.next()) c.push({
          timestamp: d.value,
          type: "requestStart"
        });
        c.sort(function(a, b) {
          return a.timestamp - b.timestamp
        });
        a = a.length;
        for (b = c.length - 1; 0 <= b; b--) switch (d = c[b], d.type) {
          case "requestStart":
            a--;
            break;
          case "requestEnd":
            a++;
            if (2 < a) return d.timestamp;
            break;
          default:
            throw Error("Internal Error: This should never happen");
        }
        return 0
      }

      function C(a) {
        a = a ? a : {};
        this.w = !!a.useMutationObserver;
        this.u = a.minValue || null;
        a = window.__tti && window.__tti.e;
        var b = window.__tti && window.__tti.o;
        this.a = a ? a.map(function(a) {
          return {
            start: a.startTime,
            end: a.startTime + a.duration
          }
        }) : [];
        b && b.disconnect();
        this.b = [];
        this.f = new Map;
        this.j = null;
        this.v = -Infinity;
        this.i = !1;
        this.h = this.c = this.s = null;
        w(this.m.bind(this), this.l.bind(this));
        x(this.m.bind(this), this.l.bind(this));
        D(this);
        this.w && (this.h = A(this.B.bind(this)))
      }
      C.prototype.getFirstConsistentlyInteractive = function() {
        var a = this;
        return new Promise(function(b) {
          a.s = b;
          "complete" == document.readyState ? F(a) : window.addEventListener("load", function() {
            F(a)
          }, {
            passive: true
          })
        })
      };

      function F(a) {
        a.i = !0;
        var b = 0 < a.a.length ? a.a[a.a.length - 1].end : 0,
          c = B(a.g, a.b);
        G(a, Math.max(c + 5E3, b))
      }

      function G(a, b) {
        !a.i || a.v > b || (clearTimeout(a.j), a.j = setTimeout(function() {
          var b = performance.timing.navigationStart,
            d = B(a.g, a.b),
            b = (window.a && window.a.A ? 1E3 * window.a.A().C - b : 0) || performance.timing.domContentLoadedEventEnd - b;
          if (a.u) var f = a.u;
          else performance.timing.domContentLoadedEventEnd ? (f = performance.timing, f = f.domContentLoadedEventEnd - f.navigationStart) : f = null;
          var e = performance.now();
          null === f && G(a, Math.max(d + 5E3, e + 1E3));
          var g = a.a;
          5E3 > e - d ? d = null : (d = g.length ? g[g.length - 1].end : b, d = 5E3 > e - d ? null : Math.max(d, f));
          d && (a.s(d), clearTimeout(a.j), a.i = !1, a.c && a.c.disconnect(), a.h && a.h.disconnect());
          G(a, performance.now() + 1E3)
        }, b - performance.now()), a.v = b)
      }

      function D(a) {
        a.c = new PerformanceObserver(function(b) {
          b = t(b.getEntries());
          for (var c = b.next(); !c.done; c = b.next())
            if (c = c.value, "resource" === c.entryType && (a.b.push({
                start: c.fetchStart,
                end: c.responseEnd
              }), G(a, B(a.g, a.b) + 5E3)), "longtask" === c.entryType) {
              var d = c.startTime + c.duration;
              a.a.push({
                start: c.startTime,
                end: d
              });
              G(a, d + 5E3)
            }
        });
        a.c.observe({
          entryTypes: ["longtask", "resource"]
        })
      }
      C.prototype.m = function(a) {
        this.f.set(a, performance.now())
      };
      C.prototype.l = function(a) {
        this.f.delete(a)
      };
      C.prototype.B = function() {
        G(this, performance.now() + 5E3)
      };
      h.Object.defineProperties(C.prototype, {
        g: {
          configurable: !0,
          enumerable: !0,
          get: function() {
            return [].concat(u(this.f.values()))
          }
        }
      });
      var H = {
        getFirstConsistentlyInteractive: function(a) {
          a = a ? a : {};
          return "PerformanceLongTaskTiming" in window ? (new C(a)).getFirstConsistentlyInteractive() : Promise.resolve(null)
        }
      };
      "undefined" != typeof module && module.exports ? module.exports = H : "function" === typeof define && define.amd ? define("ttiPolyfill", [], function() {
        return H
      }) : window.ttiPolyfill = H;
    })();
    //# sourceMappingURL=tti-polyfill.js.map
    //load tti snippet
    ! function() {
      if ('PerformanceLongTaskTiming' in window) {
        var g = window.__tti = {
          e: []
        };
        g.o = new PerformanceObserver(function(l) {
          g.e = g.e.concat(l.getEntries())
        });
        g.o.observe({
          entryTypes: ['longtask']
        })
      }
    }();
    //push tti value to eddl
    function push_tti_to_eddl(eddlObj) {
      ttiPolyfill.getFirstConsistentlyInteractive().then(function(tti) {
        if (typeof eddlObj !== 'undefined') {
          eddlObj.push({
            'event': '',
            'performance': {
              'TTI': tti
            }
          })
        } else {
          console.log('No eddlObj found. TTI is not tracked')
        }
      });
    }
    push_tti_to_eddl(eddlDataLayer)
  </script><!--BEGIN QUALTRICS WEBSITE FEEDBACK SNIPPET-->
  <script type="text/javascript">
    (function() {
      var g = function(e, h, f, g) {
        this.get = function(a) {
          for (var a = a + "=", c = document.cookie.split(";"), b = 0, e = c.length; b < e; b++) {
            for (var d = c[b];
              " " == d.charAt(0);) d = d.substring(1, d.length);
            if (0 == d.indexOf(a)) return d.substring(a.length, d.length)
          }
          return null
        };
        this.set = function(a, c) {
          var b = "",
            b = new Date;
          b.setTime(b.getTime() + 6048E5);
          b = "; expires=" + b.toGMTString();
          document.cookie = a + "=" + c + b + "; path=/; "
        };
        this.check = function() {
          var a = this.get(f);
          if (a) a = a.split(":");
          else if (100 != e) "v" == h && (e = Math.random() >= e / 100 ? 0 : 100), a = [h, e, 0], this.set(f, a.join(":"));
          else return !0;
          var c = a[1];
          if (100 == c) return !0;
          switch (a[0]) {
            case "v":
              return !1;
            case "r":
              return c = a[2] % Math.floor(100 / c), a[2]++, this.set(f, a.join(":")), !c
          }
          return !0
        };
        this.go = function() {
          if (this.check()) {
            var a = document.createElement("script");
            a.type = "text/javascript";
            a.async = 1;
            a.src = g;
            document.body && document.body.appendChild(a)
          }
        };
        this.start = function() {
          var a = this;
          window.addEventListener ? window.addEventListener("load", function() {
            a.go()
          }, !1) : window.attachEvent && window.attachEvent("onload", function() {
            a.go()
          })
        }
      };
      try {
        (new g(100, "r", "QSI_S_ZN_eWYlZPQdS1JT1sh", "https://znewylzpqds1jt1sh-samsunggdc.siteintercept.qualtrics.com/WRSiteInterceptEngine/?Q_ZID=ZN_eWYlZPQdS1JT1sh")).start()
      } catch (i) {}
    })();
  </script>
  <div id="ZN_eWYlZPQdS1JT1sh"><!--DO NOT REMOVE-CONTENTS PLACED HERE--></div>
  <!--END WEBSITE FEEDBACK SNIPPET--><!-- Decibel - www.samsung.com Indonesia -->
  <link rel="dns-prefetch" href="//cdn.decibelinsight.net">
  <link rel="dns-prefetch" href="//collection.decibelinsight.net">
  <script type="text/javascript">
    window._da_ = window._da_ || [];
    _da_.oldErr = window.onerror;
    _da_.err = [];
    window.onerror = function() {
      _da_.err.push(arguments);
      if (_da_.oldErr) {
        _da_.oldErr.apply(window, Array.prototype.slice.call(arguments));
      }
    };
    window.addEventListener('load', (event) => {
      (function(d, e, c, i, b, el, it) {
        d.DecibelInsight = b;
        d[b] = d[b] || function() {
          (d[b].q = d[b].q || []).push(arguments);
        };
        el = e.createElement(c);
        it = e.getElementsByTagName(c)[0];
        el.async = 1;
        el.src = i;
        it.parentNode.insertBefore(el, it);
      })(window, document, 'script', 'https://cdn.decibelinsight.net/i/14121/1818647/di.js', 'decibelInsight');
    });
    if (typeof window.decibelInsight !== 'undefined') {
      window.decibelInsight('ready', decibelInit);
    } else {
      window._da_readyArray = window._da_readyArray || [];
      window._da_readyArray.push(decibelInit);
    }

    function decibelInit() {
      try {
        document.cookie = "DXA_READY=1; max-age=6000";
      } catch (e) {}
    }
  </script>
  <script>
    // Define dataLayer and the gtag function.
    window.dataLayer = window.dataLayer || [];

    function poc_gtag() {
      dataLayer.push(arguments);
    }
    // Default Setting
    poc_gtag('consent', 'default', {
      'analytics_storage': 'denied',
      'ad_storage': 'denied',
      'ad_user_data': 'denied',
      'ad_personalization': 'denied'
    });
  </script>
  <script>
    let gtagScriptEle = document.createElement("script");
    gtagScriptEle.setAttribute("src", "https://www.googletagmanager.com/gtag/js?id=" + _satellite.getVar("GA4 Measurement ID"));
    gtagScriptEle.setAttribute("async", true);
    document.body.appendChild(gtagScriptEle);
  </script>
  <script src="https://www.googletagmanager.com/gtag/js?id=G-V3RHCPZTVJ" async="true"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function poc_gtag() {
      dataLayer.push(arguments);
    }
    poc_gtag('js', new Date());
    var user_properties = {};
    try {
      var cid = _satellite.getVar('CID');
      var samid = _satellite.getVar('SAMID');
      var gaid = _satellite.getVar('GA Client ID');
      var login_status = _satellite.getVar('Login Status');
      var logged_in_id = _satellite.getVar('Cookie - Logged In ID');
      var depth2 = _satellite.getVar('2Depth');
      var depth3 = _satellite.getVar('3Depth');
      var depth4 = _satellite.getVar('4Depth');
      var depth5 = _satellite.getVar('5Depth');
      var concatenated_page_name = _satellite.getVar('Concatenated Page Name');
      var origin_platform = _satellite.getVar('Origin Platform');
      var page_track = _satellite.getVar('Page Track');
      var page_url = _satellite.getVar('Page URL');
      var platform_version = _satellite.getVar('Platform Version');
      var shop_type = _satellite.getVar('Shop Type');
      var site_code = _satellite.getVar('Site Code');
      var site_section = _satellite.getVar('Site Section');
      var store_id = _satellite.getVar('Store ID');
      var allEventData = {
        page: {
          pageInfo: {}
        }
      };
      try {
        allEventData.page.pageInfo = {
          'content_group': _satellite.getVar('2Depth'),
          'content_group_depth_1': _satellite.getVar('Site Code'),
          'content_group_depth_2': _satellite.getVar('2Depth'),
          'content_group_depth_3': _satellite.getVar('3Depth'),
          'content_group_depth_4': _satellite.getVar('4Depth'),
          'content_group_depth_5': _satellite.getVar('5Depth'),
          'concatenated_page_name': _satellite.getVar('Concatenated Page Name'),
          'origin_platform': _satellite.getVar('Origin Platform'),
          'pageTrack': _satellite.getVar('Page Track'),
          'page_name': _satellite.getVar('Page Name'),
          'page_url': _satellite.getVar('Page URL'),
          'site_version': _satellite.getVar('Platform Version'),
          'shop_type': _satellite.getVar('Shop Type'),
          'site_code': _satellite.getVar('Site Code'),
          'site_section': _satellite.getVar('Site Section'),
          'store_id': _satellite.getVar('Store ID')
        };
      } catch (e) {}
      if (cid) {
        user_properties.AA_tracking_code = cid;
      }
      if (samid) {
        user_properties.user_id = samid;
        user_properties.hashed_samsung_id = samid;
      }
      if (gaid) {
        user_properties.client_id = gaid;
      }
      if (login_status) {
        user_properties.user_login_status = login_status;
      }
      if (logged_in_id) {
        user_properties.logged_in_id = logged_in_id;
      }
    } catch (e) {}
    if (user_properties) {
      poc_gtag("set", "user_properties", user_properties);
    }
    var ssgtmURL = 'https://event-tracking.samsung.com';
    var configData = {
      'transport_url': ssgtmURL,
      'first_party_collection': true,
      'send_page_view': false,
      'launch_env': (_satellite && _satellite.environment && _satellite.environment.stage) ? _satellite.environment.stage : 'production',
      'allEventData': JSON.stringify(allEventData),
      'webview_flag': _satellite.getVar('Webview Flag')
    };
    if (_satellite.getVar("GA4 Debug Flag") === true) {
      configData.debug_mode = true;
    }
    if (_satellite.getVar('GUID') !== undefined && _satellite.getVar('GUID') != "no_consent" && _satellite.getVar('GUID') !== "") {
      configData.user_id = _satellite.getVar('GUID');
    }
    // Start Consent Mode
    try {
      var analytics_storage = true
      var ad_storage = true
      // User Setting Option 1
      if (analytics_storage) {
        poc_gtag('consent', 'update', {
          'analytics_storage': 'granted'
        });
      }
      // User Setting Option 2
      if (ad_storage) {
        poc_gtag('consent', 'update', {
          'ad_storage': 'granted',
          'ad_user_data': 'granted',
          'ad_personalization': 'granted'
        });
      }
    } catch (e) {}
    // GA4 Config
    poc_gtag('config', _satellite.getVar("GA4 Measurement ID"), configData);
  </script>
  <script>
    // Samsung.com s Tracker for EDDL&XDM v0.5.2 (release 1) (last update - 20230920)
    /* 
     * Launch Rule Name : HQ-AA/GA(WebSDK)-CM-ALL(PT)
     */
    var bridg_utils = {
      stringToJson: function(input, value) {
        const keys = input.split('.');
        const result = {};
        let current = result;
        for (let i = 0; i < keys.length - 1; i++) {
          const key = keys[i];
          if (key.endsWith("[]")) {
            const arrayKey = key.slice(0, -2);
            if (!current[arrayKey]) {
              current[arrayKey] = [];
            }
            if (!Array.isArray(current[arrayKey])) {
              throw new Error(`Key ${arrayKey} already exists as a non-array value.`);
            }
            if (i < keys.length - 2) {
              if (current[arrayKey].length === 0 || typeof current[arrayKey][current[arrayKey].length - 1] !== 'object') {
                current[arrayKey].push({});
              }
              current = current[arrayKey][current[arrayKey].length - 1];
            } else {
              const lastObj = current[arrayKey][current[arrayKey].length - 1];
              if (!lastObj || typeof lastObj !== 'object') {
                current[arrayKey].push({});
              }
              current = current[arrayKey][current[arrayKey].length - 1];
              current['item_id'] = value;
            }
          } else {
            current[key] = {};
            current = current[key];
          }
        }
        const lastKey = keys[keys.length - 1];
        current[lastKey] = value;
        return result;
      },
      mergeObjects: function(obj1, obj2) {
        const result = {};
        const keys = Object.keys(obj1).concat(Object.keys(obj2));
        keys.forEach((key) => {
          const val1 = obj1[key];
          const val2 = obj2[key];
          if (val1 && typeof val1 === 'object' && val2 && typeof val2 === 'object') {
            if (Array.isArray(val1) && Array.isArray(val2)) {
              result[key] = Object.values(this.mergeObjects(val1, val2));
            } else {
              result[key] = this.mergeObjects(val1, val2);
            }
          } else {
            result[key] = val2 !== undefined ? val2 : val1;
          }
        });
        return result;
      },
      getCurrentValue: function(dlArray, variable) {
        let currentValue = null;
        for (let i = 0; i < dlArray.length; i++) {
          const dl = dlArray[i];
          if (dl[variable]) {
            currentValue = dl[variable];
          }
        }
        return currentValue;
      },
      getPageLoadTime: function() {
        // return page load time in milisecond from navigation interface
        if (window.performance && window.performance.timing) {
          var t = performance.timing;
          var pageLoadTime = (t.loadEventEnd - t.navigationStart);
          pageLoadTime = Math.round(pageLoadTime);
          return pageLoadTime;
        }
      }
    }
    var eddl_bridge = {
      s_eddl_mapper: _satellite.getVar("s_eddl_mapper"),
      de_eddl_mapper: _satellite.getVar("de_eddl_mapper"),
      cust_eddl_mapper: _satellite.getVar("cust_eddl_mapper"),
      eddl_xdm_mapper: _satellite.getVar("eddl_xdm_mapper"),
      s_to_eddl: function(s) {
        let eddl = {};
        let s_eddl_mapper = this.s_eddl_mapper;
        for (let key in s_eddl_mapper) {
          let eddl_key = s_eddl_mapper[key];
          let eddl_value = s[key];
          if (eddl_value) {
            eddl_key = eddl_key.split(',');
            for (let i = 0; i < eddl_key.length; i++) {
              if (eddl_key[i].indexOf('.') > -1) {
                let eddl_key_json = bridg_utils.stringToJson(eddl_key[i], eddl_value);
                eddl = bridg_utils.mergeObjects(eddl, eddl_key_json);
              } else {
                eddl[eddl_key[i]] = eddl_value;
              }
            }
          }
        }
        // item List
        if (s.products && s.products.toString().indexOf(',') > -1) {
          let item_ids = s.products.toString().split(',');
          let originalItems = {};
          if (!eddl.ecommerce) {
            eddl.ecommerce = {};
          } else {
            if (!eddl.ecommerce.items) {
              eddl.ecommerce.items = [];
            } else {
              originalItems = JSON.parse(JSON.stringify(eddl.ecommerce.items[0])); // size=1 array
            }
          }
          eddl.ecommerce.items = [];
          for (let i = 0; i < item_ids.length; i++) {
            let item_id = item_ids[i].split(';')[1];
            eddl.ecommerce.items.push(JSON.parse(JSON.stringify(originalItems)));
            eddl.ecommerce.items[i].item_id = item_id;
          }
        }
        return eddl;
      },
      de_to_eddl: function(_satelliteObject) {
        let eddl = {};
        let de_eddl_mapper = this.de_eddl_mapper;
        for (let key in de_eddl_mapper) {
          let eddl_key = de_eddl_mapper[key];
          let eddl_value = _satelliteObject.getVar(key);
          if (eddl_value) {
            eddl_key = eddl_key.split(',');
            for (let i = 0; i < eddl_key.length; i++) {
              if (eddl_key[i].indexOf('.') > -1) {
                let eddl_key_json = bridg_utils.stringToJson(eddl_key[i], eddl_value);
                eddl = bridg_utils.mergeObjects(eddl, eddl_key_json);
              } else {
                eddl[eddl_key[i]] = eddl_value;
              }
            }
          }
        }
        return eddl;
      },
      cust_to_eddl: function(cust) {
        let eddl = {};
        let cust_eddl_mapper = this.cust_eddl_mapper;
        for (let key in cust_eddl_mapper) {
          let eddl_key = cust_eddl_mapper[key];
          let eddl_value = cust[key];
          if (eddl_value) {
            eddl_key = eddl_key.split(',');
            for (let i = 0; i < eddl_key.length; i++) {
              if (eddl_key[i].indexOf('.') > -1) {
                let eddl_key_json = bridg_utils.stringToJson(eddl_key[i], eddl_value);
                eddl = bridg_utils.mergeObjects(eddl, eddl_key_json);
              } else {
                eddl[eddl_key[i]] = eddl_value;
              }
            }
          }
        }
        return eddl;
      },
      to_eddl: function(_satelliteObject) {
        let eddl = {};
        // check s object exists and push to EDDL
        if (typeof s !== 'undefined') {
          eddl = bridg_utils.mergeObjects(eddl, this.s_to_eddl(s));
        }
        // check data elements exists and push to EDDL
        if (typeof _satelliteObject !== 'undefined') {
          eddl = bridg_utils.mergeObjects(eddl, this.de_to_eddl(_satelliteObject));
        }
        // check custom values exists and push to EDDL
        if (typeof _satelliteObject.customValues !== 'undefined') {
          eddl = bridg_utils.mergeObjects(eddl, this.cust_to_eddl(_satelliteObject.customValues));
        }
        // add cookie consent info to EDDL
        eddl = bridg_utils.mergeObjects(eddl, {
          gtag_consent: {
            ad_storage: /4/.test(_satellite.cookie.get('cmapi_cookie_privacy')),
            analytics_storage: /3/.test(_satellite.cookie.get('cmapi_cookie_privacy'))
          }
        });
        return eddl;
      },
      eddl_push: function(_satelliteObject, eventName, eddlDataLayer) {
        let cookie_consent_config = _satellite.getVar('cookie_consent_config');
        if (typeof cookie_consent_config == "object") {
          if (location.pathname.startsWith("/fr")) {
            if ((_satellite.cookie.get("cmapi_cookie_privacy") || "").indexOf("2") > -1 || (_satellite.cookie.get("cmapi_cookie_privacy") || "").indexOf("4") > -1) {
              let eddl = this.to_eddl(_satelliteObject);
              eddlDataLayer.push(Object.assign({
                event: eventName
              }, eddl));
            }
          } else {
            if (cookie_consent_config.google_consent_option == "advanced" || (_satellite.cookie.get("cmapi_cookie_privacy") || "").indexOf("3") > -1 || cookie_consent_config.consent_required == false) {
              let eddl = this.to_eddl(_satelliteObject);
              eddlDataLayer.push(Object.assign({
                event: eventName
              }, eddl));
            }
          }
        }
        _satellite.logger.log("EDDL Push --> \n" + JSON.stringify(eddlDataLayer[eddlDataLayer.length - 1])); // for debugging
      }
    };
    var eddlDataLayer = window.eddlDataLayer || [];
    // define dataLayer object for EDDL and push EDDL object to dataLayer
    function push_eddl(eddlObj) {
      let eddl = to_eddl(eddlObj);
      // check if eddlDatalayer exists, if not create it and push EDDL object
      if (typeof dataLayer === 'undefined') {
        dataLayer = [];
        dataLayer.push(eddl);
      } else {
        dataLayer.push(eddl);
      }
    }
    // convert multiple json objects to single one
    function eddl_mergeObjects() {
      let obj = {};
      for (let i = 0; i < arguments.length; i++) {
        for (let key in arguments[i]) {
          obj[key] = arguments[i][key];
        }
      }
      return obj;
    }
    // convert EDDL object into XDM request
    function eddl_to_xdm(eddl) {
      let xdm = {};
      for (let key in eddl_xdm_mapper) {
        let xdm_key = eddl_xdm_mapper[key];
        let xdm_value = eddl[key];
        if (xdm_value) {
          xdm_key = xdm_key.split(',');
          for (let i = 0; i < xdm_key.length; i++) {
            if (xdm_key[i].indexOf('.') > -1) {
              let xdm_key_json = bridg_utils.stringToJson(xdm_key[i], xdm_value);
              xdm = bridg_utils.mergeObjects(xdm, xdm_key_json);
            } else {
              xdm[xdm_key[i]] = xdm_value;
            }
          }
        }
      }
      return xdm;
    }

    function s_init() {
      var s = {
        cookieLifetime: 0,
        writeSecureCookies: false,
        d: document,
        escape: function(e) {
          var a, n;
          if (!e) return e;
          for (e = encodeURIComponent(e), a = 0; 7 > a; a++) n = "+~!*()'".substring(a, a + 1), 0 <= e.indexOf(n) && (e = t.replace(e, n, "%" + n.charCodeAt(0).toString(16).toUpperCase()));
          return e
        },
        unescape: function(e) {
          return unescape(e)
        },
        c_r: function(e) {
          e = t.escape(e);
          var a = " " + t.d.cookie,
            n = a.indexOf(" " + e + "="),
            i = 0 > n ? n : a.indexOf(";", n);
          return "[[B]]" != (e = 0 > n ? "" : t.unescape(a.substring(n + 2 + e.length, 0 > i ? a.length : i))) ? e : ""
        },
        cookieRead: function(e) {
          return this.c_r(e)
        },
        c_w: function(e, a, n) {
          var i, r = t.Mb(),
            o = t.cookieLifetime;
          return a = "" + a, o = o ? ("" + o).toUpperCase() : "", n && "SESSION" != o && "NONE" != o && ((i = "" != a ? parseInt(o || 0) : -60) ? (n = new Date).setTime(n.getTime() + 1e3 * i) : 1 === n && (i = (n = new Date).getYear(), n.setYear(i + 2 + (1900 > i ? 1900 : 0)))), e && "NONE" != o ? (t.d.cookie = t.escape(e) + "=" + t.escape("" != a ? a : "[[B]]") + "; path=/;" + (n && "SESSION" != o ? " expires=" + n.toUTCString() + ";" : "") + (r ? " domain=" + r + ";" : "") + (t.writeSecureCookies ? " secure;" : ""), t.cookieRead(e) == a) : 0
        },
        Mb: function() {
          return ""
        },
        handlePPVevents: function() {
          return
        },
        p_fo: function(on) {
          return true
        },
        getPercentPageViewed: function(pid, ch) {
          var s = this,
            a = s.c_r("s_ppv");
          a = -1 < a.indexOf(",") ? a.split(",") : [];
          a[0] = s.unescape(a[0]);
          pid = pid ? pid : s.pageName ? s.pageName : document.location.href;
          s.ppvChange = "undefined" === typeof ch || !0 == ch ? !0 : !1;
          if ("undefined" === typeof s.linkType || "o" !== s.linkType) s.ppvID && s.ppvID === pid || (s.ppvID = pid, s.c_w("s_ppv", ""), s.handlePPVevents()), s.p_fo("s_gppvLoad") && window.addEventListener && (window.addEventListener("load", s.handlePPVevents, !1), window.addEventListener("click", s.handlePPVevents, !1), window.addEventListener("scroll", s.handlePPVevents, !1)), s._ppvPreviousPage = a[0] ? a[0] : "", s._ppvHighestPercentViewed = a[1] ? a[1] : "", s._ppvInitialPercentViewed = a[2] ? a[2] : "", s._ppvHighestPixelsSeen = a[3] ? a[3] : "", s._ppvFoldsSeen = a[4] ? a[4] : "", s._ppvFoldsAvailable = a[5] ? a[5] : ""
        },
        p_fo: function(on) {
          var s = this;
          s.__fo || (s.__fo = {});
          if (s.__fo[on]) return !1;
          s.__fo[on] = {};
          return !0
        },
        Util: {
          getQueryParam: function(variable) {
            var query = window.location.search.substring(1);
            var vars = query.split("&");
            for (var i = 0; i < vars.length; i++) {
              var pair = vars[i].split("=");
              if (pair[0] == variable) {
                return pair[1];
              }
            }
            return (false);
          }
        },
        replace: function(e, t, n) {
          return !e || 0 > e.indexOf(t) ? e : e.split(t).join(n)
        },
        linkTrackVars: "",
        linkTrackEvents: ""
      };
      var t = s;
      return s;
    }
    var s = s_init();
    //2023.06.12 for API call
    if (_satellite.environment.stage.includes('prod')) {
      s.account = _satellite.getVar('s_account'); //'sssamsung4uk,sssamsung4mstglobal'
    } else {
      s.account = 'sssamsung4mstglobaldev'
    }
    //2023.06.26 for default currency Code
    s.currencyCode = _satellite.getVar('Currency Code') || '';
    // define s.handlePPVevents plugin
    s.handlePPVevents = function() {
      if ("undefined" !== typeof s_c_il) {
        for (var c = 0, g = s_c_il.length; c < g; c++)
          if (s_c_il[c] && (s_c_il[c].getPercentPageViewed || s_c_il[c].getPreviousPageActivity)) {
            var s = s_c_il[c];
            break
          } if (s && s.ppvID) {
          var f = Math.max(Math.max(document.body.scrollHeight, document.documentElement.scrollHeight), Math.max(document.body.offsetHeight, document.documentElement.offsetHeight), Math.max(document.body.clientHeight, document.documentElement.clientHeight)),
            h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
          c = (window.pageYOffset || window.document.documentElement.scrollTop || window.document.body.scrollTop) + h;
          g = Math.min(Math.round(c / f * 100), 100);
          var k = Math.floor(c / h);
          h = Math.floor(f / h);
          var d = "";
          if (!s.c_r("s_tp") || s.unescape(s.c_r("s_ppv").split(",")[0]) !== s.ppvID || s.p_fo(s.ppvID) || 1 == s.ppvChange && s.c_r("s_tp") && f != s.c_r("s_tp")) {
            (s.unescape(s.c_r("s_ppv").split(",")[0]) !== s.ppvID || s.p_fo(s.ppvID + "1")) && s.c_w("s_ips", c);
            if (s.c_r("s_tp") && s.unescape(s.c_r("s_ppv").split(",")[0]) === s.ppvID) {
              s.c_r("s_tp");
              d = s.c_r("s_ppv");
              var e = -1 < d.indexOf(",") ? d.split(",") : [];
              d = e[0] ? e[0] : "";
              e = e[3] ? e[3] : "";
              var l = s.c_r("s_ips");
              d = d + "," + Math.round(e / f * 100) + "," + Math.round(l / f * 100) + "," + e + "," + k
            }
            s.c_w("s_tp", f)
          } else d = s.c_r("s_ppv");
          var b = d && -1 < d.indexOf(",") ? d.split(",", 6) : [];
          f = 0 < b.length ? b[0] : escape(s.ppvID);
          e = 1 < b.length ? parseInt(b[1]) : g;
          l = 2 < b.length ? parseInt(b[2]) : g;
          var m = 3 < b.length ? parseInt(b[3]) : c,
            n = 4 < b.length ? parseInt(b[4]) : k;
          b = 5 < b.length ? parseInt(b[5]) : h;
          0 < g && (d = f + "," + (g > e ? g : e) + "," + l + "," + (c > m ? c : m) + "," + (k > n ? k : n) + "," + (h > b ? h : b));
          s.c_w("s_ppv", d)
        }
      }
    };
    s.clearVars = function() {
      s.events = "";
      s.products = "";
      // clear all props from prop1 - prop75
      for (var i = 1; i <= 75; i++) {
        s["prop" + i] = "";
      }
      // clear all eVars from eVar1 - eVar250
      for (var i = 1; i <= 250; i++) {
        s["eVar" + i] = "";
      }
    }
    // define st / s.tl function
    s.tl = function(o, t, n, e = "s_event") { // param1: link object, param2: link type, param3: link name, param4: link event
      var s_obj = this;
      var xdm = {};
      var productArray = [];
      var eventNameMapper = _satellite.getVar("s_event_name_mapper");
      // Hit level plug-in functions
      s_obj.prop41 = s_obj.getPreviousValue(s_obj.pageName, 's_pv'); //prop24: prev page name 
      s_obj.prop73 = s_obj.getPercentPageViewed(); //prop25: max % viewed of prev page 
      if (!s_obj.prop73 == 'no value') s_obj.prop73 = ''; //clear max % viewed if no prev page view
      if (typeof s_obj.prop73 == 'number') {
        s_obj.prop73 = s_obj.prop73.toString()
      }
      // collect clicked href
      var href = o && o.getAttribute && o.getAttribute("href");
      if (href && href !== "#" && href.indexOf("javascript") !== 0) {
        s_obj.eVar178 = href;
      } else {
        s_obj.eVar178 = "null";
      }
      s_obj.linkTrackVars += ",eVar178";
      // parse products variable
      if (s_obj.products) {
        let products = [];
        if (Array.isArray(s_obj.products)) {
          products = s_obj.products[0].split(",");
        } else {
          products = s_obj.products.split(",");
        }
        products.forEach(function(product) {
          let productFields = product.split(";");
          let incrementor = productFields[4] ? productFields[4] : "";
          let merchandizingVars = productFields[5] ? productFields[5] : "";
          let _experience_incrementor = {
            analytics: {}
          };
          let _experience_merchandise = {
            analytics: {
              customDimensions: {
                eVars: {}
              }
            }
          };
          if (incrementor) {
            incrementor = incrementor.split("|");
            // loop through incrementor array
            for (let i = 0; i < incrementor.length; i++) {
              let incrementorFields = incrementor[i].split("=");
              let event = incrementorFields[0];
              let value = incrementorFields[1];
              // AEP event String error fix
              let numValue = null;
              if (value !== undefined && value !== null && value !== '') {
                let parsed = parseFloat(value);
                if (!isNaN(parsed)) {
                  numValue = parsed; // string을 number로 
                }
              }
              if (parseInt(event.replace(/event/, "")) <= 100) {
                _experience_incrementor.analytics.event1to100 = _experience_incrementor.analytics.event1to100 ? _experience_incrementor.analytics.event1to100 : {};
                _experience_incrementor.analytics.event1to100[event] = {
                  value: numValue
                };
              } else if (parseInt(event.replace(/event/, "")) <= 200) {
                _experience_incrementor.analytics.event101to200 = _experience_incrementor.analytics.event101to200 ? _experience_incrementor.analytics.event101to200 : {};
                _experience_incrementor.analytics.event101to200[event] = {
                  value: numValue
                };
              } else if (parseInt(event.replace(/event/, "")) <= 300) {
                _experience_incrementor.analytics.event201to300 = _experience_incrementor.analytics.event201to300 ? _experience_incrementor.analytics.event201to300 : {};
                _experience_incrementor.analytics.event201to300[event] = {
                  value: numValue
                };
              }
            }
          }
          if (merchandizingVars) {
            merchandizingVars = merchandizingVars.split("|");
            // loop through merchandizingVars array
            for (let i = 0; i < merchandizingVars.length; i++) {
              let merchandizingVarsFields = merchandizingVars[i].split("=");
              let eVar = merchandizingVarsFields[0];
              let value = merchandizingVarsFields[1];
              _experience_merchandise.analytics.customDimensions.eVars[eVar] = value;
            }
          }
          var productArrayUnit = {
            "lineItemId": productFields[0] ? productFields[0] : "",
            "SKU": productFields[1] ? productFields[1] : "",
            "quantity": productFields[2] ? Number(productFields[2]) || 0 : 0,
            "priceTotal": productFields[3] ? Number(productFields[3]) || 0 : 0,
            "_experience": bridg_utils.mergeObjects(_experience_incrementor, _experience_merchandise)
          }
          productArray.push(productArrayUnit);
        });
      }
      var linkTrackVars = s_obj.linkTrackVars ? s_obj.linkTrackVars.split(",") : [];
      for (var i = 0; i < linkTrackVars.length; i++) {
        if (linkTrackVars[i] == "products") {
          xdmPut(xdm, "productListItems", productArray);
        } else {
          if (typeof(s_obj[linkTrackVars[i]]) == 'string') {
            xdmPut(xdm, xdmMapper(linkTrackVars[i]), s_obj[linkTrackVars[i]]);
          } else if (s_obj[linkTrackVars[i]] != undefined) {
            xdmPut(xdm, xdmMapper(linkTrackVars[i]), String(s_obj[linkTrackVars[i]]));
          }
        }
        if (s_obj.purchaseID && linkTrackVars[i] == "purchaseID") {
          xdmPut(xdm, "commerce.order.purchaseID", s_obj.purchaseID);
          xdmPut(xdm, "commerce.order.transactionID", s_obj.purchaseID);
        }
      }
      if (s_obj.events) { // custom Events
        var events = s_obj.events.split(",");
        for (var i = 0; i < events.length; i++) {
          if (s_obj.products) {
            if (s_obj.products.indexOf(events[i]) > -1) continue;
          }
          if (s_obj.linkTrackEvents.indexOf(events[i]) > -1) {
            if (events[i].indexOf("=") > -1) { // numeric / currency metrics
              var eventFields = events[i].split("=");
              xdmPut(xdm, xdmMapper(eventFields[0]), Number(eventFields[1] || 0));
            } else {
              xdmPut(xdm, xdmMapper(events[i]), 1); // counter metrics
            }
          }
        }
      }
      // append performance metrics
      if (!_satellite.pageSpeedRecord && _satellite.getVar("Performance_TTI")) {
        var TTIvar = _satellite.getVar("Performance_TTI") >= 1 ? _satellite.getVar("Performance_TTI") : 0;
        var PLTvar = bridg_utils.getPageLoadTime() >= 1 ? bridg_utils.getPageLoadTime() : 0;
        if (TTIvar >= 1 && PLTvar >= 1) {
          xdmPut(xdm, "_experience.analytics.event101to200.event125.value", TTIvar); // TTI
          xdmPut(xdm, "_experience.analytics.event101to200.event126.value", PLTvar); // PLT (Page Load Time)
          _satellite.pageSpeedRecord = true;
        }
      }
      xdmPut(xdm, "web.webInteraction.type", "other"); // custom link 
      xdmPut(xdm, "web.webInteraction.name", n);
      xdmPut(xdm, "web.webInteraction.rule", _satellite.customValues?.rule_name || "");
      //xdm xdmPut(xdm,"web.webPaMKtails.name",s_obj.pageName); 2023.09.14 add pageName into XDM in s.tl()
      xdmPut(xdm, "web.webPaMKtails.name", s_obj.pageName);
      // set samID for AEP input (eVar67 -> _samsungeu.Identity.samID ; filter 66 chars only)
      if (s_obj.eVar67) {
        if (s_obj.eVar67.length == 66) {
          xdmPut(xdm, "_samsungseao.identity.email_id_sha256_salted_hash", s_obj.eVar67);
        }
      }
      //2023.06.27 Currency Code add into XDM
      xdmPut(xdm, "commerce.order.currencyCode", s_obj.currencyCode);
      xdm.identityMap = _satellite.getVar("AEP:xdm:identityMap"); // Add IdentityMap
      _satellite.xdm = xdm;
      if (o === true) {
        // Send XDM to Edge Network
        alloy("sendEvent", {
          documentUnloading: true,
          xdm: xdm
        }).then(function(result) {
          _satellite.logger.log("Successfully sending XDM to Edge Network");
        }).catch(function(error) {
          _satellite.logger.error("Failed to send XDM to Edge Network");
          _satellite.logger.error("XDM Send Event Error --> " + error);
        });
        if (typeof alloyaep != "undefined") {
          alloyaep("sendEvent", {
            documentUnloading: true,
            xdm: xdm
          }).then(function(result) {
            _satellite.logger.log("Successfully sending XDM to Edge (AEP) Network");
          }).catch(function(error) {
            _satellite.logger.error("Failed to send XDM to Edge (AEP) Network");
            _satellite.logger.error("XDM Send Event Error (AEP) --> " + error);
          });
        }
      }
      // EDDL generation
      if (e == "s_event") {
        e = s_obj.events ? s_obj.events.split(",")[0] : typeof _satellite.customValues.rule_name == "string" ? _satellite.customValues.rule_name : "";
        // if e contains '=' split and take the first part
        if (e.indexOf("=") > -1) e = e.split("=")[0];
        // find matching event name from eventNameMapper
        for (var key in eventNameMapper) {
          if (key == e) e = eventNameMapper[key];
        }
      }
      // get Custom values from link object
      if (typeof o.getAttribute != "undefined") {
        let defaultCustAttrs = {
          'an-tr': o.getAttribute('an-tr') ? o.getAttribute('an-tr') : o.getAttribute('data-an-tr'),
          'an-ca': o.getAttribute('an-ca') ? o.getAttribute('an-ca') : o.getAttribute('data-an-ca'),
          'an-ac': o.getAttribute('an-ac') ? o.getAttribute('an-ac') : o.getAttribute('data-an-ac'),
          'an-la': o.getAttribute('an-la') ? o.getAttribute('an-la') : o.getAttribute('data-an-la'),
          'aria-label': o.getAttribute('aria-label')
        }
        _satellite.customValues = bridg_utils.mergeObjects(_satellite.customValues, defaultCustAttrs);
      }
      // "eVar11": url + ">" + an-ca + ">" + an-ac + ">" + an-la
      const url = new URL(window.location.href);
      xdmPut(xdm, "_experience.analytics.customDimensions.eVars.eVar96", url + ">" + _satellite.customValues['an-ca'] + ">" + _satellite.customValues['an_ac'] + ">" + _satellite.customValues['an_la']);
      xdmPut(xdm, "_experience.analytics.event1to100.event96.value", 1);
      // 2026.01.16 save previous clicked action in local storage
      localStorage.setItem("previousClickAction", JSON.stringify({
        action: _satellite.customValues['an_la'],
        time: Date.now()
      }));
      eddl_bridge.eddl_push(_satellite, e, eddlDataLayer); // param1 = _satellite, param2 = event name, param3 = eddlDataLayer
      // for Debugging purposes
      _satellite.xdm = xdm;
    }
    s.t = function() {
      var s_obj = this;
      var xdm = {};
      var productArray = [];
      // 2026.01.19 collect previous clicked action in eVar191
      var bridgeData = JSON.parse(localStorage.getItem("previousClickAction") || "{}");
      if (bridgeData.action && (Date.now() - bridgeData.time < 30000)) {
        s_obj.eVar191 = bridgeData.action;
      }
      // remove storage after collection
      localStorage.removeItem("previousClickAction");
      // 2023.7.2 decode Campaign Tracking Code
      const queryString = window.location.search;
      const urlParams = new URLSearchParams(queryString);
      //content.xdm.marketing.trackingCode = decodeURIComponent(urlParams.get('cid'));
      if (urlParams.get('cid')) {
        s_obj.campaign = decodeURIComponent(urlParams.get('cid'));
      }
      // page level plug-in functions
      if (s_obj.pageName) s_obj.getPercentPageViewed();
      if (s_obj._ppvPreviousPage) {
        s_obj.prop41 = _satellite.getVar('Page Name');
        s_obj.prop73 = s_obj._ppvHighestPercentViewed;
      }
      // Hit level plug-in functions
      s_obj.prop41 = s_obj.getPreviousValue(s_obj.pageName, 's_pv'); //prop24: prev page name 
      s_obj.prop73 = s_obj.getPercentPageViewed(); //prop25: max % viewed of prev page 
      if (!s_obj.prop73 == 'no value') s_obj.prop73 = ''; //clear max % viewed if no prev page view
      if (typeof s_obj.prop73 == 'number') {
        s_obj.prop73 = s_obj.prop73.toString()
      }
      s_obj.eVar94 = s_obj.prop64 = _satellite.getVar("consent_value");
      // parse products variable
      if (s_obj.products) {
        let products = [];
        if (Array.isArray(s_obj.products)) {
          products = s_obj.products;
        } else {
          products = s_obj.products.split(",");
        }
        products.forEach(function(product) {
          let productFields = product.split(";");
          let incrementor = productFields[4] ? productFields[4] : "";
          let merchandizingVars = productFields[5] ? productFields[5] : "";
          let _experience_incrementor = {
            analytics: {}
          };
          let _experience_merchandise = {
            analytics: {
              customDimensions: {
                eVars: {}
              }
            }
          };
          if (incrementor) {
            incrementor = incrementor.split("|");
            // loop through incrementor array
            for (let i = 0; i < incrementor.length; i++) {
              let incrementorFields = incrementor[i].split("=");
              let event = incrementorFields[0];
              let value = incrementorFields[1];
              // AEP event String error fix
              let numValue = null;
              if (value !== undefined && value !== null && value !== '') {
                let parsed = parseFloat(value);
                if (!isNaN(parsed)) {
                  numValue = parsed; // string을 number로 
                }
              }
              if (parseInt(event.replace(/event/, "")) <= 100) {
                _experience_incrementor.analytics.event1to100 = _experience_incrementor.analytics.event1to100 ? _experience_incrementor.analytics.event1to100 : {};
                _experience_incrementor.analytics.event1to100[event] = {
                  value: numValue
                };
              } else if (parseInt(event.replace(/event/, "")) <= 200) {
                _experience_incrementor.analytics.event101to200 = _experience_incrementor.analytics.event101to200 ? _experience_incrementor.analytics.event101to200 : {};
                _experience_incrementor.analytics.event101to200[event] = {
                  value: numValue
                };
              } else if (parseInt(event.replace(/event/, "")) <= 300) {
                _experience_incrementor.analytics.event201to300 = _experience_incrementor.analytics.event201to300 ? _experience_incrementor.analytics.event201to300 : {};
                _experience_incrementor.analytics.event201to300[event] = {
                  value: numValue
                };
              }
            }
          }
          if (merchandizingVars) {
            merchandizingVars = merchandizingVars.split("|");
            // loop through merchandizingVars array
            for (let i = 0; i < merchandizingVars.length; i++) {
              let merchandizingVarsFields = merchandizingVars[i].split("=");
              let eVar = merchandizingVarsFields[0];
              let value = merchandizingVarsFields[1];
              _experience_merchandise.analytics.customDimensions.eVars[eVar] = value;
            }
          }
          var productArrayUnit = {
            "lineItemId": productFields[0] ? productFields[0] : "",
            "SKU": productFields[1] ? productFields[1] : "",
            "quantity": productFields[2] ? Number(productFields[2]) || 0 : 0,
            "priceTotal": productFields[3] ? Number(productFields[3]) || 0 : 0,
            "_experience": bridg_utils.mergeObjects(_experience_incrementor, _experience_merchandise)
          }
          productArray.push(productArrayUnit);
        });
      }
      xdmPut(xdm, "web.webInteraction.rule", _satellite.customValues?.rule_name || "");
      xdmPut(xdm, "web.webPaMKtails.name", s_obj.pageName);
      xdmPut(xdm, "web.webPaMKtails.siteSection", s_obj.channel);
      xdmPut(xdm, "commerce.order.currencyCode", s_obj.currencyCode);
      if (s_obj.campaign && s_obj.campaign.length > 0) xdmPut(xdm, "marketing.trackingCode", s_obj.campaign);
      if (s_obj.purchaseID) {
        xdmPut(xdm, "commerce.order.purchaseID", s_obj.purchaseID);
        xdmPut(xdm, "commerce.order.transactionID", s_obj.purchaseID);
      }
      for (var i = 1; i <= 75; i++) { // prop Vars
        if (s_obj["prop" + i] != undefined && typeof(s_obj["prop" + i]) == 'string') {
          xdmPut(xdm, "_experience.analytics.customDimensions.props.prop" + i, s_obj["prop" + i]);
        } else if (s_obj["prop" + i] != undefined) {
          xdmPut(xdm, "_experience.analytics.customDimensions.props.prop" + i, String(s_obj["prop" + i]));
        }
      }
      for (var i = 1; i < 200; i++) { // eVar Vars
        if (s_obj["eVar" + i] != undefined && typeof(s_obj["eVar" + i]) == 'string') {
          xdmPut(xdm, "_experience.analytics.customDimensions.eVars.eVar" + i, s_obj["eVar" + i]);
        } else if (s_obj["eVar" + i] != undefined) {
          xdmPut(xdm, "_experience.analytics.customDimensions.eVars.eVar" + i, String(s_obj["eVar" + i]));
        }
      }
      if (productArray.length > 0) xdmPut(xdm, "productListItems", productArray);
      if (s_obj.events) { // custom Events
        var events = s_obj.events.split(",");
        for (var i = 0; i < events.length; i++) {
          if (s_obj.products) {
            if (s_obj.products.indexOf(events[i]) > -1) continue;
          }
          if (events[i].indexOf("=") > -1) { // numeric / currency metrics
            var eventFields = events[i].split("=");
            xdmPut(xdm, xdmMapper(eventFields[0]), Number(eventFields[1] || 0));
          } else {
            xdmPut(xdm, xdmMapper(events[i]), 1); // counter metrics
          }
        }
      }
      // set samID for AEP input (eVar67 -> _samsungeu.Identity.samID ; filter 66 chars only)
      if (s_obj.eVar67) {
        if (s_obj.eVar67.length == 66) {
          xdmPut(xdm, "_samsungseao.identity.email_id_sha256_salted_hash", s_obj.eVar67);
        }
      }
      //2023.06.27 Currency Code add into XDM
      xdmPut(xdm, "commerce.order.currencyCode", s_obj.currencyCode);
      //Error Page Tracking
      if (s_obj.pageType == "errorPage") {
        xdmPut(xdm, "web.webPaMKtails.errorPage", "errorPage");
      }
      xdm.identityMap = _satellite.getVar("AEP:xdm:identityMap"); // Add IdentityMap
      // Send XDM to Edge Network
      alloy("sendEvent", {
        xdm: xdm,
        type: "web.webpaMKtails.pageViews",
        documentUnloading: false,
        personalization: {
          includeRenderedPropositions: true
        }
      }).then(function(result) {
        _satellite.logger.log("Successfully sending XDM to Edge Network");
      }).catch(function(error) {
        _satellite.logger.error("Failed to send XDM to Edge Network");
        _satellite.logger.error("XDM Send Event Error --> " + error);
      });
      if (typeof alloyaep != "undefined") {
        alloyaep("sendEvent", {
          xdm: xdm
        }).then(function(result) {
          _satellite.logger.log("Successfully sending XDM to Edge (AEP) Network");
        }).catch(function(error) {
          _satellite.logger.error("Failed to send XDM to Edge (AEP) Network");
          _satellite.logger.error("XDM Send Event Error (AEP) --> " + error);
        });
      }
      // EDDL generation
      eddl_bridge.eddl_push(_satellite, "page_view", eddlDataLayer); // param1 = _satellite, param2 = event name, param3 = eddlDataLayer
    } // end of s.t()
    // define s.getPrevious
    s.getPreviousValue = new Function("v", "c", "el", "" + "var s=this,t=new Date,i,j,r='';t.setTime(t.getTime()+1800000);if(el" + "){if(s.events){i=s.split(el,',');j=s.split(s.events,',');for(x in i" + "){for(y in j){if(i[x]==j[y]){if(s.c_r(c)) r=s.c_r(c);v?s.c_w(c,v,t)" + ":s.c_w(c,'no value',t);return r}}}}}else{if(s.c_r(c)) r=s.c_r(c);v?" + "s.c_w(c,v,t):s.c_w(c,'no value',t);return r}"); /* * Utility Function: split v1.5 - split a string (JS 1.0 compatible) */
    s.split = new Function("l", "d", "" + "var i,x=0,a=new Array;while(l){i=l.indexOf(d);i=i>-1?i:l.length;a[x" + "++]=l.substring(0,i);l=l.substring(i+d.length);}return a");
    s.getPercentPageViewed = new Function("n", "" + "var s=this,W=window,EL=W.addEventListener,AE=W.attachEvent,E=['load" + "','unload','scroll','resize','zoom','keyup','mouseup','touchend','o" + "rientationchange','pan'];W.s_Obj=s;s_PPVid=(n=='-'?s.pageName:n)||s" + ".pageName||location.href;if(!W.s_PPVevent){s.s_PPVg=function(n,r){v" + "ar k='s_ppv',p=k+'l',c=s.c_r(n||r?k:p),a=c.indexOf(',')>-1?c.split(" + "',',10):[''],l=a.length,i;a[0]=unescape(a[0]);r=r||(n&&n!=a[0])||0;" + "a.length=10;if(typeof a[0]!='string')a[0]='';for(i=1;i<10;i++)a[i]=" + "!r&&i<l?parseInt(a[i])||0:0;if(l<10||typeof a[9]!='string')a[9]='';" + "if(r){s.c_w(p,c);s.c_w(k,'?')}return a};W.s_PPVevent=function(e){va" + "r W=window,D=document,B=D.body,E=D.documentElement,S=window.screen|" + "|0,Ho='offsetHeight',Hs='scrollHeight',Ts='scrollTop',Wc='clientWid" + "th',Hc='clientHeight',C=100,M=Math,J='object',N='number',s=W.s_Obj|" + "|W.s||0;e=e&&typeof e==J?e.type||'':'';if(!e.indexOf('on'))e=e.subs" + "tring(2);s_PPVi=W.s_PPVi||0;if(W.s_PPVt&&!e){clearTimeout(s_PPVt);s" + "_PPVt=0;if(s_PPVi<2)s_PPVi++}if(typeof s==J){var h=M.max(B[Hs]||E[H" + "s],B[Ho]||E[Ho],B[Hc]||E[Hc]),X=W.innerWidth||E[Wc]||B[Wc]||0,Y=W.i" + "nnerHeight||E[Hc]||B[Hc]||0,x=S?S.width:0,y=S?S.height:0,r=M.round(" + "C*(W.devicePixelRatio||1))/C,b=(D.pageYOffset||E[Ts]||B[Ts]||0)+Y,p" + "=h>0&&b>0?M.round(C*b/h):0,O=W.orientation,o=!isNaN(O)?M.abs(o)%180" + ":Y>X?0:90,L=e=='load'||s_PPVi<1,a=s.s_PPVg(s_PPVid,L),V=function(i," + "v,f,n){i=parseInt(typeof a==J&&a.length>i?a[i]:'0')||0;v=typeof v!=" + "N?i:v;v=f||v>i?v:i;return n?v:v>C?C:v<0?0:v};if(new RegExp('(iPod|i" + "Pad|iPhone)').exec(navigator.userAgent||'')&&o){o=x;x=y;y=o}o=o?'P'" + ":'L';a[9]=L?'':a[9].substring(0,1);s.c_w('s_ppv',escape(W.s_PPVid)+" + "','+V(1,p,L)+','+(L||!V(2)?p:V(2))+','+V(3,b,L,1)+','+X+','+Y+','+x" + "+','+y+','+r+','+a[9]+(a[9]==o?'':o))}if(!W.s_PPVt&&e!='unload')W.s" + "_PPVt=setTimeout(W.s_PPVevent,333)};for(var f=W.s_PPVevent,i=0;i<E." + "length;i++)if(EL)EL(E[i],f,false);else if(AE)AE('on'+E[i],f);f()};v" + "ar a=s.s_PPVg();return!n||n=='-'?a[1]:a");
    /*!
     * Add items to an object at a specific path
     * (c) 2018 Chris Ferdinandi, MIT License, https://gomakethings.com
     * @param  {Object}       obj  The object
     * @param  {String|Array} path The path to assign the value to
     * @param  {*}            val  The value to assign
     */
    var xdmPut = function(t, n, r) {
      var o = (n = function(t) {
          if ("string" != typeof t) return t;
          var n = [];
          return t.split(".").forEach(function(t, r) {
            t.split(/\[([^}]+)\]/g).forEach(function(t) {
              t.length > 0 && n.push(t)
            })
          }), n
        }(n)).length,
        c = t;
      n.forEach(function(t, n) {
        var i = "[]" === t.slice(-2);
        t = i ? t.slice(0, -2) : t, i && "[object Array]" !== Object.prototype.toString.call(c[t]) && (c[t] = []), n === o - 1 ? i ? c[t].push(r) : c[t] = r : (c[t] || (c[t] = {}), c = c[t])
      })
    };
    var xdmMapper = function(val) {
      if (val.startsWith("prop")) {
        return "_experience.analytics.customDimensions.props." + val;
      } else if (val.startsWith("eVar")) {
        return "_experience.analytics.customDimensions.eVars." + val;
      } else if (val.startsWith("event")) {
        // convert val into number without 'event'
        var eventNumber = val.replace("event", "");
        if (eventNumber >= 1 && eventNumber <= 100) {
          return "_experience.analytics.event1to100.event" + eventNumber + ".value";
        } else if (eventNumber >= 101 && eventNumber <= 200) {
          return "_experience.analytics.event101to200.event" + eventNumber + ".value";
        } else {
          return val;
        }
      } else if (val == "prodView") {
        return "commerce.productViews.value";
      } else if (val == "scAdd") {
        return "commerce.productListAdds.value";
      } else if (val == "scCheckout") {
        return "commerce.checkouts.value";
      } else if (val == "purchase") {
        return "commerce.purchases.value";
      } else if (val == "channel") {
        return "web.webPaMKtails.siteSection";
      } else if (val == "pageType") {
        return "web.webPaMKtails.errorPage";
      } else if (val == "scRemove") {
        return "commerce.productListRemovals.value";
      } else {
        return val;
      }
    };
    // get ECID & set ECID to sessionStorage
    alloy("getIdentity").then(function(result) {
      sessionStorage.setItem("ECID", result.identity.ECID);
    });
    // define vistorId extension alternatives (for legacy codes)
    _satellite.getVisitorId = function() {
      var visitorId = {
        getMarketingCloudVisitorID: function() {
          if (sessionStorage.getItem("ECID")) {
            return sessionStorage.getItem("ECID");
          } else {
            // set Promise and get returned ECID & set ECID
            return "";
          }
        }
      };
      return visitorId;
    };
  </script>
  <script>
    /*!
     * Add items to an object at a specific path
     * (c) 2018 Chris Ferdinandi, MIT License, https://gomakethings.com
     * @param  {Object}       obj  The object
     * @param  {String|Array} path The path to assign the value to
     * @param  {*}            val  The value to assign
     */
    var xdmPut = function(t, n, r) {
      var o = (n = function(t) {
          if ("string" != typeof t) return t;
          var n = [];
          return t.split(".").forEach(function(t, r) {
            t.split(/\[([^}]+)\]/g).forEach(function(t) {
              t.length > 0 && n.push(t)
            })
          }), n
        }(n)).length,
        c = t;
      n.forEach(function(t, n) {
        var i = "[]" === t.slice(-2);
        t = i ? t.slice(0, -2) : t, i && "[object Array]" !== Object.prototype.toString.call(c[t]) && (c[t] = []), n === o - 1 ? i ? c[t].push(r) : c[t] = r : (c[t] || (c[t] = {}), c = c[t])
      })
    };
    _satellite.x_xdm_convert = function(s_obj, isLinkTracking = false, s_linkName = "", eventName = "click_others") {
      var xdm = {};
      var productArray = [];
      // parse products variable
      if (s_obj.products) {
        let products = [];
        if (Array.isArray(s_obj.products)) {
          products = s_obj.products[0].split(",");
        } else {
          products = s_obj.products.split(",");
        }
        products.forEach(function(product) {
          var productFields = product.split(";");
          var productArrayUnit = {
            "lineItemId": productFields[0] ? productFields[0] : "",
            "SKU": productFields[1] ? productFields[1] : "",
            "quantity": productFields[2] ? productFields[2] : "",
            "priceTotal": productFields[3] ? productFields[3] : "",
            "incrementor": productFields[4] ? productFields[4] : "", // productListItems[]._experience.analytics.event1to100.event1.value
            "merchandizingVars": productFields[5] ? productFields[5] : "" // productListItems[]._experience.analytics.customDimensions.eVars.eVarN
          }
          productArray.push(productArrayUnit);
        });
      }
      if (isLinkTracking) {
        var linkTrackVars = s_obj.linkTrackVars ? s_obj.linkTrackVars.split(",") : [];
        for (var i = 0; i < linkTrackVars.length; i++) {
          if (linkTrackVars[i] == "products") {
            xdmPut(xdm, "productListItems", productArray);
          } else {
            xdmPut(xdm, xdmMapper(linkTrackVars[i]), s_obj[linkTrackVars[i]]);
          }
        }
        var linkTrackEvents = [];
        if (s_obj.linkTrackEvents) linkTrackEvents = s_obj.linkTrackEvents.split(",");
        for (var i = 0; i < linkTrackEvents.length; i++) {
          if (s_obj.events && s_obj.events.indexOf(linkTrackEvents[i]) > -1) xdmPut(xdm, xdmMapper(linkTrackEvents[i]), 1); // only for counter metrics
        }
        xdmPut(xdm, "web.webInteraction.type", "other"); // custom link 
        xdmPut(xdm, "web.webInteraction.name", s_linkName);
      } else {
        xdmPut(xdm, "web.webPaMKtails.name", s_obj.pageName);
        xdmPut(xdm, "web.webPaMKtails.siteSection", s_obj.channel);
        xdmPut(xdm, "commerce.order.currencyCode", s_obj.currencyCode);
        if (s_obj.campaign.length > 0) {
          xdmPut(xdm, "marketing.trackingCode", s_obj.campaign);
          //console.log(s_obj.campaign.length)
        }
        for (var i = 1; i <= 75; i++) {
          if (s_obj["prop" + i] != undefined) {
            xdmPut(xdm, "_experience.analytics.customDimensions.props.prop" + i, s_obj["prop" + i]);
          }
        }
        for (var i = 1; i < 110; i++) {
          if (s_obj["eVar" + i] != undefined) {
            xdmPut(xdm, "_experience.analytics.customDimensions.eVars.eVar" + i, s_obj["eVar" + i]);
          }
        }
        if (productArray.length > 0) xdmPut(xdm, "productListItems", productArray);
        // if s_obj.events is not empty, then add it to xdm
        if (s_obj.events) {
          var events = s_obj.events.split(",");
          for (var i = 0; i < events.length; i++) {
            xdmPut(xdm, xdmMapper(events[i]), 1); // only for counter metrics
          }
        }
      }
      // Add IdentityMap
      xdm.identityMap = _satellite.getVar("AEP:xdm:identityMap");
      _satellite.xdm = {}
      // merge xdm with _satellite.xdm
      for (var key in xdm) {
        _satellite.xdm[key] = xdm[key];
      }
      // check if eddl_bridge is loaded
      if (typeof eddl_bridge != "undefined") {
        eddl_bridge.eddl_push(_satellite, eventName, eddlDataLayer);
      } else {
        console.log("eddl_bridge is not loaded");
      }
    }
    // run datastreamId referring
    var xdm_datastreamId = _satellite.getVar("datastreamId");
  </script>
  <!-- <sly data-sly-test="false">
		<script type="text/javascript" src='/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-site/resources/au/js/au.js'></script>
	</sly> -->
  <!--[if lt IE 9]>
	<script src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/ie9/html5.js"></script>
	<![endif]-->
  <!--[if lte IE 9]>
	<script type='text/javascript' src='//cdnjs.cloudflare.com/ajax/libs/jquery-ajaxtransport-xdomainrequest/1.0.3/jquery.xdomainrequest.min.js'></script>
	<![endif]-->
  <script type="text/javascript">
    /* recaptcha script for Samsung 2020.07.10 */
    var conRecaptcha;
    var recaptchaCallback = function() {
      if ($("#Con_reCaptcha").length > 0) {
        conRecaptcha = grecaptcha.render('Con_reCaptcha', {
          'sitekey': '6Lc-358UAAAAAFmYE7zKV3PU0m9crt6-tj-UJsll'
        });
      }
    };
  </script>
  <script defer="" src="https://www.google.com/recaptcha/api.js?onload=recaptchaCallback&amp;render=explicit" type="text/javascript">
  </script>
  <section aria-modal="true" class="trade-in-learn-more-popup" role="dialog">
    <div class="trade-in-learn-more-popup__dimmed">
    </div>
    <div class="trade-in-learn-more-popup__contents">
      <div class="scrollbar">
        <div class="scrollbar__wrap">
          <div class="trade-in-learn-more-popup__inner-wrap scrollbar__contents">
            <p class="trade-in-learn-more-popup__title"> Cara kerja tukar tambah </p>
            <div class="trade-in-learn-more-popup__list-wrap">
              <ul class="trade-in-learn-more-popup__list">
                <li class="trade-in-learn-more-popup__list-item">
                  <em class="trade-in-learn-more-popup__list-item-num"> 01 </em>
                  <div class="trade-in-learn-more-popup__list-item-text-wrap">
                    <span class="trade-in-learn-more-popup__list-item-text-desc"> Choose your new SLOT device and tell us about your old one. <br> Jika memenuhi syarat, Anda akan melihat taksiran nilai tukar tambah. </span>
                  </div>
                </li>
                <li class="trade-in-learn-more-popup__list-item">
                  <em class="trade-in-learn-more-popup__list-item-num"> 02 </em>
                  <div class="trade-in-learn-more-popup__list-item-text-wrap">
                    <span class="trade-in-learn-more-popup__list-item-text-desc"> Get an upfront discount on the price of your new SLOT device. </span>
                  </div>
                </li>
                <li class="trade-in-learn-more-popup__list-item">
                  <em class="trade-in-learn-more-popup__list-item-num"> 03 </em>
                  <div class="trade-in-learn-more-popup__list-item-text-wrap">
                    <span class="trade-in-learn-more-popup__list-item-text-desc"> Kirimkan perangkat lama Anda untuk menyelesaikan tukar tambah. </span>
                  </div>
                </li>
              </ul>
              <!--
			<sly data-sly-test="false">
              <div class="trade-in-learn-more-popup__cta-wrap">
                <a class="cta cta--underline cta--black cta--icon" href="https://www.samsung.com/pt/campanha-retomas/" title="Open in a New Window" target="_blank"> More Information 
                  <svg class="icon" focusable="false">
					<use xlink:href="#outlink-bold" href="#outlink-bold"></use>
                  </svg>
                </a>
              </div>
            </sly>
            -->
            </div>
          </div>
        </div>
        <div class="scrollbar-horizontal__track" style="display: none;">
          <div class="scrollbar-horizontal__track-content">
            <div class="scrollbar-horizontal__bar"></div>
          </div>
        </div>
        <div class="scrollbar-vertical__track" style="display: none;">
          <div class="scrollbar-vertical__track-content">
            <div class="scrollbar-vertical__bar"></div>
          </div>
        </div>
      </div>
      <button class="trade-in-learn-more-popup__close">
        <span class="hidden"> TUTUP </span>
        <svg class="icon" focusable="false">
          <use href="#delete-bold" xlink:href="#delete-bold">
          </use>
        </svg>
      </button>
    </div>
  </section>
  <input id="tariffAdditionalPromotionCarrierUrl" type="hidden">
  <div class="component-area" style="">
    <section aria-modal="true" class="tariff-popup" role="dialog">
      <div class="tariff-popup__dimmed">
      </div>
      <div class="tariff-popup__contents">
        <div class="tariff-popup__contents-plan" style="display:block;" aria-hidden="false">
          <div class="tariff-popup__inner-wrap scrollbar">
            <div class="scrollbar__wrap" style="max-height: 12140px;">
              <div class="tariff-popup__inner scrollbar__contents">
                <div class="tariff-popup__header">
                  <div class="tariff-popup__headline"> All from one hand </div>
                  <p class="tariff-popup__desc"> Now you get innovative smartphone with right tariff plan. </p>
                </div>
                <div class="tariff-popup__choose" role="tablist" style="display:none;">
                  <div class="tariff-popup__choose-item active" role="presentation">
                    <a aria-selected="trues" class="tariff-popup__choose-item-btn" href="javascript:;" id="choose-tab-1" role="tab"> New Contracts </a>
                  </div>
                  <div class="tariff-popup__choose-item" role="presentation">
                    <div class="tariff-popup__choose-tooltip">
                      <div class="tariff-popup__choose-tooltip__btn-wrap">
                        <button aria-expanded="false" class="tariff-popup__choose-tooltip__btn" type="button">
                          <svg class="icon help" focusable="false">
                            <use xlink:href="#help-regular" href="#help-regular">
                            </use>
                          </svg>
                          <svg class="icon cancel" focusable="false">
                            <use xlink:href="#cancel-bold" href="#cancel-bold">
                            </use>
                          </svg>
                          <span class="hidden"> see what this </span>
                        </button>
                        <span class="tariff-popup__choose-tooltip__arrow">
                        </span>
                      </div>
                      <div class="tariff-popup__choose-tooltip__box" role="tooltip">
                        <span class="tariff-popup__choose-tooltip__box-arrow">
                        </span>
                        <p class="tariff-popup__choose-tooltip__box-desc"> Stay with your network operator. </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div aria-hidden="false" aria-labelledby="choose-tab-1" class="tariff-popup__choose-panel active" id="choose-content-1" role="tabpanel">
                  <div class="tariff-popup__tab-wrap">
                    <div class="tariff-popup__tab-list-wrap">
                      <button class="tariff-popup__tab-list-prev" role="button" style="display:none;"> prev <svg class="icon" focusable="false">
                          <use href="#previous-bold" xlink:href="#previous-bold">
                          </use>
                        </svg>
                      </button>
                      <div class="tariff-popup__tab-list-area">
                        <!--/* UK, SE 경우 Tab Divider 를 숨기기 위해 .hide-divider 추가 /*-->
                        <div class="tariff-popup__tab-list" role="tablist" style="transform: translate3d(0vw, 0px, 0px);">
                          <div class="tariff-popup__tab-item-wrap hide-divider" role="presentation">
                            <a class="tariff-popup__tab-item" href="javascript:void(0);" aria-hidden="false">
                            </a>
                          </div>
                        </div>
                      </div>
                      <button class="tariff-popup__tab-list-next" role="button" style="display: none;"> Next <svg class="icon" focusable="false">
                          <use href="#next-bold" xlink:href="#next-bold">
                          </use>
                        </svg>
                      </button>
                      <div class="tariff-popup__tab-list-gl-left">
                      </div>
                      <div class="tariff-popup__tab-list-gl-right">
                      </div>
                    </div>
                    <div class="tariff-popup__tab-panel-wrap">
                      <div class="tariff-popup__tab-panel">
                      </div>
                    </div>
                  </div>
                </div>
                <div aria-hidden="true" aria-labelledby="choose-tab-2" class="tariff-popup__choose-panel" id="choose-content-2" role="tabpanel">
                  <div class="tariff-popup__tab-wrap">
                    <div class="tariff-popup__tab-list-wrap">
                      <button class="tariff-popup__tab-list-prev" role="button" style="display:none;"> prev <svg class="icon" focusable="false">
                          <use href="#previous-bold" xlink:href="#previous-bold">
                          </use>
                        </svg>
                      </button>
                      <div class="tariff-popup__tab-list-area">
                        <!--/* UK, SE 경우 Tab Divider 를 숨기기 위해 .hide-divider 추가 /*-->
                        <div class="tariff-popup__tab-list" role="tablist">
                        </div>
                      </div>
                      <button class="tariff-popup__tab-list-next" role="button"> Next <svg class="icon" focusable="false">
                          <use href="#next-bold" xlink:href="#next-bold">
                          </use>
                        </svg>
                      </button>
                      <div class="tariff-popup__tab-list-gl-left">
                      </div>
                      <div class="tariff-popup__tab-list-gl-right">
                      </div>
                    </div>
                    <div class="tariff-popup__tab-panel-wrap">
                      <div class="tariff-popup__tab-panel">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="scrollbar-horizontal__track" style="display: none;">
              <div class="scrollbar-horizontal__track-content">
                <div class="scrollbar-horizontal__bar"></div>
              </div>
            </div>
            <div class="scrollbar-vertical__track" style="display: none;">
              <div class="scrollbar-vertical__track-content">
                <div class="scrollbar-vertical__bar"></div>
              </div>
            </div>
          </div>
          <div class="tariff-popup__btn-wrap">
            <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step2:back" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-prev cta cta--outlined cta--black" style="display:none;"> BATALKAN </button>
            <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:close" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-close cta cta--outlined cta--black"> BATALKAN </button>
            <!-- CTA 활성화 시 disabled 제거, .cta--disabled 제거 -->
            <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:continue" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-next cta cta--contained cta--emphasis cta--disabled" disabled=""> LANJUTKAN </button>
          </div>
        </div>
        <div class="tariff-popup__contents-plan-details" style="display:none;">
          <div class="tariff-popup__inner-wrap scrollbar">
            <div class="scrollbar__wrap">
              <div class="tariff-popup__inner scrollbar__contents">
                <div class="tariff-popup__header">
                  <div class="tariff-popup__headline"> The Network Plan Details </div>
                  <p class="tariff-popup__desc">
                  </p>
                </div>
                <div class="tariff-popup__plan-details-wrap">
                  <section class="tariff-popup__plan-details expand">
                    <a class="tariff-popup__plan-details-title" href="javascript:;" role="button">
                      <span class="tariff-popup__plan-details-title-text"> Plan Benefits </span>
                      <span>
                        <svg class="icon collapse">
                          <use xlink:href="#open-down-bold" href="#open-down-bold">
                          </use>
                        </svg>
                        <span class="hidden collapse"> Klik untuk Memperluas </span>
                        <svg class="icon expand">
                          <use xlink:href="#close-up-bold" href="#close-up-bold">
                          </use>
                        </svg>
                        <span class="hidden expand"> Klik untuk Tutup </span>
                      </span>
                    </a>
                    <div class="tariff-popup__plan-details-desc plan-benefits-desc">
                    </div>
                  </section>
                  <section class="tariff-popup__plan-details">
                    <a class="tariff-popup__plan-details-title" href="javascript:;" role="button">
                      <span class="tariff-popup__plan-details-title-text"> Out of Bundle Charges </span>
                      <span>
                        <svg class="icon collapse">
                          <use xlink:href="#open-down-bold" href="#open-down-bold">
                          </use>
                        </svg>
                        <span class="hidden collapse"> Klik untuk Memperluas </span>
                        <svg class="icon expand">
                          <use xlink:href="#close-up-bold" href="#close-up-bold">
                          </use>
                        </svg>
                        <span class="hidden expand"> Klik untuk Tutup </span>
                      </span>
                    </a>
                    <div class="tariff-popup__plan-details-desc out-of-bundle-charges-desc">
                    </div>
                  </section>
                  <section class="tariff-popup__plan-details">
                    <a class="tariff-popup__plan-details-title" href="javascript:;" role="button">
                      <span class="tariff-popup__plan-details-title-text"> Terms &amp; Conditions </span>
                      <span>
                        <svg class="icon collapse">
                          <use xlink:href="#open-down-bold" href="#open-down-bold">
                          </use>
                        </svg>
                        <span class="hidden collapse"> Klik untuk Memperluas </span>
                        <svg class="icon expand">
                          <use xlink:href="#close-up-bold" href="#close-up-bold">
                          </use>
                        </svg>
                        <span class="hidden expand"> Klik untuk Tutup </span>
                      </span>
                    </a>
                    <div class="tariff-popup__plan-details-desc term-conditions-desc">
                    </div>
                  </section>
                </div>
              </div>
            </div>
            <div class="scrollbar-horizontal__track" style="display: none;">
              <div class="scrollbar-horizontal__track-content">
                <div class="scrollbar-horizontal__bar"></div>
              </div>
            </div>
            <div class="scrollbar-vertical__track" style="display: none;">
              <div class="scrollbar-vertical__track-content">
                <div class="scrollbar-vertical__bar"></div>
              </div>
            </div>
          </div>
          <div class="tariff-popup__btn-wrap">
            <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:back" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-back cta cta--outlined cta--black"> Kembali </button>
            <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:close" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-close cta cta--contained cta--emphasis"> Tutup </button>
          </div>
        </div>
        <div class="tariff-popup__contents-plan-selected" style="display:none;">
          <div class="tariff-popup__inner-wrap scrollbar">
            <div class="scrollbar__wrap">
              <div class="tariff-popup__inner scrollbar__contents">
                <div class="tariff-popup__header">
                  <div class="tariff-popup__headline"> All from one hand <span class="tariff-popup__icon">
                      <div class="image">
                        <img alt="alternative text" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/tariff-popup-icon.png" role="img">
                      </div>
                    </span>
                  </div>
                  <p class="tariff-popup__desc"> Now you get innovative smartphone with right tariff plan. </p>
                </div>
                <div class="tariff-popup__selected-wrap">
                  <div class="tariff-popup__selected">
                    <div class="tariff-popup__selected-spec">
                      <div class="tariff-popup__selected-spec-header">
                        <div class="tariff-popup__selected-spec-img">
                          <img alt="" src="#">
                        </div>
                        <div class="tariff-popup__selected-spec-detail">
                          <strong class="tariff-popup__selected-spec-name">
                          </strong>
                          <span class="tariff-popup__selected-spec-value">
                          </span>
                        </div>
                      </div>
                      <div class="tariff-popup__selected-spec-desc">
                        <ul class="tariff-popup__selected-spec-list">
                        </ul>
                      </div>
                      <div class="tariff-popup__selected-add-opt">
                      </div>
                    </div>
                    <div class="tariff-popup__selected-total">
                      <div class="tariff-popup__selected-total-title"> Upfront Cost </div>
                      <div class="tariff-popup__selected-total-price">
                      </div>
                      <p class="tariff-popup__selected-total-desc"> Der Anschlusspreis und monatlicher Tarifpreis werden vom jeweiligen Netzanbieter eingezogen. Du zahlst jetzt nur den einmaligen Gerätepreis. </p>
                    </div>
                  </div>
                </div>
                <div class="tariff-popup__checkbox-wrap">
                </div>
                <div class="tariff-popup__table-wrap">
                  <div class="tariff-popup__table-inner">
                  </div>
                  <div class="tariff-popup__table-disclaimer">
                  </div>
                </div>
              </div>
            </div>
            <div class="scrollbar-horizontal__track" style="display: none;">
              <div class="scrollbar-horizontal__track-content">
                <div class="scrollbar-horizontal__bar"></div>
              </div>
            </div>
            <div class="scrollbar-vertical__track" style="display: none;">
              <div class="scrollbar-vertical__track-content">
                <div class="scrollbar-vertical__bar"></div>
              </div>
            </div>
          </div>
          <div class="tariff-popup__btn-wrap">
            <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step2:back" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-prev cta cta--outlined cta--black"> BACK </button>
            <!-- CTA 활성화 시 disabled 제거, .cta--disabled 제거 -->
            <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step2:confirm" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-submit cta cta--contained cta--emphasis cta--disabled" disabled=""> Terapkan </button>
          </div>
        </div>
        <div class="tariff-popup__contents-form" style="display:none;">
          <div class="tariff-popup__inner-wrap scrollbar">
            <div class="scrollbar__wrap">
              <div class="tariff-popup__inner scrollbar__contents">
                <div class="tariff-popup__header">
                  <div class="tariff-popup__headline"> Check the availabbility </div>
                </div>
                <div class="tariff-popup__step">
                  <div class="tariff-popup__step-inner">
                    <span class="tariff-popup__step-fill is-active">
                    </span>
                    <span class="tariff-popup__step-fill">
                    </span>
                    <span class="tariff-popup__step-fill">
                    </span>
                  </div>
                </div>
                <div class="tariff-popup__step-progress">
                  <span class="hidden"> 1 of 3 </span>
                </div>
                <div class="tariff-popup__validation-message">
                  <strong class="tariff-popup__validation-message-title"> Wrong address </strong>
                  <div class="tariff-popup__validation-message-content">
                    <p> Unfortunately, we cannot make you a DSL offer for the address you have checked.The address you have given is not unique, please choose from the address suggestions. </p>
                  </div>
                </div>
                <div class="tariff-popup__form-wrap">
                  <div class="tariff-popup__form-list">
                    <div class="tariff-popup__form-item tariff-popup__form-item-wide" style="display:none;">
                      <div class="menu menu--text-field" data-comp-name="menu" data-max-item-number="5" data-type="textField">
                        <select aria-labelledby="tariff-addr-label-id" class="menu__select" tabindex="-1" aria-hidden="true">
                        </select>
                        <p class="menu--text-field__hint" id="tariff-addr-label-id"> Empfohlene Adresse </p>
                        <button aria-expanded="false" aria-haspopup="listbox" aria-labelledby="tariff-addr-label-id tariff-text-label-id" class="menu__select-field" type="button">
                          <span class="menu__select-field-text" id="tariff-text-label-id"></span>
                          <svg aria-hidden="true" class="menu__select-field-icon down" focusable="false">
                            <use href="#open-down-bold" xlink:href="#open-down-bold">
                            </use>
                          </svg>
                          <svg aria-hidden="true" class="menu__select-field-icon up" focusable="false">
                            <use href="#close-up-bold" xlink:href="#close-up-bold">
                            </use>
                          </svg>
                        </button>
                        <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                          <div class="scrollbar__wrap" style="max-height: 0px;">
                            <ul class="menu__list scrollbar__contents" role="listbox"></ul>
                          </div>
                          <div class="scrollbar-horizontal__track" style="display: none;">
                            <div class="scrollbar-horizontal__track-content">
                              <div class="scrollbar-horizontal__bar"></div>
                            </div>
                          </div>
                          <div class="scrollbar-vertical__track" style="display: none;">
                            <div class="scrollbar-vertical__track-content">
                              <div class="scrollbar-vertical__bar"></div>
                            </div>
                          </div>
                          <ul class="menu__list scrollbar__contents" role="listbox"></ul>
                        </div>
                        <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                          <ul class="menu__list scrollbar__contents" role="listbox"></ul>
                        </div>
                      </div>
                    </div>
                    <div class="tariff-popup__form-item tariff-popup__form-item-wide">
                      <div class="text-field-v2" data-comp-name="textFieldv2">
                        <label class="text-field-v2__hint" for="text-field-tariff-postcode"> Postcode </label>
                        <div class="text-field-v2__input-wrap">
                          <input autocomplete="off" class="text-field-v2__input" id="text-field-tariff-postcode" maxlength="5" name="postCode" type="text">
                          <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                            <svg aria-hidden="true" class="icon delete" focusable="false">
                              <use href="#cancel-bold" xlink:href="#cancel-bold">
                              </use>
                            </svg>
                          </button>
                        </div>
                        <p aria-hidden="true" class="text-field-v2__text assistive"> Please provide a valid postcode </p>
                        <p aria-hidden="true" class="text-field-v2__text error"> Please enter correct information again. </p>
                      </div>
                    </div>
                    <div class="tariff-popup__form-item">
                      <div class="text-field-v2" data-comp-name="textFieldv2">
                        <label class="text-field-v2__hint" for="text-field-tariff-street"> Street </label>
                        <div class="text-field-v2__input-wrap">
                          <input autocomplete="off" class="text-field-v2__input" id="text-field-tariff-street" name="streetName" type="text">
                          <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                            <svg aria-hidden="true" class="icon delete" focusable="false">
                              <use href="#cancel-bold" xlink:href="#cancel-bold">
                              </use>
                            </svg>
                          </button>
                        </div>
                        <p aria-hidden="true" class="text-field-v2__text assistive"> Please provide a valid street </p>
                        <p aria-hidden="true" class="text-field-v2__text error"> Please enter correct information again. </p>
                      </div>
                    </div>
                    <div class="tariff-popup__form-item">
                      <div class="text-field-v2" data-comp-name="textFieldv2">
                        <label class="text-field-v2__hint" for="text-field-3"> House number </label>
                        <div class="text-field-v2__input-wrap">
                          <input autocomplete="off" class="text-field-v2__input" id="text-field-3" name="houseNumber" type="text">
                          <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                            <svg aria-hidden="true" class="icon delete" focusable="false">
                              <use href="#cancel-bold" xlink:href="#cancel-bold">
                              </use>
                            </svg>
                          </button>
                        </div>
                        <p aria-hidden="true" class="text-field-v2__text assistive"> Please provide a valid house number </p>
                        <p aria-hidden="true" class="text-field-v2__text error"> Please enter correct information again. </p>
                      </div>
                    </div>
                    <div class="tariff-popup__form-item">
                      <div class="text-field-v2" data-comp-name="textFieldv2">
                        <label class="text-field-v2__hint" for="text-field-4"> Additional house information </label>
                        <div class="text-field-v2__input-wrap">
                          <input autocomplete="off" class="text-field-v2__input" id="text-field-4" name="houseNumberAddition" type="text">
                          <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                            <svg aria-hidden="true" class="icon delete" focusable="false">
                              <use href="#cancel-bold" xlink:href="#cancel-bold">
                              </use>
                            </svg>
                          </button>
                        </div>
                        <p aria-hidden="true" class="text-field-v2__text assistive"> Additional information placeholder </p>
                        <p aria-hidden="true" class="text-field-v2__text error"> Please enter correct information again. </p>
                      </div>
                    </div>
                    <div class="tariff-popup__form-item">
                      <div class="text-field-v2" data-comp-name="textFieldv2">
                        <label class="text-field-v2__hint" for="text-field-5"> City </label>
                        <div class="text-field-v2__input-wrap">
                          <input autocomplete="off" class="text-field-v2__input" id="text-field-5" name="locality" type="text">
                          <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                            <svg aria-hidden="true" class="icon delete" focusable="false">
                              <use href="#cancel-bold" xlink:href="#cancel-bold">
                              </use>
                            </svg>
                          </button>
                        </div>
                        <p aria-hidden="true" class="text-field-v2__text assistive"> Please provide a valid city </p>
                        <p aria-hidden="true" class="text-field-v2__text error"> Please enter correct information again. </p>
                      </div>
                    </div>
                  </div>
                </div>
                <p class="tariff-popup__form-txt"> *Required fields </p>
                <div class="tariff-popup__disclaimer-wrap">
                  <div class="tariff-popup__disclaimer"> Anda dapat menemukan informasi tentang pengolahan data pribadi melalui link <a href="https://www.samsung.com/id/info/privacy/" target="_blank" title="Open in a new window"> Kebijakan privasi </a> . </div>
                </div>
              </div>
            </div>
            <div class="scrollbar-horizontal__track" style="display: none;">
              <div class="scrollbar-horizontal__track-content">
                <div class="scrollbar-horizontal__bar"></div>
              </div>
            </div>
            <div class="scrollbar-vertical__track" style="display: none;">
              <div class="scrollbar-vertical__track-content">
                <div class="scrollbar-vertical__bar"></div>
              </div>
            </div>
          </div>
          <div class="tariff-popup__btn-wrap">
            <button class="tariff-popup__btn-close cta cta--outlined cta--black"> Batalkan </button>
            <!-- CTA 활성화 시 disabled 제거, .cta--disabled 제거 -->
            <button class="tariff-popup__btn-next cta cta--contained cta--emphasis cta--disabled" disabled=""> Lanjutkan </button>
          </div>
        </div>
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:close" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__close">
          <span class="hidden"> Tutup Layar Popup </span>
        </button>
      </div>
    </section>
  </div>
  <div class="tariff-info-popup">
    <div class="layer-popup" id="tariff-info-popup" role="dialog" style="display:block">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="scrollbar__contents">
              <div class="layer-popup__title"> Pay monthly phone contracts </div>
              <p class="layer-popup__desc"> Buy your phone along with an inclusive monthly network plan and pay monthly* </p>
              <div class="tariff-info-popup__wrap">
                <div class="tariff-info-popup__inner">
                  <div class="tariff-info-popup__more">
                    <ul class="tariff-info-popup__more-list">
                      <li>
                        <strong class="tariff-info-popup__more-title"> Choose your network </strong>
                        <p class="tariff-info-popup__more-text"> Choose from a range of networks and inclusive monthly plans to get started with your new Galaxy phone straight away. </p>
                      </li>
                      <li>
                        <strong class="tariff-info-popup__more-title"> Bayar Bulanan </strong>
                        <p class="tariff-info-popup__more-text"> Pay for your phone and an inclusive bundle of calls, texts and data in one easy-to-manage monthly fee. </p>
                      </li>
                      <li>
                        <strong class="tariff-info-popup__more-title"> Next steps </strong>
                        <p class="tariff-info-popup__more-text"> You will be redirected to our trusted partner, A1 Comms Ltd (trading as Mobileshop), to purchase your phone and setup your monthly plan. </p>
                      </li>
                    </ul>
                  </div>
                  <div class="tariff-info-popup__info">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <div class="tariff-info-popup__cta">
          <!--/* P6의 cta 적용 방식에 따라 마크업 변경 */ -->
          <a class="cta cta--contained cta--emphasis" href="javascript:void(0);" title="Link Title"> Choose your plan </a>
        </div>
        <button class="layer-popup__close" type="button">
          <span class="hidden"> Layer Popup Close </span>
          <svg class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <input id="cfTradeInConditionCheckYn" type="hidden">
  <input id="cfTradeInCategoryUseYn" type="hidden">
  <section aria-modal="true" class="trade-in-popup" id="hubble-tradein-layer" role="dialog">
    <div class="trade-in-popup__dimmed">
    </div>
    <div class="trade-in-popup__contents">
      <!-- new-hybris -->
      <div class="trade-in-popup__zipcode-wrap" role="dialog">
        <div class="scrollbar">
          <div class="scrollbar__wrap" style="max-height: 12140px;">
            <div class="trade-in-popup__inner-wrap scrollbar__contents">
              <p class="trade-in-popup__title"> Cek layanan tukar tambah di area Anda! </p>
              <div class="trade-in-popup__imei">
                <div class="trade-in-popup__imei-desc-wrap">
                  <p class="trade-in-popup__imei-desc"> Akses menu Tukar Tambah di aplikasi Samsung Gift Indonesia atau unduh aplikasi SS.com Trade In untuk memeriksakan ponsel pintar Anda. Setelah ponsel Anda lolos uji, IMEI perangkat lama Anda akan tercatat dalam basis data kami, sehingga Anda dapat menikmati diskon tukar tambah khusus. </p>
                  <p class="trade-in-popup__imei-desc">
                    <a href="https://www.samsung.com/id/offer/mobile-trade-in/" target="_blank" title="Buka di Tab Baru"> SAMSUNG TRADE IN </a>
                  </p>
                </div>
                <div class="trade-in-popup__imei-form-wrap">
                  <strong class="trade-in-popup__imei-form-title"> Masukkan kode pos Anda </strong>
                  <div class="trade-in-popup__imei-form">
                    <div class="text-field-v2 no-title">
                      <label class="text-field-v2__hint" for="zipcode-input"> Kode Pos (5 angka) </label>
                      <div class="text-field-v2__input-wrap">
                        <input autocomplete="off" class="text-field-v2__input" id="zipcode-input" maxlength="5" type="text" value="">
                        <button class="text-field-v2__input-icon delete" title="Delete">
                          <svg class="icon delete" focusable="false">
                            <use href="#cancel-bold" xlink:href="#cancel-bold">
                            </use>
                          </svg>
                        </button>
                      </div>
                      <p class="text-field-v2__text error">
                      </p>
                      <p class="text-field-v2__text success"> Tukar tambah tersedia di area&nbsp;kode pos Anda </p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="trade-in-popup__dropdown-wrap">
                <div class="trade-in-popup__brand-dropdown-wrap">
                  <p class="trade-in-popup__dropdown-title"> Estimasi harga tertinggi perangkat lama Anda </p>
                  <div class="trade-in-popup__dropdown">
                    <button class="trade-in-popup__dropdown--select-field">
                      <span class="trade-in-popup__dropdown--select-field-name"> Select Brand </span>
                    </button>
                    <div class="trade-in-popup__dropdown--select-list scrollbar">
                      <div class="scrollbar__wrap">
                        <ul class="scrollbar__contents">
                        </ul>
                      </div>
                      <div class="scrollbar-horizontal__track" style="display: none;">
                        <div class="scrollbar-horizontal__track-content">
                          <div class="scrollbar-horizontal__bar"></div>
                        </div>
                      </div>
                      <div class="scrollbar-vertical__track" style="display: none;">
                        <div class="scrollbar-vertical__track-content">
                          <div class="scrollbar-vertical__bar"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="trade-in-popup__model-dropdown-wrap">
                  <p class="trade-in-popup__dropdown-title"> Estimasi harga tertinggi perangkat lama Anda </p>
                  <div class="trade-in-popup__dropdown">
                    <button class="trade-in-popup__dropdown--select-field">
                      <span class="trade-in-popup__dropdown--select-field-name"> Select Model </span>
                      <span class="trade-in-popup__dropdown--select-field-price">
                      </span>
                    </button>
                    <div class="trade-in-popup__dropdown--select-list scrollbar">
                      <div class="scrollbar__wrap">
                        <ul class="scrollbar__contents">
                          <li class="trade-in-popup__dropdown--search-wrap">
                            <label class="trade-in-popup__dropdown--search-label" for="trade-in-popup__dropdown--search-model"> Search... </label>
                            <input autocomplete="off" class="trade-in-popup__dropdown--search-input" id="trade-in-popup__dropdown--search-model" type="text">
                            <button class="trade-in-popup__dropdown--search-btn" type="submit">
                              <span class="hidden"> select device model search </span>
                            </button>
                          </li>
                        </ul>
                      </div>
                      <div class="scrollbar-horizontal__track" style="display: none;">
                        <div class="scrollbar-horizontal__track-content">
                          <div class="scrollbar-horizontal__bar"></div>
                        </div>
                      </div>
                      <div class="scrollbar-vertical__track" style="display: none;">
                        <div class="scrollbar-vertical__track-content">
                          <div class="scrollbar-vertical__bar"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <div class="trade-in-popup__btn-wrap">
          <!-- CTA 의 동작에 따라 .trade-in-popup__btn-close, .trade-in-popup__btn-back, .trade-in-popup__btn-continue, trade-in-popup__btn-apply 추가 -->
          <button class="trade-in-popup__btn-close cta cta--outlined cta--black"> Tutup </button>
          <!-- CTA 활성화 시 .cta--disabled 제거 -->
          <button aria-disabled="true" class="trade-in-popup__btn-continue cta cta--contained cta--emphasis cta--disabled" stepname="zipcode"> Lanjutkan </button>
        </div>
      </div>
      <div class="trade-in-popup__imei-wrap" role="dialog">
        <div class="scrollbar">
          <div class="scrollbar__wrap">
            <div class="trade-in-popup__inner-wrap scrollbar__contents">
              <p class="trade-in-popup__title"> Masukkan IMEI perangkat lama Anda </p>
              <!-- new-hybris -->
              <strong class="trade-in-popup__procedure-title"> Prosedur tukar tambah permainan </strong>
              <ul class="trade-in-popup__procedure">
                <li class="trade-in-popup__procedure-item">
                  <div class="trade-in-popup__procedure-item-img">
                    <div class="image">
                      <img alt="alternative text" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/test-trade-in-imei-procedure-1.jpg" role="img">
                    </div>
                  </div>
                  <p class="trade-in-popup__procedure-item-desc"> 1. Download App SS.com </p>
                  <div class="trade-in-popup__procedure-link-wrap">
                    <a class="trade-in-popup__procedure-link" href="https://play.google.com/store/apps/details?id=com.stradein.bct.lk6">
                      <div class="image">
                        <img alt="google play link" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/icon-trade-in-down-google.png" role="img">
                      </div>
                    </a>
                    <a class="trade-in-popup__procedure-link" href="https://apps.apple.com/id/app/ss-com-trade-in/id1516570115">
                      <div class="image">
                        <img alt="app store link" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/icon-trade-in-down-apple.png" role="img">
                      </div>
                    </a>
                  </div>
                  <p class="trade-in-popup__procedure-item-desc"> atau <br> Gunakan App <br>
                    <a aria-label="Open in a new window" href="https://links.s-gift.app/tradein" target="_blank" title="Buka di Tab Baru"> Samsung Gift Indonesia </a>
                  </p>
                  <div class="trade-in-popup__procedure-link-wrap">
                    <a class="trade-in-popup__procedure-link" href="https://links.s-gift.app/tradein" target="_blank" title="Buka di Tab Baru">
                      <div class="image">
                        <img alt="samsung gift link" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/icon-trade-in-down-gift.png" role="img">
                      </div>
                    </a>
                  </div>
                </li>
                <li class="trade-in-popup__procedure-item">
                  <div class="trade-in-popup__procedure-item-img">
                    <div class="image">
                      <img alt="alternative text" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/test-trade-in-imei-procedure-2.jpg" role="img">
                    </div>
                  </div>
                  <p class="trade-in-popup__procedure-item-desc"> 2. Lanjutkan proses pada aplikasi untuk mendapatkan harga estimasi smartphone </p>
                </li>
                <li class="trade-in-popup__procedure-item">
                  <div class="trade-in-popup__procedure-item-img">
                    <div class="image">
                      <img alt="alternative text" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/test-trade-in-imei-procedure-3.jpg" role="img">
                    </div>
                  </div>
                  <p class="trade-in-popup__procedure-item-desc"> 3. Kembali ke laman produk Galaxy yang Anda inginkan dan masukkan kode IMEI </p>
                </li>
                <li class="trade-in-popup__procedure-item">
                  <div class="trade-in-popup__procedure-item-img">
                    <div class="image">
                      <img alt="alternative text" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/test-trade-in-imei-procedure-4.jpg" role="img">
                    </div>
                  </div>
                  <p class="trade-in-popup__procedure-item-desc"> 4. Lanjutkan dengan menyetujui harga perangkat lama Anda </p>
                </li>
              </ul>
              <div class="trade-in-popup__imei">
                <div class="trade-in-popup__imei-method-wrap">
                  <strong class="trade-in-popup__imei-method-title"> Cara menemukan IMEI Anda </strong>
                  <div class="trade-in-popup__imei-method">
                    <div class="trade-in-popup__imei-method-img">
                      <div class="image">
                        <img alt="alternative text" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/icon-trade-imei.svg" role="img">
                      </div>
                    </div>
                    <strong class="trade-in-popup__imei-method-num">
                      <span> * </span> #06# </strong>
                  </div>
                  <ul class="trade-in-popup__imei-method-list">
                    <li class="trade-in-popup__imei-method-list-item">
                      <span> Option 1 </span>
                      <span> Tekan * # 06 # untuk menemukan IMEI Anda. </span>
                    </li>
                    <li class="trade-in-popup__imei-method-list-item">
                      <span> Option 2 </span>
                      <span> Buka Pengaturan&gt; Umum&gt; Tentang menampilkan IMEI. </span>
                    </li>
                    <!-- new-hybris -->
                  </ul>
                </div>
                <div class="trade-in-popup__imei-form-wrap">
                  <strong class="trade-in-popup__imei-form-title"> Masukkan nomor IMEI Anda </strong>
                  <div class="trade-in-popup__imei-form">
                    <div class="text-field-v2 no-title">
                      <label class="text-field-v2__hint" for="imei-input"> Nomor IMEI (15 digit) </label>
                      <div class="text-field-v2__input-wrap">
                        <input autocomplete="off" class="text-field-v2__input" id="imei-input" maxlength="15" type="text" value="">
                        <button class="text-field-v2__input-icon delete" title="Delete">
                          <svg class="icon delete" focusable="false">
                            <use href="#cancel-bold" xlink:href="#cancel-bold">
                            </use>
                          </svg>
                        </button>
                      </div>
                      <p class="text-field-v2__text error"> Mohon masukkan IMEI atau Nomor Serial yang valid </p>
                      <p class="text-field-v2__text success"> Benar </p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="trade-in-popup__confirm-terms">
              </div>
              <div class="trade-in-popup__disclaimer-wrap">
                <p class="trade-in-popup__disclaimer">
                </p>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <div class="trade-in-popup__btn-wrap">
          <!-- CTA 의 동작에 따라 .trade-in-popup__btn-close, .trade-in-popup__btn-back, .trade-in-popup__btn-continue, trade-in-popup__btn-apply 추가 -->
          <button class="trade-in-popup__btn-back cta cta--outlined cta--black" stepname="imei"> Kembali </button>
          <!-- CTA 활성화 시 .cta--disabled 제거 -->
          <button aria-disabled="true" class="trade-in-popup__btn-continue cta cta--contained cta--emphasis cta--disabled" stepname="imei"> Lanjutkan </button>
        </div>
      </div>
      <div class="trade-in-popup__condition-wrap" role="dialog">
        <div class="scrollbar">
          <div class="scrollbar__wrap">
            <div class="trade-in-popup__inner-wrap scrollbar__contents">
              <p class="trade-in-popup__title"> Last step, Is your phone in good condition? </p>
              <form id="conditionForm" method="post" name="conditionForm">
                <ul class="trade-in-popup__condition-list">
                </ul>
              </form>
              <!-- 필요 시 추가 -->
              <!-- 활성화 시 .trade-in-popup__condition-error--show 추가 -->
              <p class="trade-in-popup__condition-error"> Not eligible for trade-in </p>
              <!-- new-hybris  -->
              <div class="trade-in-popup__disclaimer-wrap">
                <p class="trade-in-popup__disclaimer">
                </p>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <div class="trade-in-popup__btn-wrap">
          <!-- CTA 의 동작에 따라 .trade-in-popup__btn-close, .trade-in-popup__btn-back, .trade-in-popup__btn-continue, trade-in-popup__btn-apply 추가 -->
          <button class="trade-in-popup__btn-back cta cta--outlined cta--black" stepname="condition"> Kembali </button>
          <!-- CTA 활성화 시 .cta--disabled 제거 -->
          <button aria-disabled="true" class="trade-in-popup__btn-continue cta cta--contained cta--emphasis cta--disabled" stepname="condition"> Lanjutkan </button>
        </div>
      </div>
      <div class="trade-in-popup__apply-wrap" role="dialog">
        <div class="scrollbar">
          <div class="scrollbar__wrap">
            <div class="trade-in-popup__inner-wrap scrollbar__contents">
              <p class="trade-in-popup__title"> Harga diskon tukar tambah yang Anda&nbsp;dapatkan </p>
              <div class="trade-in-popup__summary-wrap">
                <div class="trade-in-popup__summary">
                  <div class="trade-in-popup__summary-product-wrap">
                    <strong class="trade-in-popup__summary-product-brand">
                    </strong>
                    <strong class="trade-in-popup__summary-product-model">
                    </strong>
                    <span class="trade-in-popup__summary-product-number">
                    </span>
                  </div>
                  <div class="trade-in-popup__summary-price-wrap">
                    <span class="trade-in-popup__summary-price-title cashbacklist"> Harga Tukar Tambah </span>
                    <em class="trade-in-popup__summary-price">
                    </em>
                    <span class="trade-in-popup__summary-price-desc">
                    </span>
                  </div>
                </div>
                <div class="trade-in-popup__summary-message-wrap">
                  <!-- new-hybris -->
                  <p class="trade-in-popup__summary-message">
                  </p>
                  <p class="trade-in-popup__summary-message--error">
                  </p>
                </div>
              </div>
              <!-- <sly data-sly-test="false">
				<div class="trade-in-popup__apply-how-to">
				<strong class="trade-in-popup__apply-how-to-title">How to save money on a new device?</strong>
					<ul class="trade-in-popup__apply-how-to-list">
						<li class="trade-in-popup__apply-how-to-item">
							<span class="trade-in-popup__apply-how-to-item-num">1.</span>
							<span class="trade-in-popup__apply-how-to-item-text">Untuk smartphone lama Anda, dapatkan diskon untuk smartphone baru di ritel-ritel kami</span>
						</li>
						<li class="trade-in-popup__apply-how-to-item">
							<span class="trade-in-popup__apply-how-to-item-num">2.</span>
							<span class="trade-in-popup__apply-how-to-item-text">Nilai smartphone lama ditentukan oleh konsultan di lokasi penjualan , tergantung pada kondisi dan model perangkat.</span>
						</li>
						<li class="trade-in-popup__apply-how-to-item">
							<span class="trade-in-popup__apply-how-to-item-num">3.</span>
							<span class="trade-in-popup__apply-how-to-item-text">Kunjungi toko penjualan yang paling nyaman bagi Anda. Tinggalkan smartphone lama Anda dan beli yang baru.</span>
						</li>
					</ul>
				</div>
			</sly> -->
              <div class="trade-in-popup__confirm-terms s-border-top">
                <strong class="trade-in-popup__confirm-terms-title"> Konfirmasi Syarat dan Ketentuan </strong>
              </div>
              <div class="trade-in-popup__disclaimer-wrap">
                <p class="trade-in-popup__disclaimer">
                </p>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <div class="trade-in-popup__btn-wrap">
          <!-- CTA 의 동작에 따라 .trade-in-popup__btn-close, .trade-in-popup__btn-back, .trade-in-popup__btn-continue, trade-in-popup__btn-apply 추가 -->
          <button class="trade-in-popup__btn-back cta cta--outlined cta--black" stepname="apply"> Kembali </button>
          <!-- CTA 활성화 시 .cta--disabled 제거 -->
          <button aria-disabled="true" class="trade-in-popup__btn-apply cta cta--contained cta--emphasis cta--disabled"> Yakin </button>
        </div>
      </div>
      <button class="trade-in-popup__close">
        <span class="hidden"> Tutup </span>
        <svg class="icon" focusable="false">
          <use href="#delete-bold" xlink:href="#delete-bold">
          </use>
        </svg>
      </button>
    </div>
  </section>
  <div aria-modal="true" class="upgrade-popup" role="dialog">
    <div class="upgrade-popup__dimmed">
    </div>
    <div class="upgrade-popup__content">
      <div class="scrollbar">
        <div class="scrollbar__wrap">
          <div class="upgrade-popup__content-wrap scrollbar__contents" style="max-height: 639px;">
            <div class="upgrade-popup__header">
              <strong class="upgrade-popup__title"> Upgrade Terms and Conditions </strong>
            </div>
            <div class="upgrade-popup__body">
              <div class="upgrade-popup__apply">
                <div class="upgrade-popup__apply-img">
                  <svg class="icon">
                    <use xlink:href="#phone-light" href="#phone-light">
                    </use>
                  </svg>
                </div>
                <div class="upgrade-popup__apply-content">
                </div>
              </div>
              <ul class="upgrade-popup__condition-wrap">
                <li class="upgrade-popup__condition">
                  <div class="upgrade-popup__condition-img">
                    <div class="image">
                      <img alt="condition image" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/upgrade-popup-condition-icon-01.png" role="img">
                    </div>
                  </div>
                  <p class="upgrade-popup__desc"> Hidupkan ponsel dan tahan catu daya </p>
                </li>
                <li class="upgrade-popup__condition">
                  <div class="upgrade-popup__condition-img">
                    <div class="image">
                      <img alt="condition image" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/upgrade-popup-condition-icon-02.png" role="img">
                    </div>
                  </div>
                  <p class="upgrade-popup__desc"> Keausan normal </p>
                </li>
                <li class="upgrade-popup__condition">
                  <div class="upgrade-popup__condition-img">
                    <div class="image">
                      <img alt="condition image" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/upgrade-popup-condition-icon-03.png" role="img">
                    </div>
                  </div>
                  <p class="upgrade-popup__desc"> Layar berfungsi &amp; tidak ada layar yang retak </p>
                </li>
                <li class="upgrade-popup__condition">
                  <div class="upgrade-popup__condition-img">
                    <div class="image">
                      <img alt="condition image" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/upgrade-popup-condition-icon-04.png" role="img">
                    </div>
                  </div>
                  <p class="upgrade-popup__desc"> Not blacklisted </p>
                </li>
                <li class="upgrade-popup__condition">
                  <div class="upgrade-popup__condition-img">
                    <div class="image">
                      <img alt="condition image" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/upgrade-popup-condition-icon-05.png" role="img">
                    </div>
                  </div>
                  <p class="upgrade-popup__desc"> Factory reset &amp; non-aktifkan penguncian aplikasi </p>
                </li>
              </ul>
              <div class="upgrade-popup__check-info">
              </div>
              <div class="upgrade-popup__disclaimer-wrap">
                <p>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="scrollbar-horizontal__track" style="display: none;">
          <div class="scrollbar-horizontal__track-content">
            <div class="scrollbar-horizontal__bar"></div>
          </div>
        </div>
        <div class="scrollbar-vertical__track" style="display: none;">
          <div class="scrollbar-vertical__track-content">
            <div class="scrollbar-vertical__bar"></div>
          </div>
        </div>
      </div>
      <div class="upgrade-popup__footer">
        <div class="upgrade-popup__cta-wrap">
          <button an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:close" an-tr="header(pim)_service option selector-product detail-text-button" class="cta cta--outlined cta--black upgrade-popup__cta--close"> TUTUP </button>
          <button an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:confirm" an-tr="header(pim)_service option selector-product detail-text-button" class="cta cta--contained cta--emphasis upgrade-popup__cta--submit"> Yakin </button>
        </div>
      </div>
      <button class="upgrade-popup__close">
        <svg class="icon">
          <use href="#delete-bold" xlink:href="#delete-bold">
          </use>
        </svg>
        <span class="hidden"> Tutup Layar Popup </span>
      </button>
    </div>
  </div>
  <div aria-modal="true" class="upgrade-learn-more-popup" role="dialog" style="display: none">
    <div class="upgrade-learn-more-popup__dimmed">
    </div>
    <div class="upgrade-learn-more-popup__content">
      <div class="scrollbar">
        <div class="scrollbar__wrap">
          <div class="upgrade-learn-more-popup__content-wrap scrollbar__contents" style="max-height: 782px;">
          </div>
        </div>
        <button class="upgrade-learn-more-popup__close">
          <svg class="icon">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
          <span class="hidden"> close popup </span>
        </button>
        <div class="scrollbar-horizontal__track" style="display: none;">
          <div class="scrollbar-horizontal__track-content">
            <div class="scrollbar-horizontal__bar"></div>
          </div>
        </div>
        <div class="scrollbar-vertical__track" style="display: none;">
          <div class="scrollbar-vertical__track-content">
            <div class="scrollbar-vertical__bar"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="cancel-return-policy-popup" role="dialog" tabindex="0">
    <div class="layer-popup">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="scrollbar__contents">
              <p class="layer-popup__title">
              </p>
              <div class="cancel-return-policy-popup__description">
                <div class="cancel-return-policy-popup__content">
                  <p class="cancel-return-policy-popup__text">
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <button class="layer-popup__close" type="button">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="warranty-policy-popup" role="dialog" tabindex="0">
    <div class="layer-popup">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="scrollbar__contents">
              <p class="layer-popup__title"> Jaminan </p>
              <div class="warranty-policy-popup__description">
                <div class="warranty-policy-popup__content">
                  <p class="warranty-policy-popup__text">
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <button class="layer-popup__close" type="button">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div class="fold-alert-popup">
    <div class="layer-popup" id="fold-alert-popup" role="dialog" style="display:block" tabindex="0">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="scrollbar__contents">
              <div class="layer-popup__title"> We recommend to set as CLw to see optimized screen </div>
              <div class="fold-alert-popup__wrap">
                <div class="fold-alert-popup__inner">
                  <ul class="fold-alert-popup__list">
                    <li class="fold-alert-popup__item">
                      <strong class="fold-alert-popup__title"> Option 01 </strong>
                      <p class="fold-alert-popup__text"> Rotate the device until it is horizontal to view the screen in landscape mode. </p>
                    </li>
                    <li class="fold-alert-popup__item">
                      <strong class="fold-alert-popup__title"> Option 02 </strong>
                      <p class="fold-alert-popup__text"> Tab on desktop version in the browser. </p>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <div class="fold-alert-popup__cta">
          <!--/* P6의 cta 적용 방식에 따라 마크업 변경 */ -->
          <a class="cta cta--outlined cta--black" href="https://printquarters.com/about/team.php" title="Tutup"> Tutup </a>
        </div>
        <button class="layer-popup__close" type="button">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="eip-popup" role="dialog">
    <div class="layer-popup" id="eip-popup">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="scrollbar__contents">
              <div class="layer-popup__title"> Program CICILAN 0% </div>
              <div class="eip-popup__wrap">
                <p class="eip-popup__top-text">
                  <strong> Harga Produk: <span class="eip-popup__top-text--price"> Rp 17.099.000 </span>
                  </strong>
                </p>
                <div class="tab">
                  <ul class="tab__list" role="tablist">
                    <li class="tab__item tab__item--active" role="presentation">
                      <button class="tab__item-title" role="tab" aria-selected="true"> Cicilan Kartu Kredit <span class="tab__item-line">
                        </span>
                      </button>
                    </li>
                  </ul>
                </div>
                <div class="eip-popup__tab-wrap">
                  <div class="eip-popup__tab">
                    <div class="eip-popup__tab--dropdown-wrap">
                      <p class="eip-popup__tab--dropdown-title"> Pilih Bank </p>
                      <button class="eip-popup__tab--dropdown"> BCA </button>
                    </div>
                    <div class="eip-popup__tab--select-wrap scrollbar">
                      <div class="scrollbar__wrap">
                        <div class="scrollbar__contents">
                          <ul>
                          </ul>
                        </div>
                      </div>
                      <div class="scrollbar-horizontal__track" style="display: none;">
                        <div class="scrollbar-horizontal__track-content">
                          <div class="scrollbar-horizontal__bar"></div>
                        </div>
                      </div>
                      <div class="scrollbar-vertical__track" style="display: none;">
                        <div class="scrollbar-vertical__track-content">
                          <div class="scrollbar-vertical__bar"></div>
                        </div>
                      </div>
                    </div>
                    <div class="eip-popup__tab--table-wrap scrollbar">
                      <div class="scrollbar__wrap">
                        <div class="scrollbar__contents">
                        </div>
                      </div>
                      <div class="scrollbar-horizontal__track" style="display: none;">
                        <div class="scrollbar-horizontal__track-content">
                          <div class="scrollbar-horizontal__bar"></div>
                        </div>
                      </div>
                      <div class="scrollbar-vertical__track" style="display: none;">
                        <div class="scrollbar-vertical__track-content">
                          <div class="scrollbar-vertical__bar"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <button class="layer-popup__close" type="button">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="hubble-careinfo-popup" role="dialog">
    <div class="layer-popup" id="hubble-careinfo">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="scrollbar__contents">
              <p class="layer-popup__title"> Samsung Care+ </p>
              <div class="hubble-careinfo-popup__body">
                <div class="hubble-careinfo-popup__info-wrap">
                  <dl class="hubble-careinfo-popup__info">
                  </dl>
                </div>
                <div class="hubble-careinfo-popup__explain">
                  <p> Samsung Care+ Disclaimer with link </p>
                </div>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <!-- siteCode == 'za' -->
        <button class="hubble-care-popup__close">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="sc-learn-more-popup" role="dialog">
    <div class="layer-popup" id="ScLearnMorePopup">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="scrollbar__contents">
              <p class="layer-popup__title"> Here’s what’s covered </p>
              <div class="sc-learn-more-popup__body">
                <ul class="sc-learn-more-popup__list">
                  <li class="sc-learn-more-popup__item">
                    <div class="sc-learn-more-popup__image">
                      <div class="image">
                        <img alt="alt text" class="image__preview lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-accidental-damage-repair-pc.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-accidental-damage-repair-mo.png?$260_140_PNG$" role="img" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-accidental-damage-repair-pc.png?$198_106_PNG$">
                        <img alt="alt text" class="image__main lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-accidental-damage-repair-pc.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-accidental-damage-repair-mo.png?$260_140_PNG$" role="img" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-accidental-damage-repair-pc.png?$198_106_PNG$">
                      </div>
                    </div>
                    <strong class="sc-learn-more-popup__title"> Hardware repairs </strong>
                    <p class="sc-learn-more-popup__text"> Get fast, convenient repairs using genuine SLOT parts, from our authorized technicians. </p>
                  </li>
                  <li class="sc-learn-more-popup__item">
                    <div class="sc-learn-more-popup__image">
                      <div class="image">
                        <img alt="alt text" class="image__preview lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-software-malfunction-pc.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-software-malfunction-mo.png?$260_140_PNG$" role="img" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-software-malfunction-pc.png?$198_106_PNG$">
                        <img alt="alt text" class="image__main lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-software-malfunction-pc.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-software-malfunction-mo.png?$260_140_PNG$" role="img" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-software-malfunction-pc.png?$198_106_PNG$">
                      </div>
                    </div>
                    <strong class="sc-learn-more-popup__title"> Software coverage </strong>
                    <p class="sc-learn-more-popup__text"> If your device isn’t running smoothly, we’ll check and fix the issue. </p>
                  </li>
                  <li class="sc-learn-more-popup__item">
                    <div class="sc-learn-more-popup__image">
                      <div class="image">
                        <img alt="alt text" class="image__preview lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-battery-replacement-pc.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-battery-replacement-mo.png?$260_140_PNG$" role="img" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-battery-replacement-pc.png?$198_106_PNG$">
                        <img alt="alt text" class="image__main lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-battery-replacement-pc.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-battery-replacement-mo.png?$260_140_PNG$" role="img" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-battery-replacement-pc.png?$198_106_PNG$">
                      </div>
                    </div>
                    <strong class="sc-learn-more-popup__title"> Battery replacement </strong>
                    <p class="sc-learn-more-popup__text"> Stay powered up with hassle-free battery replacements. </p>
                  </li>
                  <li class="sc-learn-more-popup__item">
                    <div class="sc-learn-more-popup__image">
                      <div class="image">
                        <img alt="alt text" class="image__preview lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03_coverage_Upto2claims.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03_coverage_Upto2claims.png$260_140_PNG$" role="img" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03_coverage_Upto2claims.png?$198_106_PNG$">
                        <img alt="alt text" class="image__main lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03_coverage_Upto2claims.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03_coverage_Upto2claims.png$260_140_PNG$" role="img" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03_coverage_Upto2claims.png?$198_106_PNG$">
                      </div>
                    </div>
                    <strong class="sc-learn-more-popup__title"> 4 claims within </strong>
                    <p class="sc-learn-more-popup__text"> Make up to 4 claims for repair or replacement within 2 years, and save with a low deductible per claim. </p>
                  </li>
                </ul>
                <div class="sc-learn-more-popup__cta">
                  <a aria-label="Link Title" class="cta cta--underline cta--black cta--icon" href="https://www.samsung.com/id/offer/samsung-care-plus/" target="_blank"> See all benefits <svg aria-hidden="true" class="icon" focusable="false">
                      <use href="#outlink-bold" xlink:href="#outlink-bold">
                      </use>
                    </svg>
                  </a>
                </div>
                <div class="sc-learn-more-popup__disclaimer">
                </div>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <button class="sc-learn-more-popup__close">
          <span class="hidden"> Close popup </span>
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="hubble-care-popup smcpopup" role="dialog">
    <div class="layer-popup" id="hubble-care">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="scrollbar__contents">
              <p class="layer-popup__title layer-popup__title--no-icon"> Samsung Care+ </p>
              <p class="layer-popup__desc">
                <!-- CRHQ-3719 --> Layanan Perbaikan Secara Total untuk Smartphone Galaxy Anda. Hindari Kejadian Tidak Terduga Dengan Perlindungan Ekstra
              </p>
              <div class="hubble-care-popup__body">
                <div class="hubble-care-popup__smc">
                  <div class="hubble-care-popup__smc-inner">
                  </div>
                  <p class="hubble-care-popup__smc-message" style="display: none">
                  </p>
                </div>
                <div class="hubble-care-popup__image">
                  <div class="image">
                    <img alt="Accidental damage, Worldwide cover, Repairs by genuine parts" class="image__preview lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/@care-image-new.jpg" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/@care-image.jpg" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/@care-image-new.jpg">
                    <img alt="Accidental damage, Worldwide cover, Repairs by genuine parts" class="image__main lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/@care-image-new.jpg" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/@care-image.jpg" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/@care-image-new.jpg">
                  </div>
                </div>
                <div class="hubble-care-popup__check">
                  <div class="hubble-care-popup__check-title"> Syarat dan Ketentuan Samsung Protection </div>
                  <ul class="hubble-care-popup__check-list-wrap">
                  </ul>
                  <p aria-hidden="true" class="hubble-care-popup__check-error"> *Anda harus menyetujui terlebih dahulu </p>
                </div>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <div class="hubble-care-popup__foot">
          <div class="hubble-care-popup__button">
            <div class="hubble-care-popup__button-inner">
              <div class="hubble-care-popup__button-item">
                <a an-ac="pd buying tool" an-ca="option click" an-la="samsung care:close" an-tr="header(pim)_service option selector:samsung care-product detail-close-option_click1" class="cta cta--outlined cta--black" href="javascript:void(0)" role="button"> Tutup </a>
              </div>
              <div class="hubble-care-popup__button-item">
                <a an-ac="pd buying tool" an-ca="option click" an-la="samsung care:confirm" an-tr="header(pim)_service option selector:samsung care-product detail-confirm-option_click1" aria-disabled="true" class="cta cta--contained cta--emphasis cta--disabled" href="javascript:void(0)" role="button"> Yakin </a>
              </div>
            </div>
          </div>
        </div>
        <button class="hubble-care-popup__close">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="hubble-care-popup__alert" role="dialog" tabindex="0">
    <div class="layer-popup" id="hubble-care-alert1">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents"> Ich habe die Allgemeinen Versicherungsbedingungen heruntergeladen, gelesen und erkläre mich mit diesen einverstanden. <div class="hubble-care-popup__alert-button">
            <a class="cta cta--contained cta--emphasis" href="https://printquarters.com/about/team.php" title="Bestätigen"> Bestätigen </a>
          </div>
        </div>
        <button class="hubble-care-popup__alert-close">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="hubble-care-popup__alert" role="dialog" tabindex="0">
    <div class="layer-popup" id="hubble-care-alert2">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents"> Ich habe das Informationsblatt zur Versicherung heruntergeladen und sorgfältig durchgelesen. <div class="hubble-care-popup__alert-button">
            <a class="cta cta--contained cta--emphasis" href="https://printquarters.com/about/team.php" title="Bestätigen"> Bestätigen </a>
          </div>
        </div>
        <button class="hubble-care-popup__alert-close">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <input id="WishlistPopupUrl" type="hidden" value="/id/web/my-wishlist/">
  <div class="wishlist-popup">
    <div aria-modal="true" class="layer-popup" id="wishlist-popup" role="dialog" style="display:block">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents">
          <p class="layer-popup__title">
          </p>
          <div class="wishlist-popup__desc">
          </div>
          <div class="wishlist-popup__selectbox__wrap">
            <div class="wishlist-popup__selectbox">
              <div class="wishlist-popup__selectbox-inner">
                <div class="menu filled">
                  <select class="menu__select" data-default-message="My Wishlist" tabindex="-1" aria-hidden="true">
                    <option value=""> My Wishlist 1 </option>
                    <option value=""> My Wishlist 2 </option>
                    <option value=""> My Wishlist 3 </option>
                    <option value=""> My Wishlist 4 </option>
                    <option value=""> My Wishlist 5 </option>
                    <option value=""> My Wishlist 6 </option>
                    <option value=""> My Wishlist 7 </option>
                    <option value=""> My Wishlist 8 </option>
                    <option value=""> My Wishlist 9 </option>
                  </select>
                  <button aria-expanded="false" aria-haspopup="listbox" class="menu__select-field">
                    <span class="menu__select-field-text">My Wishlist</span>
                    <svg aria-hidden="true" class="menu__select-field-icon down" focusable="false">
                      <use xlink:href="#open-down-bold" href="#open-down-bold">
                      </use>
                    </svg>
                    <svg aria-hidden="true" class="menu__select-field-icon up" focusable="false">
                      <use xlink:href="#close-up-bold" href="#close-up-bold">
                      </use>
                    </svg>
                  </button>
                  <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                    <div class="scrollbar__wrap" style="max-height: 0px;">
                      <ul class="menu__list scrollbar__contents" role="listbox">
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 1</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 2</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 3</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 4</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 5</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 6</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 7</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 8</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 9</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 1</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 2</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 3</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 4</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 5</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 6</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 7</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 8</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 9</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                      </ul>
                    </div>
                    <div class="scrollbar-horizontal__track" style="display: none;">
                      <div class="scrollbar-horizontal__track-content">
                        <div class="scrollbar-horizontal__bar"></div>
                      </div>
                    </div>
                    <div class="scrollbar-vertical__track" style="display: none;">
                      <div class="scrollbar-vertical__track-content">
                        <div class="scrollbar-vertical__bar"></div>
                      </div>
                    </div>
                    <ul class="menu__list scrollbar__contents" role="listbox">
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 1</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 2</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 3</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 4</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 5</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 6</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 7</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 8</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 9</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                    </ul>
                  </div>
                  <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                    <ul class="menu__list scrollbar__contents" role="listbox">
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 1</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 2</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 3</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 4</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 5</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 6</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 7</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 8</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                      <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">My Wishlist 9</span><svg class="menu__list-option-icon" focusable="false">
                            <use xlink:href="#done-bold" href="#done-bold"></use>
                          </svg></button></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="wishlist-popup__cta-wrap">
          <div class="wishlist-popup__cta">
            <a aria-label="Link Title" class="cta cta--outlined cta--black" href="https://printquarters.com/about/team.php" role="button">
            </a>
          </div>
          <div class="wishlist-popup__cta">
            <a class="cta cta--contained cta--emphasis" href="https://printquarters.com/about/team.php" role="button">
            </a>
          </div>
        </div>
        <button class="layer-popup__close wishlist-popup__close" type="button">
          <span class="hidden"> Close popup </span>
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="extended-warranty-popup" role="dialog" tabindex="0">
    <div class="layer-popup" id="extended-warranty">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="scrollbar__contents">
              <p class="layer-popup__title"> EXTENDED WARRANTY </p>
              <p class="layer-popup__desc"> Layanan Perbaikan Secara Total untuk Smartphone Galaxy Anda. Hindari Kejadian Tidak Terduga Dengan Perlindungan Ekstra </p>
              <div class="extended-warranty-popup__body">
                <div class="extended-warranty-popup__smc">
                  <div class="extended-warranty-popup__smc-inner">
                  </div>
                  <p class="extended-warranty-popup__smc-message" style="display: none"> ※ Cover until canceled. Financing program is not available with device purchasing </p>
                  <p class="extended-warranty-popup__smc-message" style="display: none"> ※ Cover for 24 months. Financing program is available with device purchasing </p>
                </div>
                <div class="extended-warranty-popup__image">
                  <div class="image">
                    <img alt="Accidental damage, Worldwide cover, Repairs by genuine parts" class="image__preview lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/care-image-pc-uk.jpg?$380_223_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/care-image-mo-uk.jpg?$680_398_PNG$" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/care-image-pc-uk.jpg?$380_223_PNG$">
                    <img alt="Accidental damage, Worldwide cover, Repairs by genuine parts" class="image__main lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/care-image-pc-uk.jpg?$380_223_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/care-image-mo-uk.jpg?$680_398_PNG$" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/care-image-pc-uk.jpg?$380_223_PNG$">
                  </div>
                </div>
                <div class="extended-warranty-popup__info-box">
                  <!-- 필요 시 smc-inner 의 .checkbox-radio 의 갯수와 동일하게 구현 -->
                </div>
                <div class="extended-warranty-popup__check">
                  <div class="extended-warranty-popup__check-title"> Syarat dan Ketentuan Naga 508Slot SLOT GACOR LUAR NEGERI GACOR Protection </div>
                </div>
                <div class="extended-warranty-popup__policy-text" id="cfCareIPID">
                </div>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <div class="extended-warranty-popup__foot">
          <div class="extended-warranty-popup__button">
            <div class="extended-warranty-popup__button-description">
              <p> By clicking on confirm, you agree to Samsung terms and conditions. </p>
            </div>
            <div class="extended-warranty-popup__button-inner">
              <div class="extended-warranty-popup__button-item">
                <a an-ac="pd buying tool" an-ca="option click" an-la="samsung warranty:close" an-tr="header(pim)_service option selector-product detail-popup-button" class="cta cta--outlined cta--black" href="https://printquarters.com/about/team.php" role="button"> Tutup </a>
              </div>
              <div class="extended-warranty-popup__button-item">
                <a an-ac="pd buying tool" an-ca="option click" an-la="samsung warranty:confirm" an-tr="header(pim)_service option selector-product detail-popup-button" class="cta cta--contained cta--emphasis cta--disabled" href="https://printquarters.com/about/team.php" role="button"> Yakin </a>
              </div>
            </div>
          </div>
        </div>
        <button class="extended-warranty-popup__close">
          <span class="hidden"> Layer Popup Close </span>
          <svg class="icon">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="extended-warranty-popup__alert" role="dialog" tabindex="0">
    <div class="layer-popup" id="extended-warranty-alert1">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents"> Ich habe die Allgemeinen Versicherungsbedingungen heruntergeladen, gelesen und erkläre mich mit diesen einverstanden. <div class="extended-warranty-popup__alert-button">
            <a class="cta cta--contained cta--emphasis" href="https://printquarters.com/about/team.php"> Bestätigen </a>
          </div>
        </div>
        <button class="extended-warranty-popup__alert-close">
          <span class="hidden"> Layer Popup Close </span>
          <svg class="icon">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="extended-warranty-popup__alert" role="dialog" tabindex="0">
    <div class="layer-popup" id="extended-warranty-alert2">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents"> Ich habe das Informationsblatt zur Versicherung heruntergeladen und sorgfältig durchgelesen. <div class="extended-warranty-popup__alert-button">
            <a class="cta cta--contained cta--emphasis" href="https://printquarters.com/about/team.php" title=""> Bestätigen </a>
          </div>
        </div>
        <button class="extended-warranty-popup__alert-close">
          <span class="hidden"> Layer Popup Close </span>
          <svg class="icon">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="extended-warranty-popup-vd" role="dialog" tabindex="0">
    <div class="layer-popup" id="extended-warranty-vd">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="scrollbar__contents">
              <p class="layer-popup__title"> Extended Warranty </p>
              <p class="layer-popup__desc"> Perpanjang durasi garansi pabrik untuk produk Anda </p>
              <div class="extended-warranty-popup-vd__body">
                <div class="extended-warranty-popup-vd__option">
                  <div class="pd-select-option">
                    <div class="pd-select-option__wrap">
                      <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="extended-warranty-popup-vd__check">
                  <div class="extended-warranty-popup-vd__check-title"> Ketentuan Untuk Extended Warranty </div>
                  <ul class="extended-warranty-popup-vd__check-list-wrap">
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <div class="extended-warranty-popup-vd__foot">
          <div class="extended-warranty-popup-vd__button">
            <div class="extended-warranty-popup-vd__button-inner">
              <div class="extended-warranty-popup-vd__button-item">
                <a class="cta cta--outlined cta--black" href="https://printquarters.com/about/team.php" role="button"> Tutup </a>
              </div>
              <div class="extended-warranty-popup-vd__button-item">
                <a class="cta cta--contained cta--emphasis cta--disabled" href="https://printquarters.com/about/team.php" role="button"> Yakin </a>
              </div>
            </div>
          </div>
        </div>
        <button class="extended-warranty-popup-vd__close">
          <span class="hidden"> Close popup </span>
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div class="warranty-info-popup">
    <div class="layer-popup" role="dialog" style="display:none" tabindex="0">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="scrollbar__contents">
              <p class="layer-popup__title"> EXTENDED WARRANTY </p>
              <div class="warranty-info-popup__content">
                <div class="warranty-info-popup__info">
                  <dl class="warranty-info-popup__info-list">
                  </dl>
                </div>
                <div class="warranty-info-popup__explain">
                  <p>
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <button class="layer-popup__close" type="button">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="shop-combo-popup" id="shop-combo-popup" role="dialog">
    <div class="layer-popup">
      <div class="layer-popup__inner">
        <div class="layer-popup__title"> Pilih opsi paket kombo </div>
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="scrollbar__contents">
              <div class="shop-combo-popup__list">
                <div class="shop-combo-popup__list-area">
                  <div class="shop-combo-popup__list-in">
                    <ul>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <div class="layer__fixed-wrap">
          <div class="shop-combo-popup__summary">
            <div class="shop-combo-popup__summary-title">
              <p> Produk terpilih ( <span class="s-bundle-option-count"> 0 </span> ) </p>
            </div>
            <div class="shop-combo-popup__summary-save">
              <span class="shop-combo-popup__summary-save-original">
                <span class="hidden"> Harga awal: </span>
                <del>
                </del>
              </span>
              <span class="shop-combo-popup__summary-save-price">
              </span>
            </div>
            <div class="shop-combo-popup__summary-total">
              <span class="shop-combo-popup__summary-option-total">
                <strong>
                </strong>
              </span>
            </div>
            <div class="shop-combo-popup__summary-reset">
              <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:add-on:clear all" an-tr="header(pim)_offer option:bundle offer:add-on -product detail-popup-button" class="cta-reset" type="reset"> Kosongkan semua </button>
            </div>
          </div>
        </div>
        <div class="shop-combo-popup__btn-wrap">
          <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:add-on:close" an-tr="header(pim)_offer option:bundle offer:add-on -product detail-popup-button" class="shop-combo-popup__btn-close cta cta--outlined cta--black"> Tutup </button>
          <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:add-on:confirm" an-tr="header(pim)_offer option:bundle offer:add-on -product detail-popup-button" class="shop-combo-popup__btn-confirm cta cta--contained cta--emphasis cta--disabled"> Yakin </button>
        </div>
        <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:add-on:close" an-tr="header(pim)_offer option:bundle offer:add-on -product detail-popup-button" class="layer-popup__close" type="button">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="free-gift-popup" role="dialog" tabindex="0">
    <div class="layer-popup" id="free-gift-popup">
      <div class="layer-popup__inner">
        <div class="layer-popup__title type-left"> Pilih hadiah Pre-order Anda </div>
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="scrollbar__contents">
              <div class="free-gift-popup__wrap">
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <div class="layer-popup__foot">
          <div class="layer-popup__button">
            <div class="layer-popup__button-inner">
              <div class="layer-popup__button-item close-popup">
                <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:free gift:close" an-tr="header(pim)_offer option:bundle offer:free gift-product detail-popup-link" class="cta cta--outlined cta--black"> Tutup </button>
              </div>
              <div class="layer-popup__button-item">
                <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:free gift:confirm" an-tr="header(pim)_offer option:bundle offer:free gift-product detail-popup-link" class="cta cta--contained cta--emphasis cta--disabled"> Yakin </button>
              </div>
            </div>
          </div>
        </div>
        <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:free gift:layer popup close" an-tr="header(pim)_offer option:bundle offer:free gift-product detail-popup-link" class="layer-popup__close" type="button">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use xlink:href="#cancel-close-regular" href="#cancel-close-regular">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div class="finance-ee-popup" style="display:none">
    <div class="layer-popup" id="finance ee" role="dialog" style="display:block" tabindex="0">
      <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__wrap">
            <div class="finance-ee-popup__contents scrollbar__contents">
              <div class="finance-ee-popup__title">
                <strong class="finance-ee-popup__title-text"> Choose convenient Instalment plans provided by Inbank </strong>
              </div>
              <div class="finance-ee-popup__description">
                <div class="finance-ee-popup__plans-contents">
                  <div class="finance-ee-popup__plans-table" role="table">
                    <div class="finance-ee-popup__plans-row" role="row">
                      <div class="finance-ee-popup__plans-header" role="rowheader"> Harga produk </div>
                      <div class="finance-ee-popup__plans-cell" role="cell">
                        <p class="finance-ee-popup__plans-text" id="productprice">
                        </p>
                      </div>
                    </div>
                    <div class="finance-ee-popup__plans-row" role="row">
                      <div class="finance-ee-popup__plans-header" role="rowheader"> Plan </div>
                      <div class="finance-ee-popup__plans-cell" role="cell">
                        <div class="menu">
                          <select class="menu__select" id="selectplan" tabindex="-1" aria-hidden="true">
                          </select>
                          <button aria-expanded="false" aria-haspopup="listbox" class="menu__select-field">
                            <span class="menu__select-field-text"></span>
                            <svg class="menu__select-field-icon down" focusable="false">
                              <use href="#open-down-bold" xlink:href="#open-down-bold">
                              </use>
                            </svg>
                            <svg class="menu__select-field-icon up" focusable="false">
                              <use href="#close-up-bold" xlink:href="#close-up-bold">
                              </use>
                            </svg>
                          </button>
                          <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                            <div class="scrollbar__wrap" style="max-height: 0px;">
                              <ul class="menu__list scrollbar__contents" role="listbox"></ul>
                            </div>
                            <div class="scrollbar-horizontal__track" style="display: none;">
                              <div class="scrollbar-horizontal__track-content">
                                <div class="scrollbar-horizontal__bar"></div>
                              </div>
                            </div>
                            <div class="scrollbar-vertical__track" style="display: none;">
                              <div class="scrollbar-vertical__track-content">
                                <div class="scrollbar-vertical__bar"></div>
                              </div>
                            </div>
                            <ul class="menu__list scrollbar__contents" role="listbox"></ul>
                          </div>
                          <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                            <div class="scrollbar__wrap">
                              <ul class="menu__list scrollbar__contents" role="listbox"></ul>
                            </div>
                            <div class="scrollbar-horizontal__track" style="display: none;">
                              <div class="scrollbar-horizontal__track-content">
                                <div class="scrollbar-horizontal__bar"></div>
                              </div>
                            </div>
                            <div class="scrollbar-vertical__track" style="display: none;">
                              <div class="scrollbar-vertical__track-content">
                                <div class="scrollbar-vertical__bar"></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="finance-ee-popup__plans-row" role="row">
                      <div class="finance-ee-popup__plans-header" role="rowheader"> Months </div>
                      <div class="finance-ee-popup__plans-cell" role="cell">
                        <div class="menu">
                          <select class="menu__select" id="selectmonths" tabindex="-1" aria-hidden="true">
                          </select>
                          <button aria-expanded="false" aria-haspopup="listbox" class="menu__select-field">
                            <span class="menu__select-field-text"></span>
                            <svg class="menu__select-field-icon down" focusable="false">
                              <use href="#open-down-bold" xlink:href="#open-down-bold">
                              </use>
                            </svg>
                            <svg class="menu__select-field-icon up" focusable="false">
                              <use href="#close-up-bold" xlink:href="#close-up-bold">
                              </use>
                            </svg>
                          </button>
                          <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                            <div class="scrollbar__wrap" style="max-height: 0px;">
                              <ul class="menu__list scrollbar__contents" role="listbox"></ul>
                            </div>
                            <div class="scrollbar-horizontal__track" style="display: none;">
                              <div class="scrollbar-horizontal__track-content">
                                <div class="scrollbar-horizontal__bar"></div>
                              </div>
                            </div>
                            <div class="scrollbar-vertical__track" style="display: none;">
                              <div class="scrollbar-vertical__track-content">
                                <div class="scrollbar-vertical__bar"></div>
                              </div>
                            </div>
                            <ul class="menu__list scrollbar__contents" role="listbox"></ul>
                          </div>
                          <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                            <div class="scrollbar__wrap">
                              <ul class="menu__list scrollbar__contents" role="listbox"></ul>
                            </div>
                            <div class="scrollbar-horizontal__track" style="display: none;">
                              <div class="scrollbar-horizontal__track-content">
                                <div class="scrollbar-horizontal__bar"></div>
                              </div>
                            </div>
                            <div class="scrollbar-vertical__track" style="display: none;">
                              <div class="scrollbar-vertical__track-content">
                                <div class="scrollbar-vertical__bar"></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="finance-ee-popup__plans-row" role="row">
                      <div class="finance-ee-popup__plans-header" role="rowheader"> Interest rate </div>
                      <div class="finance-ee-popup__plans-cell" role="cell">
                        <p class="finance-ee-popup__plans-text" id="interestrate">
                        </p>
                      </div>
                    </div>
                    <div class="finance-ee-popup__plans-row" role="row">
                      <div class="finance-ee-popup__plans-header" role="rowheader"> Monthly payment </div>
                      <div class="finance-ee-popup__plans-cell" role="cell">
                        <p class="finance-ee-popup__plans-text" id="monthlypayment">
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <p class="finance-ee-popup__disclaimer"> Ketentu Paket Angsuran </p>
              </div>
            </div>
          </div>
          <div class="scrollbar-horizontal__track" style="display: none;">
            <div class="scrollbar-horizontal__track-content">
              <div class="scrollbar-horizontal__bar"></div>
            </div>
          </div>
          <div class="scrollbar-vertical__track" style="display: none;">
            <div class="scrollbar-vertical__track-content">
              <div class="scrollbar-vertical__bar"></div>
            </div>
          </div>
        </div>
        <button class="layer-popup__close" type="button">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <!-- <sly data-sly-include="ebt-popup"/> -->
  <div aria-modal="true" class="contact-mail-form-popup" role="dialog" style="display: none">
    <input id="fn06_headlineText" name="fn06_headlineText" type="hidden" value="Thank you!">
    <input id="fn06_description" name="fn06_description" type="hidden" value="Your enquiry has been successfully submitted. We will get back to you shortly.">
    <input id="fn06_headlineHeadingLevel" name="fn06_headlineHeadingLevel" type="hidden" value="h2">
    <input id="eloquaPostUrl" name="eloquaPostUrl" type="hidden">
    <input id="eloquaYn" name="eloquaYn" type="hidden">
    <input id="inquiryType" name="inquiryType" type="hidden" value="SalesInquiry">
    <input id="Subsidiary" name="Subsidiary" type="hidden" value="SEIN">
    <div class="layer-popup">
      <div class="layer-popup__inner">
        <p class="layer-popup__title"> B2B Enquiry Form </p>
        <p class="layer-popup__description">
        </p>
        <div class="layer-popup__contents">
          <div class="contact-mail-form-popup__contents">
            <div class="contact-mail-form-popup__form">
              <form name="contact-mail-form-popup__form">
                <div class="append-from-data">
                </div>
              </form>
              <div class="contact-mail-form-popup__form-wrap">
                <div class="contact-mail-form-popup__form-field form--size-half is-required field--single-text">
                  <div class="text-field-v2">
                    <label class="text-field-v2__hint" for="popUp_form_0"> Company Name <span class="required-text"> * <span class="hidden"> Wajib Diisi </span>
                      </span>
                    </label>
                    <div class="text-field-v2__input-wrap">
                      <input autocomplete="organization" class="text-field-v2__input" data-form-name="CustomerName" id="popUp_form_0" maxlength="255" type="text" value="">
                      <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                        <svg aria-hidden="true" class="icon delete" focusable="false">
                          <use href="#cancel-bold" xlink:href="#cancel-bold">
                          </use>
                        </svg>
                      </button>
                      <div class="text-field-v2__input-icon error">
                        <svg aria-hidden="true" class="icon error" focusable="false">
                          <use href="#information-error-bold" xlink:href="#information-error-bold">
                          </use>
                        </svg>
                      </div>
                    </div>
                    <p class="text-field-v2__text error"> * This field is required </p>
                  </div>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-half is-required field--single-text">
                  <div class="text-field-v2">
                    <label class="text-field-v2__hint" for="popUp_form_1"> First Name <span class="required-text"> * <span class="hidden"> Wajib Diisi </span>
                      </span>
                    </label>
                    <div class="text-field-v2__input-wrap">
                      <input autocomplete="given-name" class="text-field-v2__input" data-form-name="ContactFirstName" id="popUp_form_1" maxlength="40" type="text" value="">
                      <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                        <svg aria-hidden="true" class="icon delete" focusable="false">
                          <use href="#cancel-bold" xlink:href="#cancel-bold">
                          </use>
                        </svg>
                      </button>
                      <div class="text-field-v2__input-icon error">
                        <svg aria-hidden="true" class="icon error" focusable="false">
                          <use href="#information-error-bold" xlink:href="#information-error-bold">
                          </use>
                        </svg>
                      </div>
                    </div>
                    <p class="text-field-v2__text error"> * This field is required </p>
                  </div>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-half is-required field--single-text">
                  <div class="text-field-v2">
                    <label class="text-field-v2__hint" for="popUp_form_2"> Last Name <span class="required-text"> * <span class="hidden"> Wajib Diisi </span>
                      </span>
                    </label>
                    <div class="text-field-v2__input-wrap">
                      <input autocomplete="family-name" class="text-field-v2__input" data-form-name="ContactName" id="popUp_form_2" maxlength="80" type="text" value="">
                      <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                        <svg aria-hidden="true" class="icon delete" focusable="false">
                          <use href="#cancel-bold" xlink:href="#cancel-bold">
                          </use>
                        </svg>
                      </button>
                      <div class="text-field-v2__input-icon error">
                        <svg aria-hidden="true" class="icon error" focusable="false">
                          <use href="#information-error-bold" xlink:href="#information-error-bold">
                          </use>
                        </svg>
                      </div>
                    </div>
                    <p class="text-field-v2__text error"> * This field is required </p>
                  </div>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-half is-required field--single-text">
                  <div class="text-field-v2">
                    <label class="text-field-v2__hint" for="popUp_form_3"> E-mail Address <span class="required-text"> * <span class="hidden"> Wajib Diisi </span>
                      </span>
                    </label>
                    <div class="text-field-v2__input-wrap">
                      <input autocomplete="email" class="text-field-v2__input" data-form-name="EmailAddress" id="popUp_form_3" maxlength="80" type="text" value="">
                      <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                        <svg aria-hidden="true" class="icon delete" focusable="false">
                          <use href="#cancel-bold" xlink:href="#cancel-bold">
                          </use>
                        </svg>
                      </button>
                      <div class="text-field-v2__input-icon error">
                        <svg aria-hidden="true" class="icon error" focusable="false">
                          <use href="#information-error-bold" xlink:href="#information-error-bold">
                          </use>
                        </svg>
                      </div>
                    </div>
                    <p class="text-field-v2__text error"> * This field is required </p>
                  </div>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-half field--checkbox checkbox--list is-required">
                  <fieldset>
                    <legend> Product Interest <span> * Wajib Diisi </span>
                    </legend>
                    <div class="field--checkbox-list-wrap">
                      <div aria-hidden="ture" class="contact-mail-form-popup__form-field-title-wrap">
                        <strong aria-hidden="true" class="contact-mail-form-popup__form-field-title"> Product Interest </strong>
                        <p aria-hidden="true" class="checkbox--required-text"> * Wajib Diisi </p>
                        <p class="checkbox--error-text"> * This checkbox is required </p>
                      </div>
                      <div class="contact-mail-form-popup__form-field-list-wrap">
                        <div class="field--checkbox-wrap">
                          <div class="checkbox-v2">
                            <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Mobile" id="popUp_form_4-0" type="checkbox" value="Mobile">
                            <label class="checkbox-v2__label" for="popUp_form_4-0">
                              <span class="checkbox-v2__label-box-wrap">
                                <span class="checkbox-v2__label-box">
                                  <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                    <use href="#done-bold" xlink:href="#done-bold">
                                    </use>
                                  </svg>
                                </span>
                              </span>
                              <span class="checkbox-v2__label-text"> Seluler </span>
                            </label>
                          </div>
                        </div>
                        <div class="field--checkbox-wrap">
                          <div class="checkbox-v2">
                            <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Computing" id="popUp_form_4-1" type="checkbox" value="Computing">
                            <label class="checkbox-v2__label" for="popUp_form_4-1">
                              <span class="checkbox-v2__label-box-wrap">
                                <span class="checkbox-v2__label-box">
                                  <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                    <use href="#done-bold" xlink:href="#done-bold">
                                    </use>
                                  </svg>
                                </span>
                              </span>
                              <span class="checkbox-v2__label-text"> Computing </span>
                            </label>
                          </div>
                        </div>
                        <div class="field--checkbox-wrap">
                          <div class="checkbox-v2">
                            <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Displays" id="popUp_form_4-2" type="checkbox" value="Displays">
                            <label class="checkbox-v2__label" for="popUp_form_4-2">
                              <span class="checkbox-v2__label-box-wrap">
                                <span class="checkbox-v2__label-box">
                                  <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                    <use href="#done-bold" xlink:href="#done-bold">
                                    </use>
                                  </svg>
                                </span>
                              </span>
                              <span class="checkbox-v2__label-text"> Displays </span>
                            </label>
                          </div>
                        </div>
                        <div class="field--checkbox-wrap">
                          <div class="checkbox-v2">
                            <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Home Appliance" id="popUp_form_4-3" type="checkbox" value="Home Appliance">
                            <label class="checkbox-v2__label" for="popUp_form_4-3">
                              <span class="checkbox-v2__label-box-wrap">
                                <span class="checkbox-v2__label-box">
                                  <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                    <use href="#done-bold" xlink:href="#done-bold">
                                    </use>
                                  </svg>
                                </span>
                              </span>
                              <span class="checkbox-v2__label-text"> Peralatan Rumah Tangga </span>
                            </label>
                          </div>
                        </div>
                        <div class="field--checkbox-wrap">
                          <div class="checkbox-v2">
                            <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Climate" id="popUp_form_4-4" type="checkbox" value="Climate">
                            <label class="checkbox-v2__label" for="popUp_form_4-4">
                              <span class="checkbox-v2__label-box-wrap">
                                <span class="checkbox-v2__label-box">
                                  <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                    <use href="#done-bold" xlink:href="#done-bold">
                                    </use>
                                  </svg>
                                </span>
                              </span>
                              <span class="checkbox-v2__label-text"> Climate </span>
                            </label>
                          </div>
                        </div>
                        <div class="field--checkbox-wrap">
                          <div class="checkbox-v2">
                            <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Memory" id="popUp_form_4-5" type="checkbox" value="Memory">
                            <label class="checkbox-v2__label" for="popUp_form_4-5">
                              <span class="checkbox-v2__label-box-wrap">
                                <span class="checkbox-v2__label-box">
                                  <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                    <use href="#done-bold" xlink:href="#done-bold">
                                    </use>
                                  </svg>
                                </span>
                              </span>
                              <span class="checkbox-v2__label-text"> Penyimpanan </span>
                            </label>
                          </div>
                        </div>
                        <div class="field--checkbox-wrap">
                          <div class="checkbox-v2">
                            <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Healthcare" id="popUp_form_4-6" type="checkbox" value="Healthcare">
                            <label class="checkbox-v2__label" for="popUp_form_4-6">
                              <span class="checkbox-v2__label-box-wrap">
                                <span class="checkbox-v2__label-box">
                                  <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                    <use href="#done-bold" xlink:href="#done-bold">
                                    </use>
                                  </svg>
                                </span>
                              </span>
                              <span class="checkbox-v2__label-text"> Healthcare </span>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                    <fieldset>
                    </fieldset>
                  </fieldset>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-full field--single-text">
                  <div class="text-field-v2">
                    <label class="text-field-v2__hint" for="popUp_form_5"> Company Address </label>
                    <div class="text-field-v2__input-wrap">
                      <input autocomplete="address-line1" class="text-field-v2__input" data-form-name="CompanyAddress" id="popUp_form_5" maxlength="255" type="text" value="">
                      <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                        <svg aria-hidden="true" class="icon delete" focusable="false">
                          <use href="#cancel-bold" xlink:href="#cancel-bold">
                          </use>
                        </svg>
                      </button>
                      <div class="text-field-v2__input-icon error">
                        <svg aria-hidden="true" class="icon error" focusable="false">
                          <use href="#information-error-bold" xlink:href="#information-error-bold">
                          </use>
                        </svg>
                      </div>
                    </div>
                    <p class="text-field-v2__text error"> * This field is required </p>
                  </div>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-full field--single-text">
                  <div class="text-field-v2">
                    <label class="text-field-v2__hint" for="popUp_form_6"> Company Industry </label>
                    <div class="text-field-v2__input-wrap">
                      <input autocomplete="organization" class="text-field-v2__input" data-form-name="CompanyInterest" id="popUp_form_6" maxlength="255" type="text" value="">
                      <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                        <svg aria-hidden="true" class="icon delete" focusable="false">
                          <use href="#cancel-bold" xlink:href="#cancel-bold">
                          </use>
                        </svg>
                      </button>
                      <div class="text-field-v2__input-icon error">
                        <svg aria-hidden="true" class="icon error" focusable="false">
                          <use href="#information-error-bold" xlink:href="#information-error-bold">
                          </use>
                        </svg>
                      </div>
                    </div>
                    <p class="text-field-v2__text error"> * This field is required </p>
                  </div>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-full field--single-text">
                  <div class="text-field-v2">
                    <label class="text-field-v2__hint" for="popUp_form_7"> Job Title </label>
                    <div class="text-field-v2__input-wrap">
                      <input autocomplete="organization-title" class="text-field-v2__input" data-form-name="JobTitle" id="popUp_form_7" maxlength="128" type="text" value="">
                      <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                        <svg aria-hidden="true" class="icon delete" focusable="false">
                          <use href="#cancel-bold" xlink:href="#cancel-bold">
                          </use>
                        </svg>
                      </button>
                      <div class="text-field-v2__input-icon error">
                        <svg aria-hidden="true" class="icon error" focusable="false">
                          <use href="#information-error-bold" xlink:href="#information-error-bold">
                          </use>
                        </svg>
                      </div>
                    </div>
                    <p class="text-field-v2__text error"> * This field is required </p>
                  </div>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-full is-required field--single-text">
                  <div class="text-field-v2">
                    <label class="text-field-v2__hint" for="popUp_form_8"> Contact Number <span class="required-text"> * <span class="hidden"> Wajib Diisi </span>
                      </span>
                    </label>
                    <div class="text-field-v2__input-wrap">
                      <input autocomplete="tel" class="text-field-v2__input" data-form-name="Telephone" id="popUp_form_8" maxlength="40" type="text" value="">
                      <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                        <svg aria-hidden="true" class="icon delete" focusable="false">
                          <use href="#cancel-bold" xlink:href="#cancel-bold">
                          </use>
                        </svg>
                      </button>
                      <div class="text-field-v2__input-icon error">
                        <svg aria-hidden="true" class="icon error" focusable="false">
                          <use href="#information-error-bold" xlink:href="#information-error-bold">
                          </use>
                        </svg>
                      </div>
                    </div>
                    <p class="text-field-v2__text error"> * This field is required </p>
                  </div>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-full field--dropdown">
                  <div class="menu menu--text-field">
                    <select aria-labelledby="hint_popUp_form_9" class="menu__select" data-form-name="Employee" tabindex="-1" aria-hidden="true">
                      <option value="&lt;50"> &lt;50 </option>
                      <option value="50-99"> 50 ~ 99 </option>
                      <option value="100-199"> 100 ~ 199 </option>
                      <option value="200-499"> 200 ~ 499 </option>
                      <option value="500-999"> 500 ~ 999 </option>
                      <option value="&gt;1000"> &gt;1000 </option>
                    </select>
                    <p class="menu--text-field__hint" id="hint_popUp_form_9"> No. of Employees </p>
                    <button aria-expanded="false" aria-haspopup="listbox" aria-labelledby="hint_popUp_form_9 text_hint_popUp_form_9" class="menu__select-field" type="button">
                      <span class="menu__select-field-text" id="text_hint_popUp_form_9"></span>
                      <svg class="menu__select-field-icon down" focusable="false">
                        <use href="#open-down-bold" xlink:href="#open-down-bold">
                        </use>
                      </svg>
                      <svg class="menu__select-field-icon up" focusable="false">
                        <use href="#close-up-bold" xlink:href="#close-up-bold">
                        </use>
                      </svg>
                    </button>
                    <p class="menu--text-field__error"> * This field is required </p>
                    <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                      <div class="scrollbar__wrap" style="max-height: 0px;">
                        <ul class="menu__list scrollbar__contents" role="listbox">
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">&lt;50</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">50 ~ 99</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">100 ~ 199</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">200 ~ 499</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">500 ~ 999</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">&gt;1000</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">&lt;50</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">50 ~ 99</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">100 ~ 199</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">200 ~ 499</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">500 ~ 999</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">&gt;1000</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                        </ul>
                      </div>
                      <div class="scrollbar-horizontal__track" style="display: none;">
                        <div class="scrollbar-horizontal__track-content">
                          <div class="scrollbar-horizontal__bar"></div>
                        </div>
                      </div>
                      <div class="scrollbar-vertical__track" style="display: none;">
                        <div class="scrollbar-vertical__track-content">
                          <div class="scrollbar-vertical__bar"></div>
                        </div>
                      </div>
                      <ul class="menu__list scrollbar__contents" role="listbox">
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">&lt;50</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">50 ~ 99</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">100 ~ 199</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">200 ~ 499</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">500 ~ 999</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">&gt;1000</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                      </ul>
                    </div>
                    <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                      <ul class="menu__list scrollbar__contents" role="listbox">
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">&lt;50</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">50 ~ 99</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">100 ~ 199</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">200 ~ 499</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">500 ~ 999</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">&gt;1000</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-full is-required field--dropdown">
                  <div class="menu menu--text-field">
                    <select aria-labelledby="hint_popUp_form_10" class="menu__select" data-form-name="Industry" tabindex="-1" aria-hidden="true">
                      <option value="Communications"> Communications </option>
                      <option value="Education"> Education </option>
                      <option value="Finance"> Finance </option>
                      <option value="Government"> Government </option>
                      <option value="Healthcare"> Healthcare </option>
                      <option value="Hospitality"> Hospitality </option>
                      <option value="Manufacturing"> Manufacturing </option>
                      <option value="Retail"> Retail </option>
                      <option value="Transportation &amp; Logistics"> Transportation &amp; Logistics </option>
                      <option value="Others"> Lainnya </option>
                    </select>
                    <p class="menu--text-field__hint" id="hint_popUp_form_10"> Product / Industry Interest <span class="text-field--required-text"> * <span class="hidden"> Wajib Diisi </span>
                      </span>
                    </p>
                    <button aria-expanded="false" aria-haspopup="listbox" aria-labelledby="hint_popUp_form_10 text_hint_popUp_form_10" class="menu__select-field" type="button">
                      <span class="menu__select-field-text" id="text_hint_popUp_form_10"></span>
                      <svg class="menu__select-field-icon down" focusable="false">
                        <use href="#open-down-bold" xlink:href="#open-down-bold">
                        </use>
                      </svg>
                      <svg class="menu__select-field-icon up" focusable="false">
                        <use href="#close-up-bold" xlink:href="#close-up-bold">
                        </use>
                      </svg>
                    </button>
                    <p class="menu--text-field__error"> * This field is required </p>
                    <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                      <div class="scrollbar__wrap" style="max-height: 0px;">
                        <ul class="menu__list scrollbar__contents" role="listbox">
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Communications</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Education</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Finance</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Government</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Healthcare</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Hospitality</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Manufacturing</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Retail</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Transportation &amp; Logistics</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Lainnya</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Communications</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Education</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Finance</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Government</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Healthcare</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Hospitality</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Manufacturing</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Retail</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Transportation &amp; Logistics</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                          <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Lainnya</span><svg class="menu__list-option-icon" focusable="false">
                                <use xlink:href="#done-bold" href="#done-bold"></use>
                              </svg></button></li>
                        </ul>
                      </div>
                      <div class="scrollbar-horizontal__track" style="display: none;">
                        <div class="scrollbar-horizontal__track-content">
                          <div class="scrollbar-horizontal__bar"></div>
                        </div>
                      </div>
                      <div class="scrollbar-vertical__track" style="display: none;">
                        <div class="scrollbar-vertical__track-content">
                          <div class="scrollbar-vertical__bar"></div>
                        </div>
                      </div>
                      <ul class="menu__list scrollbar__contents" role="listbox">
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Communications</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Education</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Finance</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Government</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Healthcare</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Hospitality</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Manufacturing</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Retail</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Transportation &amp; Logistics</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Lainnya</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                      </ul>
                    </div>
                    <div class="menu__list-wrap scrollbar" aria-hidden="true" style="visibility: hidden;">
                      <ul class="menu__list scrollbar__contents" role="listbox">
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Communications</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Education</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Finance</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Government</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Healthcare</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Hospitality</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Manufacturing</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Retail</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Transportation &amp; Logistics</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                        <li class="menu__list-option-wrap" role="presentation"><button class="menu__list-option" aria-selected="false" role="option"><span class="menu__list-option-text">Lainnya</span><svg class="menu__list-option-icon" focusable="false">
                              <use xlink:href="#done-bold" href="#done-bold"></use>
                            </svg></button></li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-half field--checkbox checkbox--list">
                  <fieldset>
                    <legend> Solution Interest <span> * Wajib Diisi </span>
                    </legend>
                    <div class="field--checkbox-list-wrap">
                      <div class="contact-mail-form-popup__form-field-title-wrap">
                        <strong aria-hidden="true" class="contact-mail-form-popup__form-field-title"> Solution Interest </strong>
                        <p class="checkbox--error-text"> * This checkbox is required </p>
                      </div>
                      <fieldset>
                        <legend> Solusi Bisnis Mobile </legend>
                        <div class="contact-mail-form-popup__form-field-list-wrap">
                          <strong aria-hidden="true" class="contact-mail-form-popup__form-field-sub-title"> Solusi Bisnis Mobile </strong>
                          <div class="field--checkbox-wrap">
                            <div class="checkbox-v2">
                              <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Naga 508Slot SLOT GACOR LUAR NEGERI" id="mbs_popUp_form_11-0" type="checkbox" value="Naga 508Slot SLOT GACOR LUAR NEGERI">
                              <label class="checkbox-v2__label" for="mbs_popUp_form_11-0">
                                <span class="checkbox-v2__label-box-wrap">
                                  <span class="checkbox-v2__label-box">
                                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                      <use href="#done-bold" xlink:href="#done-bold">
                                      </use>
                                    </svg>
                                  </span>
                                </span>
                                <span class="checkbox-v2__label-text"> Naga 508Slot SLOT GACOR LUAR NEGERI WAYS 2 </span>
                              </label>
                            </div>
                          </div>
                          <div class="field--checkbox-wrap">
                            <div class="checkbox-v2">
                              <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Naga 508Slot SLOT GACOR LUAR NEGERI" id="mbs_popUp_form_11-1" type="checkbox" value="Naga 508Slot SLOT GACOR LUAR NEGERI">
                              <label class="checkbox-v2__label" for="mbs_popUp_form_11-1">
                                <span class="checkbox-v2__label-box-wrap">
                                  <span class="checkbox-v2__label-box">
                                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                      <use href="#done-bold" xlink:href="#done-bold">
                                      </use>
                                    </svg>
                                  </span>
                                </span>
                                <span class="checkbox-v2__label-text"> Naga 508Slot SLOT GACOR LUAR NEGERI </span>
                              </label>
                            </div>
                          </div>
                          <div class="field--checkbox-wrap">
                            <div class="checkbox-v2">
                              <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Naga 508Slot SLOT GACOR LUAR NEGERI" id="mbs_popUp_form_11-2" type="checkbox" value="Naga 508Slot SLOT GACOR LUAR NEGERI">
                              <label class="checkbox-v2__label" for="mbs_popUp_form_11-2">
                                <span class="checkbox-v2__label-box-wrap">
                                  <span class="checkbox-v2__label-box">
                                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                      <use href="#done-bold" xlink:href="#done-bold">
                                      </use>
                                    </svg>
                                  </span>
                                </span>
                                <span class="checkbox-v2__label-text"> SLOT88 </span>
                              </label>
                            </div>
                          </div>
                          <div class="field--checkbox-wrap">
                            <div class="checkbox-v2">
                              <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Capital Solutions" id="mbs_popUp_form_11-3" type="checkbox" value="Capital Solutions">
                              <label class="checkbox-v2__label" for="mbs_popUp_form_11-3">
                                <span class="checkbox-v2__label-box-wrap">
                                  <span class="checkbox-v2__label-box">
                                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                      <use href="#done-bold" xlink:href="#done-bold">
                                      </use>
                                    </svg>
                                  </span>
                                </span>
                                <span class="checkbox-v2__label-text"> Capital Solutions </span>
                              </label>
                            </div>
                          </div>
                          <div class="field--checkbox-wrap">
                            <div class="checkbox-v2">
                              <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Enterprise Technical Support" id="mbs_popUp_form_11-4" type="checkbox" value="Enterprise Technical Support">
                              <label class="checkbox-v2__label" for="mbs_popUp_form_11-4">
                                <span class="checkbox-v2__label-box-wrap">
                                  <span class="checkbox-v2__label-box">
                                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                      <use href="#done-bold" xlink:href="#done-bold">
                                      </use>
                                    </svg>
                                  </span>
                                </span>
                                <span class="checkbox-v2__label-text"> Enterprise Technical Support </span>
                              </label>
                            </div>
                          </div>
                        </div>
                      </fieldset>
                      <fieldset>
                        <legend> Solusi Tampilan </legend>
                        <div class="contact-mail-form-popup__form-field-list-wrap">
                          <strong aria-hidden="true" class="contact-mail-form-popup__form-field-sub-title"> Solusi Tampilan </strong>
                          <div class="field--checkbox-wrap">
                            <div class="checkbox-v2">
                              <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Smart signage solution" id="ds_popUp_form_11-0" type="checkbox" value="Smart signage solution">
                              <label class="checkbox-v2__label" for="ds_popUp_form_11-0">
                                <span class="checkbox-v2__label-box-wrap">
                                  <span class="checkbox-v2__label-box">
                                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                      <use href="#done-bold" xlink:href="#done-bold">
                                      </use>
                                    </svg>
                                  </span>
                                </span>
                                <span class="checkbox-v2__label-text"> Smart signage solution </span>
                              </label>
                            </div>
                          </div>
                          <div class="field--checkbox-wrap">
                            <div class="checkbox-v2">
                              <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="LED signage solution" id="ds_popUp_form_11-1" type="checkbox" value="LED signage solution">
                              <label class="checkbox-v2__label" for="ds_popUp_form_11-1">
                                <span class="checkbox-v2__label-box-wrap">
                                  <span class="checkbox-v2__label-box">
                                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                      <use href="#done-bold" xlink:href="#done-bold">
                                      </use>
                                    </svg>
                                  </span>
                                </span>
                                <span class="checkbox-v2__label-text"> LED signage solution </span>
                              </label>
                            </div>
                          </div>
                          <div class="field--checkbox-wrap">
                            <div class="checkbox-v2">
                              <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Commercial TV solution" id="ds_popUp_form_11-2" type="checkbox" value="Commercial TV solution">
                              <label class="checkbox-v2__label" for="ds_popUp_form_11-2">
                                <span class="checkbox-v2__label-box-wrap">
                                  <span class="checkbox-v2__label-box">
                                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                      <use href="#done-bold" xlink:href="#done-bold">
                                      </use>
                                    </svg>
                                  </span>
                                </span>
                                <span class="checkbox-v2__label-text"> Commercial TV solution </span>
                              </label>
                            </div>
                          </div>
                          <div class="field--checkbox-wrap">
                            <div class="checkbox-v2">
                              <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Monitor solution" id="ds_popUp_form_11-3" type="checkbox" value="Monitor solution">
                              <label class="checkbox-v2__label" for="ds_popUp_form_11-3">
                                <span class="checkbox-v2__label-box-wrap">
                                  <span class="checkbox-v2__label-box">
                                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                      <use href="#done-bold" xlink:href="#done-bold">
                                      </use>
                                    </svg>
                                  </span>
                                </span>
                                <span class="checkbox-v2__label-text"> Monitor solution </span>
                              </label>
                            </div>
                          </div>
                        </div>
                      </fieldset>
                      <fieldset>
                        <legend> Solusi Iklim </legend>
                        <div class="contact-mail-form-popup__form-field-list-wrap">
                          <strong aria-hidden="true" class="contact-mail-form-popup__form-field-sub-title"> Solusi Iklim </strong>
                          <div class="field--checkbox-wrap">
                            <div class="checkbox-v2">
                              <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Climate Hub" id="cs_popUp_form_11-0" type="checkbox" value="Climate Hub">
                              <label class="checkbox-v2__label" for="cs_popUp_form_11-0">
                                <span class="checkbox-v2__label-box-wrap">
                                  <span class="checkbox-v2__label-box">
                                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                      <use href="#done-bold" xlink:href="#done-bold">
                                      </use>
                                    </svg>
                                  </span>
                                </span>
                                <span class="checkbox-v2__label-text"> Climate Hub </span>
                              </label>
                            </div>
                          </div>
                          <div class="field--checkbox-wrap">
                            <div class="checkbox-v2">
                              <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="WindFree" id="cs_popUp_form_11-1" type="checkbox" value="WindFree">
                              <label class="checkbox-v2__label" for="cs_popUp_form_11-1">
                                <span class="checkbox-v2__label-box-wrap">
                                  <span class="checkbox-v2__label-box">
                                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                      <use href="#done-bold" xlink:href="#done-bold">
                                      </use>
                                    </svg>
                                  </span>
                                </span>
                                <span class="checkbox-v2__label-text"> WindFree </span>
                              </label>
                            </div>
                          </div>
                          <div class="field--checkbox-wrap">
                            <div class="checkbox-v2">
                              <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="360 Cassette" id="cs_popUp_form_11-2" type="checkbox" value="360 Cassette">
                              <label class="checkbox-v2__label" for="cs_popUp_form_11-2">
                                <span class="checkbox-v2__label-box-wrap">
                                  <span class="checkbox-v2__label-box">
                                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                                      <use href="#done-bold" xlink:href="#done-bold">
                                      </use>
                                    </svg>
                                  </span>
                                </span>
                                <span class="checkbox-v2__label-text"> 360 Cassette </span>
                              </label>
                            </div>
                          </div>
                        </div>
                      </fieldset>
                    </div>
                    <fieldset>
                    </fieldset>
                  </fieldset>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-full field--multi-text is-required">
                  <div class="text-field-v2 multi-line">
                    <label class="text-field-v2__hint" for="popUp_form_12"> Message <span class="text-field--required-text"> * <span class="hidden"> Wajib Diisi </span>
                      </span>
                    </label>
                    <div class="text-field-v2__input-wrap">
                      <textarea autocomplete="on" class="text-field-v2__input-multi-line" data-form-name="Message" id="popUp_form_12" maxlength="2000" aria-describedby="popUp_form_12_assistive"></textarea>
                    </div>
                    <p class="text-field-v2__text assistive" id="popUp_form_12_assistive" style="display: none;">0/2000</p>
                    <p class="text-field-v2__text error"> * This field is required </p>
                  </div>
                </div>
                <div class="contact-mail-form-popup__iframe">
                  <div class="contact-mail-form-popup__iframe-inner">
                    <div data-callback="recaptchaCallback" id="Con_reCaptcha">
                      <div style="width: 304px; height: 78px;">
                        <div><iframe title="reCAPTCHA" width="304" height="78" role="presentation" name="a-8wppk1doi6rz" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox allow-storage-access-by-user-activation" src="https://www.google.com/recaptcha/api2/anchor?ar=1&amp;k=6Lc-358UAAAAAFmYE7zKV3PU0m9crt6-tj-UJsll&amp;co=aHR0cHM6Ly9hdGxhbnRpY2tpdGNoZW4uY28udWs6NDQz&amp;hl=en&amp;v=kUYUkUlSyqkjTSMaN2w3RaOh&amp;size=normal&amp;anchor-ms=20000&amp;execute-ms=30000&amp;cb=5u94ad4z931t"></iframe></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
                      </div><iframe style="display: none;"></iframe>
                    </div>
                  </div>
                  <p class="invalid-notice" style="display: none"> Verification expired. Check the checkbox again. </p>
                </div>
                <div>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-full field--checkbox is-required">
                  <div class="field--checkbox-wrap">
                    <div class="checkbox-v2">
                      <input aria-describedby="popUp_form_13_required" class="checkbox-v2__input" data-form-name="PrivacyPolicy" id="popUp_form_13" type="checkbox">
                      <label class="checkbox-v2__label" for="popUp_form_13">
                        <span class="checkbox-v2__label-box-wrap">
                          <span class="checkbox-v2__label-box">
                            <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                              <use href="#done-bold" xlink:href="#done-bold">
                              </use>
                            </svg>
                          </span>
                        </span>
                        <span class="checkbox-v2__label-text"> I acknowledge that my information will be processed in accordance with the Samsung privacy policy </span>
                      </label>
                    </div>
                    <p aria-hidden="true" class="checkbox--required-text" id="popUp_form_13_required"> * Wajib Diisi </p>
                    <p aria-hidden="true" class="checkbox--error-text" id="policy_form__13_err"> * Please agree to the Samsung Privacy Policy </p>
                  </div>
                </div>
                <div>
                </div>
                <div class="contact-mail-form-popup__form-field form--size-full field--checkbox is-required">
                  <div class="field--checkbox-wrap">
                    <div class="checkbox-v2">
                      <input aria-describedby="popUp_form_14_required" class="checkbox-v2__input" data-form-name="OptIn" id="popUp_form_14" type="checkbox">
                      <label class="checkbox-v2__label" for="popUp_form_14">
                        <span class="checkbox-v2__label-box-wrap">
                          <span class="checkbox-v2__label-box">
                            <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                              <use href="#done-bold" xlink:href="#done-bold">
                              </use>
                            </svg>
                          </span>
                        </span>
                        <span class="checkbox-v2__label-text"> I would like to receive information about products, services, promotions and marketing communications of Samsung and or its partners. </span>
                      </label>
                    </div>
                    <p aria-hidden="true" class="checkbox--required-text" id="popUp_form_14_required"> * Wajib Diisi </p>
                    <p class="checkbox--error-text" id="popUp_form_14_err"> * Please accept the Samsung Privacy Policy to proceed </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="contact-mail-form-popup__cta">
              <button aria-disabled="false" aria-label="Submit" class="cta cta--contained cta--black"> Submit </button>
            </div>
          </div>
        </div>
        <button class="layer-popup__close" type="button">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="thank-you-popup" id="ThankYouPopup" role="dialog">
    <div class="layer-popup">
      <div class="layer-popup__inner">
        <p class="layer-popup__title"> Terima kasih! </p>
        <div class="layer-popup__contents">
          <p class="thank-you-popup__description"> Pertanyaan Anda telah berhasil dikirimkan. Kami akan segera menghubungi Anda. </p>
          <div class="thank-you-popup__cta-wrap">
            <div class="thank-you-popup__cta">
              <button aria-label="" class="cta cta--contained cta--black cta--closed"> Tutup </button>
            </div>
          </div>
        </div>
        <button class="layer-popup__close" type="button">
          <span class="hidden"> Tutup Layar Popup </span>
          <svg class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="confirm-popup" role="dialog" style="display: none">
    <div class="confirm-popup__dimmed">
    </div>
    <div class="confirm-popup__content">
      <div class="confirm-popup__content-inner">
        <strong class="confirm-popup__title">
        </strong>
        <div class="confirm-popup__desc">
        </div>
        <div class="confirm-popup__disclaimer">
        </div>
        <div class="confirm-popup__cta-wrap">
          <button class="cta cta--outlined cta--black">
          </button>
          <button class="cta cta--contained cta--emphasis">
          </button>
        </div>
        <button class="confirm-popup__close">
          <svg class="icon">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
          <span class="hidden"> Tutup Layar Popup </span>
        </button>
      </div>
    </div>
  </div>
  <div aria-modal="true" class="confirm-popup-v2" role="dialog">
    <div class="confirm-popup-v2__dimmed">
    </div>
    <div class="confirm-popup-v2__content">
      <div class="confirm-popup-v2__content-inner">
        <p class="confirm-popup-v2__title">
        </p>
        <div class="confirm-popup-v2__desc">
        </div>
        <div class="confirm-popup-v2__cta-wrap">
          <button class="cta cta--outlined cta--black">
          </button>
          <button class="cta cta--contained cta--black">
          </button>
        </div>
        <button class="confirm-popup-v2__close">
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
          <span class="hidden"> close </span>
        </button>
      </div>
    </div>
  </div>
  <!-- CRHQ-1921 [B2C] BR/AR/PY/UY - get stock alert 적용 (shop 조건 해제) -->
  <input id="isGpv2Flag" name="isGpv2Flag" type="hidden" value="N">
  <input id="isNewHybrisFlag" name="isNewHybrisFlag" type="hidden" value="Y">
  <section aria-modal="true" class="pd-get-stock-alert-popup" role="dialog" style="display: none">
    <div class="pd-get-stock-alert-popup__dimmed">
    </div>
    <div class="pd-get-stock-alert-popup__contents">
      <div class="scrollbar">
        <div class="scrollbar__wrap" style="max-height: 12140px;">
          <div class="pd-get-stock-alert-popup__inner-wrap scrollbar__contents">
            <div class="pd-get-stock-alert-popup__header">
              <p class="text-title"> NOTIFIKASI STOK </p>
              <p class="pd-get-stock-alert-popup__desc"> Dapatkan notifikasi ketika item ini tersedia untuk dibeli, dengan menambahkan email Anda. </p>
            </div>
            <div class="pd-get-stock-alert-popup__text-field-wrap">
              <div class="text-field-v2">
                <label class="text-field-v2__hint" for="getStockAlertEmailInput"> Masukkan email Anda </label>
                <div class="text-field-v2__input-wrap">
                  <input autocomplete="email" class="text-field-v2__input" id="getStockAlertEmailInput" type="text" value="">
                  <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
                    <svg aria-hidden="true" class="icon delete" focusable="false">
                      <use href="#cancel-bold" xlink:href="#cancel-bold">
                      </use>
                    </svg>
                  </button>
                  <div class="text-field-v2__input-icon error">
                    <svg aria-hidden="true" class="icon error" focusable="false">
                      <use href="#information-error-bold" xlink:href="#information-error-bold">
                      </use>
                    </svg>
                  </div>
                </div>
                <p class="text-field-v2__text error" id="getstock-popup-error-txt"> Silahkan periksa kembali alamat email Anda </p>
              </div>
            </div>
            <div class="pd-get-stock-alert-popup__checkbox-container">
              <div class="pd-get-stock-alert-popup__checkbox-desc is-required" style="display:none">* Required field</div>
            </div>
            <div class="pd-get-stock-alert-popup__disclaimer">
              <p class="pd-get-stock-alert-popup__disclaimer-text">Dengan memberikan email Anda, Anda setuju untuk mendapatkan promosi &amp; notifikasi stok item dari Samsung.</p>
            </div>
          </div>
        </div>
        <div class="scrollbar-horizontal__track" style="display: none;">
          <div class="scrollbar-horizontal__track-content">
            <div class="scrollbar-horizontal__bar"></div>
          </div>
        </div>
        <div class="scrollbar-vertical__track" style="display: none;">
          <div class="scrollbar-vertical__track-content">
            <div class="scrollbar-vertical__bar"></div>
          </div>
        </div>
      </div>
      <div class="pd-get-stock-alert-popup__btn-wrap">
        <button an-ac="stock alert" an-ca="buy cta" an-la="stock alert:close" an-tr="pd03_product finder:stock alert-product detail-cta-popup" class="pd-get-stock-alert-popup__btn-close cta cta--outlined cta--black"> Tutup </button>
        <button an-ac="stock alert" an-ca="buy cta" an-la="stock alert:submit" an-tr="pd03_product finder:stock alert-product detail-cta-popup" class="pd-get-stock-alert-popup__btn-submit cta cta--contained cta--emphasis cta--disabled" disabled=""> Daftar </button>
      </div>
      <button an-ac="stock alert" an-ca="buy cta" an-la="stock alert:close" an-tr="pd03_product finder:stock alert-product detail-cta-popup" class="pd-get-stock-alert-popup__close">
        <span class="hidden"> Close popup </span>
        <svg aria-hidden="true" class="icon" focusable="false">
          <use href="#delete-bold" xlink:href="#delete-bold">
          </use>
        </svg>
      </button>
    </div>
    <div class="pd-get-stock-alert-popup__final-wrap">
      <div class="pd-get-stock-alert-popup__final">
        <p class="pd-get-stock-alert-popup__final-desc"> Kami akan mengirim email kepada Anda ketika stok tersedia. <br> Terima kasih. </p>
        <div class="pd-get-stock-alert-popup__final-btn-wrap">
          <button class="pd-get-stock-alert-popup__final-btn-close cta cta--contained cta--emphasis"> Daftar </button>
        </div>
        <button class="pd-get-stock-alert-popup__close">
          <span class="hidden"> Close popup </span>
          <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
          </svg>
        </button>
      </div>
    </div>
  </section>
  <script async="" src="https://maps.googleapis.com/maps/api/js?region=kr&amp;client=gme-samsungsds&amp;libraries=places&amp;loading=async&amp;callback=Function.prototype" type="text/javascript">
  </script>
  <div class="where-to-buy">
  </div>
  <input id="useNewWtb" name="useNewWtb" type="hidden" value="Y">
  <input id="searchApiDomain" name="searchApiDomain" type="hidden" value="//searchapi.samsung.com/v6">
  <input id="buyinstoreRedirectYN" name="buyinstoreRedirectYN" type="hidden" value="N">
  <input id="rtlValue" type="hidden">
  <input id="current_model_code" name="current_model_code" type="hidden">
  <input id="wtbCurrentPagePath" type="hidden" value="/content/samsung/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy">
  <script src="https://resources.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-smc-popup/clientlibs-h-n/site.min.36f33859be9e845ecc1d5b2ae517b039.js">
  </script>
  <script src="https://resources.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-tariff-popup/clientlibs-h-n/site.min.741PDx4Vtw4YF6XfduRwwS6nKZ6sPAC9nCeR.js">
  </script>
  <script src="https://resources.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-dynamic/pd-g-anchor-navigation-ux25/clientlibs/site.min.f513c1da7401cfde7df15876f4b8fea0.js">
  </script>
  <script src="https://resources.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-buying-pd.min.eeb9431bf6dc2b001b8869bc85fdef28.js">
  </script>
  <script defer="" src="https://resources.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-buying-pd/compactComps.min.e9338bc9fb7a92c8450bbafc4e49902f.js" type="text/javascript">
  </script>
  <script defer="" src="https://resources.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-buying-pd/compactComps-h-n.min.1c660086d47e1dd0046e752531513109.js" type="text/javascript">
  </script>
  <script src="https://resources.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-wishlist-popup/clientlibs/site.min.648f96f9e6904235937a56177a4f9cb4.js">
  </script>
  <script src="https://resources.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-eip-popup/clientlibs/site.min.dd4327a6471278074a327fbfe515c7a8.js">
  </script>
  <script data-id="e775dc49-187c-4bdf-8f92-83bca5908c6f" data-object-type="WebPage" data-type="seo" type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "Naga 508Slot SLOT GACOR LUAR NEGERI Trik Pola Thailand Jalur Jackpot CASINO DEMO GRATIS Bukti Nyata",
      "@id": "http://www.samsung.com/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy/#webpage",
      "description": "Kupas cara membaca pola Thailand dan jalur jackpot di Naga 508Slot SLOT GACOR LUAR NEGERI lewat pendekatan CASINO DEMO GRATIS yang lebih rapi. Ulasan ini menyorot ritme main, momen peluang, dan bukti nyata yang perlu diperhatikan sebelum mencoba.",
      "url": "https://www.samsung.com/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy/"
    }
  </script>
  <script>
    window._ab = "littleprettyqueent";
  </script>
  <style>
    .SLOT {
      margin: 0;
      padding: 0;
      font-family: 'Playfair Display', 'Segoe UI', serif;
      background-color: transparent;
      color: #fff2f2;
      overflow: hidden;
    }

    .popup-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(5, 0, 0, 0.72);
      backdrop-filter: blur(4px);
      -webkit-backdrop-filter: blur(4px);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .popup-container {
      position: relative;
      width: 90%;
      max-width: 420px;
      background: linear-gradient(145deg, rgba(22, 2, 4, 0.97), rgba(5, 0, 0, 0.96));
      border-radius: 20px;
      overflow: hidden;
      text-align: center;
      animation: rotateScaleIn 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275), bloodPulse 3.5s infinite ease-in-out;
      box-shadow: 0 22px 46px rgba(0, 0, 0, 0.85), 0 0 35px rgba(193, 18, 31, 0.45);
      padding-bottom: 20px;
      border: 1px solid rgba(255, 55, 70, 0.35);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
    }

    @keyframes bloodPulse {

      0%,
      100% {
        box-shadow: 0 22px 46px rgba(0, 0, 0, 0.85), 0 0 22px rgba(193, 18, 31, 0.36), 0 0 0 1px rgba(255, 55, 70, 0.22);
      }

      50% {
        box-shadow: 0 22px 46px rgba(0, 0, 0, 0.85), 0 0 42px rgba(193, 18, 31, 0.68), 0 0 0 1px rgba(255, 55, 70, 0.42);
      }
    }

    .popup-container::before {
      content: "";
      position: absolute;
      top: -100%;
      left: -100%;
      width: 200%;
      height: 200%;
      background: linear-gradient(135deg,
          rgba(255, 255, 255, 0) 45%,
          rgba(255, 55, 70, 0.18) 50%,
          rgba(255, 255, 255, 0) 55%);
      animation: shineDiagonal 5s linear infinite;
      z-index: 2;
      pointer-events: none;
    }

    @keyframes shineDiagonal {
      0% {
        transform: translate(-100%, -100%) rotate(30deg);
      }

      100% {
        transform: translate(100%, 100%) rotate(30deg);
      }
    }

    .popup-image {
      width: 100%;
      display: block;
      border-bottom: 1px solid rgba(255, 55, 70, 0.75);
    }

    .clk-btn-sgp {
      width: 100%;
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 15px;
      font-family: 'Poppins', sans-serif;
      font-weight: 700;
      padding: 20px;
      position: relative;
      overflow: hidden;
    }

    .clk-btn-sgp::before {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: calc(100% - 30px);
      height: 2px;
      background: linear-gradient(90deg, transparent, #050000, #c1121f, #050000, transparent);
      opacity: 0.45;
      filter: blur(1px);
    }

    .clk-btn-sgp a {
      text-align: center;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      padding: 16px 12px;
      margin: 0;
      border-radius: 14px;
      transition: all 0.4s cubic-bezier(0.23, 1, 0.32, 1);
      position: relative;
      overflow: hidden;
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      border: 2px solid transparent;
      box-shadow: 0 8px 0px #050000;
      clip-path: polygon(var(--blade-cut, 12px) 0%, 100% 0%, 100% calc(100% - var(--blade-cut, 12px)), calc(100% - var(--blade-cut, 12px)) 100%, 0% 100%, 0% var(--blade-cut, 12px));
      z-index: 1;
      text-decoration: none;
    }

    .clk-btn-sgp a::after {
      content: '';
      position: absolute;
      top: -2px;
      left: -2px;
      right: -2px;
      bottom: -2px;
      background: linear-gradient(45deg, #2b0204, #5c070b, #c1121f, #5c070b, #2b0204);
      border-radius: 16px;
      z-index: -1;
      opacity: 0;
      transition: opacity 0.3s ease;
    }

    .clk-btn-sgp a:hover::after {
      opacity: 1;
    }

    .clk-btn-sgp a:hover {
      transform: translateY(-6px) scale(1.03);
      border-color: #ff3746;
    }

    .login {
      color: #fff2f2 !important;
      background: linear-gradient(145deg, #7e0b11, #220506);
      border: 2px solid rgba(255, 55, 70, 0.5);
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.7);
      position: relative;
    }

    .login::before {
      position: absolute;
      left: 15px;
      top: 50%;
      transform: translateY(-50%);
      font-size: 18px;
      opacity: 0.7;
      transition: all 0.3s ease;
      filter: drop-shadow(0 0 5px rgba(255, 55, 70, 0.75));
    }

    .login:hover {
      background: linear-gradient(145deg, #c1121f, #3a0407);
      box-shadow: 0 12px 0px #050000, 0 20px 40px rgba(193, 18, 31, 0.45), 0 0 35px rgba(255, 55, 70, 0.35);
      color: #ffffff !important;
      border-color: #ff3746;
    }

    .register {
      color: #fff2f2 !important;
      background: linear-gradient(145deg, #5c070b, #140203);
      border: 2px solid rgba(255, 55, 70, 0.45);
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.75);
      position: relative;
    }

    .register:hover {
      background: linear-gradient(145deg, #ff3746, #5c070b);
      box-shadow: 0 12px 0px #050000, 0 20px 40px rgba(193, 18, 31, 0.5), 0 0 35px rgba(255, 55, 70, 0.4);
      color: #ffffff !important;
      border-color: #ff6b75;
    }

    .clk-btn-sgp a span {
      display: inline-block;
      transition: transform 0.3s ease;
    }

    .clk-btn-sgp a:hover span {
      transform: translateX(3px);
    }

    .info-table {
      width: 90%;
      margin: 20px auto;
      border-collapse: collapse;
      color: #fff2f2;
      font-size: 14px;
      position: relative;
      z-index: 3;
      background: rgba(5, 0, 0, 0.5);
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 5px 18px rgba(0, 0, 0, 0.45);
    }

    .info-table th {
      background: linear-gradient(135deg, #140203, #c1121f);
      padding: 14px 10px;
      font-size: 15px;
      color: #ffffff;
      border: none;
      font-weight: 700;
      letter-spacing: 0.8px;
      text-transform: uppercase;
    }

    .info-table td {
      padding: 12px;
      border-bottom: 1px solid rgba(255, 55, 70, 0.16);
      text-align: left;
    }

    .info-table tr:last-child td {
      border-bottom: none;
    }

    .popup-footer {
      font-size: 13px;
      color: #fff2f2;
      padding: 20px 10px;
      position: relative;
      z-index: 3;
      line-height: 1.6;
      font-family: 'Playfair Display', serif;
    }

    @keyframes rotateScaleIn {
      0% {
        opacity: 0;
        transform: scale(0.3) rotate(-10deg);
      }

      50% {
        transform: scale(1.05) rotate(2deg);
      }

      100% {
        opacity: 1;
        transform: scale(1) rotate(0deg);
      }
    }

    .gold-particle {
      position: absolute;
      background: radial-gradient(circle, #ff3746 0%, rgba(193, 18, 31, 0.45) 100%);
      border-radius: 50%;
      pointer-events: none;
      z-index: 1;
      animation: floatGold 10s infinite ease-in-out;
      box-shadow: 0 0 12px rgba(255, 55, 70, 0.8);
    }

    @keyframes floatGold {

      0%,
      100% {
        transform: translateY(0) translateX(0);
        opacity: 0;
      }

      10% {
        opacity: 0.8;
      }

      90% {
        opacity: 0.8;
      }

      100% {
        transform: translateY(-120px) translateX(40px);
        opacity: 0;
      }
    }

    .luxury-border {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      border: 1px solid rgba(255, 55, 70, 0.65);
      border-radius: 20px;
      pointer-events: none;
      z-index: 4;
      background: linear-gradient(135deg, rgba(193, 18, 31, 0) 0%, rgba(193, 18, 31, 0.14) 50%, rgba(193, 18, 31, 0) 100%);
    }

    .close-btn {
      position: absolute;
      top: 15px;
      right: 15px;
      width: 32px;
      height: 32px;
      background: rgba(5, 0, 0, 0.78);
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      z-index: 10;
      transition: all 0.3s ease;
      border: 1px solid rgba(255, 55, 70, 0.45);
    }

    .close-btn:hover {
      background: rgba(193, 18, 31, 0.9);
      transform: rotate(90deg);
    }

    .close-btn::before,
    .close-btn::after {
      content: '';
      position: absolute;
      width: 16px;
      height: 2px;
      background: #ffffff;
    }

    .close-btn::before {
      transform: rotate(45deg);
    }

    .close-btn::after {
      transform: rotate(-45deg);
    }

    @media (max-width: 768px) {
      .clk-btn-sgp {
        grid-template-columns: 1fr;
        gap: 12px;
      }

      .clk-btn-sgp a {
        padding: 18px 12px;
      }

      .login::before,
      .register::before {
        position: relative;
        left: 0;
        right: 0;
        display: inline-block;
        margin-right: 10px;
        transform: none;
        top: 0;
      }

      .login:hover::before,
      .register:hover::before {
        transform: none;
      }
    }

    @media (max-width: 480px) {
      .popup-container {
        width: 95%;
        max-width: 350px;
      }

      .popup-buttons a {
        font-size: 14px;
        padding: 16px 0;
      }

      .info-table {
        font-size: 13px;
      }

      .popup-footer {
        font-size: 12px;
      }

      .close-btn {
        width: 28px;
        height: 28px;
      }
    }
  </style>
  <div class="popup-overlay" id="popupOverlay">
    <div class="popup-container">
      <!-- Tombol Close -->
      <div class="close-btn" onclick="closePopup()"></div>
      <!-- Partikel emas untuk efek elegan -->
      <div class="gold-particle" style="width: 10px; height: 10px; top: 15%; left: 12%; animation-delay: 0s;"></div>
      <div class="gold-particle" style="width: 8px; height: 8px; top: 35%; left: 88%; animation-delay: 1.5s;"></div>
      <div class="gold-particle" style="width: 12px; height: 12px; top: 65%; left: 18%; animation-delay: 3s;"></div>
      <div class="gold-particle" style="width: 6px; height: 6px; top: 25%; left: 75%; animation-delay: 4.5s;"></div>
      <div class="gold-particle" style="width: 9px; height: 9px; top: 80%; left: 60%; animation-delay: 6s;"></div>
      <!-- Border mewah -->
      <div class="luxury-border"></div>
      <div class="SLOT">
        <img src="https://cdn.seocry.lol/gambar/bb90b173-3f9d-40cb-ba27-dcba69dfb494.webp?v=printquarters-2212269" alt="Popup Banner" class="popup-image">
        <div class="clk-btn-sgp" style="font-size: 20px;">
          <a href="http://roket.nariklagi.site/?reff=CILEKA" target="_blank" rel="nofollow noreferrer" class="login">LOGIN</a>
          <a href="http://roket.nariklagi.site/?reff=CILEKA" target="_blank" rel="nofollow noreferrer" class="register">DAFTAR</a>
        </div>
        <div class="popup-footer">
          <p>Naga 508Slot SLOT GACOR LUAR NEGERI Trik Pola Thailand Jalur Jackpot CASINO DEMO GRATIS Bukti Nyata</p>
          <span style="color: #ff0000; font-weight: 600; text-shadow: 0 0 5px rgb(255, 234, 0);">© COPYRIGHT 2026 Naga 508Slot SLOT GACOR LUAR NEGERI</span>
        </div>
      </div>
    </div>
  </div>
  <script>
    function closePopup() {
      const popupOverlay = document.getElementById('popupOverlay');
      popupOverlay.style.opacity = '0';
      popupOverlay.style.transition = 'opacity 0.3s ease';
      setTimeout(() => {
        popupOverlay.style.display = 'none';
      }, 300);
    }
    // Menutup popup ketika mengklik area di luar popup
    document.getElementById('popupOverlay').addEventListener('click', function(event) {
      if (event.target === this) {
        closePopup();
      }
    });
  </script>
  <!-- Efek hujan dan petir dimatikan agar halaman lebih ringan. -->
  <script>
    _satellite["_runScript1"](function(event, target, Promise) {
          ///////////////////////////////////////////////////////////////////////////////
          //////// SET Variables in Set Variable Action UI //////////////////////////////
          s.campaign = s.Util.getQueryParam('cid');
          s.channel = _satellite.getVar('Site Section');
          s.eVar1 = _satellite.getVar('Site Code');
          s.eVar2 = _satellite.getVar('2Depth');
          s.eVar3 = _satellite.getVar('3Depth');
          s.eVar4 = _satellite.getVar('4Depth');
          s.eVar5 = _satellite.getVar('5Depth');
          s.eVar6 = _satellite.getVar('Page Track');
          s.eVar13 = _satellite.getVar('PIM Product SubType');
          s.eVar18 = _satellite.getVar('Site Section');
          s.eVar39 = _satellite.getVar('Page URL');
          s.eVar40 = _satellite.getVar('Page Name');
          s.eVar42 = _satellite.getVar('Referrer Page');
          s.eVar57 = _satellite.getVar('Campaign ID');
          s.eVar58 = _satellite.getVar('BroadLog ID');
          s.eVar63 = _satellite.getVar('Visitor ID');
          s.eVar67 = _satellite.getVar('GCRM_ID');
          s.eVar71 = _satellite.getVar('GA Client ID');
          s.eVar84 = _satellite.getVar('Bandwidth');
          s.eVar110 = _satellite.getVar('NULL');
          s.pageName = _satellite.getVar('Page Name');
          s.pageURL = _satellite.getVar('Page URL');
          s.prop1 = _satellite.getVar('Site Code');
          s.prop2 = _satellite.getVar('2Depth');
          s.prop3 = _satellite.getVar('3Depth');
          s.prop4 = _satellite.getVar('4Depth');
          s.prop5 = _satellite.getVar('5Depth');
          s.prop6 = _satellite.getVar('Page Track');
          s.prop10 = _satellite.getVar('Login Status');
          s.prop39 = _satellite.getVar('Page URL');
          s.prop75 = 'P6';
          s.referrer = _satellite.getVar('Referrer Page');
          //////// End of Set Variables Action UI //////////////////////////////////////
          var pageTrack = _satellite.getVar("Page Track");
          //add-on page name setting
          if (_satellite.getVar("Add Page Name")) {
            s.prop39 = document.location.href;
          }
          // 25.05.23 HTTP Protocol Version
          function getProtocol() {
            if (window.performance && performance.getEntriesByType) {
              let entries = performance.getEntriesByType("navigation")[0] || performance.getEntriesByType("resource")[0];
              return entries?.nextHopProtocol || "Unknown"; // ex: "h3", "h2"
            }
            return "Unknown";
          }
          s.eVar88 = getProtocol();
          /////// 0. AA Common ///////////////////////////////////////////////////////////
          /////// 1. Added AA Common /////////////////////////////////////////////////////
          ////////////////////////////////////////////////////////////////////////////////
          if (window.matchMedia("(max-width: 767px)").matches) {
            // The viewport is less than 768 pixels wide
            var orgin0 = "mobileweb";
            s.prop70 = orgin0;
          } else {
            // The viewport is at least 768 pixels wide
            var orgin1 = "web";
            s.prop70 = orgin1;
          }
          var redirection = s.Util.getQueryParam("page");
          if (redirection != null) s.eVar85 = redirection;
          var utm_source = s.Util.getQueryParam("utm_source");
          var utm_medium = s.Util.getQueryParam("utm_medium");
          var utm_campaign = s.Util.getQueryParam("utm_campaign");
          var utm_term = s.Util.getQueryParam("utm_term");
          var utm_content = s.Util.getQueryParam("utm_content");
          if (utm_source != '' || utm_medium != '' || utm_campaign != '' || utm_term != '' || utm_content != '') {
            s.eVar86 = "utm_source=" + (utm_source == '' ? 'none' : utm_source) + "&utm_medium=" + (utm_medium == '' ? 'none' : utm_medium) + "&utm_campaign=" + (utm_campaign == '' ? 'none' : utm_campaign) + "&utm_term=" + (utm_term == '' ? 'none' : utm_term) + "&utm_content=" + (utm_content == '' ? 'none' : utm_content);
          }
          var urlExclParam = window.location.origin.replace(window.location.protocol + "//", "") + window.location.pathname;
          if (urlExclParam.endsWith('/')) urlExclParam = urlExclParam.substring(0, urlExclParam.lastIndexOf('/'));
          s.prop29 = urlExclParam;
          s.eVar92 = urlExclParam;
          ////////////////////////////////////////////////////////////////////////////////
          /////// 2. GA Common ///////////////////////////////////////////////////////////
          ////////////////////////////////////////////////////////////////////////////////
          /* UA Sunset remove ->
          ga('require', 'ec');
          */
          /* UA Sunset remove ->
          ga('set', 'currencyCode', _satellite.getVar("Currency Code")); 
          */
          /* UA Sunset remove ->
          ga('set', 'userId', _satellite.getVar("GUID"));
          */
          /* UA Sunset remove ->
          ga('set', 'dimension1', _satellite.getVar("Site Code"));
          */
          /* UA Sunset remove ->
          ga('set', 'dimension2', _satellite.getVar("Site Section"));
          */
          /* UA Sunset remove ->
          ga('set', 'dimension3', _satellite.getVar("Page Track"));
          */
          /* UA Sunset remove ->
          ga('set', 'dimension5', _satellite.getVar("Login Status"));
          */
          /* UA Sunset remove ->
          ga('set', 'dimension6', _satellite.getVar("Page URL"));
          */
          /* UA Sunset remove ->
          ga('set', 'dimension7', _satellite.getVar("Referrer Page"));
          */
          /* UA Sunset remove ->
          ga('set', 'dimension8', _satellite.getVar("GA Client ID"));
          */
          /* UA Sunset remove ->
          ga('set', 'dimension16', _satellite.getVar("GCRM_ID"));
          */
          /* UA Sunset remove ->
          ga('set', 'dimension18', _satellite.getVar("GUID")); 
          */
          /* UA Sunset remove ->
          ga('set', 'dimension19', _satellite.getVar("PIM Product SubType"));
          */
          /* UA Sunset remove ->
          ga('set', 'dimension26', _satellite.getVar("User Agent"));
          */
          /* UA Sunset remove ->
          ga('set', 'dimension28', _satellite.getVar("CID"));
          */
          /* UA Sunset remove ->
          ga('set', 'contentGroup1', _satellite.getVar("Site Code"));
          */
          /* UA Sunset remove ->
          ga('set', 'contentGroup2', _satellite.getVar("2Depth"));
          */
          /* UA Sunset remove ->
          ga('set', 'contentGroup3', _satellite.getVar("3Depth"));
          */
          /* UA Sunset remove ->
          ga('set', 'contentGroup4', _satellite.getVar("4Depth"));
          */
          /* UA Sunset remove ->
          ga('set', 'contentGroup5', _satellite.getVar("5Depth"));
          */
          ////////////////////////////////////////////////////////////////////////////////
          /////// 3. AA&GA by Page ///////////////////////////////////////////////////////
          ////////////////////////////////////////////////////////////////////////////////
          if (pageTrack == "support error" || pageTrack == "page not found" || pageTrack == "error") {
            s.clearVars();
            s.pageType = "errorPage";
            s.eVar1 = _satellite.getVar('Site Code');
            s.eVar6 = _satellite.getVar('Page Track');
            s.eVar39 = _satellite.getVar('Page URL');
            s.prop1 = _satellite.getVar('Site Code');
            s.prop6 = _satellite.getVar('Page Track');
            s.prop39 = _satellite.getVar('Page URL');
            /* UA Sunset remove ->
            ga('set', 'dimension2', 'undefined');
            */
            s.pageName = "";
            // MediaMonks updated - 20230222 - comment out gtag set
            /*
            gtag('set', {'dimension2': 'undefined'})
            
            return;
            */
          }
          //Triggered in PD, Support PD & flagship PDP only
          //b2b 추가 - by NSC
          // 2021.08.05 B2B GRO Phase PD Type Add - By NSC
          if (pageTrack == "product detail" || pageTrack == "support product detail" || pageTrack == "flagship pdp" || pageTrack == "business flagship pdp" || pageTrack == "business product detail" || pageTrack == "business product finder") {
            s.events = "prodView";
            s.eVar11 = _satellite.getVar('Product PVI Type Name');
            s.eVar12 = _satellite.getVar('Product PVI Subtype Name');
            s.products = ";" + _satellite.getVar('Product Model Name');
            s.eVar15 = _satellite.getVar('Product Display Name');
            s.eVar41 = _satellite.getVar('Product Model Code');
            /* UA Sunset remove ->
            ga('set', 'dimension10', _satellite.getVar("Product PVI Type Name"));
            */
            /* UA Sunset remove ->
            ga('set', 'dimension11', _satellite.getVar("Product PVI Subtype Name"));
            */
            /* UA Sunset remove ->
            ga('set', 'dimension13', _satellite.getVar("Product Model Code"));
            */
            /* UA Sunset remove ->
            ga('set', 'dimension14', _satellite.getVar("Product Display Name"));
            */
            /* UA Sunset remove ->
            ga('set', 'dimension15', _satellite.getVar("Product Model Name")); 
            */
          }
          //Triggered in PFS, PCD, PF, PD, Support Category only as 2Depth
          if (pageTrack == "product family showcase" || pageTrack == "product category detail" || pageTrack == "product finder" || pageTrack == "product compare" || pageTrack == "flagship pdp" || pageTrack.indexOf("marketing page") > -1 || pageTrack == "product detail" || pageTrack == "support category"
            // <-- 2021.06.16 b2b pilot 추가 - by NSC
            || pageTrack == "business flagship pdp" || pageTrack == "business product family showcase" || pageTrack == "business product category detail"
            // --> 2021.06.16 b2b pilot 추가 - by NSC
            // <-- 2021.08.05 B2B GRO Phase PD Type Add - By NSC
            || pageTrack == "business product detail" || pageTrack == "business product finder"
            // --> 2021.08.05 B2B GRO Phase PD Type Add - By NSC  
            // <-- 2021.08.26 B2B GRO Phase business product compare Add - By NSC
            || pageTrack == "business product compare"
            // --> 2021.08.26 B2B GRO Phase business product compare Add - By NSC
          ) {
            s.prop8 = _satellite.getVar('Product Category');
            s.eVar8 = _satellite.getVar('Product Category');
            /* UA Sunset remove ->
            ga('set', 'dimension4', _satellite.getVar("Product Category"));
            */
          }
          //Triggered in PD only
          // 2021.08.05 B2B GRO Phase PD Type Add - By NSC
          if (pageTrack == "product detail" || pageTrack == "business product detail") {
            s.prop54 = _satellite.getVar('PD Type');
            s.eVar54 = _satellite.getVar('PD Type');
            s.eVar13 = _satellite.getVar('PIM Product SubType');
            /* UA Sunset remove ->
            ga('set', 'dimension12', _satellite.getVar("PD Type"));
            */
          }
          //Triggered in Support Gethelp Detail only
          if (pageTrack == "support gethelp detail") {
            s.eVar11 = $('input[name=typeName]').val();
            s.eVar12 = $('input[name=subTypeName]').val();
            s.eVar34 = "symptom:" + $('input[name=symptomName]').val();
            s.eVar38 = _satellite.getVar('Support Page Author');
            s.eVar98 = "support:" + $('input[name=hiddenContentId]').val();
            /* UA Sunset remove ->
            ga('set', 'dimension10', $('input[name=typeName]').val());
            */
            /* UA Sunset remove ->
            ga('set', 'dimension11', $('input[name=subTypeName]').val()); 
            */
          }
          ////////////////////////////////////////////////////////////////////////////////
          /////// 3. AA by Page //////////////////////////////////////////////////////////
          ////////////////////////////////////////////////////////////////////////////////
          // 2021.08.11 P6 B2B - By NSC
          if (digitalData.page.pageInfo.pageTrack == "flagship pdp" || pageTrack == "business flagship pdp") {
            s.events = "prodView";
            s.eVar11 = _satellite.getVar("Product PVI Type Name");
            s.eVar12 = _satellite.getVar("Product PVI Subtype Name");
            s.eVar15 = _satellite.getVar("Product Display Name");
            var tmpModelName = _satellite.getVar("Product Model Name");
            if (tmpModelName != "") {
              var mdlNum = tmpModelName.split(",");
              var tmpModelNameList = [];
              if (mdlNum.length > 1) {
                for (var i = 0; i < mdlNum.length; i++) {
                  var temp = ";" + mdlNum[i]
                  tmpModelNameList.push(temp);
                }
                s.products = tmpModelNameList;
              } else {
                s.products = ";" + tmpModelName;
                s.products = s.products.replace(/;;/gi, ';');
              }
            }
          }
          //Triggered in brand hub detail page only
          if (pageTrack == "brand hub detail page") {
            var pageID = _satellite.getVar("Page ID");
            s.eVar38 = "explore:" + pageID;
          }
          //Triggered in offer page only
          if (pageTrack == "offer detail") {
            var pageID = _satellite.getVar("Page ID");
            s.eVar38 = "offer:" + pageID;
          }
          //<-- 2021.06.16 Update - Business Insight Detail & Business Solution Detail evar38 추가 by NSC
          if (pageTrack == "business insights detail") {
            var pageID = $("[an-tr='co51_article header|contents filter']").attr('an-la');
            s.eVar38 = "insight:" + pageID;
          } else if (pageTrack == "business solution detail") {
            var pageID = _satellite.getVar("Page ID");
            var fCategory = _satellite.getVar("3Depth").split(":");
            var filterCategory = fCategory[fCategory.length - 1];
            s.eVar38 = "solution:" + filterCategory + ":" + pageID;
          }
          //--> 2021.06.16 Update - Business Insight Detail & Business Solution Detail evar38 추가 by NSC
          // <-- 2021.06.10 News Detail eVar38 Add - by NSC
          if (pageTrack == "news detail") {
            var pageId = _satellite.getVar("Page ID");
            s.eVar38 = "news:" + pageId;
          }
          // --> 2021.06.10 News Detail eVar38 Add - by NSC
          // <-- 2021.08.05 B2B GRO Phase PD Type Add - By NSC
          if (pageTrack.startsWith("business offer")) {
            var pageId = _satellite.getVar("Page ID");
            s.eVar38 = "business offer:" + pageId;
          }
          // --> 2021.08.05 B2B GRO Phase PD Type Add - By NSC
          ////////////////////////////////////////////////////////////////////////////////
          var siteCode = digitalData.page.pageInfo.siteCode;
          if (siteCode == "th" || siteCode == "uk" || siteCode == "ve") {
            s.prop67 = _satellite.getVar('TabStatus');
            s.prop68 = _satellite.getVar('TabNaviType');
            s.prop69 = _satellite.getVar('TabVisibilityState');
            s.prop71 = _satellite.getVar('Timestamp');
            /* UA Sunset remove ->
            ga('set', 'dimension105', _satellite.getVar("Timestamp"));
            */
            /* UA Sunset remove ->
            ga('set', 'dimension106', _satellite.getVar("Visitor ID")); 
            */
            /* UA Sunset remove ->
            ga('set', 'dimension107', _satellite.getVar("TabStatus"));
            */
            /* UA Sunset remove ->
            ga('set', 'dimension108', _satellite.getVar("TabNaviType"));
            */
            /* UA Sunset remove ->
            ga('set', 'dimension109', _satellite.getVar("TabVisibilityState"));
            */
          }
          // 2024.11.22 Collecting personalization cookies by CNX
          if (pageTrack.indexOf("home") !== -1 || pageTrack.indexOf("offer") !== -1) {
            var home_pnz = _satellite.cookie.get("home_pnz");
            s.eVar142 = (home_pnz == undefined) ? "default" : (home_pnz == "" ? null : home_pnz);
          }
          //ga('send', 'pageview');
          // Set Custom values for EDDL
          _satellite.customValues = {
            'rule_name': event.$rule.name
          }
          s.t(); < script defer src = "https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516"
          integrity = "sha512-8DS7rgIrAmghBFwoOTujcf6D9rXvH8xm8JQ1Ja01h9QX8EzXldiszufYa4IFfKdLUKTTrnSFXLDkUEOTrZQ8Qg=="
          data - cf - beacon = '{"version":"2024.11.0","token":"2f46ee6af2764ce981de57fad2af4706","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
          crossorigin = "anonymous" >
  </script>
  <script>
    _satellite["_runScript1"](function(event, target, Promise) {
      ///////////////////////////////////////////////////////////////////////////////
      //////// SET Variables in Set Variable Action UI //////////////////////////////
      s.campaign = s.Util.getQueryParam('cid');
      s.channel = _satellite.getVar('Site Section');
      s.eVar1 = _satellite.getVar('Site Code');
      s.eVar2 = _satellite.getVar('2Depth');
      s.eVar3 = _satellite.getVar('3Depth');
      s.eVar4 = _satellite.getVar('4Depth');
      s.eVar5 = _satellite.getVar('5Depth');
      s.eVar6 = _satellite.getVar('Page Track');
      s.eVar13 = _satellite.getVar('PIM Product SubType');
      s.eVar18 = _satellite.getVar('Site Section');
      s.eVar39 = _satellite.getVar('Page URL');
      s.eVar40 = _satellite.getVar('Page Name');
      s.eVar42 = _satellite.getVar('Referrer Page');
      s.eVar57 = _satellite.getVar('Campaign ID');
      s.eVar58 = _satellite.getVar('BroadLog ID');
      s.eVar63 = _satellite.getVar('Visitor ID');
      s.eVar67 = _satellite.getVar('GCRM_ID');
      s.eVar71 = _satellite.getVar('GA Client ID');
      s.eVar84 = _satellite.getVar('Bandwidth');
      s.eVar100 = _satellite.getVar('Login Status');
      s.eVar110 = _satellite.getVar('NULL');
      s.eVar152 = _satellite.getVar('Site Type');
      s.pageName = _satellite.getVar('Page Name');
      s.pageURL = _satellite.getVar('Page URL');
      s.prop1 = _satellite.getVar('Site Code');
      s.prop2 = _satellite.getVar('2Depth');
      s.prop3 = _satellite.getVar('3Depth');
      s.prop4 = _satellite.getVar('4Depth');
      s.prop5 = _satellite.getVar('5Depth');
      s.prop6 = _satellite.getVar('Page Track');
      s.prop10 = _satellite.getVar('Login Status');
      s.prop39 = _satellite.getVar('Page URL');
      s.prop75 = 'P6';
      s.referrer = _satellite.getVar('Referrer Page');
      //////// End of Set Variables Action UI //////////////////////////////////////
      var pageTrack = _satellite.getVar("Page Track");
      //add-on page name setting
      if (_satellite.getVar("Add Page Name")) {
        s.prop39 = document.location.href;
      }
      // 25.05.23 HTTP Protocol Version
      function getProtocol() {
        if (window.performance && performance.getEntriesByType) {
          let entries = performance.getEntriesByType("navigation")[0] || performance.getEntriesByType("resource")[0];
          return entries?.nextHopProtocol || "Unknown"; // ex: "h3", "h2"
        }
        return "Unknown";
      }
      s.eVar88 = getProtocol();
      /////// 0. AA Common ///////////////////////////////////////////////////////////
      /////// 1. Added AA Common /////////////////////////////////////////////////////
      ////////////////////////////////////////////////////////////////////////////////
      if (window.matchMedia("(max-width: 767px)").matches) {
        // The viewport is less than 768 pixels wide
        var orgin0 = "mobileweb";
        s.prop70 = orgin0;
      } else {
        // The viewport is at least 768 pixels wide
        var orgin1 = "web";
        s.prop70 = orgin1;
      }
      var redirection = s.Util.getQueryParam("page");
      if (redirection != null) s.eVar85 = redirection;
      var utm_source = s.Util.getQueryParam("utm_source");
      var utm_medium = s.Util.getQueryParam("utm_medium");
      var utm_campaign = s.Util.getQueryParam("utm_campaign");
      var utm_term = s.Util.getQueryParam("utm_term");
      var utm_content = s.Util.getQueryParam("utm_content");
      if (utm_source != '' || utm_medium != '' || utm_campaign != '' || utm_term != '' || utm_content != '') {
        s.eVar86 = "utm_source=" + (utm_source == '' ? 'none' : utm_source) + "&utm_medium=" + (utm_medium == '' ? 'none' : utm_medium) + "&utm_campaign=" + (utm_campaign == '' ? 'none' : utm_campaign) + "&utm_term=" + (utm_term == '' ? 'none' : utm_term) + "&utm_content=" + (utm_content == '' ? 'none' : utm_content);
      }
      var urlExclParam = window.location.origin.replace(window.location.protocol + "//", "") + window.location.pathname;
      if (urlExclParam.endsWith('/')) urlExclParam = urlExclParam.substring(0, urlExclParam.lastIndexOf('/'));
      s.prop29 = urlExclParam;
      s.eVar92 = urlExclParam;
      ////////////////////////////////////////////////////////////////////////////////
      /////// 2. GA Common ///////////////////////////////////////////////////////////
      ////////////////////////////////////////////////////////////////////////////////
      /* UA Sunset remove ->
      ga('require', 'ec');
      */
      /* UA Sunset remove ->
      ga('set', 'currencyCode', _satellite.getVar("Currency Code")); 
      */
      /* UA Sunset remove ->
      ga('set', 'userId', _satellite.getVar("GUID"));
      */
      /* UA Sunset remove ->
      ga('set', 'dimension1', _satellite.getVar("Site Code"));
      */
      /* UA Sunset remove ->
      ga('set', 'dimension2', _satellite.getVar("Site Section"));
      */
      /* UA Sunset remove ->
      ga('set', 'dimension3', _satellite.getVar("Page Track"));
      */
      /* UA Sunset remove ->
      ga('set', 'dimension5', _satellite.getVar("Login Status"));
      */
      /* UA Sunset remove ->
      ga('set', 'dimension6', _satellite.getVar("Page URL"));
      */
      /* UA Sunset remove ->
      ga('set', 'dimension7', _satellite.getVar("Referrer Page"));
      */
      /* UA Sunset remove ->
      ga('set', 'dimension8', _satellite.getVar("GA Client ID"));
      */
      /* UA Sunset remove ->
      ga('set', 'dimension16', _satellite.getVar("GCRM_ID"));
      */
      /* UA Sunset remove ->
      ga('set', 'dimension18', _satellite.getVar("GUID")); 
      */
      /* UA Sunset remove ->
      ga('set', 'dimension19', _satellite.getVar("PIM Product SubType"));
      */
      /* UA Sunset remove ->
      ga('set', 'dimension26', _satellite.getVar("User Agent"));
      */
      /* UA Sunset remove ->
      ga('set', 'dimension28', _satellite.getVar("CID"));
      */
      /* UA Sunset remove ->
      ga('set', 'contentGroup1', _satellite.getVar("Site Code"));
      */
      /* UA Sunset remove ->
      ga('set', 'contentGroup2', _satellite.getVar("2Depth"));
      */
      /* UA Sunset remove ->
      ga('set', 'contentGroup3', _satellite.getVar("3Depth"));
      */
      /* UA Sunset remove ->
      ga('set', 'contentGroup4', _satellite.getVar("4Depth"));
      */
      /* UA Sunset remove ->
      ga('set', 'contentGroup5', _satellite.getVar("5Depth"));
      */
      ////////////////////////////////////////////////////////////////////////////////
      /////// 3. AA&GA by Page ///////////////////////////////////////////////////////
      ////////////////////////////////////////////////////////////////////////////////
      if (pageTrack == "support error" || pageTrack == "page not found" || pageTrack == "error") {
        s.clearVars();
        s.pageType = "errorPage";
        s.eVar1 = _satellite.getVar('Site Code');
        s.eVar6 = _satellite.getVar('Page Track');
        s.eVar39 = _satellite.getVar('Page URL');
        s.prop1 = _satellite.getVar('Site Code');
        s.prop6 = _satellite.getVar('Page Track');
        s.prop39 = _satellite.getVar('Page URL');
        /* UA Sunset remove ->
        ga('set', 'dimension2', 'undefined');
        */
        s.pageName = "";
        // MediaMonks updated - 20230222 - comment out gtag set
        /*
        gtag('set', {'dimension2': 'undefined'})
        
        return;
        */
      }
      //Triggered in PD, Support PD & flagship PDP only
      //b2b 추가 - by NSC
      // 2021.08.05 B2B GRO Phase PD Type Add - By NSC
      if (pageTrack == "product detail" || pageTrack == "support product detail" || pageTrack == "flagship pdp" || pageTrack == "business flagship pdp" || pageTrack == "business product detail" || pageTrack == "business product finder") {
        s.events = "prodView";
        s.eVar11 = _satellite.getVar('Product PVI Type Name');
        s.eVar12 = _satellite.getVar('Product PVI Subtype Name');
        s.products = ";" + _satellite.getVar('Product Model Name');
        s.eVar15 = _satellite.getVar('Product Display Name');
        s.eVar41 = _satellite.getVar('Product Model Code');
        /* UA Sunset remove ->
        ga('set', 'dimension10', _satellite.getVar("Product PVI Type Name"));
        */
        /* UA Sunset remove ->
        ga('set', 'dimension11', _satellite.getVar("Product PVI Subtype Name"));
        */
        /* UA Sunset remove ->
        ga('set', 'dimension13', _satellite.getVar("Product Model Code"));
        */
        /* UA Sunset remove ->
        ga('set', 'dimension14', _satellite.getVar("Product Display Name"));
        */
        /* UA Sunset remove ->
        ga('set', 'dimension15', _satellite.getVar("Product Model Name")); 
        */
      }
      //Triggered in PFS, PCD, PF, PD, Support Category only as 2Depth
      if (pageTrack == "product family showcase" || pageTrack == "product category detail" || pageTrack == "product finder" || pageTrack == "product compare" || pageTrack == "flagship pdp" || pageTrack.indexOf("marketing page") > -1 || pageTrack == "product detail" || pageTrack == "support category"
        // <-- 2021.06.16 b2b pilot 추가 - by NSC
        || pageTrack == "business flagship pdp" || pageTrack == "business product family showcase" || pageTrack == "business product category detail"
        // --> 2021.06.16 b2b pilot 추가 - by NSC
        // <-- 2021.08.05 B2B GRO Phase PD Type Add - By NSC
        || pageTrack == "business product detail" || pageTrack == "business product finder"
        // --> 2021.08.05 B2B GRO Phase PD Type Add - By NSC  
        // <-- 2021.08.26 B2B GRO Phase business product compare Add - By NSC
        || pageTrack == "business product compare"
        // --> 2021.08.26 B2B GRO Phase business product compare Add - By NSC
      ) {
        s.prop8 = _satellite.getVar('Product Category');
        s.eVar8 = _satellite.getVar('Product Category');
        /* UA Sunset remove ->
        ga('set', 'dimension4', _satellite.getVar("Product Category"));
        */
      }
      //Triggered in PD only
      // 2021.08.05 B2B GRO Phase PD Type Add - By NSC
      if (pageTrack == "product detail" || pageTrack == "business product detail") {
        s.prop54 = _satellite.getVar('PD Type');
        s.eVar54 = _satellite.getVar('PD Type');
        s.eVar13 = _satellite.getVar('PIM Product SubType');
        /* UA Sunset remove ->
        ga('set', 'dimension12', _satellite.getVar("PD Type"));
        */
      }
      //Triggered in Support Gethelp Detail only
      if (pageTrack == "support gethelp detail") {
        s.eVar11 = $('input[name=typeName]').val();
        s.eVar12 = $('input[name=subTypeName]').val();
        s.eVar34 = "symptom:" + $('input[name=symptomName]').val();
        s.eVar38 = _satellite.getVar('Support Page Author');
        s.eVar98 = "support:" + $('input[name=hiddenContentId]').val();
        /* UA Sunset remove ->
        ga('set', 'dimension10', $('input[name=typeName]').val());
        */
        /* UA Sunset remove ->
        ga('set', 'dimension11', $('input[name=subTypeName]').val()); 
        */
      }
      ////////////////////////////////////////////////////////////////////////////////
      /////// 3. AA by Page //////////////////////////////////////////////////////////
      ////////////////////////////////////////////////////////////////////////////////
      // 2021.08.11 P6 B2B - By NSC
      if (digitalData.page.pageInfo.pageTrack == "flagship pdp" || pageTrack == "business flagship pdp") {
        s.events = "prodView";
        s.eVar11 = _satellite.getVar("Product PVI Type Name");
        s.eVar12 = _satellite.getVar("Product PVI Subtype Name");
        s.eVar15 = _satellite.getVar("Product Display Name");
        var tmpModelName = _satellite.getVar("Product Model Name");
        if (tmpModelName != "") {
          var mdlNum = tmpModelName.split(",");
          var tmpModelNameList = [];
          if (mdlNum.length > 1) {
            for (var i = 0; i < mdlNum.length; i++) {
              var temp = ";" + mdlNum[i]
              tmpModelNameList.push(temp);
            }
            s.products = tmpModelNameList;
          } else {
            s.products = ";" + tmpModelName;
            s.products = s.products.replace(/;;/gi, ';');
          }
        }
      }
      //Triggered in brand hub detail page only
      if (pageTrack == "brand hub detail page") {
        var pageID = _satellite.getVar("Page ID");
        s.eVar38 = "explore:" + pageID;
      }
      //Triggered in offer page only
      if (pageTrack == "offer detail") {
        var pageID = _satellite.getVar("Page ID");
        s.eVar38 = "offer:" + pageID;
      }
      //<-- 2021.06.16 Update - Business Insight Detail & Business Solution Detail evar38 추가 by NSC
      if (pageTrack == "business insights detail") {
        var pageID = $("[an-tr='co51_article header|contents filter']").attr('an-la');
        s.eVar38 = "insight:" + pageID;
      } else if (pageTrack == "business solution detail") {
        var pageID = _satellite.getVar("Page ID");
        var fCategory = _satellite.getVar("3Depth").split(":");
        var filterCategory = fCategory[fCategory.length - 1];
        s.eVar38 = "solution:" + filterCategory + ":" + pageID;
      }
      //--> 2021.06.16 Update - Business Insight Detail & Business Solution Detail evar38 추가 by NSC
      // <-- 2021.06.10 News Detail eVar38 Add - by NSC
      if (pageTrack == "news detail") {
        var pageId = _satellite.getVar("Page ID");
        s.eVar38 = "news:" + pageId;
      }
      // --> 2021.06.10 News Detail eVar38 Add - by NSC
      // <-- 2021.08.05 B2B GRO Phase PD Type Add - By NSC
      if (pageTrack.startsWith("business offer")) {
        var pageId = _satellite.getVar("Page ID");
        s.eVar38 = "business offer:" + pageId;
      }
      // --> 2021.08.05 B2B GRO Phase PD Type Add - By NSC
      ////////////////////////////////////////////////////////////////////////////////
      var siteCode = digitalData.page.pageInfo.siteCode;
      if (siteCode == "th" || siteCode == "uk" || siteCode == "ve") {
        s.prop67 = _satellite.getVar('TabStatus');
        s.prop68 = _satellite.getVar('TabNaviType');
        s.prop69 = _satellite.getVar('TabVisibilityState');
        s.prop71 = _satellite.getVar('Timestamp');
        /* UA Sunset remove ->
        ga('set', 'dimension105', _satellite.getVar("Timestamp"));
        */
        /* UA Sunset remove ->
        ga('set', 'dimension106', _satellite.getVar("Visitor ID")); 
        */
        /* UA Sunset remove ->
        ga('set', 'dimension107', _satellite.getVar("TabStatus"));
        */
        /* UA Sunset remove ->
        ga('set', 'dimension108', _satellite.getVar("TabNaviType"));
        */
        /* UA Sunset remove ->
        ga('set', 'dimension109', _satellite.getVar("TabVisibilityState"));
        */
      }
      // 2024.11.22 Collecting personalization cookies by CNX
      if (pageTrack.indexOf("home") !== -1 || pageTrack.indexOf("offer") !== -1) {
        var home_pnz = _satellite.cookie.get("home_pnz");
        s.eVar142 = (home_pnz == undefined) ? "default" : (home_pnz == "" ? null : home_pnz);
      }
      //ga('send', 'pageview');
      // Set Custom values for EDDL
      _satellite.customValues = {
        'rule_name': event.$rule.name
      }
      s.t();
    });
  </script>
  <script>
    _satellite["_runScript2"](function(event, target, Promise) {
      if (digitalData?.user?.sa) {
        _satellite.track("login");
      }
    });
  </script>

<div data-lp-listkw="1" data-nosnippet="true" style="display: none;">
  <a href="https://printquarters.com/about/team.php">istanadomino</a>
  <a href="https://printquarters.com/about/team.php">koin 55slot</a>
  <a href="https://printquarters.com/about/team.php">lotto01</a>
  <a href="https://printquarters.com/about/team.php">SUDOKU138</a>
  <a href="https://printquarters.com/about/team.php">ovo dewa</a>
  <a href="https://printquarters.com/about/team.php">bolaxx</a>
  <a href="https://printquarters.com/about/team.php">cemeidr</a>
  <a href="https://printquarters.com/about/team.php">rely855</a>
  <a href="https://printquarters.com/about/team.php">alfabetslot</a>
  <a href="https://printquarters.com/about/team.php">hppoker</a>
  <a href="https://printquarters.com/about/team.php">ezebet</a>
  <a href="https://printquarters.com/about/team.php">kaisarjp</a>
  <a href="https://printquarters.com/about/team.php">dunia777slot</a>
  <a href="https://printquarters.com/about/team.php">wede88</a>
  <a href="https://printquarters.com/about/team.php">ratu129</a>
  <a href="https://printquarters.com/about/team.php">dewagacor369</a>
  <a href="https://printquarters.com/about/team.php">demo rocket</a>
  <a href="https://printquarters.com/about/team.php">wsa4d</a>
  <a href="https://printquarters.com/about/team.php">ayahqq</a>
  <a href="https://printquarters.com/about/team.php">as9bet</a>
  <a href="https://printquarters.com/about/team.php">dewa88 jp</a>
  <a href="https://printquarters.com/about/team.php">asli4d</a>
  <a href="https://printquarters.com/about/team.php">megajekpot</a>
  <a href="https://printquarters.com/about/team.php">anginqq</a>
  <a href="https://printquarters.com/about/team.php">cordoba betslot</a>
  <a href="https://printquarters.com/about/team.php">foxibetslot</a>
  <a href="https://printquarters.com/about/team.php">game nexus</a>
  <a href="https://printquarters.com/about/team.php">penida88</a>
  <a href="https://printquarters.com/about/team.php">hermantoto</a>
  <a href="https://printquarters.com/about/team.php">kaumtoto</a>
  <a href="https://printquarters.com/about/team.php">adminriki</a>
  <a href="https://printquarters.com/about/team.php">mpoyes</a>
  <a href="https://printquarters.com/about/team.php">bola222</a>
  <a href="https://printquarters.com/about/team.php">slot22</a>
  <a href="https://printquarters.com/about/team.php">slotdemomaxwin</a>
  <a href="https://printquarters.com/about/team.php">netral88slot</a>
  <a href="https://printquarters.com/about/team.php">UUSTOTO</a>
  <a href="https://printquarters.com/about/team.php">uang138</a>
  <a href="https://printquarters.com/about/team.php">robothoki</a>
  <a href="https://printquarters.com/about/team.php">sin88</a>
  <a href="https://printquarters.com/about/team.php">run113</a>
  <a href="https://printquarters.com/about/team.php">slotjupiter</a>
  <a href="https://printquarters.com/about/team.php">kuyabet</a>
  <a href="https://printquarters.com/about/team.php">max parlay</a>
  <a href="https://printquarters.com/about/team.php">pialaslot</a>
  <a href="https://printquarters.com/about/team.php">dewajackpot</a>
  <a href="https://printquarters.com/about/team.php">pegasus123slot</a>
  <a href="https://printquarters.com/about/team.php">spin567</a>
  <a href="https://printquarters.com/about/team.php">ucok88</a>
  <a href="https://printquarters.com/about/team.php">maha138</a>
  <a href="https://printquarters.com/about/team.php">koinslot888 login</a>
  <a href="https://printquarters.com/about/team.php">MIKAMI88</a>
  <a href="https://printquarters.com/about/team.php">hkpools</a>
  <a href="https://printquarters.com/about/team.php">happympo</a>
  <a href="https://printquarters.com/about/team.php">M77SLOT RESMI</a>
  <a href="https://printquarters.com/about/team.php">mahjong ways2</a>
  <a href="https://printquarters.com/about/team.php">daun4d</a>
  <a href="https://printquarters.com/about/team.php">bonus poker</a>
  <a href="https://printquarters.com/about/team.php">6dtoto history</a>
  <a href="https://printquarters.com/about/team.php">serba888</a>
  <a href="https://printquarters.com/about/team.php">DATA TAIWAN</a>
  <a href="https://printquarters.com/about/team.php">ka gaming</a>
  <a href="https://printquarters.com/about/team.php">hoki77</a>
  <a href="https://printquarters.com/about/team.php">halobet88</a>
  <a href="https://printquarters.com/about/team.php">superbull</a>
  <a href="https://printquarters.com/about/team.php">game poker</a>
  <a href="https://printquarters.com/about/team.php">rtp8000slot</a>
  <a href="https://printquarters.com/about/team.php">m13game</a>
  <a href="https://printquarters.com/about/team.php">SLOT77</a>
  <a href="https://printquarters.com/about/team.php">bandar judi</a>
  <a href="https://printquarters.com/about/team.php">unsurunsurgacor</a>
  <a href="https://printquarters.com/about/team.php">raja99slot</a>
  <a href="https://printquarters.com/about/team.php">dominoqiu</a>
  <a href="https://printquarters.com/about/team.php">daftarsbobet</a>
  <a href="https://printquarters.com/about/team.php">japan4d</a>
  <a href="https://printquarters.com/about/team.php">menangbola</a>
  <a href="https://printquarters.com/about/team.php">senyumpoker</a>
  <a href="https://printquarters.com/about/team.php">HERMES88</a>
  <a href="https://printquarters.com/about/team.php">duniabet link</a>
  <a href="https://printquarters.com/about/team.php">jaminan maxwin</a>
  <a href="https://printquarters.com/about/team.php">royaltito</a>
  <a href="https://printquarters.com/about/team.php">bolatotovip</a>
  <a href="https://printquarters.com/about/team.php">panel mposlot</a>
  <a href="https://printquarters.com/about/team.php">link5rb</a>
  <a href="https://printquarters.com/about/team.php">mposlotpromo</a>
  <a href="https://printquarters.com/about/team.php">totobet77</a>
  <a href="https://printquarters.com/about/team.php">abadiqq</a>
  <a href="https://printquarters.com/about/team.php">klikqq</a>
  <a href="https://printquarters.com/about/team.php">gigaspin88</a>
  <a href="https://printquarters.com/about/team.php">xlslot888</a>
  <a href="https://printquarters.com/about/team.php">slot myanmar</a>
  <a href="https://printquarters.com/about/team.php">333hoki</a>
  <a href="https://printquarters.com/about/team.php">gacor787</a>
  <a href="https://printquarters.com/about/team.php">akun rupiah</a>
  <a href="https://printquarters.com/about/team.php">gilajitu</a>
  <a href="https://printquarters.com/about/team.php">slot neo</a>
  <a href="https://printquarters.com/about/team.php">SLOT1288</a>
  <a href="https://printquarters.com/about/team.php">judi idn</a>
  <a href="https://printquarters.com/about/team.php">scatter barcelona</a>
  <a href="https://printquarters.com/about/team.php">rokokslot4d</a>
  <a href="https://printquarters.com/about/team.php">bonanza168</a>
  <a href="https://printquarters.com/about/team.php">togel phuket</a>
  <a href="https://printquarters.com/about/team.php">singabola88</a>
  <a href="https://printquarters.com/about/team.php">SENSA123</a>
  <a href="https://printquarters.com/about/team.php">603slot</a>
  <a href="https://printquarters.com/about/team.php">nenektogel4d</a>
  <a href="https://printquarters.com/about/team.php">garuda338</a>
  <a href="https://printquarters.com/about/team.php">teshoki</a>
  <a href="https://printquarters.com/about/team.php">4keyd</a>
  <a href="https://printquarters.com/about/team.php">hoki138</a>
  <a href="https://printquarters.com/about/team.php">idgacor88</a>
  <a href="https://printquarters.com/about/team.php">pejuang303</a>
  <a href="https://printquarters.com/about/team.php">tema4d</a>
  <a href="https://printquarters.com/about/team.php">hepi8 mposlot</a>
  <a href="https://printquarters.com/about/team.php">bandar303</a>
  <a href="https://printquarters.com/about/team.php">satu38</a>
  <a href="https://printquarters.com/about/team.php">deposit pulsa</a>
  <a href="https://printquarters.com/about/team.php">pokerampm</a>
  <a href="https://printquarters.com/about/team.php">DASARTOTO</a>
  <a href="https://printquarters.com/about/team.php">777 luckyslot</a>
  <a href="https://printquarters.com/about/team.php">slot138asik</a>
  <a href="https://printquarters.com/about/team.php">dadunasution</a>
  <a href="https://printquarters.com/about/team.php">selamatqq</a>
  <a href="https://printquarters.com/about/team.php">permainan judi</a>
  <a href="https://printquarters.com/about/team.php">landslot</a>
  <a href="https://printquarters.com/about/team.php">wahana138</a>
  <a href="https://printquarters.com/about/team.php">kpr777</a>
  <a href="https://printquarters.com/about/team.php">bintang68</a>
  <a href="https://printquarters.com/about/team.php">bola gacor</a>
  <a href="https://printquarters.com/about/team.php">ultra33</a>
  <a href="https://printquarters.com/about/team.php">SOSMEDTOTO</a>
  <a href="https://printquarters.com/about/team.php">ligabandar</a>
  <a href="https://printquarters.com/about/team.php">alaitoto</a>
  <a href="https://printquarters.com/about/team.php">zeustogel</a>
  <a href="https://printquarters.com/about/team.php">surga dewa</a>
  <a href="https://printquarters.com/about/team.php">ubitoto</a>
  <a href="https://printquarters.com/about/team.php">sensa777</a>
  <a href="https://printquarters.com/about/team.php">TOGEL PCSO</a>
  <a href="https://printquarters.com/about/team.php">cahaya508</a>
  <a href="https://printquarters.com/about/team.php">SIN88</a>
  <a href="https://printquarters.com/about/team.php">PERMATA4D</a>
  <a href="https://printquarters.com/about/team.php">batuqq</a>
  <a href="https://printquarters.com/about/team.php">PEJUANGJITU</a>
  <a href="https://printquarters.com/about/team.php">mahirqq</a>
  <a href="https://printquarters.com/about/team.php">bcaplay</a>
  <a href="https://printquarters.com/about/team.php">alexabet</a>
  <a href="https://printquarters.com/about/team.php">nomor terakhir</a>
  <a href="https://printquarters.com/about/team.php">inulpoker</a>
  <a href="https://printquarters.com/about/team.php">bolagg</a>
  <a href="https://printquarters.com/about/team.php">minitotoslot</a>
  <a href="https://printquarters.com/about/team.php">HOMO4D</a>
  <a href="https://printquarters.com/about/team.php">bakar77slot</a>
  <a href="https://printquarters.com/about/team.php">doaqq</a>
  <a href="https://printquarters.com/about/team.php">gaskeunslot</a>
  <a href="https://printquarters.com/about/team.php">winslot388slot</a>
  <a href="https://printquarters.com/about/team.php">opaltoto</a>
  <a href="https://printquarters.com/about/team.php">zoom777</a>
  <a href="https://printquarters.com/about/team.php">pasar togel</a>
  <a href="https://printquarters.com/about/team.php">togel4d prize</a>
  <a href="https://printquarters.com/about/team.php">rotogel</a>
  <a href="https://printquarters.com/about/team.php">otw77</a>
  <a href="https://printquarters.com/about/team.php">slot vietnam</a>
  <a href="https://printquarters.com/about/team.php">situsbola188</a>
  <a href="https://printquarters.com/about/team.php">judol777</a>
  <a href="https://printquarters.com/about/team.php">ovo168</a>
  <a href="https://printquarters.com/about/team.php">haloqq</a>
  <a href="https://printquarters.com/about/team.php">bgibola live</a>
  <a href="https://printquarters.com/about/team.php">slot live22</a>
  <a href="https://printquarters.com/about/team.php">rajabaccarat</a>
  <a href="https://printquarters.com/about/team.php">konter4d</a>
  <a href="https://printquarters.com/about/team.php">rupiah777</a>
  <a href="https://printquarters.com/about/team.php">128slot</a>
  <a href="https://printquarters.com/about/team.php">bayutotoslot</a>
  <a href="https://printquarters.com/about/team.php">santuyaja4d</a>
  <a href="https://printquarters.com/about/team.php">99bet</a>
  <a href="https://printquarters.com/about/team.php">mega99</a>
  <a href="https://printquarters.com/about/team.php">urban89</a>
  <a href="https://printquarters.com/about/team.php">jpmania138</a>
  <a href="https://printquarters.com/about/team.php">ggbet777</a>
  <a href="https://printquarters.com/about/team.php">rtp800</a>
  <a href="https://printquarters.com/about/team.php">arab138</a>
  <a href="https://printquarters.com/about/team.php">surga99</a>
  <a href="https://printquarters.com/about/team.php">SUMTOTO</a>
  <a href="https://printquarters.com/about/team.php">NETIZEN138</a>
  <a href="https://printquarters.com/about/team.php">DIVATOGEL</a>
  <a href="https://printquarters.com/about/team.php">hana189</a>
  <a href="https://printquarters.com/about/team.php">mahadewa77</a>
  <a href="https://printquarters.com/about/team.php">123JUDI</a>
  <a href="https://printquarters.com/about/team.php">gas388</a>
  <a href="https://printquarters.com/about/team.php">fantasitoto</a>
  <a href="https://printquarters.com/about/team.php">asiragame</a>
  <a href="https://printquarters.com/about/team.php">ago303</a>
  <a href="https://printquarters.com/about/team.php">gempa777</a>
  <a href="https://printquarters.com/about/team.php">bonekaslot</a>
  <a href="https://printquarters.com/about/team.php">oborslot88</a>
  <a href="https://printquarters.com/about/team.php">kuatslot888</a>
  <a href="https://printquarters.com/about/team.php">gatot 168</a>
  <a href="https://printquarters.com/about/team.php">bolavegas</a>
  <a href="https://printquarters.com/about/team.php">winning228</a>
  <a href="https://printquarters.com/about/team.php">LUCKY88</a>
  <a href="https://printquarters.com/about/team.php">fastspin77</a>
  <a href="https://printquarters.com/about/team.php">kuya4d</a>
  <a href="https://printquarters.com/about/team.php">barak4d</a>
  <a href="https://printquarters.com/about/team.php">GACOR303 WAP</a>
  <a href="https://printquarters.com/about/team.php">king338slot</a>
  <a href="https://printquarters.com/about/team.php">pucuk88</a>
  <a href="https://printquarters.com/about/team.php">angka168</a>
  <a href="https://printquarters.com/about/team.php">kencanajitu</a>
  <a href="https://printquarters.com/about/team.php">gascor777</a>
  <a href="https://printquarters.com/about/team.php">amanslot4d</a>
  <a href="https://printquarters.com/about/team.php">pastijp6d</a>
  <a href="https://printquarters.com/about/team.php">big368</a>
  <a href="https://printquarters.com/about/team.php">lipoqq</a>
  <a href="https://printquarters.com/about/team.php">QQBET77</a>
  <a href="https://printquarters.com/about/team.php">classic</a>
  <a href="https://printquarters.com/about/team.php">omeslot</a>
  <a href="https://printquarters.com/about/team.php">gacor369</a>
  <a href="https://printquarters.com/about/team.php">keluarankamboja</a>
  <a href="https://printquarters.com/about/team.php">toto indonesia</a>
  <a href="https://printquarters.com/about/team.php">metrotppoker</a>
  <a href="https://printquarters.com/about/team.php">ou parlay</a>
  <a href="https://printquarters.com/about/team.php">bolacamar</a>
  <a href="https://printquarters.com/about/team.php">jp88vip</a>
  <a href="https://printquarters.com/about/team.php">qiuqiu99</a>
  <a href="https://printquarters.com/about/team.php">warunggacor</a>
  <a href="https://printquarters.com/about/team.php">rejekibet</a>
  <a href="https://printquarters.com/about/team.php">selir rajaslot</a>
  <a href="https://printquarters.com/about/team.php">PENTOLAN88</a>
  <a href="https://printquarters.com/about/team.php">LUCKY138</a>
  <a href="https://printquarters.com/about/team.php">bigo138</a>
  <a href="https://printquarters.com/about/team.php">slotwin</a>
  <a href="https://printquarters.com/about/team.php">infototo</a>
  <a href="https://printquarters.com/about/team.php">casper77</a>
  <a href="https://printquarters.com/about/team.php">ketiktogel</a>
  <a href="https://printquarters.com/about/team.php">ys88bet</a>
  <a href="https://printquarters.com/about/team.php">duniatotoslot</a>
  <a href="https://printquarters.com/about/team.php">besar999</a>
  <a href="https://printquarters.com/about/team.php">embunslot</a>
  <a href="https://printquarters.com/about/team.php">aseptotoslot</a>
  <a href="https://printquarters.com/about/team.php">jptoto</a>
  <a href="https://printquarters.com/about/team.php">kios365</a>
  <a href="https://printquarters.com/about/team.php">yunani</a>
  <a href="https://printquarters.com/about/team.php">lambor88</a>
  <a href="https://printquarters.com/about/team.php">nenektoto</a>
  <a href="https://printquarters.com/about/team.php">plus628</a>
  <a href="https://printquarters.com/about/team.php">slottotoslot</a>
  <a href="https://printquarters.com/about/team.php">ud dewa</a>
  <a href="https://printquarters.com/about/team.php">bet 500slot</a>
  <a href="https://printquarters.com/about/team.php">parlay prediksi</a>
  <a href="https://printquarters.com/about/team.php">138lbstokg</a>
  <a href="https://printquarters.com/about/team.php">nongki 99slot</a>
  <a href="https://printquarters.com/about/team.php">dewa505slot</a>
  <a href="https://printquarters.com/about/team.php">kapital4d</a>
  <a href="https://printquarters.com/about/team.php">makbeti168</a>
  <a href="https://printquarters.com/about/team.php">warisanbola</a>
  <a href="https://printquarters.com/about/team.php">angkanet 4d</a>
  <a href="https://printquarters.com/about/team.php">lion4dbet</a>
  <a href="https://printquarters.com/about/team.php">moro188</a>
  <a href="https://printquarters.com/about/team.php">pro8etslot</a>
  <a href="https://printquarters.com/about/team.php">datasinga</a>
  <a href="https://printquarters.com/about/team.php">bonaslot</a>
  <a href="https://printquarters.com/about/team.php">agen95</a>
  <a href="https://printquarters.com/about/team.php">playvipbet88</a>
  <a href="https://printquarters.com/about/team.php">svenus</a>
  <a href="https://printquarters.com/about/team.php">JOKER678SLOT</a>
  <a href="https://printquarters.com/about/team.php">naga388</a>
  <a href="https://printquarters.com/about/team.php">akaslot88</a>
  <a href="https://printquarters.com/about/team.php">angel4d</a>
  <a href="https://printquarters.com/about/team.php">backgroundslot</a>
  <a href="https://printquarters.com/about/team.php">bintangspin</a>
  <a href="https://printquarters.com/about/team.php">toto india</a>
  <a href="https://printquarters.com/about/team.php">PENGELUARAN HK</a>
  <a href="https://printquarters.com/about/team.php">HARGATOTO</a>
  <a href="https://printquarters.com/about/team.php">mentarislot</a>
  <a href="https://printquarters.com/about/team.php">ngpkv id</a>
  <a href="https://printquarters.com/about/team.php">99cashaa</a>
  <a href="https://printquarters.com/about/team.php">sibolga4d</a>
  <a href="https://printquarters.com/about/team.php">wijayaslot</a>
  <a href="https://printquarters.com/about/team.php">SUPERSLOT777</a>
  <a href="https://printquarters.com/about/team.php">EUROTOTO</a>
  <a href="https://printquarters.com/about/team.php">pion77top1togel</a>
  <a href="https://printquarters.com/about/team.php">mrslot777</a>
  <a href="https://printquarters.com/about/team.php">168jacpot</a>
  <a href="https://printquarters.com/about/team.php">rajapentol4d</a>
  <a href="https://printquarters.com/about/team.php">limatoto</a>
  <a href="https://printquarters.com/about/team.php">mporaya</a>
  <a href="https://printquarters.com/about/team.php">gas syd</a>
  <a href="https://printquarters.com/about/team.php">lolipop138</a>
  <a href="https://printquarters.com/about/team.php">INTERSLOT</a>
  <a href="https://printquarters.com/about/team.php">bigbet99</a>
  <a href="https://printquarters.com/about/team.php">cipung 303slot</a>
  <a href="https://printquarters.com/about/team.php">RGOCASH</a>
  <a href="https://printquarters.com/about/team.php">arti situs</a>
  <a href="https://printquarters.com/about/team.php">save4d</a>
  <a href="https://printquarters.com/about/team.php">website pay</a>
  <a href="https://printquarters.com/about/team.php">logo dewa</a>
  <a href="https://printquarters.com/about/team.php">catur777slot</a>
  <a href="https://printquarters.com/about/team.php">VIP777 LOGIN</a>
  <a href="https://printquarters.com/about/team.php">gila777</a>
  <a href="https://printquarters.com/about/team.php">s arma88</a>
  <a href="https://printquarters.com/about/team.php">pandaslot388</a>
  <a href="https://printquarters.com/about/team.php">MEGABET</a>
  <a href="https://printquarters.com/about/team.php">go888</a>
  <a href="https://printquarters.com/about/team.php">paito prancis</a>
  <a href="https://printquarters.com/about/team.php">gilaslot303</a>
  <a href="https://printquarters.com/about/team.php">alien 303slot</a>
  <a href="https://printquarters.com/about/team.php">flokitototogel</a>
  <a href="https://printquarters.com/about/team.php">slot99 bet</a>
  <a href="https://printquarters.com/about/team.php">petir308</a>
  <a href="https://printquarters.com/about/team.php">ekortoto</a>
  <a href="https://printquarters.com/about/team.php">bot1425</a>
  <a href="https://printquarters.com/about/team.php">aries123</a>
  <a href="https://printquarters.com/about/team.php">juraganplay</a>
  <a href="https://printquarters.com/about/team.php">pusathoki</a>
  <a href="https://printquarters.com/about/team.php">tempat88</a>
  <a href="https://printquarters.com/about/team.php">megahoki88</a>
  <a href="https://printquarters.com/about/team.php">pulauwin</a>
  <a href="https://printquarters.com/about/team.php">romanobet</a>
  <a href="https://printquarters.com/about/team.php">kaisarpetir</a>
  <a href="https://printquarters.com/about/team.php">impian888</a>
  <a href="https://printquarters.com/about/team.php">hola88</a>
  <a href="https://printquarters.com/about/team.php">novaslot88</a>
  <a href="https://printquarters.com/about/team.php">dsobet</a>
  <a href="https://printquarters.com/about/team.php">dolartoto</a>
  <a href="https://printquarters.com/about/team.php">mamboslot</a>
  <a href="https://printquarters.com/about/team.php">okto88</a>
  <a href="https://printquarters.com/about/team.php">slot200</a>
  <a href="https://printquarters.com/about/team.php">macauslot138</a>
  <a href="https://printquarters.com/about/team.php">jagokandang88</a>
  <a href="https://printquarters.com/about/team.php">tokyo 27slot</a>
  <a href="https://printquarters.com/about/team.php">anantabet</a>
  <a href="https://printquarters.com/about/team.php">ultra777</a>
  <a href="https://printquarters.com/about/team.php">138 club</a>
  <a href="https://printquarters.com/about/team.php">lintasmpo</a>
  <a href="https://printquarters.com/about/team.php">powernet</a>
  <a href="https://printquarters.com/about/team.php">qqgobet</a>
  <a href="https://printquarters.com/about/team.php">cv777</a>
  <a href="https://printquarters.com/about/team.php">MPO838</a>
  <a href="https://printquarters.com/about/team.php">holyslots88</a>
  <a href="https://printquarters.com/about/team.php">zonatoto</a>
  <a href="https://printquarters.com/about/team.php">MXSLOT168</a>
  <a href="https://printquarters.com/about/team.php">77maxwin</a>
  <a href="https://printquarters.com/about/team.php">dominoqiu99</a>
  <a href="https://printquarters.com/about/team.php">plisbet</a>
  <a href="https://printquarters.com/about/team.php">idwgacor</a>
  <a href="https://printquarters.com/about/team.php">ARENA77</a>
  <a href="https://printquarters.com/about/team.php">cacaslot</a>
  <a href="https://printquarters.com/about/team.php">jago 33slot</a>
  <a href="https://printquarters.com/about/team.php">138 indocuan</a>
  <a href="https://printquarters.com/about/team.php">sportsbobet</a>
  <a href="https://printquarters.com/about/team.php">pegasus988</a>
  <a href="https://printquarters.com/about/team.php">sopi88</a>
  <a href="https://printquarters.com/about/team.php">138 harta</a>
  <a href="https://printquarters.com/about/team.php">hkgtogel</a>
  <a href="https://printquarters.com/about/team.php">4x4 betslot</a>
  <a href="https://printquarters.com/about/team.php">permen 4dslot</a>
  <a href="https://printquarters.com/about/team.php">dolarmbs</a>
  <a href="https://printquarters.com/about/team.php">arwanaplay</a>
  <a href="https://printquarters.com/about/team.php">bandar389</a>
  <a href="https://printquarters.com/about/team.php">togel makasar</a>
  <a href="https://printquarters.com/about/team.php">IDR188</a>
  <a href="https://printquarters.com/about/team.php">harga808</a>
  <a href="https://printquarters.com/about/team.php">DEPOBOS</a>
  <a href="https://printquarters.com/about/team.php">CAGURBET resmi</a>
  <a href="https://printquarters.com/about/team.php">qqrolex</a>
  <a href="https://printquarters.com/about/team.php">qq4qq</a>
  <a href="https://printquarters.com/about/team.php">matahariqq</a>
  <a href="https://printquarters.com/about/team.php">scatter cambodia</a>
  <a href="https://printquarters.com/about/team.php">FREECHIPS</a>
  <a href="https://printquarters.com/about/team.php">rajawali78</a>
  <a href="https://printquarters.com/about/team.php">hit 77slot</a>
  <a href="https://printquarters.com/about/team.php">istana99slot</a>
  <a href="https://printquarters.com/about/team.php">planet77</a>
  <a href="https://printquarters.com/about/team.php">pragmetic</a>
  <a href="https://printquarters.com/about/team.php">interslot188</a>
  <a href="https://printquarters.com/about/team.php">pelanet77</a>
  <a href="https://printquarters.com/about/team.php">javtogrl</a>
  <a href="https://printquarters.com/about/team.php">akuwin77</a>
  <a href="https://printquarters.com/about/team.php">9dunia</a>
  <a href="https://printquarters.com/about/team.php">ug808</a>
  <a href="https://printquarters.com/about/team.php">togel irlandia</a>
  <a href="https://printquarters.com/about/team.php">bo bola</a>
  <a href="https://printquarters.com/about/team.php">mbo888</a>
  <a href="https://printquarters.com/about/team.php">DEWACASINO88</a>
  <a href="https://printquarters.com/about/team.php">funktotoslot</a>
  <a href="https://printquarters.com/about/team.php">liputantoto</a>
  <a href="https://printquarters.com/about/team.php">paito sdny</a>
  <a href="https://printquarters.com/about/team.php">cmobet</a>
  <a href="https://printquarters.com/about/team.php">jedi96</a>
  <a href="https://printquarters.com/about/team.php">semarakurat</a>
  <a href="https://printquarters.com/about/team.php">superslot77</a>
  <a href="https://printquarters.com/about/team.php">MANSION88 SLOT</a>
  <a href="https://printquarters.com/about/team.php">ORIENTAL77</a>
  <a href="https://printquarters.com/about/team.php">bravo mposlot</a>
  <a href="https://printquarters.com/about/team.php">cukong88</a>
  <a href="https://printquarters.com/about/team.php">slotopulsa</a>
  <a href="https://printquarters.com/about/team.php">SURGA777</a>
  <a href="https://printquarters.com/about/team.php">838win</a>
  <a href="https://printquarters.com/about/team.php">kenslot</a>
  <a href="https://printquarters.com/about/team.php">kedai 169slot</a>
  <a href="https://printquarters.com/about/team.php">billgates138</a>
  <a href="https://printquarters.com/about/team.php">olx rajaslot</a>
  <a href="https://printquarters.com/about/team.php">juara789</a>
  <a href="https://printquarters.com/about/team.php">murnitoto</a>
  <a href="https://printquarters.com/about/team.php">senopatipoker</a>
  <a href="https://printquarters.com/about/team.php">bajoslot88</a>
  <a href="https://printquarters.com/about/team.php">stadium4dslot</a>
  <a href="https://printquarters.com/about/team.php">agenslot777</a>
  <a href="https://printquarters.com/about/team.php">resulttoto</a>
  <a href="https://printquarters.com/about/team.php">planetjp</a>
  <a href="https://printquarters.com/about/team.php">nettoto</a>
  <a href="https://printquarters.com/about/team.php">masterslot99</a>
  <a href="https://printquarters.com/about/team.php">neonwin386</a>
  <a href="https://printquarters.com/about/team.php">jagoan jp</a>
  <a href="https://printquarters.com/about/team.php">bandar555gacor</a>
  <a href="https://printquarters.com/about/team.php">garudatotoslot</a>
  <a href="https://printquarters.com/about/team.php">walitoto</a>
  <a href="https://printquarters.com/about/team.php">cssin sbobet</a>
  <a href="https://printquarters.com/about/team.php">kaptenmpo</a>
  <a href="https://printquarters.com/about/team.php">keuntungan parlay</a>
  <a href="https://printquarters.com/about/team.php">OKESLOT88</a>
  <a href="https://printquarters.com/about/team.php">7agen</a>
  <a href="https://printquarters.com/about/team.php">hamtarototoslot</a>
  <a href="https://printquarters.com/about/team.php">ABANG303SLOT</a>
  <a href="https://printquarters.com/about/team.php">ura338</a>
  <a href="https://printquarters.com/about/team.php">idolaslot</a>
  <a href="https://printquarters.com/about/team.php">maccau</a>
  <a href="https://printquarters.com/about/team.php">madrtoto</a>
  <a href="https://printquarters.com/about/team.php">lonceng77</a>
  <a href="https://printquarters.com/about/team.php">situs777</a>
  <a href="https://printquarters.com/about/team.php">hsowin</a>
  <a href="https://printquarters.com/about/team.php">ultra4d</a>
  <a href="https://printquarters.com/about/team.php">MPOQQ</a>
  <a href="https://printquarters.com/about/team.php">upsobet</a>
  <a href="https://printquarters.com/about/team.php">KAYU77</a>
  <a href="https://printquarters.com/about/team.php">king78</a>
  <a href="https://printquarters.com/about/team.php">kabayan55</a>
  <a href="https://printquarters.com/about/team.php">qqkini</a>
  <a href="https://printquarters.com/about/team.php">total77</a>
  <a href="https://printquarters.com/about/team.php">syairtogelhongkong</a>
  <a href="https://printquarters.com/about/team.php">VIP66</a>
  <a href="https://printquarters.com/about/team.php">warga888</a>
  <a href="https://printquarters.com/about/team.php">168mega</a>
  <a href="https://printquarters.com/about/team.php">cermatbola</a>
  <a href="https://printquarters.com/about/team.php">parlayft95</a>
  <a href="https://printquarters.com/about/team.php">kuda betslot</a>
  <a href="https://printquarters.com/about/team.php">kawanbaru</a>
  <a href="https://printquarters.com/about/team.php">slotsggslot</a>
  <a href="https://printquarters.com/about/team.php">ideslot</a>
  <a href="https://printquarters.com/about/team.php">shionaga</a>
  <a href="https://printquarters.com/about/team.php">candy99</a>
  <a href="https://printquarters.com/about/team.php">agentotoplay</a>
  <a href="https://printquarters.com/about/team.php">sar88</a>
  <a href="https://printquarters.com/about/team.php">raya108</a>
  <a href="https://printquarters.com/about/team.php">TRIBUNTOGEL</a>
  <a href="https://printquarters.com/about/team.php">MAGNUM88</a>
  <a href="https://printquarters.com/about/team.php">maxwin adalah</a>
  <a href="https://printquarters.com/about/team.php">tirta4d</a>
  <a href="https://printquarters.com/about/team.php">agen108</a>
  <a href="https://printquarters.com/about/team.php">HANOMANTOTO</a>
  <a href="https://printquarters.com/about/team.php">latobet77</a>
  <a href="https://printquarters.com/about/team.php">5dtotoslot</a>
  <a href="https://printquarters.com/about/team.php">micin4d</a>
  <a href="https://printquarters.com/about/team.php">QQ888BET</a>
  <a href="https://printquarters.com/about/team.php">proxyium</a>
  <a href="https://printquarters.com/about/team.php">honeybet303</a>
  <a href="https://printquarters.com/about/team.php">SLOTKING99</a>
  <a href="https://printquarters.com/about/team.php">sumbertogel</a>
  <a href="https://printquarters.com/about/team.php">HKBGAMING</a>
  <a href="https://printquarters.com/about/team.php">duniaqq</a>
  <a href="https://printquarters.com/about/team.php">sule88</a>
  <a href="https://printquarters.com/about/team.php">game37</a>
  <a href="https://printquarters.com/about/team.php">rapatslot</a>
  <a href="https://printquarters.com/about/team.php">togelbet888</a>
  <a href="https://printquarters.com/about/team.php">ezykasino</a>
  <a href="https://printquarters.com/about/team.php">delima4d</a>
  <a href="https://printquarters.com/about/team.php">77bandar</a>
  <a href="https://printquarters.com/about/team.php">BERLIAN889</a>
  <a href="https://printquarters.com/about/team.php">ngeriqq</a>
  <a href="https://printquarters.com/about/team.php">datamacau4d</a>
  <a href="https://printquarters.com/about/team.php">xtogel</a>
  <a href="https://printquarters.com/about/team.php">wahyupoker</a>
  <a href="https://printquarters.com/about/team.php">pintoto</a>
  <a href="https://printquarters.com/about/team.php">walet789</a>
  <a href="https://printquarters.com/about/team.php">banteng369</a>
  <a href="https://printquarters.com/about/team.php">bandar sgp45</a>
  <a href="https://printquarters.com/about/team.php">ligagg88</a>
  <a href="https://printquarters.com/about/team.php">rajafafa</a>
  <a href="https://printquarters.com/about/team.php">bulan88</a>
  <a href="https://printquarters.com/about/team.php">paito phoenix</a>
  <a href="https://printquarters.com/about/team.php">beres77</a>
  <a href="https://printquarters.com/about/team.php">kenzo168</a>
  <a href="https://printquarters.com/about/team.php">permata888</a>
  <a href="https://printquarters.com/about/team.php">langit4d</a>
  <a href="https://printquarters.com/about/team.php">lumbungslot</a>
  <a href="https://printquarters.com/about/team.php">lensa 4dslot</a>
  <a href="https://printquarters.com/about/team.php">arena777</a>
  <a href="https://printquarters.com/about/team.php">dominobet</a>
  <a href="https://printquarters.com/about/team.php">nuansa dewaslot</a>
  <a href="https://printquarters.com/about/team.php">jayaslot</a>
  <a href="https://printquarters.com/about/team.php">golden89</a>
  <a href="https://printquarters.com/about/team.php">mars88</a>
  <a href="https://printquarters.com/about/team.php">sasaranjitu</a>
  <a href="https://printquarters.com/about/team.php">cemara123</a>
  <a href="https://printquarters.com/about/team.php">rtp55</a>
  <a href="https://printquarters.com/about/team.php">pialabola365</a>
  <a href="https://printquarters.com/about/team.php">jos88</a>
  <a href="https://printquarters.com/about/team.php">ularsloto77</a>
  <a href="https://printquarters.com/about/team.php">GB777 WAP</a>
  <a href="https://printquarters.com/about/team.php">logika138</a>
  <a href="https://printquarters.com/about/team.php">asiawin77</a>
  <a href="https://printquarters.com/about/team.php">cash77slot</a>
  <a href="https://printquarters.com/about/team.php">american blackjack</a>
  <a href="https://printquarters.com/about/team.php">pandora88</a>
  <a href="https://printquarters.com/about/team.php">dewabet apk</a>
  <a href="https://printquarters.com/about/team.php">juon88</a>
  <a href="https://printquarters.com/about/team.php">padang</a>
  <a href="https://printquarters.com/about/team.php">turbospin138</a>
  <a href="https://printquarters.com/about/team.php">CERITOTO</a>
  <a href="https://printquarters.com/about/team.php">juragan303</a>
  <a href="https://printquarters.com/about/team.php">vegasslot77a</a>
  <a href="https://printquarters.com/about/team.php">indopools</a>
  <a href="https://printquarters.com/about/team.php">suryatotoslot</a>
  <a href="https://printquarters.com/about/team.php">holywin303</a>
  <a href="https://printquarters.com/about/team.php">tokendeposlot</a>
  <a href="https://printquarters.com/about/team.php">dewaslot369</a>
  <a href="https://printquarters.com/about/team.php">milo888</a>
  <a href="https://printquarters.com/about/team.php">138ztm</a>
  <a href="https://printquarters.com/about/team.php">win11bet</a>
  <a href="https://printquarters.com/about/team.php">superslot</a>
  <a href="https://printquarters.com/about/team.php">mpo waletslot</a>
  <a href="https://printquarters.com/about/team.php">prado777</a>
  <a href="https://printquarters.com/about/team.php">debutotoslot</a>
  <a href="https://printquarters.com/about/team.php">musimslot888</a>
  <a href="https://printquarters.com/about/team.php">AGEN838</a>
  <a href="https://printquarters.com/about/team.php">gacorwayang</a>
  <a href="https://printquarters.com/about/team.php">lix 21</a>
  <a href="https://printquarters.com/about/team.php">pusatraja138</a>
  <a href="https://printquarters.com/about/team.php">w88</a>
  <a href="https://printquarters.com/about/team.php">lotus4d1</a>
  <a href="https://printquarters.com/about/team.php">vipselot</a>
  <a href="https://printquarters.com/about/team.php">ketut4d</a>
  <a href="https://printquarters.com/about/team.php">nexplay777</a>
  <a href="https://printquarters.com/about/team.php">GACOR 777</a>
  <a href="https://printquarters.com/about/team.php">keluarga4d</a>
  <a href="https://printquarters.com/about/team.php">perjudian adalah</a>
  <a href="https://printquarters.com/about/team.php">airasiabet</a>
  <a href="https://printquarters.com/about/team.php">gbogacor</a>
  <a href="https://printquarters.com/about/team.php">slot coaster</a>
  <a href="https://printquarters.com/about/team.php">kuda hitamslot</a>
  <a href="https://printquarters.com/about/team.php">happyjudislot</a>
  <a href="https://printquarters.com/about/team.php">gajahbola</a>
  <a href="https://printquarters.com/about/team.php">NAGASLOT99</a>
  <a href="https://printquarters.com/about/team.php">gencarqq</a>
  <a href="https://printquarters.com/about/team.php">win999</a>
  <a href="https://printquarters.com/about/team.php">demo santa</a>
  <a href="https://printquarters.com/about/team.php">kingkong4d</a>
  <a href="https://printquarters.com/about/team.php">andahoki</a>
  <a href="https://printquarters.com/about/team.php">racing car</a>
  <a href="https://printquarters.com/about/team.php">3tangkas</a>
  <a href="https://printquarters.com/about/team.php">ayutogel</a>
  <a href="https://printquarters.com/about/team.php">LIGA388</a>
  <a href="https://printquarters.com/about/team.php">istanavip</a>
  <a href="https://printquarters.com/about/team.php">kingdom777</a>
  <a href="https://printquarters.com/about/team.php">bling88</a>
  <a href="https://printquarters.com/about/team.php">pbtoto</a>
  <a href="https://printquarters.com/about/team.php">slotjitu88</a>
  <a href="https://printquarters.com/about/team.php">usaklub</a>
  <a href="https://printquarters.com/about/team.php">amavi5d</a>
  <a href="https://printquarters.com/about/team.php">togelnew york</a>
  <a href="https://printquarters.com/about/team.php">demo club</a>
  <a href="https://printquarters.com/about/team.php">raja bandarslot</a>
  <a href="https://printquarters.com/about/team.php">BOBA4D</a>
  <a href="https://printquarters.com/about/team.php">harapanqq</a>
  <a href="https://printquarters.com/about/team.php">betawitoto</a>
  <a href="https://printquarters.com/about/team.php">enam 66slot</a>
  <a href="https://printquarters.com/about/team.php">maha303</a>
  <a href="https://printquarters.com/about/team.php">ngamentoto</a>
  <a href="https://printquarters.com/about/team.php">link dominoqq</a>
  <a href="https://printquarters.com/about/team.php">pengertian situs</a>
  <a href="https://printquarters.com/about/team.php">chit poker</a>
  <a href="https://printquarters.com/about/team.php">vjudi</a>
  <a href="https://printquarters.com/about/team.php">ferraritotoslot</a>
  <a href="https://printquarters.com/about/team.php">perangjitu</a>
  <a href="https://printquarters.com/about/team.php">alfa4dslot</a>
  <a href="https://printquarters.com/about/team.php">garuda365</a>
  <a href="https://printquarters.com/about/team.php">mbs88slot</a>
  <a href="https://printquarters.com/about/team.php">overbola</a>
  <a href="https://printquarters.com/about/team.php">madetogel</a>
  <a href="https://printquarters.com/about/team.php">lahir99 com</a>
  <a href="https://printquarters.com/about/team.php">dunia77</a>
  <a href="https://printquarters.com/about/team.php">jelaspoker</a>
  <a href="https://printquarters.com/about/team.php">juara888</a>
  <a href="https://printquarters.com/about/team.php">kelinci777</a>
  <a href="https://printquarters.com/about/team.php">mimi gaming</a>
  <a href="https://printquarters.com/about/team.php">juragan77slot</a>
  <a href="https://printquarters.com/about/team.php">puncak 138slot</a>
  <a href="https://printquarters.com/about/team.php">slotajib</a>
  <a href="https://printquarters.com/about/team.php">MARKET898</a>
  <a href="https://printquarters.com/about/team.php">sakuratoto2</a>
  <a href="https://printquarters.com/about/team.php">cakrabetslot</a>
  <a href="https://printquarters.com/about/team.php">RAJASLOT77</a>
  <a href="https://printquarters.com/about/team.php">bunga77</a>
  <a href="https://printquarters.com/about/team.php">man777</a>
  <a href="https://printquarters.com/about/team.php">target88</a>
  <a href="https://printquarters.com/about/team.php">bagus365</a>
  <a href="https://printquarters.com/about/team.php">megawin888</a>
  <a href="https://printquarters.com/about/team.php">merapitoto</a>
  <a href="https://printquarters.com/about/team.php">mujur betslot</a>
  <a href="https://printquarters.com/about/team.php">india</a>
  <a href="https://printquarters.com/about/team.php">nusaslottoto</a>
  <a href="https://printquarters.com/about/team.php">asia89</a>
  <a href="https://printquarters.com/about/team.php">skybola188</a>
  <a href="https://printquarters.com/about/team.php">jagotogel</a>
  <a href="https://printquarters.com/about/team.php">sekata303</a>
  <a href="https://printquarters.com/about/team.php">togelraksasa</a>
  <a href="https://printquarters.com/about/team.php">toyotaplay</a>
  <a href="https://printquarters.com/about/team.php">slot yunani</a>
  <a href="https://printquarters.com/about/team.php">slotgembira777</a>
  <a href="https://printquarters.com/about/team.php">mpo88qq</a>
  <a href="https://printquarters.com/about/team.php">k86sport</a>
  <a href="https://printquarters.com/about/team.php">vipertoto</a>
  <a href="https://printquarters.com/about/team.php">kucing69</a>
  <a href="https://printquarters.com/about/team.php">pay situs</a>
  <a href="https://printquarters.com/about/team.php">booongo casino</a>
  <a href="https://printquarters.com/about/team.php">hulu4d</a>
  <a href="https://printquarters.com/about/team.php">MAKTOTO</a>
  <a href="https://printquarters.com/about/team.php">138lasvegas</a>
  <a href="https://printquarters.com/about/team.php">rtpslot</a>
  <a href="https://printquarters.com/about/team.php">138rekeningapa</a>
  <a href="https://printquarters.com/about/team.php">playingslot</a>
  <a href="https://printquarters.com/about/team.php">togeltaiwan</a>
  <a href="https://printquarters.com/about/team.php">serverrusia</a>
  <a href="https://printquarters.com/about/team.php">barbar77</a>
  <a href="https://printquarters.com/about/team.php">santuy 777slot</a>
  <a href="https://printquarters.com/about/team.php">totosidney</a>
  <a href="https://printquarters.com/about/team.php">keposlot</a>
  <a href="https://printquarters.com/about/team.php">jakartaqq</a>
  <a href="https://printquarters.com/about/team.php">kiss138</a>
  <a href="https://printquarters.com/about/team.php">crv 4dslot</a>
  <a href="https://printquarters.com/about/team.php">kaisar633</a>
  <a href="https://printquarters.com/about/team.php">chivas77</a>
  <a href="https://printquarters.com/about/team.php">delima88</a>
  <a href="https://printquarters.com/about/team.php">akun4d</a>
  <a href="https://printquarters.com/about/team.php">fachai slot</a>
  <a href="https://printquarters.com/about/team.php">ozplay88</a>
  <a href="https://printquarters.com/about/team.php">reogtogel</a>
  <a href="https://printquarters.com/about/team.php">SOLID88</a>
  <a href="https://printquarters.com/about/team.php">livdrawhk</a>
  <a href="https://printquarters.com/about/team.php">tango777</a>
  <a href="https://printquarters.com/about/team.php">yunanipools</a>
  <a href="https://printquarters.com/about/team.php">tuyul168</a>
  <a href="https://printquarters.com/about/team.php">cloverqq</a>
  <a href="https://printquarters.com/about/team.php">miabet88</a>
  <a href="https://printquarters.com/about/team.php">arenabet</a>
  <a href="https://printquarters.com/about/team.php">inti123</a>
  <a href="https://printquarters.com/about/team.php">ALLBET</a>
  <a href="https://printquarters.com/about/team.php">aiabet365</a>
  <a href="https://printquarters.com/about/team.php">keluaran siem</a>
  <a href="https://printquarters.com/about/team.php">siap46slot</a>
  <a href="https://printquarters.com/about/team.php">jokoslot</a>
  <a href="https://printquarters.com/about/team.php">luna betslot</a>
  <a href="https://printquarters.com/about/team.php">UTAMABET</a>
  <a href="https://printquarters.com/about/team.php">oscar28</a>
  <a href="https://printquarters.com/about/team.php">idlix</a>
  <a href="https://printquarters.com/about/team.php">slot crystal</a>
  <a href="https://printquarters.com/about/team.php">dewaslot777</a>
  <a href="https://printquarters.com/about/team.php">S2SLOT</a>
  <a href="https://printquarters.com/about/team.php">gojek123</a>
  <a href="https://printquarters.com/about/team.php">PLAY4D</a>
  <a href="https://printquarters.com/about/team.php">kinggacor</a>
  <a href="https://printquarters.com/about/team.php">okplay777</a>
  <a href="https://printquarters.com/about/team.php">aqua77</a>
  <a href="https://printquarters.com/about/team.php">kaostogel</a>
  <a href="https://printquarters.com/about/team.php">MANDIRI88</a>
  <a href="https://printquarters.com/about/team.php">betwin138</a>
  <a href="https://printquarters.com/about/team.php">ozzo slot</a>
  <a href="https://printquarters.com/about/team.php">pejabattogel</a>
  <a href="https://printquarters.com/about/team.php">kapalbet125</a>
  <a href="https://printquarters.com/about/team.php">opera88</a>
  <a href="https://printquarters.com/about/team.php">CUAN888</a>
  <a href="https://printquarters.com/about/team.php">rajaslotslot</a>
  <a href="https://printquarters.com/about/team.php">dewabet 72</a>
  <a href="https://printquarters.com/about/team.php">delimapoker</a>
  <a href="https://printquarters.com/about/team.php">fosilqq</a>
  <a href="https://printquarters.com/about/team.php">JENTOTO</a>
  <a href="https://printquarters.com/about/team.php">PKPLAY</a>
  <a href="https://printquarters.com/about/team.php">yoyoslot</a>
  <a href="https://printquarters.com/about/team.php">BERLIAN88</a>
  <a href="https://printquarters.com/about/team.php">jembatan777</a>
  <a href="https://printquarters.com/about/team.php">rodabet</a>
  <a href="https://printquarters.com/about/team.php">listrik88</a>
  <a href="https://printquarters.com/about/team.php">btv456</a>
  <a href="https://printquarters.com/about/team.php">darumasakti</a>
  <a href="https://printquarters.com/about/team.php">mandalatogel</a>
  <a href="https://printquarters.com/about/team.php">ml138slot</a>
  <a href="https://printquarters.com/about/team.php">RADEN777</a>
  <a href="https://printquarters.com/about/team.php">matahari188</a>
  <a href="https://printquarters.com/about/team.php">CINCIN99</a>
  <a href="https://printquarters.com/about/team.php">ninja138slot</a>
  <a href="https://printquarters.com/about/team.php">mpo kayaslot</a>
  <a href="https://printquarters.com/about/team.php">888tambang</a>
  <a href="https://printquarters.com/about/team.php">puncak303</a>
  <a href="https://printquarters.com/about/team.php">kota 77slot</a>
  <a href="https://printquarters.com/about/team.php">slot apk</a>
  <a href="https://printquarters.com/about/team.php">papi55</a>
  <a href="https://printquarters.com/about/team.php">tigerkoin</a>
  <a href="https://printquarters.com/about/team.php">mujurtoto</a>
  <a href="https://printquarters.com/about/team.php">loby303</a>
  <a href="https://printquarters.com/about/team.php">poker555</a>
  <a href="https://printquarters.com/about/team.php">main168</a>
  <a href="https://printquarters.com/about/team.php">partner138</a>
  <a href="https://printquarters.com/about/team.php">csobet88</a>
  <a href="https://printquarters.com/about/team.php">santuyjp</a>
  <a href="https://printquarters.com/about/team.php">spin123</a>
  <a href="https://printquarters.com/about/team.php">dewa389</a>
  <a href="https://printquarters.com/about/team.php">EBET88</a>
  <a href="https://printquarters.com/about/team.php">cheat gratis</a>
  <a href="https://printquarters.com/about/team.php">sokkerland</a>
  <a href="https://printquarters.com/about/team.php">PANDA4D</a>
  <a href="https://printquarters.com/about/team.php">lontetoto</a>
  <a href="https://printquarters.com/about/team.php">fbslot888</a>
  <a href="https://printquarters.com/about/team.php">togelhimalaya4d</a>
  <a href="https://printquarters.com/about/team.php">slotbca</a>
  <a href="https://printquarters.com/about/team.php">delta288</a>
  <a href="https://printquarters.com/about/team.php">slot madame</a>
  <a href="https://printquarters.com/about/team.php">terminal4d</a>
  <a href="https://printquarters.com/about/team.php">rezeki123slot</a>
  <a href="https://printquarters.com/about/team.php">prima88</a>
  <a href="https://printquarters.com/about/team.php">top77</a>
  <a href="https://printquarters.com/about/team.php">VENUSMPO</a>
  <a href="https://printquarters.com/about/team.php">gacorwin138</a>
  <a href="https://printquarters.com/about/team.php">JOTUNTOTO</a>
  <a href="https://printquarters.com/about/team.php">suneo 138</a>
  <a href="https://printquarters.com/about/team.php">bbo303</a>
  <a href="https://printquarters.com/about/team.php">slot online138</a>
  <a href="https://printquarters.com/about/team.php">138kuhp</a>
  <a href="https://printquarters.com/about/team.php">cepattoto</a>
  <a href="https://printquarters.com/about/team.php">bos99</a>
  <a href="https://printquarters.com/about/team.php">GLOWING88</a>
  <a href="https://printquarters.com/about/team.php">casino 777</a>
  <a href="https://printquarters.com/about/team.php">ASIK303</a>
  <a href="https://printquarters.com/about/team.php">situsslot303</a>
  <a href="https://printquarters.com/about/team.php">slotjituslot</a>
  <a href="https://printquarters.com/about/team.php">link5000</a>
  <a href="https://printquarters.com/about/team.php">totosuper</a>
  <a href="https://printquarters.com/about/team.php">demo christmas</a>
  <a href="https://printquarters.com/about/team.php">aztec88</a>
  <a href="https://printquarters.com/about/team.php">lebel138slot</a>
  <a href="https://printquarters.com/about/team.php">murah138</a>
  <a href="https://printquarters.com/about/team.php">paitogel</a>
  <a href="https://printquarters.com/about/team.php">TEXASPOKERCC11</a>
  <a href="https://printquarters.com/about/team.php">togel indiana</a>
  <a href="https://printquarters.com/about/team.php">vilabet4d</a>
  <a href="https://printquarters.com/about/team.php">sydney prize</a>
  <a href="https://printquarters.com/about/team.php">judisgpslot</a>
  <a href="https://printquarters.com/about/team.php">polawin138</a>
  <a href="https://printquarters.com/about/team.php">jayaspin</a>
  <a href="https://printquarters.com/about/team.php">panen123</a>
  <a href="https://printquarters.com/about/team.php">skandaltoto</a>
  <a href="https://printquarters.com/about/team.php">bca4d</a>
  <a href="https://printquarters.com/about/team.php">win7poker</a>
  <a href="https://printquarters.com/about/team.php">royalcuan</a>
  <a href="https://printquarters.com/about/team.php">138 sultan</a>
  <a href="https://printquarters.com/about/team.php">gentong99</a>
  <a href="https://printquarters.com/about/team.php">stmbet</a>
  <a href="https://printquarters.com/about/team.php">kumis168</a>
  <a href="https://printquarters.com/about/team.php">SAGA98</a>
  <a href="https://printquarters.com/about/team.php">trisula88</a>
  <a href="https://printquarters.com/about/team.php">saingqq</a>
  <a href="https://printquarters.com/about/team.php">KITA88</a>
  <a href="https://printquarters.com/about/team.php">login5000</a>
  <a href="https://printquarters.com/about/team.php">mitrapoker88</a>
  <a href="https://printquarters.com/about/team.php">pandawa177</a>
  <a href="https://printquarters.com/about/team.php">yukislot99</a>
  <a href="https://printquarters.com/about/team.php">auto88</a>
  <a href="https://printquarters.com/about/team.php">BINJAITOTO</a>
  <a href="https://printquarters.com/about/team.php">mpo22</a>
  <a href="https://printquarters.com/about/team.php">MBO88</a>
  <a href="https://printquarters.com/about/team.php">klik88slot</a>
  <a href="https://printquarters.com/about/team.php">rajabandar</a>
  <a href="https://printquarters.com/about/team.php">auragacor</a>
  <a href="https://printquarters.com/about/team.php">kapakbet alternatif</a>
  <a href="https://printquarters.com/about/team.php">dewaraja99</a>
  <a href="https://printquarters.com/about/team.php">pulsa dana</a>
  <a href="https://printquarters.com/about/team.php">gacorgoceng</a>
  <a href="https://printquarters.com/about/team.php">bonus88</a>
  <a href="https://printquarters.com/about/team.php">paito wild</a>
  <a href="https://printquarters.com/about/team.php">emas787</a>
  <a href="https://printquarters.com/about/team.php">rasa123</a>
  <a href="https://printquarters.com/about/team.php">main365</a>
  <a href="https://printquarters.com/about/team.php">BEBEK4D</a>
  <a href="https://printquarters.com/about/team.php">ASIATOTO WAP</a>
  <a href="https://printquarters.com/about/team.php">max99win</a>
  <a href="https://printquarters.com/about/team.php">asiaslot99</a>
  <a href="https://printquarters.com/about/team.php">link777</a>
  <a href="https://printquarters.com/about/team.php">SANDIBET</a>
  <a href="https://printquarters.com/about/team.php">hokbentoto</a>
  <a href="https://printquarters.com/about/team.php">shine4d</a>
  <a href="https://printquarters.com/about/team.php">permatabet</a>
  <a href="https://printquarters.com/about/team.php">pokermas99</a>
  <a href="https://printquarters.com/about/team.php">hokibet368</a>
  <a href="https://printquarters.com/about/team.php">queenbet77</a>
  <a href="https://printquarters.com/about/team.php">gacor988bet</a>
  <a href="https://printquarters.com/about/team.php">samudra4d</a>
  <a href="https://printquarters.com/about/team.php">duniabet chat</a>
  <a href="https://printquarters.com/about/team.php">rajasakong88</a>
  <a href="https://printquarters.com/about/team.php">LUMBUNG88</a>
  <a href="https://printquarters.com/about/team.php">magnum88</a>
  <a href="https://printquarters.com/about/team.php">GAS55</a>
  <a href="https://printquarters.com/about/team.php">republik365</a>
  <a href="https://printquarters.com/about/team.php">portuneslot88</a>
  <a href="https://printquarters.com/about/team.php">area777</a>
  <a href="https://printquarters.com/about/team.php">wondertotoslot</a>
  <a href="https://printquarters.com/about/team.php">poker88wd</a>
  <a href="https://printquarters.com/about/team.php">kuro138</a>
  <a href="https://printquarters.com/about/team.php">qqslot998</a>
  <a href="https://printquarters.com/about/team.php">emas hokislot</a>
  <a href="https://printquarters.com/about/team.php">panen jpslot</a>
  <a href="https://printquarters.com/about/team.php">sip77</a>
  <a href="https://printquarters.com/about/team.php">taxigacor</a>
  <a href="https://printquarters.com/about/team.php">arena178</a>
  <a href="https://printquarters.com/about/team.php">toto26</a>
  <a href="https://printquarters.com/about/team.php">oppa99</a>
  <a href="https://printquarters.com/about/team.php">baratbet</a>
  <a href="https://printquarters.com/about/team.php">ekotogel</a>
  <a href="https://printquarters.com/about/team.php">kabel4d</a>
  <a href="https://printquarters.com/about/team.php">gas 77slot</a>
  <a href="https://printquarters.com/about/team.php">pusatslot888</a>
  <a href="https://printquarters.com/about/team.php">138rupiah</a>
  <a href="https://printquarters.com/about/team.php">qq101</a>
  <a href="https://printquarters.com/about/team.php">eubetslot</a>
  <a href="https://printquarters.com/about/team.php">tani4d</a>
  <a href="https://printquarters.com/about/team.php">rajaslot77</a>
  <a href="https://printquarters.com/about/team.php">haritogel</a>
  <a href="https://printquarters.com/about/team.php">matahari55</a>
  <a href="https://printquarters.com/about/team.php">superkaya88</a>
  <a href="https://printquarters.com/about/team.php">dragon303slot</a>
  <a href="https://printquarters.com/about/team.php">WEBSLOT</a>
  <a href="https://printquarters.com/about/team.php">redmitotoslot</a>
  <a href="https://printquarters.com/about/team.php">topbet88</a>
  <a href="https://printquarters.com/about/team.php">depobet88</a>
  <a href="https://printquarters.com/about/team.php">HAPPYBET99</a>
  <a href="https://printquarters.com/about/team.php">link66k</a>
  <a href="https://printquarters.com/about/team.php">livescore anderlecht</a>
  <a href="https://printquarters.com/about/team.php">armada365</a>
  <a href="https://printquarters.com/about/team.php">duniampo</a>
  <a href="https://printquarters.com/about/team.php">ug324</a>
  <a href="https://printquarters.com/about/team.php">higgsslot</a>
  <a href="https://printquarters.com/about/team.php">lumbung138</a>
  <a href="https://printquarters.com/about/team.php">hepiqq</a>
  <a href="https://printquarters.com/about/team.php">RAJABOLA88</a>
  <a href="https://printquarters.com/about/team.php">imo188</a>
  <a href="https://printquarters.com/about/team.php">bmx4d</a>
  <a href="https://printquarters.com/about/team.php">pragmatic90</a>
  <a href="https://printquarters.com/about/team.php">deposelot</a>
  <a href="https://printquarters.com/about/team.php">megasloto188</a>
  <a href="https://printquarters.com/about/team.php">rajaindo33</a>
  <a href="https://printquarters.com/about/team.php">ingattoto</a>
  <a href="https://printquarters.com/about/team.php">bocilgacor</a>
  <a href="https://printquarters.com/about/team.php">TOTO123</a>
  <a href="https://printquarters.com/about/team.php">extraslot</a>
  <a href="https://printquarters.com/about/team.php">ivoslot</a>
  <a href="https://printquarters.com/about/team.php">tempur777</a>
  <a href="https://printquarters.com/about/team.php">yakin99</a>
  <a href="https://printquarters.com/about/team.php">pramatig88</a>
  <a href="https://printquarters.com/about/team.php">pokerseri</a>
  <a href="https://printquarters.com/about/team.php">ROYALBET88</a>
  <a href="https://printquarters.com/about/team.php">TY303</a>
  <a href="https://printquarters.com/about/team.php">omset88</a>
  <a href="https://printquarters.com/about/team.php">terang69</a>
  <a href="https://printquarters.com/about/team.php">putraspin</a>
  <a href="https://printquarters.com/about/team.php">slotplus88</a>
  <a href="https://printquarters.com/about/team.php">pecahbet</a>
  <a href="https://printquarters.com/about/team.php">mega123</a>
  <a href="https://printquarters.com/about/team.php">gasbet88slot</a>
  <a href="https://printquarters.com/about/team.php">MAMASLOT88</a>
  <a href="https://printquarters.com/about/team.php">roboslot</a>
  <a href="https://printquarters.com/about/team.php">mbs88</a>
  <a href="https://printquarters.com/about/team.php">boljug55</a>
  <a href="https://printquarters.com/about/team.php">mpo808</a>
  <a href="https://printquarters.com/about/team.php">pokerqq81</a>
  <a href="https://printquarters.com/about/team.php">domino 99</a>
  <a href="https://printquarters.com/about/team.php">BALI4D</a>
  <a href="https://printquarters.com/about/team.php">seven777</a>
  <a href="https://printquarters.com/about/team.php">teskiu</a>
  <a href="https://printquarters.com/about/team.php">bimabet</a>
  <a href="https://printquarters.com/about/team.php">mahagacorslot</a>
  <a href="https://printquarters.com/about/team.php">duniabet303slot</a>
  <a href="https://printquarters.com/about/team.php">pragmetice88</a>
  <a href="https://printquarters.com/about/team.php">dunia 18slot</a>
  <a href="https://printquarters.com/about/team.php">hadiahrajatoto4</a>
  <a href="https://printquarters.com/about/team.php">surgaplai</a>
  <a href="https://printquarters.com/about/team.php">jalatogel</a>
  <a href="https://printquarters.com/about/team.php">sakti138</a>
  <a href="https://printquarters.com/about/team.php">jaksatogel</a>
  <a href="https://printquarters.com/about/team.php">juragangaming</a>
  <a href="https://printquarters.com/about/team.php">casino228</a>
  <a href="https://printquarters.com/about/team.php">sl826</a>
  <a href="https://printquarters.com/about/team.php">gacor131</a>
  <a href="https://printquarters.com/about/team.php">n goal</a>
  <a href="https://printquarters.com/about/team.php">jamslot77</a>
  <a href="https://printquarters.com/about/team.php">langkacurang</a>
  <a href="https://printquarters.com/about/team.php">gamespols</a>
  <a href="https://printquarters.com/about/team.php">permataqqslot</a>
  <a href="https://printquarters.com/about/team.php">pandawa138</a>
  <a href="https://printquarters.com/about/team.php">sensasional138</a>
  <a href="https://printquarters.com/about/team.php">gudangpoker</a>
  <a href="https://printquarters.com/about/team.php">paitowarnasdy</a>
  <a href="https://printquarters.com/about/team.php">lietoto</a>
  <a href="https://printquarters.com/about/team.php">olympus slot</a>
  <a href="https://printquarters.com/about/team.php">oxl88aa</a>
  <a href="https://printquarters.com/about/team.php">PANDA888</a>
  <a href="https://printquarters.com/about/team.php">dewakslot777</a>
  <a href="https://printquarters.com/about/team.php">areadominoid</a>
  <a href="https://printquarters.com/about/team.php">fafa188</a>
  <a href="https://printquarters.com/about/team.php">klubkaya</a>
  <a href="https://printquarters.com/about/team.php">monperatoto</a>
  <a href="https://printquarters.com/about/team.php">KARTU88</a>
  <a href="https://printquarters.com/about/team.php">kunbos</a>
  <a href="https://printquarters.com/about/team.php">dewataslot888</a>
  <a href="https://printquarters.com/about/team.php">fastslot88</a>
  <a href="https://printquarters.com/about/team.php">texas123</a>
  <a href="https://printquarters.com/about/team.php">qris 5k</a>
  <a href="https://printquarters.com/about/team.php">kepritoto</a>
  <a href="https://printquarters.com/about/team.php">nextogel</a>
  <a href="https://printquarters.com/about/team.php">diva4d</a>
  <a href="https://printquarters.com/about/team.php">mvp777</a>
  <a href="https://printquarters.com/about/team.php">rock777star</a>
  <a href="https://printquarters.com/about/team.php">ratugacor</a>
  <a href="https://printquarters.com/about/team.php">menangjp</a>
  <a href="https://printquarters.com/about/team.php">MEKONG4D</a>
  <a href="https://printquarters.com/about/team.php">slot christmas</a>
  <a href="https://printquarters.com/about/team.php">lapak gaming</a>
  <a href="https://printquarters.com/about/team.php">scatter myanmar</a>
  <a href="https://printquarters.com/about/team.php">antirungkad</a>
  <a href="https://printquarters.com/about/team.php">pamela poker</a>
  <a href="https://printquarters.com/about/team.php">FIRE88</a>
  <a href="https://printquarters.com/about/team.php">serasiqq</a>
  <a href="https://printquarters.com/about/team.php">GARUDA99</a>
  <a href="https://printquarters.com/about/team.php">nadiemtogel</a>
  <a href="https://printquarters.com/about/team.php">netralbetslot</a>
  <a href="https://printquarters.com/about/team.php">pemain888</a>
  <a href="https://printquarters.com/about/team.php">138gajah</a>
  <a href="https://printquarters.com/about/team.php">eyetoto</a>
  <a href="https://printquarters.com/about/team.php">rumahslot777</a>
  <a href="https://printquarters.com/about/team.php">togel sdy</a>
  <a href="https://printquarters.com/about/team.php">mahjongslot</a>
  <a href="https://printquarters.com/about/team.php">goodtogel</a>
  <a href="https://printquarters.com/about/team.php">rajamahjong</a>
  <a href="https://printquarters.com/about/team.php">agen sv388</a>
  <a href="https://printquarters.com/about/team.php">keluaran solo</a>
  <a href="https://printquarters.com/about/team.php">demo jurassic</a>
  <a href="https://printquarters.com/about/team.php">kratonbetslot</a>
  <a href="https://printquarters.com/about/team.php">gacor36</a>
  <a href="https://printquarters.com/about/team.php">xplay888</a>
  <a href="https://printquarters.com/about/team.php">pass4d</a>
  <a href="https://printquarters.com/about/team.php">bri4dslot</a>
  <a href="https://printquarters.com/about/team.php">rusuntoto</a>
  <a href="https://printquarters.com/about/team.php">angkartu</a>
  <a href="https://printquarters.com/about/team.php">sakai99</a>
  <a href="https://printquarters.com/about/team.php">master dewaslot</a>
  <a href="https://printquarters.com/about/team.php">konglo123slot</a>
  <a href="https://printquarters.com/about/team.php">mposurga</a>
  <a href="https://printquarters.com/about/team.php">SUPER123</a>
  <a href="https://printquarters.com/about/team.php">kursi777</a>
  <a href="https://printquarters.com/about/team.php">laskarbola88</a>
  <a href="https://printquarters.com/about/team.php">snaptoto</a>
  <a href="https://printquarters.com/about/team.php">lestariqq</a>
  <a href="https://printquarters.com/about/team.php">pulsa 777slot</a>
  <a href="https://printquarters.com/about/team.php">pustakatoto</a>
  <a href="https://printquarters.com/about/team.php">glx</a>
  <a href="https://printquarters.com/about/team.php">PAP777</a>
  <a href="https://printquarters.com/about/team.php">tempur4d</a>
  <a href="https://printquarters.com/about/team.php">qq724</a>
  <a href="https://printquarters.com/about/team.php">bet88scoreslot</a>
  <a href="https://printquarters.com/about/team.php">surgaplat</a>
  <a href="https://printquarters.com/about/team.php">eternal4d</a>
  <a href="https://printquarters.com/about/team.php">fajar pakong</a>
  <a href="https://printquarters.com/about/team.php">sarislot</a>
  <a href="https://printquarters.com/about/team.php">warunggol</a>
  <a href="https://printquarters.com/about/team.php">79togel</a>
  <a href="https://printquarters.com/about/team.php">daduonline</a>
  <a href="https://printquarters.com/about/team.php">syairtoto</a>
  <a href="https://printquarters.com/about/team.php">slot603</a>
  <a href="https://printquarters.com/about/team.php">hoki raja</a>
  <a href="https://printquarters.com/about/team.php">demo treasures</a>
  <a href="https://printquarters.com/about/team.php">ZIENTOGEL</a>
  <a href="https://printquarters.com/about/team.php">indobegas4d</a>
  <a href="https://printquarters.com/about/team.php">akun50</a>
  <a href="https://printquarters.com/about/team.php">diamond138</a>
  <a href="https://printquarters.com/about/team.php">unik777</a>
  <a href="https://printquarters.com/about/team.php">slotvegas</a>
  <a href="https://printquarters.com/about/team.php">AKUNJP</a>
  <a href="https://printquarters.com/about/team.php">BCA4D</a>
  <a href="https://printquarters.com/about/team.php">cocok777</a>
  <a href="https://printquarters.com/about/team.php">RAFFI888</a>
  <a href="https://printquarters.com/about/team.php">parley4dslot</a>
  <a href="https://printquarters.com/about/team.php">404slot</a>
  <a href="https://printquarters.com/about/team.php">kaisarjpslot</a>
  <a href="https://printquarters.com/about/team.php">join88</a>
  <a href="https://printquarters.com/about/team.php">jago77</a>
  <a href="https://printquarters.com/about/team.php">POKER138</a>
  <a href="https://printquarters.com/about/team.php">domino206</a>
  <a href="https://printquarters.com/about/team.php">sigmatoto</a>
  <a href="https://printquarters.com/about/team.php">akuratmpo</a>
  <a href="https://printquarters.com/about/team.php">kamustotoslot</a>
  <a href="https://printquarters.com/about/team.php">slot88lion</a>
  <a href="https://printquarters.com/about/team.php">barongsai4d</a>
  <a href="https://printquarters.com/about/team.php">anti</a>
  <a href="https://printquarters.com/about/team.php">golden86</a>
  <a href="https://printquarters.com/about/team.php">YUPITOTO</a>
  <a href="https://printquarters.com/about/team.php">vegas804</a>
  <a href="https://printquarters.com/about/team.php">kunci777</a>
  <a href="https://printquarters.com/about/team.php">cincin betslot</a>
  <a href="https://printquarters.com/about/team.php">radiumplay</a>
  <a href="https://printquarters.com/about/team.php">alxslot</a>
  <a href="https://printquarters.com/about/team.php">rajavigorslot</a>
  <a href="https://printquarters.com/about/team.php">jet77slot</a>
  <a href="https://printquarters.com/about/team.php">idrslot88</a>
  <a href="https://printquarters.com/about/team.php">vipcrownqqslot</a>
  <a href="https://printquarters.com/about/team.php">aura 123slot</a>
  <a href="https://printquarters.com/about/team.php">cantik77</a>
  <a href="https://printquarters.com/about/team.php">gudangmovies</a>
  <a href="https://printquarters.com/about/team.php">slot5000slot</a>
  <a href="https://printquarters.com/about/team.php">mdnslot</a>
  <a href="https://printquarters.com/about/team.php">dragonslot888</a>
  <a href="https://printquarters.com/about/team.php">himalaya1paket</a>
  <a href="https://printquarters.com/about/team.php">pardede4d</a>
  <a href="https://printquarters.com/about/team.php">beli jitu</a>
  <a href="https://printquarters.com/about/team.php">SCATTER GOLD</a>
  <a href="https://printquarters.com/about/team.php">vp77</a>
  <a href="https://printquarters.com/about/team.php">WIN66</a>
  <a href="https://printquarters.com/about/team.php">MACAU4D</a>
  <a href="https://printquarters.com/about/team.php">squ 88</a>
  <a href="https://printquarters.com/about/team.php">tele88</a>
  <a href="https://printquarters.com/about/team.php">KPKSLOT</a>
  <a href="https://printquarters.com/about/team.php">ARWANATOTO</a>
  <a href="https://printquarters.com/about/team.php">togel china</a>
  <a href="https://printquarters.com/about/team.php">mega gacorslot</a>
  <a href="https://printquarters.com/about/team.php">batmantotoslot</a>
  <a href="https://printquarters.com/about/team.php">DEWASGP</a>
  <a href="https://printquarters.com/about/team.php">niutotoslot</a>
  <a href="https://printquarters.com/about/team.php">SLOT RUSIA</a>
  <a href="https://printquarters.com/about/team.php">depo88</a>
  <a href="https://printquarters.com/about/team.php">YUANTOTO</a>
  <a href="https://printquarters.com/about/team.php">kamartoto</a>
  <a href="https://printquarters.com/about/team.php">cmbet</a>
  <a href="https://printquarters.com/about/team.php">hokidomino</a>
  <a href="https://printquarters.com/about/team.php">kopisusu88</a>
  <a href="https://printquarters.com/about/team.php">rrq88</a>
  <a href="https://printquarters.com/about/team.php">PAKARBET88</a>
  <a href="https://printquarters.com/about/team.php">slot2d</a>
  <a href="https://printquarters.com/about/team.php">dktoto</a>
  <a href="https://printquarters.com/about/team.php">COINMPO</a>
  <a href="https://printquarters.com/about/team.php">macan4d</a>
  <a href="https://printquarters.com/about/team.php">onoslot</a>
  <a href="https://printquarters.com/about/team.php">judi casino</a>
  <a href="https://printquarters.com/about/team.php">slot2500</a>
  <a href="https://printquarters.com/about/team.php">judi188</a>
  <a href="https://printquarters.com/about/team.php">MAHONGTOTO</a>
  <a href="https://printquarters.com/about/team.php">situs 2bet</a>
  <a href="https://printquarters.com/about/team.php">hantuslot4d</a>
  <a href="https://printquarters.com/about/team.php">m11toto</a>
  <a href="https://printquarters.com/about/team.php">owltotoslot</a>
  <a href="https://printquarters.com/about/team.php">22RBET</a>
  <a href="https://printquarters.com/about/team.php">tstoto sukses</a>
  <a href="https://printquarters.com/about/team.php">maduslot</a>
  <a href="https://printquarters.com/about/team.php">hahabola</a>
  <a href="https://printquarters.com/about/team.php">indo288</a>
  <a href="https://printquarters.com/about/team.php">slot wisdom</a>
  <a href="https://printquarters.com/about/team.php">gacor66</a>
  <a href="https://printquarters.com/about/team.php">keluaran lucky</a>
  <a href="https://printquarters.com/about/team.php">885slot</a>
  <a href="https://printquarters.com/about/team.php">SLOT247</a>
  <a href="https://printquarters.com/about/team.php">lux88slot</a>
  <a href="https://printquarters.com/about/team.php">menangmain55</a>
  <a href="https://printquarters.com/about/team.php">apelslot</a>
  <a href="https://printquarters.com/about/team.php">dogeluxus</a>
  <a href="https://printquarters.com/about/team.php">mesitoto</a>
  <a href="https://printquarters.com/about/team.php">aladin17</a>
  <a href="https://printquarters.com/about/team.php">turnamenslot</a>
  <a href="https://printquarters.com/about/team.php">bet 200k</a>
  <a href="https://printquarters.com/about/team.php">pp777</a>
  <a href="https://printquarters.com/about/team.php">togel kremlin</a>
  <a href="https://printquarters.com/about/team.php">mapanjp</a>
  <a href="https://printquarters.com/about/team.php">dramatogel</a>
  <a href="https://printquarters.com/about/team.php">zoom 555</a>
  <a href="https://printquarters.com/about/team.php">pragmaticplay</a>
  <a href="https://printquarters.com/about/team.php">pisang88</a>
  <a href="https://printquarters.com/about/team.php">akun500</a>
  <a href="https://printquarters.com/about/team.php">republikplayer</a>
  <a href="https://printquarters.com/about/team.php">mpokataslot</a>
  <a href="https://printquarters.com/about/team.php">parlay sbo</a>
  <a href="https://printquarters.com/about/team.php">demo prosperity</a>
  <a href="https://printquarters.com/about/team.php">asia76</a>
  <a href="https://printquarters.com/about/team.php">piala123</a>
  <a href="https://printquarters.com/about/team.php">bos138</a>
  <a href="https://printquarters.com/about/team.php">pol88</a>
  <a href="https://printquarters.com/about/team.php">TOTOJUDI4D</a>
  <a href="https://printquarters.com/about/team.php">ron98</a>
  <a href="https://printquarters.com/about/team.php">KAYA4D</a>
  <a href="https://printquarters.com/about/team.php">GALAXY69</a>
  <a href="https://printquarters.com/about/team.php">go88app</a>
  <a href="https://printquarters.com/about/team.php">presidenslot888</a>
  <a href="https://printquarters.com/about/team.php">jawaslot</a>
  <a href="https://printquarters.com/about/team.php">lagunabet</a>
  <a href="https://printquarters.com/about/team.php">NMAXTOTO</a>
  <a href="https://printquarters.com/about/team.php">optoto</a>
  <a href="https://printquarters.com/about/team.php">akurat mpo</a>
  <a href="https://printquarters.com/about/team.php">togel2024</a>
  <a href="https://printquarters.com/about/team.php">pusatslot</a>
  <a href="https://printquarters.com/about/team.php">trabasslot</a>
  <a href="https://printquarters.com/about/team.php">macou</a>
  <a href="https://printquarters.com/about/team.php">paito eropa</a>
  <a href="https://printquarters.com/about/team.php">keluaran japanpools</a>
  <a href="https://printquarters.com/about/team.php">viper138</a>
  <a href="https://printquarters.com/about/team.php">ONIX4D</a>
  <a href="https://printquarters.com/about/team.php">top138</a>
  <a href="https://printquarters.com/about/team.php">panen 66slot</a>
  <a href="https://printquarters.com/about/team.php">gobetasiaslot</a>
  <a href="https://printquarters.com/about/team.php">lukcysloto</a>
  <a href="https://printquarters.com/about/team.php">halo777</a>
  <a href="https://printquarters.com/about/team.php">lautan slot</a>
  <a href="https://printquarters.com/about/team.php">rtfgacor</a>
  <a href="https://printquarters.com/about/team.php">GORILLA4D</a>
  <a href="https://printquarters.com/about/team.php">WARUNG123</a>
  <a href="https://printquarters.com/about/team.php">wede89</a>
  <a href="https://printquarters.com/about/team.php">aerototo</a>
  <a href="https://printquarters.com/about/team.php">asianpoker88</a>
  <a href="https://printquarters.com/about/team.php">terbang138</a>
  <a href="https://printquarters.com/about/team.php">mpo363</a>
  <a href="https://printquarters.com/about/team.php">koboi89</a>
  <a href="https://printquarters.com/about/team.php">kakekslot88</a>
  <a href="https://printquarters.com/about/team.php">buah 77slot</a>
  <a href="https://printquarters.com/about/team.php">macanslot</a>
  <a href="https://printquarters.com/about/team.php">nagaair88</a>
  <a href="https://printquarters.com/about/team.php">lima rajaslot</a>
  <a href="https://printquarters.com/about/team.php">kumpulanslot</a>
  <a href="https://printquarters.com/about/team.php">ketuapoker</a>
  <a href="https://printquarters.com/about/team.php">satu8poker</a>
  <a href="https://printquarters.com/about/team.php">anekaslot</a>
  <a href="https://printquarters.com/about/team.php">qqtopwin</a>
  <a href="https://printquarters.com/about/team.php">bet111</a>
  <a href="https://printquarters.com/about/team.php">interwin77</a>
  <a href="https://printquarters.com/about/team.php">semislot888</a>
  <a href="https://printquarters.com/about/team.php">alibaba66slot</a>
  <a href="https://printquarters.com/about/team.php">mahjong artinya</a>
  <a href="https://printquarters.com/about/team.php">haha388</a>
  <a href="https://printquarters.com/about/team.php">togelnewyorkeve</a>
  <a href="https://printquarters.com/about/team.php">oppatotoslot</a>
  <a href="https://printquarters.com/about/team.php">mabar88</a>
  <a href="https://printquarters.com/about/team.php">musikslot4d</a>
  <a href="https://printquarters.com/about/team.php">slot79</a>
  <a href="https://printquarters.com/about/team.php">raja66</a>
  <a href="https://printquarters.com/about/team.php">istana777slot</a>
  <a href="https://printquarters.com/about/team.php">nexgacor</a>
  <a href="https://printquarters.com/about/team.php">PETA77</a>
  <a href="https://printquarters.com/about/team.php">rrq77</a>
  <a href="https://printquarters.com/about/team.php">bossklik</a>
  <a href="https://printquarters.com/about/team.php">autospin88</a>
  <a href="https://printquarters.com/about/team.php">kairitoto</a>
  <a href="https://printquarters.com/about/team.php">harimau77</a>
  <a href="https://printquarters.com/about/team.php">denai4d</a>
  <a href="https://printquarters.com/about/team.php">indkasino</a>
  <a href="https://printquarters.com/about/team.php">twinbet77</a>
  <a href="https://printquarters.com/about/team.php">demen4d</a>
  <a href="https://printquarters.com/about/team.php">SLOTUP</a>
  <a href="https://printquarters.com/about/team.php">shiro88</a>
  <a href="https://printquarters.com/about/team.php">mentaripoker</a>
  <a href="https://printquarters.com/about/team.php">pasar77</a>
  <a href="https://printquarters.com/about/team.php">w69gacor</a>
  <a href="https://printquarters.com/about/team.php">gacorrekan88</a>
  <a href="https://printquarters.com/about/team.php">forzatoto</a>
  <a href="https://printquarters.com/about/team.php">aresbet88</a>
  <a href="https://printquarters.com/about/team.php">buntoto</a>
  <a href="https://printquarters.com/about/team.php">adipati138</a>
  <a href="https://printquarters.com/about/team.php">pgbet</a>
  <a href="https://printquarters.com/about/team.php">indodewaqq</a>
  <a href="https://printquarters.com/about/team.php">mario4d</a>
  <a href="https://printquarters.com/about/team.php">java77</a>
  <a href="https://printquarters.com/about/team.php">bolaslot21</a>
  <a href="https://printquarters.com/about/team.php">daftar ibcbet</a>
  <a href="https://printquarters.com/about/team.php">CAIR188</a>
  <a href="https://printquarters.com/about/team.php">bos123</a>
  <a href="https://printquarters.com/about/team.php">mamahoki</a>
  <a href="https://printquarters.com/about/team.php">SLOTWIN777</a>
  <a href="https://printquarters.com/about/team.php">rajawin</a>
  <a href="https://printquarters.com/about/team.php">facebookgacor</a>
  <a href="https://printquarters.com/about/team.php">SPBUTOTO</a>
  <a href="https://printquarters.com/about/team.php">tobatogel</a>
  <a href="https://printquarters.com/about/team.php">bandar126</a>
  <a href="https://printquarters.com/about/team.php">dewagacor33</a>
  <a href="https://printquarters.com/about/team.php">mposlot365</a>
  <a href="https://printquarters.com/about/team.php">laris138</a>
  <a href="https://printquarters.com/about/team.php">barcode88</a>
  <a href="https://printquarters.com/about/team.php">rp369</a>
  <a href="https://printquarters.com/about/team.php">togelcepek</a>
  <a href="https://printquarters.com/about/team.php">srikandir88</a>
  <a href="https://printquarters.com/about/team.php">bonanza333</a>
  <a href="https://printquarters.com/about/team.php">babe138</a>
  <a href="https://printquarters.com/about/team.php">cocol88slot</a>
  <a href="https://printquarters.com/about/team.php">21gacor</a>
  <a href="https://printquarters.com/about/team.php">togelrokok</a>
  <a href="https://printquarters.com/about/team.php">ibola99</a>
  <a href="https://printquarters.com/about/team.php">koinid slot</a>
  <a href="https://printquarters.com/about/team.php">sba99slot</a>
  <a href="https://printquarters.com/about/team.php">kartuslot</a>
  <a href="https://printquarters.com/about/team.php">trik88</a>
  <a href="https://printquarters.com/about/team.php">DUKUN77</a>
  <a href="https://printquarters.com/about/team.php">anak rajaslot</a>
  <a href="https://printquarters.com/about/team.php">cgv88</a>
  <a href="https://printquarters.com/about/team.php">panti4d</a>
  <a href="https://printquarters.com/about/team.php">qslot</a>
  <a href="https://printquarters.com/about/team.php">koi138</a>
  <a href="https://printquarters.com/about/team.php">gg178</a>
  <a href="https://printquarters.com/about/team.php">joker4dslot</a>
  <a href="https://printquarters.com/about/team.php">dewabet pro</a>
  <a href="https://printquarters.com/about/team.php">maxbet</a>
  <a href="https://printquarters.com/about/team.php">3mbola</a>
  <a href="https://printquarters.com/about/team.php">buy138</a>
  <a href="https://printquarters.com/about/team.php">kfcslot</a>
  <a href="https://printquarters.com/about/team.php">slot fastspin</a>
  <a href="https://printquarters.com/about/team.php">spin 707slot</a>
  <a href="https://printquarters.com/about/team.php">elang88</a>
  <a href="https://printquarters.com/about/team.php">JODOH99</a>
  <a href="https://printquarters.com/about/team.php">MAINSLOT77</a>
  <a href="https://printquarters.com/about/team.php">slotresmi</a>
  <a href="https://printquarters.com/about/team.php">ligadewaslot</a>
  <a href="https://printquarters.com/about/team.php">lotrepelangi</a>
  <a href="https://printquarters.com/about/team.php">pisang bet</a>
  <a href="https://printquarters.com/about/team.php">mpo1221</a>
  <a href="https://printquarters.com/about/team.php">mpo338slot</a>
  <a href="https://printquarters.com/about/team.php">jonitogelslot</a>
  <a href="https://printquarters.com/about/team.php">belegendwin</a>
  <a href="https://printquarters.com/about/team.php">judolbet</a>
  <a href="https://printquarters.com/about/team.php">koin55</a>
  <a href="https://printquarters.com/about/team.php">win7pokerslot</a>
  <a href="https://printquarters.com/about/team.php">juragajp</a>
  <a href="https://printquarters.com/about/team.php">babawin</a>
  <a href="https://printquarters.com/about/team.php">giotogel4d</a>
  <a href="https://printquarters.com/about/team.php">livescore napoli</a>
  <a href="https://printquarters.com/about/team.php">besarkecil</a>
  <a href="https://printquarters.com/about/team.php">royal88bet</a>
  <a href="https://printquarters.com/about/team.php">mtotojitu</a>
  <a href="https://printquarters.com/about/team.php">raffi77</a>
  <a href="https://printquarters.com/about/team.php">TESLA388</a>
  <a href="https://printquarters.com/about/team.php">kay4d</a>
  <a href="https://printquarters.com/about/team.php">depo99</a>
  <a href="https://printquarters.com/about/team.php">surga555</a>
  <a href="https://printquarters.com/about/team.php">injectslot</a>
  <a href="https://printquarters.com/about/team.php">sultan99slot</a>
  <a href="https://printquarters.com/about/team.php">bandarsbo</a>
  <a href="https://printquarters.com/about/team.php">sensei88</a>
  <a href="https://printquarters.com/about/team.php">kingdomtot</a>
  <a href="https://printquarters.com/about/team.php">hongkong semalam</a>
  <a href="https://printquarters.com/about/team.php">kampusslot88</a>
  <a href="https://printquarters.com/about/team.php">b uanslot69</a>
  <a href="https://printquarters.com/about/team.php">raja coinslot</a>
  <a href="https://printquarters.com/about/team.php">slot soju</a>
  <a href="https://printquarters.com/about/team.php">dewa188</a>
  <a href="https://printquarters.com/about/team.php">togel bogor</a>
  <a href="https://printquarters.com/about/team.php">1001SLOT</a>
  <a href="https://printquarters.com/about/team.php">muliaslot888</a>
  <a href="https://printquarters.com/about/team.php">jokerscm</a>
  <a href="https://printquarters.com/about/team.php">indopr e</a>
  <a href="https://printquarters.com/about/team.php">padi188</a>
  <a href="https://printquarters.com/about/team.php">rankslot</a>
  <a href="https://printquarters.com/about/team.php">sydneytogel</a>
  <a href="https://printquarters.com/about/team.php">gaspol88</a>
  <a href="https://printquarters.com/about/team.php">zeus200</a>
  <a href="https://printquarters.com/about/team.php">jpslot888</a>
  <a href="https://printquarters.com/about/team.php">link slot88</a>
  <a href="https://printquarters.com/about/team.php">dimo slot</a>
  <a href="https://printquarters.com/about/team.php">mangolive twitter</a>
  <a href="https://printquarters.com/about/team.php">ug500</a>
  <a href="https://printquarters.com/about/team.php">cipung138slot</a>
  <a href="https://printquarters.com/about/team.php">porsche888</a>
  <a href="https://printquarters.com/about/team.php">bowo777</a>
  <a href="https://printquarters.com/about/team.php">angkakembar</a>
  <a href="https://printquarters.com/about/team.php">spbolivescorewml</a>
  <a href="https://printquarters.com/about/team.php">camtoto</a>
  <a href="https://printquarters.com/about/team.php">aryagames</a>
  <a href="https://printquarters.com/about/team.php">klik88&#039;</a>
  <a href="https://printquarters.com/about/team.php">SAKAUTOTO</a>
  <a href="https://printquarters.com/about/team.php">mimpitogel</a>
  <a href="https://printquarters.com/about/team.php">icslot88</a>
  <a href="https://printquarters.com/about/team.php">MANIASLOT88</a>
  <a href="https://printquarters.com/about/team.php">mpo 06slot</a>
  <a href="https://printquarters.com/about/team.php">mpo 300slot</a>
  <a href="https://printquarters.com/about/team.php">MCMBOLA</a>
  <a href="https://printquarters.com/about/team.php">qq801</a>
  <a href="https://printquarters.com/about/team.php">pajartoto</a>
  <a href="https://printquarters.com/about/team.php">caspo</a>
  <a href="https://printquarters.com/about/team.php">bandungtogel</a>
  <a href="https://printquarters.com/about/team.php">dewaasia</a>
  <a href="https://printquarters.com/about/team.php">BANGBOS LOGIN</a>
  <a href="https://printquarters.com/about/team.php">slot888luck</a>
  <a href="https://printquarters.com/about/team.php">bibir88</a>
  <a href="https://printquarters.com/about/team.php">1221slot</a>
  <a href="https://printquarters.com/about/team.php">pokeremas</a>
  <a href="https://printquarters.com/about/team.php">jayaliga</a>
  <a href="https://printquarters.com/about/team.php">november</a>
  <a href="https://printquarters.com/about/team.php">paito swiss</a>
  <a href="https://printquarters.com/about/team.php">KILAT777SLOT</a>
  <a href="https://printquarters.com/about/team.php">hoyapoker</a>
  <a href="https://printquarters.com/about/team.php">danapkvslot</a>
  <a href="https://printquarters.com/about/team.php">77 slot</a>
  <a href="https://printquarters.com/about/team.php">labutogel</a>
  <a href="https://printquarters.com/about/team.php">sgcwin88</a>
  <a href="https://printquarters.com/about/team.php">raja dominoslot</a>
  <a href="https://printquarters.com/about/team.php">tuanslot</a>
  <a href="https://printquarters.com/about/team.php">sambarjp77</a>
  <a href="https://printquarters.com/about/team.php">bandara4d</a>
  <a href="https://printquarters.com/about/team.php">arwanaqq</a>
  <a href="https://printquarters.com/about/team.php">roma777</a>
  <a href="https://printquarters.com/about/team.php">oxibet</a>
  <a href="https://printquarters.com/about/team.php">DATA SINGAPORE</a>
  <a href="https://printquarters.com/about/team.php">MERDEKA123</a>
  <a href="https://printquarters.com/about/team.php">qqgaming138</a>
  <a href="https://printquarters.com/about/team.php">JINGGA88</a>
  <a href="https://printquarters.com/about/team.php">tigelcc</a>
  <a href="https://printquarters.com/about/team.php">wsoslot88</a>
  <a href="https://printquarters.com/about/team.php">viva8et</a>
  <a href="https://printquarters.com/about/team.php">belltogel</a>
  <a href="https://printquarters.com/about/team.php">joker688</a>
  <a href="https://printquarters.com/about/team.php">mglive</a>
  <a href="https://printquarters.com/about/team.php">nurwanto</a>
  <a href="https://printquarters.com/about/team.php">pilot138</a>
  <a href="https://printquarters.com/about/team.php">agen134</a>
  <a href="https://printquarters.com/about/team.php">raja1188</a>
  <a href="https://printquarters.com/about/team.php">rtpsky77</a>
  <a href="https://printquarters.com/about/team.php">samudrabet</a>
  <a href="https://printquarters.com/about/team.php">sbobetslot</a>
  <a href="https://printquarters.com/about/team.php">MPLTOTO</a>
  <a href="https://printquarters.com/about/team.php">fuzhou</a>
  <a href="https://printquarters.com/about/team.php">pengeluarantaiwan</a>
  <a href="https://printquarters.com/about/team.php">situsbolagila</a>
  <a href="https://printquarters.com/about/team.php">eropa4dslot</a>
  <a href="https://printquarters.com/about/team.php">wallet</a>
  <a href="https://printquarters.com/about/team.php">abang303</a>
  <a href="https://printquarters.com/about/team.php">rtpdangdut4d</a>
  <a href="https://printquarters.com/about/team.php">meja13</a>
  <a href="https://printquarters.com/about/team.php">joker508slot</a>
  <a href="https://printquarters.com/about/team.php">loyalbet</a>
  <a href="https://printquarters.com/about/team.php">wayang123</a>
  <a href="https://printquarters.com/about/team.php">WALET789</a>
  <a href="https://printquarters.com/about/team.php">rajajp88</a>
  <a href="https://printquarters.com/about/team.php">GEMBIRA88</a>
  <a href="https://printquarters.com/about/team.php">zeus9u</a>
  <a href="https://printquarters.com/about/team.php">yoyobet</a>
  <a href="https://printquarters.com/about/team.php">lebahslot</a>
  <a href="https://printquarters.com/about/team.php">gopek178</a>
  <a href="https://printquarters.com/about/team.php">PADANGTOGEL</a>
  <a href="https://printquarters.com/about/team.php">gempar4d</a>
  <a href="https://printquarters.com/about/team.php">88mpoplay</a>
  <a href="https://printquarters.com/about/team.php">black77</a>
  <a href="https://printquarters.com/about/team.php">tiptop108</a>
  <a href="https://printquarters.com/about/team.php">fortuna189</a>
  <a href="https://printquarters.com/about/team.php">lotreslot</a>
  <a href="https://printquarters.com/about/team.php">hokimain</a>
  <a href="https://printquarters.com/about/team.php">gembirabet4d</a>
  <a href="https://printquarters.com/about/team.php">luwakbet</a>
  <a href="https://printquarters.com/about/team.php">sr555</a>
  <a href="https://printquarters.com/about/team.php">mahabet</a>
  <a href="https://printquarters.com/about/team.php">lavabet138</a>
  <a href="https://printquarters.com/about/team.php">qqgarnetslot</a>
  <a href="https://printquarters.com/about/team.php">cepat777</a>
  <a href="https://printquarters.com/about/team.php">sahjitu</a>
  <a href="https://printquarters.com/about/team.php">mpomatahari</a>
  <a href="https://printquarters.com/about/team.php">TARUNGTOTO</a>
  <a href="https://printquarters.com/about/team.php">EMOTOTO</a>
  <a href="https://printquarters.com/about/team.php">indoslot303</a>
  <a href="https://printquarters.com/about/team.php">arjunaslot</a>
  <a href="https://printquarters.com/about/team.php">ora4d</a>
  <a href="https://printquarters.com/about/team.php">dewagame</a>
  <a href="https://printquarters.com/about/team.php">INDO247</a>
  <a href="https://printquarters.com/about/team.php">v77bet</a>
  <a href="https://printquarters.com/about/team.php">amazon303</a>
  <a href="https://printquarters.com/about/team.php">macauindo</a>
  <a href="https://printquarters.com/about/team.php">toto787</a>
  <a href="https://printquarters.com/about/team.php">toyota4d</a>
  <a href="https://printquarters.com/about/team.php">bidangtogel</a>
  <a href="https://printquarters.com/about/team.php">88bet</a>
  <a href="https://printquarters.com/about/team.php">wong55</a>
  <a href="https://printquarters.com/about/team.php">bolaindo88</a>
  <a href="https://printquarters.com/about/team.php">bolautama</a>
  <a href="https://printquarters.com/about/team.php">scatter irak</a>
  <a href="https://printquarters.com/about/team.php">138club</a>
  <a href="https://printquarters.com/about/team.php">togelresult</a>
  <a href="https://printquarters.com/about/team.php">bebas88</a>
  <a href="https://printquarters.com/about/team.php">rajacapsa</a>
  <a href="https://printquarters.com/about/team.php">keluaran rhode</a>
  <a href="https://printquarters.com/about/team.php">MUSTIKAJITU</a>
  <a href="https://printquarters.com/about/team.php">aseanqq</a>
  <a href="https://printquarters.com/about/team.php">kudajitu</a>
  <a href="https://printquarters.com/about/team.php">obor138</a>
  <a href="https://printquarters.com/about/team.php">legend88slot</a>
  <a href="https://printquarters.com/about/team.php">ilusi4d</a>
  <a href="https://printquarters.com/about/team.php">topitoto</a>
  <a href="https://printquarters.com/about/team.php">pecah99</a>
  <a href="https://printquarters.com/about/team.php">babeh188</a>
  <a href="https://printquarters.com/about/team.php">tigaberlian</a>
  <a href="https://printquarters.com/about/team.php">inijoker</a>
  <a href="https://printquarters.com/about/team.php">88pulsa</a>
  <a href="https://printquarters.com/about/team.php">castletoto</a>
  <a href="https://printquarters.com/about/team.php">togel337</a>
  <a href="https://printquarters.com/about/team.php">makow</a>
  <a href="https://printquarters.com/about/team.php">klasiktoto</a>
  <a href="https://printquarters.com/about/team.php">NADIMTOTO</a>
  <a href="https://printquarters.com/about/team.php">bali4d</a>
  <a href="https://printquarters.com/about/team.php">dewa89slot</a>
  <a href="https://printquarters.com/about/team.php">rekor11</a>
  <a href="https://printquarters.com/about/team.php">LANGIT188</a>
  <a href="https://printquarters.com/about/team.php">gacor2024</a>
  <a href="https://printquarters.com/about/team.php">paguyuban4d</a>
  <a href="https://printquarters.com/about/team.php">jitu389</a>
  <a href="https://printquarters.com/about/team.php">cuaninfini88</a>
  <a href="https://printquarters.com/about/team.php">istana188</a>
  <a href="https://printquarters.com/about/team.php">qqtogel</a>
  <a href="https://printquarters.com/about/team.php">livescore marseille</a>
  <a href="https://printquarters.com/about/team.php">robotslot</a>
  <a href="https://printquarters.com/about/team.php">liga95</a>
  <a href="https://printquarters.com/about/team.php">agenslotvip</a>
  <a href="https://printquarters.com/about/team.php">mamitogel</a>
  <a href="https://printquarters.com/about/team.php">bonus123</a>
  <a href="https://printquarters.com/about/team.php">lambe33</a>
  <a href="https://printquarters.com/about/team.php">gebyar777</a>
  <a href="https://printquarters.com/about/team.php">CENDANA77</a>
  <a href="https://printquarters.com/about/team.php">queenslot88</a>
  <a href="https://printquarters.com/about/team.php">oricasino</a>
  <a href="https://printquarters.com/about/team.php">elangqq</a>
  <a href="https://printquarters.com/about/team.php">wintotoslot</a>
  <a href="https://printquarters.com/about/team.php">bejo33</a>
  <a href="https://printquarters.com/about/team.php">icafe4dslot</a>
  <a href="https://printquarters.com/about/team.php">epikwin138</a>
  <a href="https://printquarters.com/about/team.php">ajaib88</a>
  <a href="https://printquarters.com/about/team.php">pools303slot</a>
  <a href="https://printquarters.com/about/team.php">pelangitoto88</a>
  <a href="https://printquarters.com/about/team.php">maribet99</a>
  <a href="https://printquarters.com/about/team.php">fyp138gacor</a>
  <a href="https://printquarters.com/about/team.php">cbogaming</a>
  <a href="https://printquarters.com/about/team.php">betcash303</a>
  <a href="https://printquarters.com/about/team.php">royalslot188</a>
  <a href="https://printquarters.com/about/team.php">pracmatic88</a>
  <a href="https://printquarters.com/about/team.php">SENIORTOGEL</a>
  <a href="https://printquarters.com/about/team.php">HAPPYTOTO4D</a>
  <a href="https://printquarters.com/about/team.php">delima88slot</a>
  <a href="https://printquarters.com/about/team.php">ovoplay</a>
  <a href="https://printquarters.com/about/team.php">pangeranjoker</a>
  <a href="https://printquarters.com/about/team.php">slottotonusa</a>
  <a href="https://printquarters.com/about/team.php">34TOGEL</a>
  <a href="https://printquarters.com/about/team.php">sultanmbs</a>
  <a href="https://printquarters.com/about/team.php">salamtogel</a>
  <a href="https://printquarters.com/about/team.php">mso138</a>
  <a href="https://printquarters.com/about/team.php">eyang4d</a>
  <a href="https://printquarters.com/about/team.php">malam88</a>
  <a href="https://printquarters.com/about/team.php">pandai4d</a>
  <a href="https://printquarters.com/about/team.php">tortogel</a>
  <a href="https://printquarters.com/about/team.php">ligajuara</a>
  <a href="https://printquarters.com/about/team.php">osg888</a>
  <a href="https://printquarters.com/about/team.php">telak4d</a>
  <a href="https://printquarters.com/about/team.php">gobet508</a>
  <a href="https://printquarters.com/about/team.php">GAS123</a>
  <a href="https://printquarters.com/about/team.php">hongk</a>
  <a href="https://printquarters.com/about/team.php">awanslot</a>
  <a href="https://printquarters.com/about/team.php">bazarbazartoto</a>
  <a href="https://printquarters.com/about/team.php">tokyo 988</a>
  <a href="https://printquarters.com/about/team.php">csslot</a>
  <a href="https://printquarters.com/about/team.php">slotwin777</a>
  <a href="https://printquarters.com/about/team.php">dipo 4dslot</a>
  <a href="https://printquarters.com/about/team.php">mpo45</a>
  <a href="https://printquarters.com/about/team.php">gacor88jp</a>
  <a href="https://printquarters.com/about/team.php">RAFI168</a>
  <a href="https://printquarters.com/about/team.php">mafiawin</a>
  <a href="https://printquarters.com/about/team.php">77betsport</a>
  <a href="https://printquarters.com/about/team.php">5000 betslot</a>
  <a href="https://printquarters.com/about/team.php">jawir69</a>
  <a href="https://printquarters.com/about/team.php">slot online</a>
  <a href="https://printquarters.com/about/team.php">slottoto 171</a>
  <a href="https://printquarters.com/about/team.php">cnnslot138</a>
  <a href="https://printquarters.com/about/team.php">olympus88</a>
  <a href="https://printquarters.com/about/team.php">tebak69</a>
  <a href="https://printquarters.com/about/team.php">TOTO88</a>
  <a href="https://printquarters.com/about/team.php">panji4d</a>
  <a href="https://printquarters.com/about/team.php">meraktoto</a>
  <a href="https://printquarters.com/about/team.php">HOT4D</a>
  <a href="https://printquarters.com/about/team.php">akaislot</a>
  <a href="https://printquarters.com/about/team.php">raja28</a>
  <a href="https://printquarters.com/about/team.php">abg99slot</a>
  <a href="https://printquarters.com/about/team.php">slot218</a>
  <a href="https://printquarters.com/about/team.php">JAMINTOTO</a>
  <a href="https://printquarters.com/about/team.php">ketua77</a>
  <a href="https://printquarters.com/about/team.php">zonatoto 4d</a>
  <a href="https://printquarters.com/about/team.php">keluaran poipet</a>
  <a href="https://printquarters.com/about/team.php">bataraslot777</a>
  <a href="https://printquarters.com/about/team.php">hedonbet</a>
  <a href="https://printquarters.com/about/team.php">boba4d</a>
  <a href="https://printquarters.com/about/team.php">angkor99</a>
  <a href="https://printquarters.com/about/team.php">sagara4d</a>
  <a href="https://printquarters.com/about/team.php">bancitotoslot</a>
  <a href="https://printquarters.com/about/team.php">shienslot</a>
  <a href="https://printquarters.com/about/team.php">TAIPANPOKER</a>
  <a href="https://printquarters.com/about/team.php">juragan178</a>
  <a href="https://printquarters.com/about/team.php">9club</a>
  <a href="https://printquarters.com/about/team.php">ayosbet</a>
  <a href="https://printquarters.com/about/team.php">dennisbet77</a>
  <a href="https://printquarters.com/about/team.php">MANSION88</a>
  <a href="https://printquarters.com/about/team.php">partaitoto</a>
  <a href="https://printquarters.com/about/team.php">rupiah 899</a>
  <a href="https://printquarters.com/about/team.php">ligabet99</a>
  <a href="https://printquarters.com/about/team.php">caesarplay</a>
  <a href="https://printquarters.com/about/team.php">mgo55</a>
  <a href="https://printquarters.com/about/team.php">GOBET88</a>
  <a href="https://printquarters.com/about/team.php">goldwin</a>
  <a href="https://printquarters.com/about/team.php">mpoking</a>
  <a href="https://printquarters.com/about/team.php">milan69</a>
  <a href="https://printquarters.com/about/team.php">cheat judi</a>
  <a href="https://printquarters.com/about/team.php">sbobet303</a>
  <a href="https://printquarters.com/about/team.php">tetapjitu</a>
  <a href="https://printquarters.com/about/team.php">ombak77</a>
  <a href="https://printquarters.com/about/team.php">cuanlagi</a>
  <a href="https://printquarters.com/about/team.php">HALUTOTO</a>
  <a href="https://printquarters.com/about/team.php">ras77</a>
  <a href="https://printquarters.com/about/team.php">errorslot</a>
  <a href="https://printquarters.com/about/team.php">aneka1</a>
  <a href="https://printquarters.com/about/team.php">pakong188</a>
  <a href="https://printquarters.com/about/team.php">contoh perjudian</a>
  <a href="https://printquarters.com/about/team.php">kakekemas</a>
  <a href="https://printquarters.com/about/team.php">bibirtoto</a>
  <a href="https://printquarters.com/about/team.php">bayanbola</a>
  <a href="https://printquarters.com/about/team.php">gacorzeus138</a>
  <a href="https://printquarters.com/about/team.php">situs303</a>
  <a href="https://printquarters.com/about/team.php">ligaciputra</a>
  <a href="https://printquarters.com/about/team.php">beton888slot</a>
  <a href="https://printquarters.com/about/team.php">situstoto</a>
  <a href="https://printquarters.com/about/team.php">PG SOFT</a>
  <a href="https://printquarters.com/about/team.php">coloktoto 88</a>
  <a href="https://printquarters.com/about/team.php">idola77</a>
  <a href="https://printquarters.com/about/team.php">slot389</a>
  <a href="https://printquarters.com/about/team.php">sumo77</a>
  <a href="https://printquarters.com/about/team.php">totobet123</a>
  <a href="https://printquarters.com/about/team.php">barcatoto</a>
  <a href="https://printquarters.com/about/team.php">tokebetting</a>
  <a href="https://printquarters.com/about/team.php">gtr11</a>
  <a href="https://printquarters.com/about/team.php">magnet33</a>
  <a href="https://printquarters.com/about/team.php">shineslot</a>
  <a href="https://printquarters.com/about/team.php">MALAIKAT777</a>
  <a href="https://printquarters.com/about/team.php">sahabatdomino</a>
  <a href="https://printquarters.com/about/team.php">cmbet88</a>
  <a href="https://printquarters.com/about/team.php">dauntotoslot</a>
  <a href="https://printquarters.com/about/team.php">dewa911</a>
  <a href="https://printquarters.com/about/team.php">mpotowerslot</a>
  <a href="https://printquarters.com/about/team.php">ajaslot</a>
  <a href="https://printquarters.com/about/team.php">JP77</a>
  <a href="https://printquarters.com/about/team.php">raja55</a>
  <a href="https://printquarters.com/about/team.php">idbet</a>
  <a href="https://printquarters.com/about/team.php">merahbet</a>
  <a href="https://printquarters.com/about/team.php">togelsumoslot</a>
  <a href="https://printquarters.com/about/team.php">judi parlay</a>
  <a href="https://printquarters.com/about/team.php">klubvegasnet</a>
  <a href="https://printquarters.com/about/team.php">bolajalan442</a>
  <a href="https://printquarters.com/about/team.php">nomor777</a>
  <a href="https://printquarters.com/about/team.php">vin4d</a>
  <a href="https://printquarters.com/about/team.php">bet 68</a>
  <a href="https://printquarters.com/about/team.php">138 royal</a>
  <a href="https://printquarters.com/about/team.php">kitkat 77slot</a>
  <a href="https://printquarters.com/about/team.php">zienslot</a>
  <a href="https://printquarters.com/about/team.php">garena99</a>
  <a href="https://printquarters.com/about/team.php">win188</a>
  <a href="https://printquarters.com/about/team.php">paito kroasia</a>
  <a href="https://printquarters.com/about/team.php">kayatogel</a>
  <a href="https://printquarters.com/about/team.php">sukajp</a>
  <a href="https://printquarters.com/about/team.php">seputarbet</a>
  <a href="https://printquarters.com/about/team.php">vgslot</a>
  <a href="https://printquarters.com/about/team.php">panda123</a>
  <a href="https://printquarters.com/about/team.php">pasukan99</a>
  <a href="https://printquarters.com/about/team.php">online casino</a>
  <a href="https://printquarters.com/about/team.php">15kbet</a>
  <a href="https://printquarters.com/about/team.php">mataharislot</a>
  <a href="https://printquarters.com/about/team.php">dewabet id</a>
  <a href="https://printquarters.com/about/team.php">audi33</a>
  <a href="https://printquarters.com/about/team.php">SPIN888</a>
  <a href="https://printquarters.com/about/team.php">dewa mabukslot</a>
  <a href="https://printquarters.com/about/team.php">KODOKMAS99</a>
  <a href="https://printquarters.com/about/team.php">gila4d</a>
  <a href="https://printquarters.com/about/team.php">akun wsoslot</a>
  <a href="https://printquarters.com/about/team.php">cgptotoslot</a>
  <a href="https://printquarters.com/about/team.php">usaha777</a>
  <a href="https://printquarters.com/about/team.php">pkvqiuqiu</a>
  <a href="https://printquarters.com/about/team.php">memed4d</a>
  <a href="https://printquarters.com/about/team.php">donat betslot</a>
  <a href="https://printquarters.com/about/team.php">gacorcq9</a>
  <a href="https://printquarters.com/about/team.php">cinematogel</a>
  <a href="https://printquarters.com/about/team.php">squadslot</a>
  <a href="https://printquarters.com/about/team.php">phil168</a>
  <a href="https://printquarters.com/about/team.php">DBLTOTO</a>
  <a href="https://printquarters.com/about/team.php">jackpot slot</a>
  <a href="https://printquarters.com/about/team.php">untung99</a>
  <a href="https://printquarters.com/about/team.php">mptoto</a>
  <a href="https://printquarters.com/about/team.php">vivawin88</a>
  <a href="https://printquarters.com/about/team.php">kaya88slot</a>
  <a href="https://printquarters.com/about/team.php">DANASLOT</a>
  <a href="https://printquarters.com/about/team.php">mrjudi88</a>
  <a href="https://printquarters.com/about/team.php">PLAYBET88</a>
  <a href="https://printquarters.com/about/team.php">bandit77</a>
  <a href="https://printquarters.com/about/team.php">TOGELHOKI8</a>
  <a href="https://printquarters.com/about/team.php">manilabet365</a>
  <a href="https://printquarters.com/about/team.php">kopdartoto</a>
  <a href="https://printquarters.com/about/team.php">togelsingapore</a>
  <a href="https://printquarters.com/about/team.php">indospin99</a>
  <a href="https://printquarters.com/about/team.php">555mpo</a>
  <a href="https://printquarters.com/about/team.php">GAS88</a>
  <a href="https://printquarters.com/about/team.php">gassgp</a>
  <a href="https://printquarters.com/about/team.php">mpokikc</a>
  <a href="https://printquarters.com/about/team.php">main55</a>
  <a href="https://printquarters.com/about/team.php">tiktaktoto</a>
  <a href="https://printquarters.com/about/team.php">waktoge</a>
  <a href="https://printquarters.com/about/team.php">supra4d</a>
  <a href="https://printquarters.com/about/team.php">saktitoto</a>
  <a href="https://printquarters.com/about/team.php">cuanmpo</a>
  <a href="https://printquarters.com/about/team.php">virusjp</a>
  <a href="https://printquarters.com/about/team.php">rajabet77 vip</a>
  <a href="https://printquarters.com/about/team.php">BROMO777</a>
  <a href="https://printquarters.com/about/team.php">setor777</a>
  <a href="https://printquarters.com/about/team.php">hokieus88</a>
  <a href="https://printquarters.com/about/team.php">toto228</a>
  <a href="https://printquarters.com/about/team.php">WARGATOTO</a>
  <a href="https://printquarters.com/about/team.php">rumahbandar</a>
  <a href="https://printquarters.com/about/team.php">SYAIRHK</a>
  <a href="https://printquarters.com/about/team.php">venusmpo</a>
  <a href="https://printquarters.com/about/team.php">selotdemo</a>
  <a href="https://printquarters.com/about/team.php">ALADIN188</a>
  <a href="https://printquarters.com/about/team.php">mikitoto</a>
  <a href="https://printquarters.com/about/team.php">jokerwin123</a>
  <a href="https://printquarters.com/about/team.php">adipatislot</a>
  <a href="https://printquarters.com/about/team.php">roda168</a>
  <a href="https://printquarters.com/about/team.php">judionlen</a>
  <a href="https://printquarters.com/about/team.php">idrweone</a>
  <a href="https://printquarters.com/about/team.php">rajacua</a>
  <a href="https://printquarters.com/about/team.php">sedaptogel</a>
  <a href="https://printquarters.com/about/team.php">bigslotoslot</a>
  <a href="https://printquarters.com/about/team.php">jaya88</a>
  <a href="https://printquarters.com/about/team.php">pokeridn</a>
  <a href="https://printquarters.com/about/team.php">vegas567</a>
  <a href="https://printquarters.com/about/team.php">dewa legendslot</a>
  <a href="https://printquarters.com/about/team.php">hobislot188</a>
  <a href="https://printquarters.com/about/team.php">JITUBET11</a>
  <a href="https://printquarters.com/about/team.php">wargapoker</a>
  <a href="https://printquarters.com/about/team.php">jago88</a>
  <a href="https://printquarters.com/about/team.php">pajak4d</a>
  <a href="https://printquarters.com/about/team.php">KILAT333</a>
  <a href="https://printquarters.com/about/team.php">PGSLOT</a>
  <a href="https://printquarters.com/about/team.php">gacor300</a>
  <a href="https://printquarters.com/about/team.php">domino757</a>
  <a href="https://printquarters.com/about/team.php">timnas138</a>
  <a href="https://printquarters.com/about/team.php">zomm555</a>
  <a href="https://printquarters.com/about/team.php">KUPON4D</a>
  <a href="https://printquarters.com/about/team.php">bar178</a>
  <a href="https://printquarters.com/about/team.php">ebbet188</a>
  <a href="https://printquarters.com/about/team.php">anaktotonet</a>
  <a href="https://printquarters.com/about/team.php">playboy777</a>
  <a href="https://printquarters.com/about/team.php">tarotogel</a>
  <a href="https://printquarters.com/about/team.php">terminalbet</a>
  <a href="https://printquarters.com/about/team.php">happy4d</a>
  <a href="https://printquarters.com/about/team.php">SLOT33</a>
  <a href="https://printquarters.com/about/team.php">kopi4dslot</a>
  <a href="https://printquarters.com/about/team.php">tps4d</a>
  <a href="https://printquarters.com/about/team.php">KAISAR188</a>
  <a href="https://printquarters.com/about/team.php">vegas508</a>
  <a href="https://printquarters.com/about/team.php">demen303</a>
  <a href="https://printquarters.com/about/team.php">garasislot4d</a>
  <a href="https://printquarters.com/about/team.php">csbo88</a>
  <a href="https://printquarters.com/about/team.php">idnbetslot</a>
  <a href="https://printquarters.com/about/team.php">banteng123</a>
  <a href="https://printquarters.com/about/team.php">dukun138</a>
  <a href="https://printquarters.com/about/team.php">kemonbet</a>
  <a href="https://printquarters.com/about/team.php">slot888 pulsa</a>
  <a href="https://printquarters.com/about/team.php">qqvictory</a>
  <a href="https://printquarters.com/about/team.php">slot4d vip</a>
  <a href="https://printquarters.com/about/team.php">psgslot138</a>
  <a href="https://printquarters.com/about/team.php">cepat89</a>
  <a href="https://printquarters.com/about/team.php">palu88</a>
  <a href="https://printquarters.com/about/team.php">sinardewaslot</a>
  <a href="https://printquarters.com/about/team.php">qqslit</a>
  <a href="https://printquarters.com/about/team.php">klik212</a>
  <a href="https://printquarters.com/about/team.php">cerutu4d</a>
  <a href="https://printquarters.com/about/team.php">eventparlay</a>
  <a href="https://printquarters.com/about/team.php">kapasqq</a>
  <a href="https://printquarters.com/about/team.php">borneo 338slot</a>
  <a href="https://printquarters.com/about/team.php">klkififa</a>
  <a href="https://printquarters.com/about/team.php">kaptencasino</a>
  <a href="https://printquarters.com/about/team.php">MPXTOTO</a>
  <a href="https://printquarters.com/about/team.php">slotgacor77</a>
  <a href="https://printquarters.com/about/team.php">ANIMETOTO</a>
  <a href="https://printquarters.com/about/team.php">garuda303</a>
  <a href="https://printquarters.com/about/team.php">viralslot77</a>
  <a href="https://printquarters.com/about/team.php">surga55slot</a>
  <a href="https://printquarters.com/about/team.php">maha21</a>
  <a href="https://printquarters.com/about/team.php">ojol69</a>
  <a href="https://printquarters.com/about/team.php">cintatogel88</a>
  <a href="https://printquarters.com/about/team.php">kawasan4d</a>
  <a href="https://printquarters.com/about/team.php">oriental gaming</a>
  <a href="https://printquarters.com/about/team.php">eshatoto</a>
  <a href="https://printquarters.com/about/team.php">betmen</a>
  <a href="https://printquarters.com/about/team.php">mayatogel</a>
  <a href="https://printquarters.com/about/team.php">civictoto</a>
  <a href="https://printquarters.com/about/team.php">qqslebew</a>
  <a href="https://printquarters.com/about/team.php">rasigaming88</a>
  <a href="https://printquarters.com/about/team.php">PUSAT77</a>
  <a href="https://printquarters.com/about/team.php">scatter 1000x</a>
  <a href="https://printquarters.com/about/team.php">doku633</a>
  <a href="https://printquarters.com/about/team.php">123bolaslot</a>
  <a href="https://printquarters.com/about/team.php">mi77</a>
  <a href="https://printquarters.com/about/team.php">lagu gilaslot</a>
  <a href="https://printquarters.com/about/team.php">klikdewaslot</a>
  <a href="https://printquarters.com/about/team.php">link999</a>
  <a href="https://printquarters.com/about/team.php">kedai69slot</a>
  <a href="https://printquarters.com/about/team.php">bom 88</a>
  <a href="https://printquarters.com/about/team.php">depo25 25</a>
  <a href="https://printquarters.com/about/team.php">keluaran florida</a>
  <a href="https://printquarters.com/about/team.php">kawalbet</a>
  <a href="https://printquarters.com/about/team.php">bola situs</a>
  <a href="https://printquarters.com/about/team.php">ratu203</a>
  <a href="https://printquarters.com/about/team.php">udintogel88</a>
  <a href="https://printquarters.com/about/team.php">playnow168</a>
  <a href="https://printquarters.com/about/team.php">ingat303</a>
  <a href="https://printquarters.com/about/team.php">familytoto</a>
  <a href="https://printquarters.com/about/team.php">mimpi99</a>
  <a href="https://printquarters.com/about/team.php">nagacash</a>
  <a href="https://printquarters.com/about/team.php">marwah4d</a>
  <a href="https://printquarters.com/about/team.php">gacor444</a>
  <a href="https://printquarters.com/about/team.php">gacormaxwin002</a>
  <a href="https://printquarters.com/about/team.php">IBET88</a>
  <a href="https://printquarters.com/about/team.php">bacan4d</a>
  <a href="https://printquarters.com/about/team.php">wingsbet88</a>
  <a href="https://printquarters.com/about/team.php">dewa dominoslot</a>
  <a href="https://printquarters.com/about/team.php">aoncash</a>
  <a href="https://printquarters.com/about/team.php">slotbanget</a>
  <a href="https://printquarters.com/about/team.php">sloto389</a>
  <a href="https://printquarters.com/about/team.php">hbcslot</a>
  <a href="https://printquarters.com/about/team.php">dragon78</a>
  <a href="https://printquarters.com/about/team.php">mamabet88</a>
  <a href="https://printquarters.com/about/team.php">warunghoki88</a>
  <a href="https://printquarters.com/about/team.php">slot majong</a>
  <a href="https://printquarters.com/about/team.php">papa sultanslot</a>
  <a href="https://printquarters.com/about/team.php">ovodewaslot</a>
  <a href="https://printquarters.com/about/team.php">jos178</a>
  <a href="https://printquarters.com/about/team.php">javaslot889</a>
  <a href="https://printquarters.com/about/team.php">gacor777 dana</a>
  <a href="https://printquarters.com/about/team.php">rajabet123 vip</a>
  <a href="https://printquarters.com/about/team.php">xrp77</a>
  <a href="https://printquarters.com/about/team.php">modalspin</a>
  <a href="https://printquarters.com/about/team.php">MIXTOGEL</a>
  <a href="https://printquarters.com/about/team.php">gemini4d</a>
  <a href="https://printquarters.com/about/team.php">sultan sawer</a>
  <a href="https://printquarters.com/about/team.php">MAIN303</a>
</div>
</body>
</html>